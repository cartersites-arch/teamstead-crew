const CACHE='teamstead-public-v4';
const STATIC=['/offline.html','/try/style.css','/icons/icon-192.png','/icons/teamstead-software-icon.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(STATIC)));self.skipWaiting();});
self.addEventListener('activate',event=>{event.waitUntil(Promise.all([self.clients.claim(),caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key))))]));});
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url);
  if(event.request.method!=='GET'||url.origin!==self.location.origin||url.search)return;
  if(event.request.mode==='navigate'&&['/','/try/','/try/demo/','/install/','/pricing/','/parts/'].includes(url.pathname)){
    event.respondWith(fetch(event.request,{cache:'no-store'}).catch(()=>caches.match('/offline.html')));
    return;
  }
  if(STATIC.includes(url.pathname))event.respondWith(fetch(event.request).catch(()=>caches.match(event.request)));
});
