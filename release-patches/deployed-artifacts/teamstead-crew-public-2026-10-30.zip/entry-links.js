(()=>{if(new URLSearchParams(location.hash.slice(1)).has('access'))location.replace('https://teamstead-crew.pages.dev/'+location.search+location.hash);})();
