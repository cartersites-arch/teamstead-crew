import {readdir,readFile,stat} from 'node:fs/promises';
import {join,dirname,resolve} from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const walk=async dir=>(await Promise.all((await readdir(dir,{withFileTypes:true})).map(async entry=>entry.isDirectory()?walk(join(dir,entry.name)):[join(dir,entry.name)]))).flat();
const files=await walk(root);
const html=files.filter(file=>file.endsWith('.html'));
const allText=(await Promise.all(files.filter(file=>/\.(?:html|js|css|xml|txt|webmanifest)$/.test(file)).map(file=>readFile(file,'utf8')))).join('\n');

for(const legacy of ['Relay Grove','Project Room','ONE WORKSPACE, TWO CONNECTED TOOLS','Chat + Hub','Crew & Maintenance'])assert.equal(allText.includes(legacy),false,`legacy copy remains: ${legacy}`);
for(const required of ['Crew Chat','Maintenance Hub','Parts Finder'])assert.match(allText,new RegExp(required),`missing ${required}`);
assert.match(await readFile(join(root,'try','demo','index.html'),'utf8'),/data-view="parts"/);
assert.match(await readFile(join(root,'try','demo','demo.js'),'utf8'),/shopping list/);
const partsPage=await readFile(join(root,'parts','index.html'),'utf8');
assert.match(partsPage,/Internet prices/);
assert.match(partsPage,/PARTS FINDER · AVAILABLE NOW/);
assert.doesNotMatch(allText,/PRELAUNCH|COMING SOON|products are not live/i);

assert.equal(allText.includes('teamstead-software.polsia.io'),false,'Cloudflare site must not route customers to Polsia');
assert.equal(allText.includes('project-room-ekn.pages.dev/signup'),false,'legacy project-room signup destination remains');
assert.equal(/https:\/\/teamstead-software\.polsia\.io\/signup\?plan=/.test(allText),false,'outdated Polsia signup link remains');
const pricingPage=await readFile(join(root,'pricing','index.html'),'utf8');
for(const plan of ['Chat only','Maintenance only','Parts Finder only','Chat + Maintenance','Chat + Parts','Maintenance + Parts','Complete suite'])assert.ok(pricingPage.includes(plan),`missing plan: ${plan}`);
for(const price of ['$15','$29','$19','$39','$59','$79'])assert.ok(pricingPage.includes(price),`missing price: ${price}`);
assert.match(pricingPage,/\/checkout\/\?plan=complete/);
assert.match(pricingPage,/does not start a trial or charge your card/);
assert.match(pricingPage,/one company location and up to 10 active members/i);
const checkoutPage=await readFile(join(root,'checkout','index.html'),'utf8');
assert.match(checkoutPage,/class="theme-page checkout-page"/);
assert.match(checkoutPage,/https:\/\/teamstead-crew.pages.dev\/signup\/\?plan=complete/);
assert.match(checkoutPage,/payment method is collected by Stripe/i);
assert.match(checkoutPage,/review the final amount on Stripe/i);
assert.match(checkoutPage,/Up to 10 active members/);
const notFoundPage=await readFile(join(root,'404.html'),'utf8');
assert.match(notFoundPage,/PAGE NOT FOUND/);
const headers=await readFile(join(root,'_headers'),'utf8');
assert.match(headers,/Strict-Transport-Security/);
assert.match(headers,/Content-Security-Policy/);

for(const file of html){
  const source=await readFile(file,'utf8');
  for(const match of source.matchAll(/(?:href|src)="(\/[^"]+)"/g)){
    const raw=match[1].split(/[?#]/)[0];
    if(!raw||raw==='/'||raw.startsWith('/signup/')||raw.startsWith('/api/'))continue;
    const target=raw.endsWith('/')?join(root,raw,'index.html'):join(root,raw);
    await stat(target).catch(()=>{throw new Error(`Missing local asset ${raw} referenced by ${file}`);});
  }
}

for(const name of ['teamstead-software-icon.png','teamstead-software-logo.png','icon-192.png','icon-512.png','apple-touch-icon.png','social.png']){
  const size=(await stat(join(root,'icons',name))).size;
  assert.ok(size<512000,`${name} exceeds 512 KB (${size} bytes)`);
}

console.log(`Verified ${html.length} HTML pages, three product previews, seven Cloudflare checkout plans, local links, and image limits.`);
