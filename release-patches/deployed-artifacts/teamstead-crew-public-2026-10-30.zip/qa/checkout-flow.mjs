import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

const source=await readFile(new URL('../checkout/checkout.js',import.meta.url),'utf8');
const prices={chat:15,hub:29,parts:19,combined:39,chat_parts:39,hub_parts:59,complete:79};
function run(query){
  const elements=Object.fromEntries(['summary-name','summary-description','summary-price','summary-renewal','continue-checkout'].map(id=>[id,{}]));
  const radios=Object.keys(prices).map(value=>({value,checked:false,addEventListener(event,handler){this.onChange=handler;}}));
  const updates=[];
  vm.runInNewContext(source,{URL,URLSearchParams,document:{querySelectorAll:()=>radios,getElementById:id=>elements[id]},location:{href:'https://crew-maintenance.pages.dev/checkout/'+query,search:query},history:{replaceState:(a,b,path)=>updates.push(path)}});
  return {elements,radios,updates};
}
for(const [plan,price] of Object.entries(prices)){
  const result=run('?plan='+plan+'&price=0&redirect=https://example.invalid');
  assert.equal(result.elements['summary-price'].textContent,'$'+price);
  assert.equal(result.elements['continue-checkout'].href,'https://teamstead-crew.pages.dev/signup/?plan='+plan);
  assert.equal(result.radios.filter(r=>r.checked).length,1);
  assert.equal(result.radios.find(r=>r.checked).value,plan);
  assert.match(result.elements['summary-renewal'].textContent,new RegExp('\\$'+price+' USD'));
  assert.equal(result.updates.at(-1),'/checkout/?plan='+plan);
  result.radios.find(r=>r.value==='chat').onChange();
  assert.equal(result.elements['summary-price'].textContent,'$15');
  assert.equal(result.elements['continue-checkout'].href,'https://teamstead-crew.pages.dev/signup/?plan=chat');
}
for(const query of ['', '?plan=__proto__','?plan=constructor','?plan=https://example.invalid','?plan=%3Cscript%3E']){
  const result=run(query);
  assert.equal(result.elements['summary-price'].textContent,'$79');
  assert.equal(result.elements['continue-checkout'].href,'https://teamstead-crew.pages.dev/signup/?plan=complete');
}
console.log('Checkout flow passed: seven plans, plan changes, immutable handoff origin, price tampering, invalid/prototype inputs and query cleanup.');
