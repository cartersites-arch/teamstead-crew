(()=>{
  let stage=0;
  const stages=[
    ['Reported','Assign to Alex','The reported problem is ready for assignment.'],
    ['Assigned','Start sample repair','Alex has been assigned to check the light.'],
    ['In progress','Mark sample repair complete','Alex is checking connections and recording the repair.'],
    ['Awaiting manager review','Approve sample completion','Repair recorded: replaced a sample connector and checked the light.'],
    ['Completed','Workflow complete','Sam reviewed the sample repair. It is now part of the equipment history.']
  ];
  const views=['chat','hub','parts'];
  const showView=view=>{
    views.forEach(name=>document.getElementById(name+'-view').hidden=name!==view);
    document.querySelectorAll('[data-view]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.view===view)));
    if(location.hash!==`#${view}`)history.replaceState(null,'',`#${view}`);
  };
  document.querySelectorAll('[data-view]').forEach(button=>button.addEventListener('click',()=>showView(button.dataset.view)));
  function render(){
    const data=stages[stage];
    document.getElementById('job-status').textContent=data[0];
    document.getElementById('advance-job').textContent=data[1];
    document.getElementById('advance-job').disabled=stage===4;
    document.getElementById('job-note').textContent=data[2];
  }
  document.getElementById('advance-job').addEventListener('click',()=>{if(stage<4)stage++;render();});
  document.getElementById('sample-chat-form').addEventListener('submit',event=>{
    event.preventDefault();
    const input=document.getElementById('sample-message'),value=input.value.trim();
    if(!value)return;
    const row=document.createElement('div');row.className='message';
    const avatar=document.createElement('div');avatar.className='avatar';avatar.textContent='YOU';
    const content=document.createElement('div'),title=document.createElement('strong'),text=document.createElement('p');
    title.textContent='You · Sample visitor';text.textContent=value;content.append(title,text);row.append(avatar,content);
    document.getElementById('demo-messages').append(row);input.value='';row.scrollIntoView({block:'nearest'});
  });
  document.querySelectorAll('.save-sample').forEach(button=>button.addEventListener('click',()=>{
    document.querySelectorAll('.save-sample').forEach(item=>{item.textContent='Save to shopping list';item.disabled=false;});
    button.textContent='Saved';button.disabled=true;
    document.getElementById('shopping-note').textContent='Sample price saved to the company shopping list.';
  }));
  document.getElementById('reset-demo').addEventListener('click',()=>location.reload());
  const initial=views.includes(location.hash.slice(1))?location.hash.slice(1):'chat';
  showView(initial);
})();
