var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// lib/request-context.ts
import { AsyncLocalStorage } from "node:async_hooks";
function withRequest(request2, callback) {
  return requests.run(request2, callback);
}
async function headers() {
  const request2 = requests.getStore();
  if (!request2) throw new Error("A request context is required.");
  return request2.headers;
}
function request() {
  return requests.getStore();
}
var requests;
var init_request_context = __esm({
  "lib/request-context.ts"() {
    "use strict";
    requests = new AsyncLocalStorage();
  }
});

// lib/app-errors.ts
function fail(status, message) {
  throw new ChatError(status, message);
}
var ChatError;
var init_app_errors = __esm({
  "lib/app-errors.ts"() {
    "use strict";
    ChatError = class extends Error {
      constructor(status, message) {
        super(message);
        this.status = status;
      }
    };
  }
});

// lib/company-context.ts
function validCompany(id) {
  return typeof id === "string" && (/^(main|demo|pilot)$/.test(id) || /^c_[a-f0-9]{16}$/.test(id));
}
function companyId() {
  const r = request();
  if (!r) return "main";
  const u = new URL(r.url), q = u.searchParams.get("company"), h = r.headers.get("X-Company");
  if (q && h && q !== h) fail(400, "Company selection changed. Reopen your workspace.");
  const id = h || q || "main";
  if (!validCompany(id)) fail(404, "Company workspace not found.");
  return id;
}
function companyPath(value) {
  const id = companyId();
  if (id === "main") return value;
  const u = new URL(value, "https://teamstead-crew.pages.dev");
  u.searchParams.set("company", id);
  return u.pathname + u.search + u.hash;
}
var init_company_context = __esm({
  "lib/company-context.ts"() {
    "use strict";
    init_request_context();
    init_app_errors();
  }
});

// lib/r2-storage.ts
import { env } from "cloudflare:workers";
function companyObjectKey(key2) {
  const co = companyId(), prefix = "companies/" + co + "/";
  return co === "main" || key2.startsWith(prefix) ? key2 : prefix + key2;
}
async function digest(bytes) {
  return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)), (x) => x.toString(16).padStart(2, "0")).join("");
}
function r2Bucket(app) {
  return app === "chat" ? env.CHAT_PHOTOS : env.MAINTENANCE_PHOTOS;
}
async function operation(kind) {
  const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10), limit = kind === "read" ? 2e4 : 1e3;
  const result = await db().prepare("INSERT INTO r2_daily_operations(day,kind,count) VALUES(?,?,1) ON CONFLICT(day,kind) DO UPDATE SET count=count+1 WHERE count<? RETURNING count").bind(day, kind, limit).first();
  if (!result) fail(429, "Today\u2019s photo activity limit has been reached. Please try again tomorrow.");
}
async function r2Get(app, key2) {
  key2 = companyObjectKey(key2);
  const bucket2 = r2Bucket(app);
  if (!bucket2) fail(503, "Photo storage is not connected yet.");
  await operation("read");
  return bucket2.get(key2);
}
async function r2Put(app, key2, bytes, contentType) {
  key2 = companyObjectKey(key2);
  const bucket2 = r2Bucket(app);
  if (!bucket2) fail(503, "Photo storage is not connected yet.");
  const table = app === "maintenance" && key2.startsWith("manuals/") ? "r2_manual_objects" : "r2_objects";
  const sha = await digest(bytes);
  try {
    await db().prepare(`INSERT OR IGNORE INTO ${table}(app,object_key,size,sha256,created_at) VALUES(?,?,?,?,?)`).bind(app, key2, bytes.length, sha, Date.now()).run();
  } catch (e) {
    if (String(e).includes("R2_BUDGET_FULL")) fail(507, "Teamstead\u2019s shared 500 MB file space is full.");
    throw e;
  }
  const stored = await db().prepare(`SELECT size,sha256 FROM ${table} WHERE app=? AND object_key=?`).bind(app, key2).first();
  if (!stored || stored.size !== bytes.length || stored.sha256 !== sha) fail(409, "This photo key already belongs to another file.");
  await operation("write");
  const result = await bucket2.put(key2, bytes, { httpMetadata: { contentType }, customMetadata: { sha256: sha }, onlyIf: { etagDoesNotMatch: "*" } });
  if (!result) {
    const existing = await r2Get(app, key2);
    if (!existing || existing.customMetadata?.sha256 !== sha || existing.size !== bytes.length) fail(409, "Photo upload conflict.");
  }
}
async function r2Delete(app, key2) {
  key2 = companyObjectKey(key2);
  const bucket2 = r2Bucket(app);
  if (!bucket2) fail(503, "Photo storage is not connected yet.");
  await operation("write");
  await bucket2.delete(key2);
  const table = app === "maintenance" && key2.startsWith("manuals/") ? "r2_manual_objects" : "r2_objects";
  await db().prepare(`DELETE FROM ${table} WHERE app=? AND object_key=?`).bind(app, key2).run();
}
var R2_APP_LIMIT;
var init_r2_storage = __esm({
  "lib/r2-storage.ts"() {
    "use strict";
    init_company_context();
    init_chat_db();
    init_app_errors();
    R2_APP_LIMIT = 5e8;
  }
});

// lib/photo-storage.ts
import { env as env2 } from "cloudflare:workers";
function bytesFromDb(value) {
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (ArrayBuffer.isView(value)) return new Uint8Array(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
  if (Array.isArray(value)) return Uint8Array.from(value);
  throw new Error("Photo data is unavailable.");
}
async function photoStorageUsage() {
  const row = await db().prepare("SELECT used_bytes,limit_bytes FROM photo_budget WHERE id = 1").first();
  if (!row) throw new Error("Photo storage is not configured.");
  const r2 = env2.CHAT_PHOTOS ? await db().prepare("SELECT COALESCE(SUM(size),0) AS used FROM r2_objects WHERE app='chat' AND object_key LIKE ?").bind(companyId() === "main" ? "%" : "companies/" + companyId() + "/%").first() : null;
  return { usedBytes: row.used_bytes + (r2?.used || 0), limitBytes: env2.CHAT_PHOTOS ? R2_APP_LIMIT : row.limit_bytes, maxPhotoBytes: MAX_PHOTO_BYTES };
}
var MAX_PHOTO_BYTES, PHOTO_BUDGET_BYTES, photoStore;
var init_photo_storage = __esm({
  "lib/photo-storage.ts"() {
    "use strict";
    init_company_context();
    init_r2_storage();
    init_chat_db();
    init_app_errors();
    MAX_PHOTO_BYTES = 512 * 1024;
    PHOTO_BUDGET_BYTES = 64 * 1024 * 1024;
    photoStore = {
      async put(key2, bytes, _options) {
        if (!bytes.byteLength || bytes.byteLength > MAX_PHOTO_BYTES) {
          fail(413, "This file is too large for the free pilot. Photos can be resized; PDFs must fit 512 KB.");
        }
        if (env2.CHAT_PHOTOS) {
          await r2Put("chat", key2, new Uint8Array(bytes), _options?.httpMetadata?.contentType || "application/octet-stream");
          return;
        }
        try {
          await db().prepare("INSERT INTO photo_objects (object_key,size,body,created_at) VALUES (?,?,?,?)").bind(key2, bytes.byteLength, new Uint8Array(bytes).buffer, Date.now()).run();
        } catch (error) {
          if (String(error).includes("PHOTO_BUDGET_FULL")) {
            fail(507, "The shared 64 MB file space is full. Remove unneeded file messages and finish any pending photo deletions in Security. Text chat is still available.");
          }
          throw error;
        }
      },
      async get(key2) {
        if (env2.CHAT_PHOTOS) {
          const alias = await db().prepare("SELECT object_key FROM r2_aliases WHERE legacy_key=?").bind(companyObjectKey(key2)).first();
          const object = await r2Get("chat", alias?.object_key || key2);
          if (object) return { body: new Uint8Array(await object.arrayBuffer()), size: object.size };
        }
        const row = await db().prepare("SELECT size,body FROM photo_objects WHERE object_key = ?").bind(key2).first();
        if (!row) return null;
        const body = bytesFromDb(row.body);
        if (body.byteLength !== row.size || body.byteLength > MAX_PHOTO_BYTES) throw new Error("Photo data is incomplete.");
        return { body, size: row.size };
      },
      async delete(key2) {
        const alias = await db().prepare("SELECT object_key FROM r2_aliases WHERE legacy_key=?").bind(companyObjectKey(key2)).first();
        const r2Key = alias?.object_key || key2;
        const object = await db().prepare("SELECT size FROM r2_objects WHERE app=? AND object_key=?").bind("chat", companyObjectKey(r2Key)).first();
        if (object) await r2Delete("chat", r2Key);
        await db().prepare("DELETE FROM r2_aliases WHERE legacy_key=?").bind(companyObjectKey(key2)).run();
        await db().prepare("DELETE FROM photo_objects WHERE object_key = ?").bind(key2).run();
      }
    };
  }
});

// lib/company-sql.ts
function companySql(sql, company) {
  if (company === "main") return sql;
  if (!validCompany(company)) throw Error("Unknown company");
  return sql.replace(/'(?:''|[^'])*'|--[^\n]*|\/\*[\s\S]*?\*\/|`[^`]*`|"[^"]*"|[A-Za-z_][A-Za-z_0-9]*/g, (token) => {
    if (token.startsWith("'") || token.startsWith("--") || token.startsWith("/*")) return token;
    const quoted = token[0] === "`" || token[0] === '"', name = quoted ? token.slice(1, -1) : token;
    if (!companyTables.has(name)) return token;
    return quoted ? token[0] + company + "_" + name + token[0] : company + "_" + name;
  });
}
var companyTables;
var init_company_sql = __esm({
  "lib/company-sql.ts"() {
    "use strict";
    init_company_context();
    companyTables = /* @__PURE__ */ new Set(["attachments", "invitations", "messages", "people", "reactions", "room_members", "rooms", "workspace", "maintenance_links", "file_deletions", "passkey_challenges", "passkeys", "security_events", "access_tokens", "sessions", "photo_budget", "photo_objects", "bot_preferences", "bot_events", "push_devices", "chat_notification_preferences", "chat_push_receipts", "employee_status", "conversation_preferences", "saved_messages", "crew_profiles"]);
  }
});

// lib/chat-db.ts
import { env as env3 } from "cloudflare:workers";
function rawDb() {
  if (!env3.DB) throw Error("Database unavailable");
  return env3.DB;
}
function db() {
  const database = rawDb(), id = companyId();
  if (id === "main") return database;
  return { prepare: (sql) => database.prepare(companySql(sql, id)), batch: (statements) => database.batch(statements), exec: () => {
    throw Error("Workspace SQL execution denied");
  }, dump: () => {
    throw Error("Workspace export denied");
  }, withSession: () => {
    throw Error("Workspace session unavailable");
  } };
}
function bucket() {
  return photoStore;
}
var init_chat_db = __esm({
  "lib/chat-db.ts"() {
    "use strict";
    init_photo_storage();
    init_company_context();
    init_company_sql();
  }
});

// lib/security-events.ts
function auditStatement(actorId, action, targetId = null) {
  return db().prepare("INSERT INTO security_events (id,actor_id,target_id,action,at) VALUES (?,?,?,?,?)").bind(crypto.randomUUID(), actorId, targetId, action, Date.now());
}
function securityGate(person, action, targetId = null, guard2) {
  const id = crypto.randomUUID(), now = Date.now();
  const memberTarget = person.role === "admin" && action === "account_access_reset";
  const targetGuard = (guard2 ? " AND (" + guard2.sql + ")" : "") + (memberTarget ? " AND EXISTS (SELECT 1 FROM people target WHERE target.id=? AND target.active=1 AND target.role='member')" : "");
  return { id, condition: "EXISTS (SELECT 1 FROM security_events WHERE id = '" + id + "')", statement: db().prepare("INSERT INTO security_events (id,actor_id,target_id,action,at) SELECT ?,p.id,?,?,? FROM sessions s JOIN people p ON p.id = s.user_id WHERE s.session_hash = ? AND s.user_id = ? AND s.auth_level = ? AND s.expires_at > ? AND s.verified_at >= ? AND p.active = 1 AND p.auth_version = s.auth_version AND p.auth_version = ? AND p.role = ?" + targetGuard).bind(id, targetId, action, now, person.session_hash, person.id, "passkey", now, now - 5 * 60 * 1e3, person.auth_version, person.role, ...guard2?.values || [], ...memberTarget ? [targetId] : []) };
}
var init_security_events = __esm({
  "lib/security-events.ts"() {
    "use strict";
    init_chat_db();
  }
});

// lib/access.ts
import { env as env4 } from "cloudflare:workers";
function newToken() {
  return toBase64url(crypto.getRandomValues(new Uint8Array(32)));
}
function toBase64url(bytes) {
  return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}
function fromBase64url(value) {
  return Uint8Array.from(atob(value.replaceAll("-", "+").replaceAll("_", "/")), (c) => c.charCodeAt(0));
}
async function tokenHash(value) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(bytes), (b) => b.toString(16).padStart(2, "0")).join("");
}
function constantEquals(a, b) {
  if (a.length !== 64 || b.length !== 64) return false;
  let n = 0;
  for (let i = 0; i < 64; i++) n |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return n === 0;
}
async function cookieValue(name) {
  const value = (await headers()).get("cookie") || "";
  return value.split(";").map((s) => s.trim()).find((s) => s.startsWith(name + "="))?.slice(name.length + 1) || "";
}
function sessionCookie(value, clear = false, maxAge = SESSION_AGE) {
  return (companyId() === "main" ? SESSION_COOKIE : SESSION_COOKIE + "_" + companyId()) + "=" + value + "; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=" + (clear ? 0 : maxAge);
}
function deviceLabel(agent) {
  if (/iPad/i.test(agent)) return "iPad";
  if (/iPhone/i.test(agent)) return "iPhone";
  if (/Android/i.test(agent)) return "Android";
  if (/Windows/i.test(agent)) return "Windows browser";
  if (/Macintosh|Mac OS/i.test(agent)) return "Mac browser";
  if (/Linux/i.test(agent)) return "Linux browser";
  return "Browser";
}
async function currentSession(allowSetup = false) {
  const token = await cookieValue(companyId() === "main" ? SESSION_COOKIE : SESSION_COOKIE + "_" + companyId());
  if (!/^[A-Za-z0-9_-]{43}$/.test(token)) fail(401, "Sign in with your passkey to open Teamstead Crew.");
  const person = await db().prepare("SELECT " + personFields + ",p.auth_version,p.passkey_enrolled,p.webauthn_user_id,s.session_hash,s.id AS session_id,s.auth_level,s.setup_token_hash,s.verified_at,s.last_seen_at FROM sessions s JOIN people p ON p.id = s.user_id WHERE s.session_hash = ? AND s.expires_at > ? AND s.auth_version = p.auth_version AND p.active = 1").bind(await tokenHash(token), Date.now()).first();
  if (!person || !["setup", "passkey"].includes(person.auth_level)) fail(401, "Sign in with your passkey to continue.");
  const expected = (await headers()).get("X-Project-User");
  if (expected && expected !== person.id) fail(401, "Your account changed on this device. Open Teamstead Crew again.");
  if (person.auth_level !== "passkey") {
    if (!allowSetup) fail(401, "Finish setting up your passkey to open Teamstead Crew.");
    const grant = await db().prepare("SELECT purpose FROM access_tokens WHERE token_hash = ? AND user_id = ? AND used_at = 0 AND expires_at > ?").bind(person.setup_token_hash, person.id, Date.now()).first();
    if (!grant || person.passkey_enrolled && grant.purpose !== "recovery") fail(401, "This setup link has been used or has expired. Sign in with your passkey.");
  }
  if (person.auth_level === "passkey" && person.last_seen_at < Date.now() - 3e5) await db().prepare("UPDATE sessions SET last_seen_at = ? WHERE session_hash = ?").bind(Date.now(), person.session_hash).run();
  return person;
}
async function currentPerson() {
  const p = await currentSession();
  return { id: p.id, email: p.email, name: p.name, role: p.role, active: p.active, joined_at: p.joined_at };
}
async function requireRecent() {
  const person = await currentSession();
  if (person.verified_at < Date.now() - RECENT_AGE) fail(428, "Confirm your passkey to make this security change.");
  return person;
}
function bootstrapValid(hash) {
  const expected = env4.BOOTSTRAP_ACCESS_HASH || process.env.BOOTSTRAP_ACCESS_HASH || "", expires = Number(env4.BOOTSTRAP_ACCESS_EXPIRES_AT || process.env.BOOTSTRAP_ACCESS_EXPIRES_AT || 0);
  return constantEquals(hash, expected) && expires > Date.now();
}
async function bootstrap(hash) {
  if (companyId() !== "main") return;
  const existing = await db().prepare("SELECT owner_id,access_bootstrapped FROM workspace WHERE id = ?").bind("main").first();
  if (existing?.access_bootstrapped || !bootstrapValid(hash)) return;
  const now = Date.now(), id = existing?.owner_id || "owner";
  await db().batch([
    db().prepare("INSERT OR IGNORE INTO workspace (id,name,owner_id,created_at) VALUES (?,?,?,?)").bind("main", "Teamstead Crew", id, now),
    db().prepare("INSERT OR IGNORE INTO people (id,email,name,role,active,joined_at,auth_version) VALUES (?,?,?, ?,1,0,1)").bind(id, "", "Jerry", "owner"),
    db().prepare("INSERT OR IGNORE INTO access_tokens (token_hash,user_id,created_at,expires_at,purpose) SELECT ?,owner_id,?,?,? FROM workspace WHERE id = ? AND access_bootstrapped = 0 AND NOT EXISTS (SELECT 1 FROM access_tokens WHERE user_id = workspace.owner_id)").bind(hash, now, now + INVITE_AGE, "invite", "main"),
    db().prepare("UPDATE workspace SET access_bootstrapped = 1 WHERE id = ? AND EXISTS (SELECT 1 FROM access_tokens WHERE user_id = workspace.owner_id)").bind("main"),
    ...[["general", "The everyday conversation. Updates, questions, and quick hellos."], ["projects", "Keep the work moving. Share progress, questions, and the next step."], ["ideas", "A little room for the next big thing."]].flatMap(([name, description]) => [
      db().prepare("INSERT OR IGNORE INTO rooms (id,name,description,kind,visibility,created_by,created_at) VALUES (?,?,?,?,?,?,?)").bind("room-" + name, name, description, "channel", "private", id, now),
      db().prepare("INSERT OR IGNORE INTO room_members (room_id,user_id,read_at) VALUES (?,?,0)").bind("room-" + name, id)
    ])
  ]);
}
async function inspectPersonalLink(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(value)) fail(401, "That personal link is incomplete or invalid.");
  const hash = await tokenHash(value);
  const person = await db().prepare("SELECT p.id,p.name,p.passkey_enrolled,t.used_at,t.expires_at,t.purpose FROM access_tokens t JOIN people p ON p.id = t.user_id WHERE t.token_hash = ? AND p.active = 1").bind(hash).first();
  if (person) {
    if (person.used_at || person.passkey_enrolled && person.purpose !== "recovery") return { id: person.id, name: person.name, mode: "passkey" };
    if (person.expires_at <= Date.now()) fail(401, "That setup link expired. Ask the workspace owner for a replacement.");
    return { id: person.id, name: person.name, mode: "enroll" };
  }
  if (bootstrapValid(hash)) {
    const workspace = await db().prepare("SELECT owner_id,access_bootstrapped FROM workspace WHERE id = ?").bind("main").first();
    if (!workspace) return { id: "owner", name: "Jerry", mode: "enroll" };
    if (!workspace.access_bootstrapped) {
      const owner3 = await db().prepare("SELECT id,name FROM people WHERE id = ? AND active = 1").bind(workspace.owner_id).first();
      if (owner3) return { ...owner3, mode: "enroll" };
    }
  }
  fail(401, "That link is inactive. Use your passkey, or ask the workspace owner for help.");
}
async function exchangePersonalLink(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(value)) fail(401, "Use the full personal setup link you were given.");
  const hash = await tokenHash(value);
  await bootstrap(hash);
  const actor = await db().prepare("SELECT p.id,p.auth_version FROM access_tokens t JOIN people p ON p.id = t.user_id WHERE t.token_hash = ? AND t.used_at = 0 AND t.expires_at > ? AND p.active = 1 AND (p.passkey_enrolled = 0 OR t.purpose = ?)").bind(hash, Date.now(), "recovery").first();
  if (!actor) fail(401, "Use your passkey. This link cannot sign you in on its own.");
  const session = newToken(), now = Date.now();
  const created = await db().prepare("INSERT INTO sessions (session_hash,user_id,auth_version,expires_at,id,auth_level,setup_token_hash,created_at,device_label) SELECT ?,p.id,p.auth_version,?,?,?,t.token_hash,?,? FROM access_tokens t JOIN people p ON p.id = t.user_id WHERE t.token_hash = ? AND t.used_at = 0 AND t.expires_at > ? AND p.id = ? AND p.active = 1 AND p.auth_version = ? AND (p.passkey_enrolled = 0 OR t.purpose = ?)").bind(await tokenHash(session), now + SETUP_AGE * 1e3, crypto.randomUUID(), "setup", now, deviceLabel((await headers()).get("user-agent") || ""), hash, now, actor.id, actor.auth_version, "recovery").run();
  if (!created.meta.changes) fail(401, "That setup link changed. Ask for the latest link.");
  return { cookie: sessionCookie(session, false, SETUP_AGE), userId: actor.id };
}
async function signOut() {
  const token = await cookieValue(companyId() === "main" ? SESSION_COOKIE : SESSION_COOKIE + "_" + companyId());
  if (token) {
    const hash = await tokenHash(token), row = await db().prepare("SELECT user_id FROM sessions WHERE session_hash = ?").bind(hash).first();
    const expected = (await headers()).get("X-Project-User");
    if (row && expected && row.user_id !== expected) fail(401, "Your account changed on this device. Open Teamstead Crew again.");
    if (row) await db().batch([db().prepare("DELETE FROM sessions WHERE session_hash = ?").bind(hash), auditStatement(row.user_id, "signed_out", row.user_id)]);
  }
  return sessionCookie("", true);
}
async function resetPersonalLink(userId, actor) {
  const actorId = actor.id;
  if (userId === actorId) fail(400, "Add a backup passkey in Security before removing an old one. You cannot reset your own account from People.");
  const target = await db().prepare("SELECT passkey_enrolled FROM people WHERE id = ? AND active = 1").bind(userId).first();
  if (!target) fail(404, "This person is no longer in the workspace.");
  const token = newToken(), now = Date.now();
  const gate = securityGate(actor, "account_access_reset", userId);
  const results = await db().batch([
    gate.statement,
    db().prepare("UPDATE people SET auth_version = auth_version + 1 WHERE id = ? AND active = 1 AND " + gate.condition).bind(userId),
    db().prepare("DELETE FROM sessions WHERE user_id = ? AND " + gate.condition).bind(userId),
    db().prepare("DELETE FROM passkeys WHERE user_id = ? AND " + gate.condition).bind(userId),
    db().prepare("DELETE FROM passkey_challenges WHERE user_id = ? AND " + gate.condition).bind(userId),
    db().prepare("DELETE FROM access_tokens WHERE user_id = ? AND " + gate.condition).bind(userId),
    db().prepare("INSERT INTO access_tokens (token_hash,user_id,created_at,expires_at,purpose) SELECT ?,id,?,CASE WHEN passkey_enrolled = 1 THEN ? ELSE ? END,CASE WHEN passkey_enrolled = 1 THEN ? ELSE ? END FROM people WHERE id = ? AND active = 1 AND " + gate.condition).bind(await tokenHash(token), now, now + 24 * 60 * 60 * 1e3, now + INVITE_AGE, "recovery", "invite", userId)
  ]);
  if (!results[0].meta.changes) fail(401, "Your session changed. Sign in again before managing access.");
  const grant = await db().prepare("SELECT expires_at FROM access_tokens WHERE token_hash = ?").bind(await tokenHash(token)).first();
  if (!grant) fail(409, "The invitation changed again. Ask for the latest link.");
  return { token, expiresAt: grant.expires_at };
}
var SESSION_COOKIE, SESSION_AGE, SETUP_AGE, INVITE_AGE, RECENT_AGE, personFields;
var init_access = __esm({
  "lib/access.ts"() {
    "use strict";
    init_company_context();
    init_request_context();
    init_chat_db();
    init_app_errors();
    init_security_events();
    SESSION_COOKIE = "__Host-project_room_session";
    SESSION_AGE = 7 * 24 * 60 * 60;
    SETUP_AGE = 15 * 60;
    INVITE_AGE = 7 * 24 * 60 * 60 * 1e3;
    RECENT_AGE = 5 * 60 * 1e3;
    personFields = "p.id,p.email,p.name,p.role,p.active,p.joined_at";
  }
});

// lib/push-crypto-bridge.ts
var push_crypto_bridge_exports = {};
__export(push_crypto_bridge_exports, {
  createCipheriv: () => createCipheriv,
  createDecipheriv: () => createDecipheriv,
  createECDH: () => createECDH,
  createHmac: () => createHmac,
  randomBytes: () => randomBytes
});
import { createECDH, randomBytes, createHmac, createCipheriv, createDecipheriv } from "node:crypto";
var init_push_crypto_bridge = __esm({
  "lib/push-crypto-bridge.ts"() {
    "use strict";
  }
});

// node_modules/http_ece/ece.js
var require_ece = __commonJS({
  "node_modules/http_ece/ece.js"(exports, module) {
    "use strict";
    var crypto2 = (init_push_crypto_bridge(), __toCommonJS(push_crypto_bridge_exports));
    var AES_GCM = "aes-128-gcm";
    var PAD_SIZE = { "aes128gcm": 1, "aesgcm": 2 };
    var TAG_LENGTH = 16;
    var KEY_LENGTH = 16;
    var NONCE_LENGTH = 12;
    var SHA_256_LENGTH = 32;
    var MODE_ENCRYPT = "encrypt";
    var MODE_DECRYPT = "decrypt";
    var keylog;
    if (process.env.ECE_KEYLOG === "1") {
      keylog = function(m, k) {
        console.warn(m + " [" + k.length + "]: " + k.toString("base64url"));
        return k;
      };
    } else {
      keylog = function(m, k) {
        return k;
      };
    }
    function decode9(b) {
      if (typeof b === "string") {
        return Buffer.from(b, "base64url");
      }
      return b;
    }
    function HMAC_hash(key2, input) {
      var hmac = crypto2.createHmac("sha256", key2);
      hmac.update(input);
      return hmac.digest();
    }
    function HKDF_extract(salt, ikm) {
      keylog("salt", salt);
      keylog("ikm", ikm);
      return keylog("extract", HMAC_hash(salt, ikm));
    }
    function HKDF_expand(prk, info2, l) {
      keylog("prk", prk);
      keylog("info", info2);
      var output = Buffer.alloc(0);
      var T = Buffer.alloc(0);
      info2 = Buffer.from(info2, "ascii");
      var counter = 0;
      var cbuf = Buffer.alloc(1);
      while (output.length < l) {
        cbuf.writeUIntBE(++counter, 0, 1);
        T = HMAC_hash(prk, Buffer.concat([T, info2, cbuf]));
        output = Buffer.concat([output, T]);
      }
      return keylog("expand", output.slice(0, l));
    }
    function HKDF(salt, ikm, info2, len) {
      return HKDF_expand(HKDF_extract(salt, ikm), info2, len);
    }
    function info(base, context3) {
      var result = Buffer.concat([
        Buffer.from("Content-Encoding: " + base + "\0", "ascii"),
        context3
      ]);
      keylog("info " + base, result);
      return result;
    }
    function lengthPrefix(buffer) {
      var b = Buffer.concat([Buffer.alloc(2), buffer]);
      b.writeUIntBE(buffer.length, 0, 2);
      return b;
    }
    function extractDH(header, mode) {
      var key2 = header.privateKey;
      var senderPubKey, receiverPubKey;
      if (mode === MODE_ENCRYPT) {
        senderPubKey = key2.getPublicKey();
        receiverPubKey = header.dh;
      } else if (mode === MODE_DECRYPT) {
        senderPubKey = header.dh;
        receiverPubKey = key2.getPublicKey();
      } else {
        throw new Error("Unknown mode only " + MODE_ENCRYPT + " and " + MODE_DECRYPT + " supported");
      }
      return {
        secret: key2.computeSecret(header.dh),
        context: Buffer.concat([
          Buffer.from(header.keylabel, "ascii"),
          Buffer.from([0]),
          lengthPrefix(receiverPubKey),
          // user agent
          lengthPrefix(senderPubKey)
          // application server
        ])
      };
    }
    function extractSecretAndContext(header, mode) {
      var result = { secret: null, context: Buffer.alloc(0) };
      if (header.key) {
        result.secret = header.key;
        if (result.secret.length !== KEY_LENGTH) {
          throw new Error("An explicit key must be " + KEY_LENGTH + " bytes");
        }
      } else if (header.dh) {
        result = extractDH(header, mode);
      } else if (typeof header.keyid !== void 0) {
        result.secret = header.keymap[header.keyid];
      }
      if (!result.secret) {
        throw new Error("Unable to determine key");
      }
      keylog("secret", result.secret);
      keylog("context", result.context);
      if (header.authSecret) {
        result.secret = HKDF(
          header.authSecret,
          result.secret,
          info("auth", Buffer.alloc(0)),
          SHA_256_LENGTH
        );
        keylog("authsecret", result.secret);
      }
      return result;
    }
    function webpushSecret(header, mode) {
      if (!header.authSecret) {
        throw new Error("No authentication secret for webpush");
      }
      keylog("authsecret", header.authSecret);
      var remotePubKey, senderPubKey, receiverPubKey;
      if (mode === MODE_ENCRYPT) {
        senderPubKey = header.privateKey.getPublicKey();
        remotePubKey = receiverPubKey = header.dh;
      } else if (mode === MODE_DECRYPT) {
        remotePubKey = senderPubKey = header.keyid;
        receiverPubKey = header.privateKey.getPublicKey();
      } else {
        throw new Error("Unknown mode only " + MODE_ENCRYPT + " and " + MODE_DECRYPT + " supported");
      }
      keylog("remote pubkey", remotePubKey);
      keylog("sender pubkey", senderPubKey);
      keylog("receiver pubkey", receiverPubKey);
      return keylog(
        "secret dh",
        HKDF(
          header.authSecret,
          header.privateKey.computeSecret(remotePubKey),
          Buffer.concat([
            Buffer.from("WebPush: info\0"),
            receiverPubKey,
            senderPubKey
          ]),
          SHA_256_LENGTH
        )
      );
    }
    function extractSecret(header, mode, keyLookupCallback) {
      if (keyLookupCallback) {
        if (!isFunction(keyLookupCallback)) {
          throw new Error("Callback is not a function");
        }
      }
      if (header.key) {
        if (header.key.length !== KEY_LENGTH) {
          throw new Error("An explicit key must be " + KEY_LENGTH + " bytes");
        }
        return keylog("secret key", header.key);
      }
      if (!header.privateKey) {
        if (!keyLookupCallback) {
          var key2 = header.keymap && header.keymap[header.keyid];
        } else {
          var key2 = keyLookupCallback(header.keyid);
        }
        if (!key2) {
          throw new Error('No saved key (keyid: "' + header.keyid + '")');
        }
        return key2;
      }
      return webpushSecret(header, mode);
    }
    function deriveKeyAndNonce(header, mode, lookupKeyCallback) {
      if (!header.salt) {
        throw new Error("must include a salt parameter for " + header.version);
      }
      var keyInfo;
      var nonceInfo;
      var secret;
      if (header.version === "aesgcm") {
        var s = extractSecretAndContext(header, mode, lookupKeyCallback);
        keyInfo = info("aesgcm", s.context);
        nonceInfo = info("nonce", s.context);
        secret = s.secret;
      } else if (header.version === "aes128gcm") {
        keyInfo = Buffer.from("Content-Encoding: aes128gcm\0");
        nonceInfo = Buffer.from("Content-Encoding: nonce\0");
        secret = extractSecret(header, mode, lookupKeyCallback);
      } else {
        throw new Error("Unable to set context for mode " + header.version);
      }
      var prk = HKDF_extract(header.salt, secret);
      var result = {
        key: HKDF_expand(prk, keyInfo, KEY_LENGTH),
        nonce: HKDF_expand(prk, nonceInfo, NONCE_LENGTH)
      };
      keylog("key", result.key);
      keylog("nonce base", result.nonce);
      return result;
    }
    function parseParams(params) {
      var header = {};
      header.version = params.version || "aes128gcm";
      header.rs = parseInt(params.rs, 10);
      if (isNaN(header.rs)) {
        header.rs = 4096;
      }
      var overhead = PAD_SIZE[header.version];
      if (header.version === "aes128gcm") {
        overhead += TAG_LENGTH;
      }
      if (header.rs <= overhead) {
        throw new Error("The rs parameter has to be greater than " + overhead);
      }
      if (params.salt) {
        header.salt = decode9(params.salt);
        if (header.salt.length !== KEY_LENGTH) {
          throw new Error("The salt parameter must be " + KEY_LENGTH + " bytes");
        }
      }
      header.keyid = params.keyid;
      if (params.key) {
        header.key = decode9(params.key);
      } else {
        header.privateKey = params.privateKey;
        if (!header.privateKey) {
          header.keymap = params.keymap;
        }
        if (header.version !== "aes128gcm") {
          header.keylabel = params.keylabel || "P-256";
        }
        if (params.dh) {
          header.dh = decode9(params.dh);
        }
      }
      if (params.authSecret) {
        header.authSecret = decode9(params.authSecret);
      }
      return header;
    }
    function generateNonce(base, counter) {
      var nonce = Buffer.from(base);
      var m = nonce.readUIntBE(nonce.length - 6, 6);
      var x = ((m ^ counter) & 16777215) + ((m / 16777216 ^ counter / 16777216) & 16777215) * 16777216;
      nonce.writeUIntBE(x, nonce.length - 6, 6);
      keylog("nonce" + counter, nonce);
      return nonce;
    }
    function readHeader(buffer, header) {
      var idsz = buffer.readUIntBE(20, 1);
      header.salt = buffer.slice(0, KEY_LENGTH);
      header.rs = buffer.readUIntBE(KEY_LENGTH, 4);
      header.keyid = buffer.slice(21, 21 + idsz);
      return 21 + idsz;
    }
    function unpadLegacy(data, version) {
      var padSize = PAD_SIZE[version];
      var pad2 = data.readUIntBE(0, padSize);
      if (pad2 + padSize > data.length) {
        throw new Error("padding exceeds block size");
      }
      keylog("padding", data.slice(0, padSize + pad2));
      var padCheck = Buffer.alloc(pad2);
      padCheck.fill(0);
      if (padCheck.compare(data.slice(padSize, padSize + pad2)) !== 0) {
        throw new Error("invalid padding");
      }
      return data.slice(padSize + pad2);
    }
    function unpad(data, last) {
      var i = data.length - 1;
      while (i >= 0) {
        if (data[i]) {
          if (last) {
            if (data[i] !== 2) {
              throw new Error("last record needs to start padding with a 2");
            }
          } else {
            if (data[i] !== 1) {
              throw new Error("last record needs to start padding with a 2");
            }
          }
          return data.slice(0, i);
        }
        --i;
      }
      throw new Error("all zero plaintext");
    }
    function decryptRecord(key2, counter, buffer, header, last) {
      keylog("decrypt", buffer);
      var nonce = generateNonce(key2.nonce, counter);
      var gcm = crypto2.createDecipheriv(AES_GCM, key2.key, nonce);
      gcm.setAuthTag(buffer.slice(buffer.length - TAG_LENGTH));
      var data = gcm.update(buffer.slice(0, buffer.length - TAG_LENGTH));
      data = Buffer.concat([data, gcm.final()]);
      keylog("decrypted", data);
      if (header.version !== "aes128gcm") {
        return unpadLegacy(data, header.version);
      }
      return unpad(data, last);
    }
    function decrypt(buffer, params, keyLookupCallback) {
      var header = parseParams(params);
      if (header.version === "aes128gcm") {
        var headerLength = readHeader(buffer, header);
        buffer = buffer.slice(headerLength);
      }
      var key2 = deriveKeyAndNonce(header, MODE_DECRYPT, keyLookupCallback);
      var start = 0;
      var result = Buffer.alloc(0);
      var chunkSize = header.rs;
      if (header.version !== "aes128gcm") {
        chunkSize += TAG_LENGTH;
      }
      for (var i = 0; start < buffer.length; ++i) {
        var end = start + chunkSize;
        if (header.version !== "aes128gcm" && end === buffer.length) {
          throw new Error("Truncated payload");
        }
        end = Math.min(end, buffer.length);
        if (end - start <= TAG_LENGTH) {
          throw new Error("Invalid block: too small at " + i);
        }
        var block = decryptRecord(
          key2,
          i,
          buffer.slice(start, end),
          header,
          end >= buffer.length
        );
        result = Buffer.concat([result, block]);
        start = end;
      }
      return result;
    }
    function encryptRecord(key2, counter, buffer, pad2, header, last) {
      keylog("encrypt", buffer);
      pad2 = pad2 || 0;
      var nonce = generateNonce(key2.nonce, counter);
      var gcm = crypto2.createCipheriv(AES_GCM, key2.key, nonce);
      var ciphertext = [];
      var padSize = PAD_SIZE[header.version];
      var padding = Buffer.alloc(pad2 + padSize);
      padding.fill(0);
      if (header.version !== "aes128gcm") {
        padding.writeUIntBE(pad2, 0, padSize);
        keylog("padding", padding);
        ciphertext.push(gcm.update(padding));
        ciphertext.push(gcm.update(buffer));
        if (!last && padding.length + buffer.length < header.rs) {
          throw new Error("Unable to pad to record size");
        }
      } else {
        ciphertext.push(gcm.update(buffer));
        padding.writeUIntBE(last ? 2 : 1, 0, 1);
        keylog("padding", padding);
        ciphertext.push(gcm.update(padding));
      }
      gcm.final();
      var tag = gcm.getAuthTag();
      if (tag.length !== TAG_LENGTH) {
        throw new Error("invalid tag generated");
      }
      ciphertext.push(tag);
      return keylog("encrypted", Buffer.concat(ciphertext));
    }
    function writeHeader(header) {
      var ints = Buffer.alloc(5);
      var keyid = Buffer.from(header.keyid || []);
      if (keyid.length > 255) {
        throw new Error("keyid is too large");
      }
      ints.writeUIntBE(header.rs, 0, 4);
      ints.writeUIntBE(keyid.length, 4, 1);
      return Buffer.concat([header.salt, ints, keyid]);
    }
    function encrypt(buffer, params, keyLookupCallback) {
      if (!Buffer.isBuffer(buffer)) {
        throw new Error("buffer argument must be a Buffer");
      }
      var header = parseParams(params);
      if (!header.salt) {
        header.salt = crypto2.randomBytes(KEY_LENGTH);
      }
      var result;
      if (header.version === "aes128gcm") {
        if (header.privateKey && !header.keyid) {
          header.keyid = header.privateKey.getPublicKey();
        }
        result = writeHeader(header);
      } else {
        result = Buffer.alloc(0);
      }
      var key2 = deriveKeyAndNonce(header, MODE_ENCRYPT, keyLookupCallback);
      var start = 0;
      var padSize = PAD_SIZE[header.version];
      var overhead = padSize;
      if (header.version === "aes128gcm") {
        overhead += TAG_LENGTH;
      }
      var pad2 = isNaN(parseInt(params.pad, 10)) ? 0 : parseInt(params.pad, 10);
      var counter = 0;
      var last = false;
      while (!last) {
        var recordPad = Math.min(header.rs - overhead - 1, pad2);
        if (header.version !== "aes128gcm") {
          recordPad = Math.min((1 << padSize * 8) - 1, recordPad);
        }
        if (pad2 > 0 && recordPad === 0) {
          ++recordPad;
        }
        pad2 -= recordPad;
        var end = start + header.rs - overhead - recordPad;
        if (header.version !== "aes128gcm") {
          last = end > buffer.length;
        } else {
          last = end >= buffer.length;
        }
        last = last && pad2 <= 0;
        var block = encryptRecord(
          key2,
          counter,
          buffer.slice(start, end),
          recordPad,
          header,
          last
        );
        result = Buffer.concat([result, block]);
        start = end;
        ++counter;
      }
      return result;
    }
    function isFunction(object) {
      return typeof object === "function";
    }
    module.exports = {
      decrypt,
      encrypt
    };
  }
});

// node_modules/web-push/src/encryption-helper.js
var require_encryption_helper = __commonJS({
  "node_modules/web-push/src/encryption-helper.js"(exports, module) {
    "use strict";
    var crypto2 = (init_push_crypto_bridge(), __toCommonJS(push_crypto_bridge_exports));
    var ece = require_ece();
    var encrypt = function(userPublicKey, userAuth, payload, contentEncoding) {
      if (!userPublicKey) {
        throw new Error("No user public key provided for encryption.");
      }
      if (typeof userPublicKey !== "string") {
        throw new Error("The subscription p256dh value must be a string.");
      }
      if (Buffer.from(userPublicKey, "base64url").length !== 65) {
        throw new Error("The subscription p256dh value should be 65 bytes long.");
      }
      if (!userAuth) {
        throw new Error("No user auth provided for encryption.");
      }
      if (typeof userAuth !== "string") {
        throw new Error("The subscription auth key must be a string.");
      }
      if (Buffer.from(userAuth, "base64url").length < 16) {
        throw new Error("The subscription auth key should be at least 16 bytes long");
      }
      if (typeof payload !== "string" && !Buffer.isBuffer(payload)) {
        throw new Error("Payload must be either a string or a Node Buffer.");
      }
      if (typeof payload === "string" || payload instanceof String) {
        payload = Buffer.from(payload);
      }
      const localCurve = crypto2.createECDH("prime256v1");
      const localPublicKey = localCurve.generateKeys();
      const salt = crypto2.randomBytes(16).toString("base64url");
      const cipherText = ece.encrypt(payload, {
        version: contentEncoding,
        dh: userPublicKey,
        privateKey: localCurve,
        salt,
        authSecret: userAuth
      });
      return {
        localPublicKey,
        salt,
        cipherText
      };
    };
    module.exports = {
      encrypt
    };
  }
});

// lib/web-push-request.ts
async function pushRequest(subscription, payload, publicKey, privateKey) {
  const point = fromBase64url(publicKey);
  if (point.length !== 65 || point[0] !== 4 || fromBase64url(privateKey).length !== 32) throw new Error("Phone notifications need valid server keys.");
  const key2 = await crypto.subtle.importKey("jwk", { kty: "EC", crv: "P-256", x: toBase64url(point.slice(1, 33)), y: toBase64url(point.slice(33)), d: privateKey, ext: true }, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
  const encode10 = (data) => toBase64url(new TextEncoder().encode(JSON.stringify(data)));
  const jwt = encode10({ typ: "JWT", alg: "ES256" }) + "." + encode10({ aud: new URL(subscription.endpoint).origin, exp: Math.floor(Date.now() / 1e3) + 3600, sub: "https://teamstead-crew.pages.dev" });
  const signature = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key2, new TextEncoder().encode(jwt));
  const encrypted = import_encryption_helper.default.encrypt(subscription.keys.p256dh, subscription.keys.auth, payload, "aes128gcm");
  return { endpoint: subscription.endpoint, headers: { Authorization: "vapid t=" + jwt + "." + toBase64url(new Uint8Array(signature)) + ", k=" + publicKey, TTL: "3600", Urgency: "normal", "Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream" }, body: new Uint8Array(encrypted.cipherText) };
}
var import_encryption_helper;
var init_web_push_request = __esm({
  "lib/web-push-request.ts"() {
    "use strict";
    import_encryption_helper = __toESM(require_encryption_helper(), 1);
    init_access();
  }
});

// lib/maintenance-links.ts
import { env as env5 } from "cloudflare:workers";
function base64(bytes) {
  return btoa(String.fromCharCode(...bytes));
}
function unbase64(value) {
  return Uint8Array.from(atob(value), (c) => c.charCodeAt(0));
}
async function key() {
  const value = env5.MAINTENANCE_LINK_KEY || process.env.MAINTENANCE_LINK_KEY;
  if (!value) fail(503, "Private maintenance connections are not configured yet.");
  let bytes;
  try {
    bytes = unbase64(value);
  } catch {
    fail(503, "Private maintenance connections are unavailable.");
  }
  if (bytes.length !== 32) fail(503, "Private maintenance connections are unavailable.");
  return crypto.subtle.importKey("raw", bytes, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}
function parsePersonalLink(value) {
  if (typeof value !== "string" || value.length > 4096) fail(400, "Paste your complete personal Maintenance Hub link.");
  let url;
  try {
    url = new URL(value.trim());
  } catch {
    fail(400, "Paste your complete personal Maintenance Hub link.");
  }
  const environment = url.origin === hubOrigins.live ? "live" : url.origin === hubOrigins.test ? "test" : null;
  if (url.origin !== hubOrigins.live || url.username || url.password) fail(400, "Use your company\u2019s complete Maintenance Hub link.");
  const token = new URLSearchParams(url.hash.slice(1)).get("hub");
  if (!token || token.length < 12 || token.length > 2048 || /\s/.test(token)) fail(400, "That link does not include personal access. Use the complete link you were given, including the part after #hub=.");
  return { environment: environment || "live", url: (url.origin === "https://pms-company-hub.pages.dev" ? url.origin : hubOrigins[environment]) + "/#hub=" + encodeURIComponent(token) };
}
async function connectionStatus(userId) {
  const row = await db().prepare("SELECT environment,connected_at FROM maintenance_links WHERE user_id = ?").bind(userId).first();
  return row ? { connected: true, environment: row.environment, connectedAt: row.connected_at } : { connected: false };
}
async function saveConnection(userId, value, actor) {
  const parsed = parsePersonalLink(value), iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: new TextEncoder().encode("maintenance-link:" + userId + (companyId() === "main" ? "" : ":" + companyId())) }, await key(), new TextEncoder().encode(parsed.url));
  const gate = securityGate(actor, "maintenance_link_connected", userId);
  const result = await db().batch([gate.statement, db().prepare("INSERT INTO maintenance_links (user_id,environment,ciphertext,iv,connected_at) SELECT id,?,?,?,? FROM people WHERE id = ? AND active = 1 AND " + gate.condition + " ON CONFLICT(user_id) DO UPDATE SET environment=excluded.environment,ciphertext=excluded.ciphertext,iv=excluded.iv,connected_at=excluded.connected_at").bind(parsed.environment, base64(new Uint8Array(ciphertext)), base64(iv), Date.now(), userId)]);
  if (!result[0].meta.changes || !result[1].meta.changes) fail(401, "Your account changed before the connection was saved.");
  return connectionStatus(userId);
}
async function disconnect(userId, actor) {
  const gate = securityGate(actor, "maintenance_link_disconnected", userId);
  const r = await db().batch([gate.statement, db().prepare("DELETE FROM maintenance_links WHERE user_id = ? AND " + gate.condition).bind(userId)]);
  if (!r[0].meta.changes) fail(401, "Your account changed. Sign in again.");
}
async function connectionUrl(userId) {
  const row = await db().prepare("SELECT * FROM maintenance_links WHERE user_id = ?").bind(userId).first();
  if (!row) return null;
  let plaintext;
  try {
    plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unbase64(row.iv), additionalData: new TextEncoder().encode("maintenance-link:" + userId + (companyId() === "main" ? "" : ":" + companyId())) }, await key(), unbase64(row.ciphertext));
  } catch {
    fail(503, "Your saved maintenance connection could not be opened. Please reconnect your personal link.");
  }
  const parsed = parsePersonalLink(new TextDecoder().decode(plaintext));
  if (parsed.environment !== row.environment) fail(503, "Please reconnect your personal Maintenance Hub link.");
  return parsed.url;
}
async function encryptCompanyConnection(userId, url, company) {
  if (!validCompany(company) || !url.startsWith((company === "main" ? "https://pms-company-hub.pages.dev" : "https://pms-company-hub.pages.dev") + "/#hub=")) fail(400, "Company connection unavailable.");
  const iv = crypto.getRandomValues(new Uint8Array(12)), ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: new TextEncoder().encode("maintenance-link:" + userId + (company === "main" ? "" : ":" + company)) }, await key(), new TextEncoder().encode(url));
  return { iv: base64(iv), ciphertext: base64(new Uint8Array(ciphertext)) };
}
var hubOrigins;
var init_maintenance_links = __esm({
  "lib/maintenance-links.ts"() {
    "use strict";
    init_company_context();
    init_company_context();
    init_chat_db();
    init_app_errors();
    init_security_events();
    hubOrigins = { test: "https://pms-maintenance-hub-test.pages.dev", live: "https://pms-company-hub.pages.dev" };
  }
});

// lib/maintenance-bot-rules.ts
function scopedJobs(snapshot) {
  const actor = snapshot?.employee?.id;
  if (typeof actor !== "string" || !Array.isArray(snapshot.work_requests)) throw new Error("Invalid Hub response");
  return snapshot.work_requests.filter((j) => j && !j.is_test && typeof j.id === "string" && (j.requester_id === actor || j.assigned_to === actor || j.assignments?.some((a) => a.employee_id === actor && a.status === "active"))).map((j) => ({ id: j.id, number: String(j.work_order_number || j.id.slice(0, 8)).slice(0, 80), description: String(j.description || "Maintenance job").slice(0, 300), status: String(j.status || "unknown").slice(0, 60), due: typeof j.due_date === "string" ? j.due_date.slice(0, 10) : null, version: Number(j.version) || 0, mine: true, assigned: j.assigned_to === actor || !!j.assignments?.some((a) => a.employee_id === actor && a.status === "active") }));
}
function openJob(j) {
  return !["completed", "denied", "cancelled", "canceled", "rejected", "closed"].includes(j.status.toLowerCase());
}
function jobLine(j) {
  return `${j.number}: ${j.description}
Status: ${j.status}${j.due ? " \xB7 Due " + j.due : ""}`;
}
function changes(j, old, day, baseline) {
  const events = [];
  if (!baseline && j.assigned && !old?.assigned && openJob(j)) events.push({ key: `assigned:${j.id}:${j.version}`, body: "Assigned to you\n" + jobLine(j) });
  else if (!baseline && (!old || old.version !== j.version || old.status !== j.status || old.due !== j.due)) events.push({ key: `update:${j.id}:${j.version}:${j.status}:${j.due}`, body: "Maintenance update\n" + jobLine(j) });
  if (j.assigned && openJob(j) && j.due && /^\d{4}-\d{2}-\d{2}$/.test(j.due) && j.due < day) events.push({ key: `overdue:${j.id}:${j.due}:${day}`, body: "Overdue reminder\n" + jobLine(j) });
  return events;
}
var init_maintenance_bot_rules = __esm({
  "lib/maintenance-bot-rules.ts"() {
    "use strict";
  }
});

// lib/chat-notification-rules.ts
function quietNow(start, end, timezone, now = /* @__PURE__ */ new Date()) {
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: timezone, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(now);
  const minute = Number(parts.find((p) => p.type === "hour")?.value) * 60 + Number(parts.find((p) => p.type === "minute")?.value);
  return start === end ? true : start < end ? minute >= start && minute < end : minute >= start || minute < end;
}
function mentions(body, name) {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp("(^|[\\s(])@" + escaped + "(?=$|[\\s.,!?:;)])", "iu").test(body);
}
var init_chat_notification_rules = __esm({
  "lib/chat-notification-rules.ts"() {
    "use strict";
  }
});

// lib/chat-notifications.ts
var chat_notifications_exports = {};
__export(chat_notifications_exports, {
  notificationStatus: () => notificationStatus,
  runChatNotifications: () => runChatNotifications,
  updateNotifications: () => updateNotifications
});
import { env as env6 } from "cloudflare:workers";
async function driving(userId, version) {
  return !!await db().prepare("SELECT user_id FROM employee_status WHERE user_id=? AND auth_version=? AND status=? AND expires_at>?").bind(userId, version, "driving", Date.now()).first();
}
async function notificationStatus(userId) {
  const p = await db().prepare("SELECT cn.* FROM chat_notification_preferences cn JOIN people p ON p.id=cn.user_id WHERE cn.user_id=? AND cn.auth_version=p.auth_version AND p.active=1").bind(userId).first();
  return { enabled: !!p?.enabled, quietEnabled: !!p?.quiet_enabled, quietStart: p?.quiet_start ?? 1320, quietEnd: p?.quiet_end ?? 420, timezone: p?.timezone || "UTC", mutedRooms: JSON.parse(p?.muted_rooms || "[]"), pushReady: !!env6.VAPID_PUBLIC_KEY && !!env6.VAPID_PRIVATE_KEY, publicKey: env6.VAPID_PUBLIC_KEY || "", backgroundReady: !!env6.BOT_RUNNER_TOKEN_HASH };
}
async function updateNotifications(me, data) {
  if (typeof data.enabled !== "boolean" || typeof data.quietEnabled !== "boolean") fail(400, "Choose your notification settings.");
  const start = Number(data.quietStart), end = Number(data.quietEnd), zone = String(data.timezone || "");
  if (!Number.isInteger(start) || !Number.isInteger(end) || start < 0 || start > 1439 || end < 0 || end > 1439 || zone.length > 80) fail(400, "Choose valid quiet hours.");
  try {
    new Intl.DateTimeFormat("en", { timeZone: zone }).format();
  } catch {
    fail(400, "Choose a valid time zone.");
  }
  if (!Array.isArray(data.mutedRooms) || data.mutedRooms.length > 100 || data.mutedRooms.some((x) => typeof x !== "string" || x.length > 100)) fail(400, "Choose conversations to mute.");
  const rooms = await db().prepare("SELECT room_id FROM room_members WHERE user_id=?").bind(me.id).all();
  if (data.mutedRooms.some((x) => !rooms.results.some((r) => r.room_id === x))) fail(400, "You can only mute your own conversations.");
  const gate = securityGate(me, "chat_notifications_updated", me.id);
  const results = await db().batch([gate.statement, db().prepare("INSERT INTO chat_notification_preferences (user_id,auth_version,enabled,enabled_at,quiet_start,quiet_end,quiet_enabled,timezone,muted_rooms) SELECT ?,?,?,?,?,?,?,?,? WHERE " + gate.condition + " ON CONFLICT(user_id) DO UPDATE SET enabled_at=CASE WHEN chat_notification_preferences.enabled=0 OR chat_notification_preferences.auth_version<>excluded.auth_version THEN excluded.enabled_at ELSE chat_notification_preferences.enabled_at END,auth_version=excluded.auth_version,enabled=excluded.enabled,quiet_start=excluded.quiet_start,quiet_end=excluded.quiet_end,quiet_enabled=excluded.quiet_enabled,timezone=excluded.timezone,muted_rooms=excluded.muted_rooms").bind(me.id, me.auth_version, data.enabled ? 1 : 0, Date.now(), start, end, data.quietEnabled ? 1 : 0, zone, JSON.stringify(data.mutedRooms))]);
  if (!results[0].meta.changes) fail(401, "Your account changed. Sign in again.");
  return notificationStatus(me.id);
}
async function runChatNotifications() {
  if (!env6.VAPID_PUBLIC_KEY || !env6.VAPID_PRIVATE_KEY) return { chatChecked: 0 };
  const now = Date.now(), token = crypto.randomUUID();
  const p = await db().prepare("SELECT cn.*,p.name FROM chat_notification_preferences cn JOIN people p ON p.id=cn.user_id WHERE cn.enabled=1 AND p.active=1 AND p.auth_version=cn.auth_version AND cn.lease_until<? AND cn.last_attempt<? ORDER BY cn.last_attempt LIMIT 1").bind(now, now - 6e4).first();
  if (!p) return { chatChecked: 0 };
  const lease = await db().prepare("UPDATE chat_notification_preferences SET lease_until=?,lease_token=?,last_attempt=? WHERE user_id=? AND lease_until<? AND enabled=1 AND auth_version=?").bind(now + 55e3, token, now, p.user_id, now, p.auth_version).run();
  if (!lease.meta.changes) return { chatChecked: 0 };
  try {
    if (p.quiet_enabled && quietNow(p.quiet_start, p.quiet_end, p.timezone) || await driving(p.user_id, p.auth_version)) return { chatChecked: 1 };
    const devices = await db().prepare("SELECT id,subscription FROM push_devices WHERE user_id=? AND auth_version=? LIMIT 5").bind(p.user_id, p.auth_version).all();
    const muted = JSON.parse(p.muted_rooms);
    for (const device of devices.results) {
      const rows = await db().prepare("SELECT m.id,m.room_id,m.body,r.kind,COALESCE(cp.notification,'mentions') AS notification FROM messages m JOIN rooms r ON r.id=m.room_id JOIN room_members rm ON rm.room_id=m.room_id JOIN people sender ON sender.id=m.user_id LEFT JOIN conversation_preferences cp ON cp.room_id=m.room_id AND cp.user_id=rm.user_id WHERE rm.user_id=? AND m.user_id<>? AND sender.role<>? AND m.deleted=0 AND m.created_at>rm.read_at AND m.created_at>? AND r.kind IN (?,?) AND NOT EXISTS(SELECT 1 FROM chat_push_receipts cr WHERE cr.device_id=? AND cr.message_id=m.id) ORDER BY m.created_at DESC,m.id DESC LIMIT 80").bind(p.user_id, p.user_id, "bot", Math.max(p.enabled_at, now - 864e5), "dm", "channel", device.id).all();
      const eligible = rows.results.filter((m) => !muted.includes(m.room_id) && m.notification !== "muted" && (m.notification === "all" || m.kind === "dm" || mentions(m.body, p.name)));
      if (!eligible.length) continue;
      const message = eligible[0];
      const current = await db().prepare("SELECT cn.* FROM chat_notification_preferences cn JOIN people p ON p.id=cn.user_id JOIN room_members rm ON rm.user_id=p.id WHERE cn.user_id=? AND cn.enabled=1 AND cn.auth_version=? AND p.auth_version=cn.auth_version AND p.active=1 AND rm.room_id=?").bind(p.user_id, p.auth_version, message.room_id).first();
      if (!current || JSON.parse(current.muted_rooms).includes(message.room_id) || current.quiet_enabled && quietNow(current.quiet_start, current.quiet_end, current.timezone)) continue;
      const roomPref = await db().prepare("SELECT notification FROM conversation_preferences WHERE user_id=? AND room_id=?").bind(p.user_id, message.room_id).first();
      if (roomPref?.notification === "muted") continue;
      if (roomPref?.notification !== "all" && message.kind !== "dm" && !mentions(message.body, p.name)) continue;
      if (await driving(p.user_id, p.auth_version)) continue;
      const request2 = await pushRequest(validateSubscription(JSON.parse(device.subscription)), JSON.stringify({ title: "Teamstead Crew", body: "You have a new chat message.", url: companyPath("/?room=" + encodeURIComponent(message.room_id)), kind: "chat" }), env6.VAPID_PUBLIC_KEY, env6.VAPID_PRIVATE_KEY);
      const response2 = await fetch(request2.endpoint, { method: "POST", headers: request2.headers, body: new Uint8Array(request2.body), redirect: "manual", signal: AbortSignal.timeout(8e3) });
      if (response2.status === 404 || response2.status === 410) {
        await db().prepare("DELETE FROM push_devices WHERE id=? AND user_id=?").bind(device.id, p.user_id).run();
        continue;
      }
      if (!response2.ok) continue;
      const ids = eligible.filter((m) => m.room_id === message.room_id).map((m) => m.id);
      await db().prepare("INSERT OR IGNORE INTO chat_push_receipts (device_id,message_id,created_at) SELECT ?,value,? FROM json_each(?)").bind(device.id, now, JSON.stringify(ids)).run();
    }
    await db().prepare("DELETE FROM chat_push_receipts WHERE created_at<?").bind(now - 1728e5).run();
    return { chatChecked: 1 };
  } finally {
    await db().prepare("UPDATE chat_notification_preferences SET lease_until=0,lease_token=? WHERE user_id=? AND lease_token=?").bind("", p.user_id, token).run();
  }
}
var init_chat_notifications = __esm({
  "lib/chat-notifications.ts"() {
    "use strict";
    init_company_context();
    init_chat_db();
    init_app_errors();
    init_security_events();
    init_web_push_request();
    init_maintenance_bots();
    init_chat_notification_rules();
  }
});

// lib/maintenance-bots.ts
var maintenance_bots_exports = {};
__export(maintenance_bots_exports, {
  botStatus: () => botStatus,
  checkJobs: () => checkJobs,
  enableBot: () => enableBot,
  runBots: () => runBots,
  sendPush: () => sendPush,
  subscribe: () => subscribe,
  unsubscribe: () => unsubscribe,
  validateSubscription: () => validateSubscription
});
import { env as env7 } from "cloudflare:workers";
function guard(userId) {
  return db().prepare("SELECT bp.* " + join + " WHERE " + valid + " AND bp.user_id = ?").bind(userId).first();
}
async function botStatus(userId) {
  const p = await guard(userId);
  const devices = await db().prepare("SELECT COUNT(*) AS n FROM push_devices d JOIN people p ON p.id = d.user_id WHERE d.user_id = ? AND d.auth_version = p.auth_version AND p.active = 1").bind(userId).first();
  return { enabled: !!p, roomId: p?.room_id, lastChecked: p?.last_checked || 0, error: p?.last_error || "", pushReady: !!env7.VAPID_PUBLIC_KEY && !!env7.VAPID_PRIVATE_KEY, publicKey: env7.VAPID_PUBLIC_KEY || "", deviceCount: devices?.n || 0, backgroundReady: !!env7.BOT_RUNNER_TOKEN_HASH };
}
async function enableBot(me, enabled) {
  const link = await db().prepare("SELECT iv FROM maintenance_links WHERE user_id = ?").bind(me.id).first();
  if (enabled && !link) fail(400, "Connect your own Maintenance Hub link first.");
  const room = "maintenance-" + me.id, gate = securityGate(me, enabled ? "maintenance_bots_enabled" : "maintenance_bots_disabled", me.id), now = Date.now();
  const results = await db().batch([
    gate.statement,
    db().prepare("INSERT OR IGNORE INTO rooms (id,name,description,kind,visibility,created_by,created_at) SELECT ?,'My Maintenance Bot','Your private job updates. Type /my-jobs to see your current jobs.','bot','private',?,? WHERE " + gate.condition).bind(room, me.id, now),
    db().prepare("INSERT OR IGNORE INTO room_members (room_id,user_id,read_at) SELECT ?,?,0 WHERE " + gate.condition).bind(room, me.id),
    db().prepare("INSERT INTO bot_preferences (user_id,enabled,auth_version,connection_iv,room_id,enabled_at) SELECT ?,?,?,?,?,? WHERE " + gate.condition + " ON CONFLICT(user_id) DO UPDATE SET enabled=excluded.enabled,auth_version=excluded.auth_version,connection_iv=excluded.connection_iv,actor_id=NULL,snapshot='[]',last_checked=0,last_error='',enabled_at=excluded.enabled_at").bind(me.id, enabled ? 1 : 0, me.auth_version, link?.iv || "", room, now),
    db().prepare("DELETE FROM push_devices WHERE user_id = ? AND NOT EXISTS(SELECT 1 FROM chat_notification_preferences cn WHERE cn.user_id=push_devices.user_id AND cn.enabled=1 AND cn.auth_version=push_devices.auth_version) AND " + gate.condition).bind(me.id)
  ]);
  if (!results[0].meta.changes) fail(401, "Your account changed. Sign in again.");
  return botStatus(me.id);
}
function validateSubscription(value) {
  if (!value || typeof value.endpoint !== "string" || value.endpoint.length > 2048) fail(400, "Invalid phone notification subscription.");
  let url;
  try {
    url = new URL(value.endpoint);
  } catch {
    fail(400, "Invalid notification address.");
  }
  const host = url.hostname;
  const allowed = host === "fcm.googleapis.com" || host === "updates.push.services.mozilla.com" || host.endsWith(".push.apple.com") || host === "web.push.apple.com" || host.endsWith(".notify.windows.com");
  if (url.protocol !== "https:" || !allowed || url.port || url.username || url.password || url.hash) fail(400, "This notification provider is not supported.");
  const key2 = value.keys?.p256dh, auth = value.keys?.auth;
  if (typeof key2 !== "string" || !/^[-_A-Za-z0-9]{87}={0,2}$/.test(key2) || typeof auth !== "string" || !/^[-_A-Za-z0-9]{22}={0,2}$/.test(auth)) fail(400, "Invalid notification keys.");
  return { endpoint: url.href, keys: { p256dh: key2, auth } };
}
async function subscribe(me, value, chat = false) {
  if (!env7.VAPID_PUBLIC_KEY || !env7.VAPID_PRIVATE_KEY) fail(503, "Phone notifications are still being configured.");
  if (chat) {
    const { notificationStatus: notificationStatus2 } = await Promise.resolve().then(() => (init_chat_notifications(), chat_notifications_exports));
    if (!(await notificationStatus2(me.id)).enabled) fail(400, "Enable your chat alerts first.");
  } else if (!await guard(me.id)) fail(400, "Enable your Maintenance bots first.");
  const sub = validateSubscription(value), id = await tokenHash(sub.endpoint), gate = securityGate(me, "phone_notifications_enabled", me.id);
  const existing = await db().prepare("SELECT user_id FROM push_devices WHERE id = ?").bind(id).first();
  if (existing && existing.user_id !== me.id) fail(409, "Turn off phone notifications in the previous account before enabling them here.");
  const count = await db().prepare("SELECT COUNT(*) AS n FROM push_devices WHERE user_id = ?").bind(me.id).first();
  if (!existing && (count?.n || 0) >= 5) fail(400, "You have five notification devices. Remove one before adding another.");
  const r = await db().batch([gate.statement, db().prepare("INSERT INTO push_devices (id,user_id,auth_version,subscription,created_at) SELECT ?,?,?,?,? WHERE " + gate.condition + " ON CONFLICT(id) DO UPDATE SET auth_version=excluded.auth_version,subscription=excluded.subscription,created_at=excluded.created_at").bind(id, me.id, me.auth_version, JSON.stringify(sub), Date.now())]);
  if (!r[0].meta.changes) fail(401, "Sign in again.");
  return { id };
}
async function unsubscribe(me, id) {
  if (typeof id !== "string" || !/^[a-f0-9]{64}$/.test(id)) fail(400, "Choose your notification device.");
  const gate = securityGate(me, "phone_notifications_disabled", me.id);
  const r = await db().batch([gate.statement, db().prepare("DELETE FROM push_devices WHERE id = ? AND user_id = ? AND " + gate.condition).bind(id, me.id)]);
  if (!r[0].meta.changes) fail(401, "Sign in again.");
  return { ok: true };
}
async function hubJobs(userId) {
  const link = await connectionUrl(userId);
  if (!link) fail(400, "Reconnect your personal Hub link.");
  const token = new URLSearchParams(new URL(link).hash.slice(1)).get("hub");
  const jobs = /* @__PURE__ */ new Map();
  let cursor = null, actor = "";
  for (let page = 0; page < 10; page++) {
    const res = await fetch("https://fhqmnlpgqslllzrovxbp.supabase.co/functions/v1/" + (companyId() === "main" ? "hub-read" : "company-hub/hub-read"), { method: "POST", headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" }, body: JSON.stringify(cursor ? { cursor } : {}), redirect: "manual", signal: AbortSignal.timeout(15e3) });
    if (!res.ok) fail(503, res.status === 401 || res.status === 403 ? "The Hub needs a fresh personal link or manager verification. Open your Hub, then reconnect if needed." : "Maintenance Hub is unavailable. Try again later.");
    const raw = await res.text();
    if (raw.length > 8 * 1024 * 1024) fail(503, "The Hub response is too large.");
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      fail(503, "The Hub response was unavailable.");
    }
    const id = data?.employee?.id;
    if (typeof id !== "string" || actor && actor !== id) fail(503, "Your Hub identity changed. Reconnect your link.");
    actor = id;
    for (const job of scopedJobs(data)) jobs.set(job.id, job);
    if (jobs.size > 1e3) fail(503, "Too many personal jobs to check safely. Open your Hub for the full list.");
    if (!data.has_more) return { actor, jobs: [...jobs.values()] };
    if (!data.next_cursor || JSON.stringify(cursor) === JSON.stringify(data.next_cursor)) fail(503, "Your Hub jobs could not be fully loaded.");
    cursor = data.next_cursor;
  }
  fail(503, "Too many Hub pages to check safely. Ask your administrator to narrow your Hub access.");
}
async function emit(p, key2, body) {
  const id = await tokenHash(`${p.user_id}:${p.enabled_at}:${key2}`), now = Date.now();
  const condition = "EXISTS (SELECT 1 " + join + " WHERE " + valid + " AND bp.user_id = ? AND bp.enabled_at = ? AND bp.connection_iv = ? AND bp.auth_version = ? AND EXISTS (SELECT 1 FROM room_members rm WHERE rm.room_id = bp.room_id AND rm.user_id = bp.user_id))";
  await db().batch([db().prepare("INSERT OR IGNORE INTO messages (id,room_id,user_id,body,created_at) SELECT ?,?,'maintenance-bot',?,? WHERE " + condition).bind(id, p.room_id, body.slice(0, 9500), now, p.user_id, p.enabled_at, p.connection_iv, p.auth_version), db().prepare("INSERT OR IGNORE INTO bot_events (id,user_id,message_id,created_at) SELECT ?,?,?,? WHERE EXISTS (SELECT 1 FROM messages WHERE id = ?)").bind(id, p.user_id, id, now, id)]);
}
async function checkJobs(userId, command = false, commandId = crypto.randomUUID()) {
  const p = await guard(userId);
  if (!p) fail(400, "Enable your Maintenance bots and reconnect your personal Hub if needed.");
  const now = Date.now(), lease = crypto.randomUUID();
  const claim = await db().prepare("UPDATE bot_preferences SET last_attempt = ?, lease_until = ?, lease_token = ? WHERE user_id = ? AND enabled = 1 AND lease_until < ?").bind(now, now + 18e4, lease, userId, now).run();
  if (!claim.meta.changes) fail(409, "Your Maintenance bot is checking jobs. Try again shortly.");
  try {
    const snapshot = await hubJobs(userId);
    if (p.actor_id && p.actor_id !== snapshot.actor) fail(400, "Your personal Hub identity changed. Reconnect and enable the bot again.");
    const current = await guard(userId);
    if (!current || current.enabled_at !== p.enabled_at || current.connection_iv !== p.connection_iv || current.auth_version !== p.auth_version) fail(409, "Your Hub connection changed during the check.");
    const old = new Map(JSON.parse(p.snapshot).map((j) => [j.id, j]));
    const day = new Date(now).toISOString().slice(0, 10);
    const groups = /* @__PURE__ */ new Map();
    for (const job of snapshot.jobs) for (const event of changes(job, old.get(job.id), day, !p.last_checked)) {
      const type = event.key.split(":")[0];
      groups.set(type, [...groups.get(type) || [], event]);
    }
    for (const [type, events] of groups) {
      const key2 = type + ":" + await tokenHash(events.map((e) => e.key).sort().join("|"));
      await emit(p, key2, events.slice(0, 15).map((e) => e.body).join("\n\n") + (events.length > 15 ? "\n\nMore updates are available in your Maintenance Hub." : ""));
    }
    if (command) {
      const active = snapshot.jobs.filter(openJob);
      await emit(p, "command:" + commandId, active.length ? "Your jobs (" + active.length + ")\n\n" + active.slice(0, 20).map(jobLine).join("\n\n") + (active.length > 20 ? "\n\nOpen your Maintenance Hub for the full list." : "") : "You have no open jobs requested by or assigned to you.");
    }
    const condition = "EXISTS (SELECT 1 " + join + " WHERE " + valid + " AND bp.user_id = ? AND bp.enabled_at = ? AND bp.lease_token = ?)";
    await db().prepare("UPDATE bot_preferences SET snapshot = ?,actor_id = ?,last_checked = ?,last_error = '' WHERE user_id = ? AND " + condition).bind(JSON.stringify(snapshot.jobs), snapshot.actor, now, userId, userId, p.enabled_at, lease).run();
    return { roomId: p.room_id, count: snapshot.jobs.filter(openJob).length };
  } catch (e) {
    await db().prepare("UPDATE bot_preferences SET last_error = 'The Hub check needs attention. Open your Hub or refresh your connection.' WHERE user_id = ? AND lease_token = ?").bind(userId, lease).run();
    throw e;
  } finally {
    await db().prepare("UPDATE bot_preferences SET lease_until = 0,lease_token = '' WHERE user_id = ? AND lease_token = ?").bind(userId, lease).run();
  }
}
async function sendPush(userId, test = false, through = Date.now()) {
  if (!env7.VAPID_PRIVATE_KEY || !env7.VAPID_PUBLIC_KEY) fail(503, "Phone notifications are still being configured.");
  const p = await guard(userId);
  if (!p) return;
  const devices = await db().prepare("SELECT id,subscription,last_sent FROM push_devices WHERE user_id = ? AND auth_version = ?").bind(userId, p.auth_version).all();
  for (const device of devices.results) {
    if (!test && device.last_sent >= through) continue;
    const sub = validateSubscription(JSON.parse(device.subscription));
    const details = await pushRequest(sub, JSON.stringify({ title: "Teamstead Crew", body: test ? "Your phone notification test is ready." : "You have a new Maintenance update.", url: companyPath("/?room=" + encodeURIComponent(p.room_id)) }), env7.VAPID_PUBLIC_KEY, env7.VAPID_PRIVATE_KEY);
    const res = await fetch(details.endpoint, { method: "POST", headers: details.headers, body: new Uint8Array(details.body), redirect: "manual", signal: AbortSignal.timeout(1e4) });
    if (res.status === 404 || res.status === 410) await db().prepare("DELETE FROM push_devices WHERE id = ? AND user_id = ?").bind(device.id, userId).run();
    else if (!res.ok) fail(503, "Your phone notification provider could not accept this alert. Try again later.");
    else await db().prepare("UPDATE push_devices SET last_sent = ? WHERE id = ?").bind(through, device.id).run();
  }
}
async function runBots() {
  const { runChatNotifications: runChatNotifications2 } = await Promise.resolve().then(() => (init_chat_notifications(), chat_notifications_exports));
  let chat = { chatChecked: 0 };
  try {
    chat = await runChatNotifications2();
  } catch {
  }
  const candidates = await db().prepare("SELECT bp.user_id " + join + " WHERE " + valid + " AND bp.last_attempt < ? AND bp.lease_until < ? ORDER BY bp.last_attempt LIMIT 1").bind(Date.now() - 24e4, Date.now()).all();
  let checked = 0;
  for (const row of candidates.results) {
    try {
      await checkJobs(row.user_id);
      checked++;
    } catch {
    }
  }
  const pending = await db().prepare("SELECT user_id,MAX(created_at) AS through FROM bot_events WHERE push_done = 0 AND created_at > ? GROUP BY user_id LIMIT 1").bind(Date.now() - 36e5).all();
  for (const row of pending.results) {
    const through = row.through;
    try {
      await sendPush(row.user_id, false, through);
      await db().prepare("UPDATE bot_events SET push_done = 1 WHERE user_id = ? AND created_at <= ?").bind(row.user_id, through).run();
    } catch {
    }
  }
  return { checked, ...chat };
}
var valid, join;
var init_maintenance_bots = __esm({
  "lib/maintenance-bots.ts"() {
    "use strict";
    init_company_context();
    init_web_push_request();
    init_chat_db();
    init_maintenance_links();
    init_app_errors();
    init_access();
    init_security_events();
    init_maintenance_bot_rules();
    valid = "bp.enabled = 1 AND p.active = 1 AND p.auth_version = bp.auth_version AND ml.iv = bp.connection_iv";
    join = "FROM bot_preferences bp JOIN people p ON p.id = bp.user_id JOIN maintenance_links ml ON ml.user_id = p.id";
  }
});

// node_modules/pvtsutils/build/index.js
var require_build = __commonJS({
  "node_modules/pvtsutils/build/index.js"(exports) {
    "use strict";
    var ARRAY_BUFFER_NAME = "[object ArrayBuffer]";
    var BufferSourceConverter4 = class _BufferSourceConverter {
      static isArrayBuffer(data) {
        return Object.prototype.toString.call(data) === ARRAY_BUFFER_NAME;
      }
      static toArrayBuffer(data) {
        if (this.isArrayBuffer(data)) {
          return data;
        }
        if (data.byteLength === data.buffer.byteLength) {
          return data.buffer;
        }
        if (data.byteOffset === 0 && data.byteLength === data.buffer.byteLength) {
          return data.buffer;
        }
        return this.toUint8Array(data.buffer).slice(data.byteOffset, data.byteOffset + data.byteLength).buffer;
      }
      static toUint8Array(data) {
        return this.toView(data, Uint8Array);
      }
      static toView(data, type) {
        if (data.constructor === type) {
          return data;
        }
        if (this.isArrayBuffer(data)) {
          return new type(data);
        }
        if (this.isArrayBufferView(data)) {
          return new type(data.buffer, data.byteOffset, data.byteLength);
        }
        throw new TypeError("The provided value is not of type '(ArrayBuffer or ArrayBufferView)'");
      }
      static isBufferSource(data) {
        return this.isArrayBufferView(data) || this.isArrayBuffer(data);
      }
      static isArrayBufferView(data) {
        return ArrayBuffer.isView(data) || data && this.isArrayBuffer(data.buffer);
      }
      static isEqual(a, b) {
        const aView = _BufferSourceConverter.toUint8Array(a);
        const bView = _BufferSourceConverter.toUint8Array(b);
        if (aView.length !== bView.byteLength) {
          return false;
        }
        for (let i = 0; i < aView.length; i++) {
          if (aView[i] !== bView[i]) {
            return false;
          }
        }
        return true;
      }
      static concat(...args) {
        let buffers;
        if (Array.isArray(args[0]) && !(args[1] instanceof Function)) {
          buffers = args[0];
        } else if (Array.isArray(args[0]) && args[1] instanceof Function) {
          buffers = args[0];
        } else {
          if (args[args.length - 1] instanceof Function) {
            buffers = args.slice(0, args.length - 1);
          } else {
            buffers = args;
          }
        }
        let size = 0;
        for (const buffer of buffers) {
          size += buffer.byteLength;
        }
        const res = new Uint8Array(size);
        let offset = 0;
        for (const buffer of buffers) {
          const view = this.toUint8Array(buffer);
          res.set(view, offset);
          offset += view.length;
        }
        if (args[args.length - 1] instanceof Function) {
          return this.toView(res, args[args.length - 1]);
        }
        return res.buffer;
      }
    };
    var STRING_TYPE = "string";
    var HEX_REGEX = /^[0-9a-f\s]+$/i;
    var BASE64_REGEX2 = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
    var BASE64URL_REGEX2 = /^[a-zA-Z0-9-_]+$/;
    var Utf8Converter = class {
      static fromString(text) {
        const s = unescape(encodeURIComponent(text));
        const uintArray = new Uint8Array(s.length);
        for (let i = 0; i < s.length; i++) {
          uintArray[i] = s.charCodeAt(i);
        }
        return uintArray.buffer;
      }
      static toString(buffer) {
        const buf = BufferSourceConverter4.toUint8Array(buffer);
        let encodedString = "";
        for (let i = 0; i < buf.length; i++) {
          encodedString += String.fromCharCode(buf[i]);
        }
        const decodedString = decodeURIComponent(escape(encodedString));
        return decodedString;
      }
    };
    var Utf16Converter = class {
      static toString(buffer, littleEndian = false) {
        const arrayBuffer = BufferSourceConverter4.toArrayBuffer(buffer);
        const dataView = new DataView(arrayBuffer);
        let res = "";
        for (let i = 0; i < arrayBuffer.byteLength; i += 2) {
          const code = dataView.getUint16(i, littleEndian);
          res += String.fromCharCode(code);
        }
        return res;
      }
      static fromString(text, littleEndian = false) {
        const res = new ArrayBuffer(text.length * 2);
        const dataView = new DataView(res);
        for (let i = 0; i < text.length; i++) {
          dataView.setUint16(i * 2, text.charCodeAt(i), littleEndian);
        }
        return res;
      }
    };
    var Convert4 = class _Convert {
      static isHex(data) {
        return typeof data === STRING_TYPE && HEX_REGEX.test(data);
      }
      static isBase64(data) {
        return typeof data === STRING_TYPE && BASE64_REGEX2.test(data);
      }
      static isBase64Url(data) {
        return typeof data === STRING_TYPE && BASE64URL_REGEX2.test(data);
      }
      static ToString(buffer, enc = "utf8") {
        const buf = BufferSourceConverter4.toUint8Array(buffer);
        switch (enc.toLowerCase()) {
          case "utf8":
            return this.ToUtf8String(buf);
          case "binary":
            return this.ToBinary(buf);
          case "hex":
            return this.ToHex(buf);
          case "base64":
            return this.ToBase64(buf);
          case "base64url":
            return this.ToBase64Url(buf);
          case "utf16le":
            return Utf16Converter.toString(buf, true);
          case "utf16":
          case "utf16be":
            return Utf16Converter.toString(buf);
          default:
            throw new Error(`Unknown type of encoding '${enc}'`);
        }
      }
      static FromString(str2, enc = "utf8") {
        if (!str2) {
          return new ArrayBuffer(0);
        }
        switch (enc.toLowerCase()) {
          case "utf8":
            return this.FromUtf8String(str2);
          case "binary":
            return this.FromBinary(str2);
          case "hex":
            return this.FromHex(str2);
          case "base64":
            return this.FromBase64(str2);
          case "base64url":
            return this.FromBase64Url(str2);
          case "utf16le":
            return Utf16Converter.fromString(str2, true);
          case "utf16":
          case "utf16be":
            return Utf16Converter.fromString(str2);
          default:
            throw new Error(`Unknown type of encoding '${enc}'`);
        }
      }
      static ToBase64(buffer) {
        const buf = BufferSourceConverter4.toUint8Array(buffer);
        if (typeof btoa !== "undefined") {
          const binary2 = this.ToString(buf, "binary");
          return btoa(binary2);
        } else {
          return Buffer.from(buf).toString("base64");
        }
      }
      static FromBase64(base644) {
        const formatted = this.formatString(base644);
        if (!formatted) {
          return new ArrayBuffer(0);
        }
        if (!_Convert.isBase64(formatted)) {
          throw new TypeError("Argument 'base64Text' is not Base64 encoded");
        }
        if (typeof atob !== "undefined") {
          return this.FromBinary(atob(formatted));
        } else {
          return new Uint8Array(Buffer.from(formatted, "base64")).buffer;
        }
      }
      static FromBase64Url(base64url2) {
        const formatted = this.formatString(base64url2);
        if (!formatted) {
          return new ArrayBuffer(0);
        }
        if (!_Convert.isBase64Url(formatted)) {
          throw new TypeError("Argument 'base64url' is not Base64Url encoded");
        }
        return this.FromBase64(this.Base64Padding(formatted.replace(/\-/g, "+").replace(/\_/g, "/")));
      }
      static ToBase64Url(data) {
        return this.ToBase64(data).replace(/\+/g, "-").replace(/\//g, "_").replace(/\=/g, "");
      }
      static FromUtf8String(text, encoding = _Convert.DEFAULT_UTF8_ENCODING) {
        switch (encoding) {
          case "ascii":
            return this.FromBinary(text);
          case "utf8":
            return Utf8Converter.fromString(text);
          case "utf16":
          case "utf16be":
            return Utf16Converter.fromString(text);
          case "utf16le":
          case "usc2":
            return Utf16Converter.fromString(text, true);
          default:
            throw new Error(`Unknown type of encoding '${encoding}'`);
        }
      }
      static ToUtf8String(buffer, encoding = _Convert.DEFAULT_UTF8_ENCODING) {
        switch (encoding) {
          case "ascii":
            return this.ToBinary(buffer);
          case "utf8":
            return Utf8Converter.toString(buffer);
          case "utf16":
          case "utf16be":
            return Utf16Converter.toString(buffer);
          case "utf16le":
          case "usc2":
            return Utf16Converter.toString(buffer, true);
          default:
            throw new Error(`Unknown type of encoding '${encoding}'`);
        }
      }
      static FromBinary(text) {
        const stringLength = text.length;
        const resultView = new Uint8Array(stringLength);
        for (let i = 0; i < stringLength; i++) {
          resultView[i] = text.charCodeAt(i);
        }
        return resultView.buffer;
      }
      static ToBinary(buffer) {
        const buf = BufferSourceConverter4.toUint8Array(buffer);
        let res = "";
        for (let i = 0; i < buf.length; i++) {
          res += String.fromCharCode(buf[i]);
        }
        return res;
      }
      static ToHex(buffer) {
        const buf = BufferSourceConverter4.toUint8Array(buffer);
        let result = "";
        const len = buf.length;
        for (let i = 0; i < len; i++) {
          const byte = buf[i];
          if (byte < 16) {
            result += "0";
          }
          result += byte.toString(16);
        }
        return result;
      }
      static FromHex(hexString) {
        let formatted = this.formatString(hexString);
        if (!formatted) {
          return new ArrayBuffer(0);
        }
        if (!_Convert.isHex(formatted)) {
          throw new TypeError("Argument 'hexString' is not HEX encoded");
        }
        if (formatted.length % 2) {
          formatted = `0${formatted}`;
        }
        const res = new Uint8Array(formatted.length / 2);
        for (let i = 0; i < formatted.length; i = i + 2) {
          const c = formatted.slice(i, i + 2);
          res[i / 2] = parseInt(c, 16);
        }
        return res.buffer;
      }
      static ToUtf16String(buffer, littleEndian = false) {
        return Utf16Converter.toString(buffer, littleEndian);
      }
      static FromUtf16String(text, littleEndian = false) {
        return Utf16Converter.fromString(text, littleEndian);
      }
      static Base64Padding(base644) {
        const padCount = 4 - base644.length % 4;
        if (padCount < 4) {
          for (let i = 0; i < padCount; i++) {
            base644 += "=";
          }
        }
        return base644;
      }
      static formatString(data) {
        return (data === null || data === void 0 ? void 0 : data.replace(/[\n\r\t ]/g, "")) || "";
      }
    };
    Convert4.DEFAULT_UTF8_ENCODING = "utf8";
    function assign2(target, ...sources) {
      const res = arguments[0];
      for (let i = 1; i < arguments.length; i++) {
        const obj = arguments[i];
        for (const prop in obj) {
          res[prop] = obj[prop];
        }
      }
      return res;
    }
    function combine3(...buf) {
      const totalByteLength = buf.map((item) => item.byteLength).reduce((prev, cur) => prev + cur);
      const res = new Uint8Array(totalByteLength);
      let currentPos = 0;
      buf.map((item) => new Uint8Array(item)).forEach((arr) => {
        for (const item2 of arr) {
          res[currentPos++] = item2;
        }
      });
      return res.buffer;
    }
    function isEqual3(bytes1, bytes2) {
      if (!(bytes1 && bytes2)) {
        return false;
      }
      if (bytes1.byteLength !== bytes2.byteLength) {
        return false;
      }
      const b1 = new Uint8Array(bytes1);
      const b2 = new Uint8Array(bytes2);
      for (let i = 0; i < bytes1.byteLength; i++) {
        if (b1[i] !== b2[i]) {
          return false;
        }
      }
      return true;
    }
    exports.BufferSourceConverter = BufferSourceConverter4;
    exports.Convert = Convert4;
    exports.assign = assign2;
    exports.combine = combine3;
    exports.isEqual = isEqual3;
  }
});

// node_modules/reflect-metadata/Reflect.js
var require_Reflect = __commonJS({
  "node_modules/reflect-metadata/Reflect.js"() {
    "use strict";
    var Reflect2;
    (function(Reflect3) {
      (function(factory) {
        var root = typeof globalThis === "object" ? globalThis : typeof global === "object" ? global : typeof self === "object" ? self : typeof this === "object" ? this : sloppyModeThis();
        var exporter = makeExporter(Reflect3);
        if (typeof root.Reflect !== "undefined") {
          exporter = makeExporter(root.Reflect, exporter);
        }
        factory(exporter, root);
        if (typeof root.Reflect === "undefined") {
          root.Reflect = Reflect3;
        }
        function makeExporter(target, previous) {
          return function(key2, value) {
            Object.defineProperty(target, key2, { configurable: true, writable: true, value });
            if (previous)
              previous(key2, value);
          };
        }
        function functionThis() {
          try {
            return Function("return this;")();
          } catch (_) {
          }
        }
        function indirectEvalThis() {
          try {
            return (void 0, eval)("(function() { return this; })()");
          } catch (_) {
          }
        }
        function sloppyModeThis() {
          return functionThis() || indirectEvalThis();
        }
      })(function(exporter, root) {
        var hasOwn = Object.prototype.hasOwnProperty;
        var supportsSymbol = typeof Symbol === "function";
        var toPrimitiveSymbol = supportsSymbol && typeof Symbol.toPrimitive !== "undefined" ? Symbol.toPrimitive : "@@toPrimitive";
        var iteratorSymbol = supportsSymbol && typeof Symbol.iterator !== "undefined" ? Symbol.iterator : "@@iterator";
        var supportsCreate = typeof Object.create === "function";
        var supportsProto = { __proto__: [] } instanceof Array;
        var downLevel = !supportsCreate && !supportsProto;
        var HashMap = {
          // create an object in dictionary mode (a.k.a. "slow" mode in v8)
          create: supportsCreate ? function() {
            return MakeDictionary(/* @__PURE__ */ Object.create(null));
          } : supportsProto ? function() {
            return MakeDictionary({ __proto__: null });
          } : function() {
            return MakeDictionary({});
          },
          has: downLevel ? function(map, key2) {
            return hasOwn.call(map, key2);
          } : function(map, key2) {
            return key2 in map;
          },
          get: downLevel ? function(map, key2) {
            return hasOwn.call(map, key2) ? map[key2] : void 0;
          } : function(map, key2) {
            return map[key2];
          }
        };
        var functionPrototype = Object.getPrototypeOf(Function);
        var _Map = typeof Map === "function" && typeof Map.prototype.entries === "function" ? Map : CreateMapPolyfill();
        var _Set = typeof Set === "function" && typeof Set.prototype.entries === "function" ? Set : CreateSetPolyfill();
        var _WeakMap = typeof WeakMap === "function" ? WeakMap : CreateWeakMapPolyfill();
        var registrySymbol = supportsSymbol ? /* @__PURE__ */ Symbol.for("@reflect-metadata:registry") : void 0;
        var metadataRegistry = GetOrCreateMetadataRegistry();
        var metadataProvider = CreateMetadataProvider(metadataRegistry);
        function decorate(decorators, target, propertyKey, attributes) {
          if (!IsUndefined(propertyKey)) {
            if (!IsArray(decorators))
              throw new TypeError();
            if (!IsObject(target))
              throw new TypeError();
            if (!IsObject(attributes) && !IsUndefined(attributes) && !IsNull(attributes))
              throw new TypeError();
            if (IsNull(attributes))
              attributes = void 0;
            propertyKey = ToPropertyKey(propertyKey);
            return DecorateProperty(decorators, target, propertyKey, attributes);
          } else {
            if (!IsArray(decorators))
              throw new TypeError();
            if (!IsConstructor(target))
              throw new TypeError();
            return DecorateConstructor(decorators, target);
          }
        }
        exporter("decorate", decorate);
        function metadata(metadataKey, metadataValue) {
          function decorator(target, propertyKey) {
            if (!IsObject(target))
              throw new TypeError();
            if (!IsUndefined(propertyKey) && !IsPropertyKey(propertyKey))
              throw new TypeError();
            OrdinaryDefineOwnMetadata(metadataKey, metadataValue, target, propertyKey);
          }
          return decorator;
        }
        exporter("metadata", metadata);
        function defineMetadata(metadataKey, metadataValue, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryDefineOwnMetadata(metadataKey, metadataValue, target, propertyKey);
        }
        exporter("defineMetadata", defineMetadata);
        function hasMetadata(metadataKey, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryHasMetadata(metadataKey, target, propertyKey);
        }
        exporter("hasMetadata", hasMetadata);
        function hasOwnMetadata(metadataKey, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryHasOwnMetadata(metadataKey, target, propertyKey);
        }
        exporter("hasOwnMetadata", hasOwnMetadata);
        function getMetadata(metadataKey, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryGetMetadata(metadataKey, target, propertyKey);
        }
        exporter("getMetadata", getMetadata);
        function getOwnMetadata(metadataKey, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryGetOwnMetadata(metadataKey, target, propertyKey);
        }
        exporter("getOwnMetadata", getOwnMetadata);
        function getMetadataKeys(target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryMetadataKeys(target, propertyKey);
        }
        exporter("getMetadataKeys", getMetadataKeys);
        function getOwnMetadataKeys(target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          return OrdinaryOwnMetadataKeys(target, propertyKey);
        }
        exporter("getOwnMetadataKeys", getOwnMetadataKeys);
        function deleteMetadata(metadataKey, target, propertyKey) {
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          if (!IsObject(target))
            throw new TypeError();
          if (!IsUndefined(propertyKey))
            propertyKey = ToPropertyKey(propertyKey);
          var provider = GetMetadataProvider(
            target,
            propertyKey,
            /*Create*/
            false
          );
          if (IsUndefined(provider))
            return false;
          return provider.OrdinaryDeleteMetadata(metadataKey, target, propertyKey);
        }
        exporter("deleteMetadata", deleteMetadata);
        function DecorateConstructor(decorators, target) {
          for (var i = decorators.length - 1; i >= 0; --i) {
            var decorator = decorators[i];
            var decorated = decorator(target);
            if (!IsUndefined(decorated) && !IsNull(decorated)) {
              if (!IsConstructor(decorated))
                throw new TypeError();
              target = decorated;
            }
          }
          return target;
        }
        function DecorateProperty(decorators, target, propertyKey, descriptor) {
          for (var i = decorators.length - 1; i >= 0; --i) {
            var decorator = decorators[i];
            var decorated = decorator(target, propertyKey, descriptor);
            if (!IsUndefined(decorated) && !IsNull(decorated)) {
              if (!IsObject(decorated))
                throw new TypeError();
              descriptor = decorated;
            }
          }
          return descriptor;
        }
        function OrdinaryHasMetadata(MetadataKey, O, P) {
          var hasOwn2 = OrdinaryHasOwnMetadata(MetadataKey, O, P);
          if (hasOwn2)
            return true;
          var parent = OrdinaryGetPrototypeOf(O);
          if (!IsNull(parent))
            return OrdinaryHasMetadata(MetadataKey, parent, P);
          return false;
        }
        function OrdinaryHasOwnMetadata(MetadataKey, O, P) {
          var provider = GetMetadataProvider(
            O,
            P,
            /*Create*/
            false
          );
          if (IsUndefined(provider))
            return false;
          return ToBoolean(provider.OrdinaryHasOwnMetadata(MetadataKey, O, P));
        }
        function OrdinaryGetMetadata(MetadataKey, O, P) {
          var hasOwn2 = OrdinaryHasOwnMetadata(MetadataKey, O, P);
          if (hasOwn2)
            return OrdinaryGetOwnMetadata(MetadataKey, O, P);
          var parent = OrdinaryGetPrototypeOf(O);
          if (!IsNull(parent))
            return OrdinaryGetMetadata(MetadataKey, parent, P);
          return void 0;
        }
        function OrdinaryGetOwnMetadata(MetadataKey, O, P) {
          var provider = GetMetadataProvider(
            O,
            P,
            /*Create*/
            false
          );
          if (IsUndefined(provider))
            return;
          return provider.OrdinaryGetOwnMetadata(MetadataKey, O, P);
        }
        function OrdinaryDefineOwnMetadata(MetadataKey, MetadataValue, O, P) {
          var provider = GetMetadataProvider(
            O,
            P,
            /*Create*/
            true
          );
          provider.OrdinaryDefineOwnMetadata(MetadataKey, MetadataValue, O, P);
        }
        function OrdinaryMetadataKeys(O, P) {
          var ownKeys = OrdinaryOwnMetadataKeys(O, P);
          var parent = OrdinaryGetPrototypeOf(O);
          if (parent === null)
            return ownKeys;
          var parentKeys = OrdinaryMetadataKeys(parent, P);
          if (parentKeys.length <= 0)
            return ownKeys;
          if (ownKeys.length <= 0)
            return parentKeys;
          var set = new _Set();
          var keys = [];
          for (var _i = 0, ownKeys_1 = ownKeys; _i < ownKeys_1.length; _i++) {
            var key2 = ownKeys_1[_i];
            var hasKey = set.has(key2);
            if (!hasKey) {
              set.add(key2);
              keys.push(key2);
            }
          }
          for (var _a3 = 0, parentKeys_1 = parentKeys; _a3 < parentKeys_1.length; _a3++) {
            var key2 = parentKeys_1[_a3];
            var hasKey = set.has(key2);
            if (!hasKey) {
              set.add(key2);
              keys.push(key2);
            }
          }
          return keys;
        }
        function OrdinaryOwnMetadataKeys(O, P) {
          var provider = GetMetadataProvider(
            O,
            P,
            /*create*/
            false
          );
          if (!provider) {
            return [];
          }
          return provider.OrdinaryOwnMetadataKeys(O, P);
        }
        function Type(x) {
          if (x === null)
            return 1;
          switch (typeof x) {
            case "undefined":
              return 0;
            case "boolean":
              return 2;
            case "string":
              return 3;
            case "symbol":
              return 4;
            case "number":
              return 5;
            case "object":
              return x === null ? 1 : 6;
            default:
              return 6;
          }
        }
        function IsUndefined(x) {
          return x === void 0;
        }
        function IsNull(x) {
          return x === null;
        }
        function IsSymbol(x) {
          return typeof x === "symbol";
        }
        function IsObject(x) {
          return typeof x === "object" ? x !== null : typeof x === "function";
        }
        function ToPrimitive(input, PreferredType) {
          switch (Type(input)) {
            case 0:
              return input;
            case 1:
              return input;
            case 2:
              return input;
            case 3:
              return input;
            case 4:
              return input;
            case 5:
              return input;
          }
          var hint = PreferredType === 3 ? "string" : PreferredType === 5 ? "number" : "default";
          var exoticToPrim = GetMethod(input, toPrimitiveSymbol);
          if (exoticToPrim !== void 0) {
            var result = exoticToPrim.call(input, hint);
            if (IsObject(result))
              throw new TypeError();
            return result;
          }
          return OrdinaryToPrimitive(input, hint === "default" ? "number" : hint);
        }
        function OrdinaryToPrimitive(O, hint) {
          if (hint === "string") {
            var toString_1 = O.toString;
            if (IsCallable(toString_1)) {
              var result = toString_1.call(O);
              if (!IsObject(result))
                return result;
            }
            var valueOf = O.valueOf;
            if (IsCallable(valueOf)) {
              var result = valueOf.call(O);
              if (!IsObject(result))
                return result;
            }
          } else {
            var valueOf = O.valueOf;
            if (IsCallable(valueOf)) {
              var result = valueOf.call(O);
              if (!IsObject(result))
                return result;
            }
            var toString_2 = O.toString;
            if (IsCallable(toString_2)) {
              var result = toString_2.call(O);
              if (!IsObject(result))
                return result;
            }
          }
          throw new TypeError();
        }
        function ToBoolean(argument) {
          return !!argument;
        }
        function ToString(argument) {
          return "" + argument;
        }
        function ToPropertyKey(argument) {
          var key2 = ToPrimitive(
            argument,
            3
            /* String */
          );
          if (IsSymbol(key2))
            return key2;
          return ToString(key2);
        }
        function IsArray(argument) {
          return Array.isArray ? Array.isArray(argument) : argument instanceof Object ? argument instanceof Array : Object.prototype.toString.call(argument) === "[object Array]";
        }
        function IsCallable(argument) {
          return typeof argument === "function";
        }
        function IsConstructor(argument) {
          return typeof argument === "function";
        }
        function IsPropertyKey(argument) {
          switch (Type(argument)) {
            case 3:
              return true;
            case 4:
              return true;
            default:
              return false;
          }
        }
        function SameValueZero(x, y) {
          return x === y || x !== x && y !== y;
        }
        function GetMethod(V, P) {
          var func = V[P];
          if (func === void 0 || func === null)
            return void 0;
          if (!IsCallable(func))
            throw new TypeError();
          return func;
        }
        function GetIterator(obj) {
          var method = GetMethod(obj, iteratorSymbol);
          if (!IsCallable(method))
            throw new TypeError();
          var iterator = method.call(obj);
          if (!IsObject(iterator))
            throw new TypeError();
          return iterator;
        }
        function IteratorValue(iterResult) {
          return iterResult.value;
        }
        function IteratorStep(iterator) {
          var result = iterator.next();
          return result.done ? false : result;
        }
        function IteratorClose(iterator) {
          var f = iterator["return"];
          if (f)
            f.call(iterator);
        }
        function OrdinaryGetPrototypeOf(O) {
          var proto = Object.getPrototypeOf(O);
          if (typeof O !== "function" || O === functionPrototype)
            return proto;
          if (proto !== functionPrototype)
            return proto;
          var prototype = O.prototype;
          var prototypeProto = prototype && Object.getPrototypeOf(prototype);
          if (prototypeProto == null || prototypeProto === Object.prototype)
            return proto;
          var constructor = prototypeProto.constructor;
          if (typeof constructor !== "function")
            return proto;
          if (constructor === O)
            return proto;
          return constructor;
        }
        function CreateMetadataRegistry() {
          var fallback;
          if (!IsUndefined(registrySymbol) && typeof root.Reflect !== "undefined" && !(registrySymbol in root.Reflect) && typeof root.Reflect.defineMetadata === "function") {
            fallback = CreateFallbackProvider(root.Reflect);
          }
          var first;
          var second;
          var rest;
          var targetProviderMap = new _WeakMap();
          var registry = {
            registerProvider,
            getProvider,
            setProvider
          };
          return registry;
          function registerProvider(provider) {
            if (!Object.isExtensible(registry)) {
              throw new Error("Cannot add provider to a frozen registry.");
            }
            switch (true) {
              case fallback === provider:
                break;
              case IsUndefined(first):
                first = provider;
                break;
              case first === provider:
                break;
              case IsUndefined(second):
                second = provider;
                break;
              case second === provider:
                break;
              default:
                if (rest === void 0)
                  rest = new _Set();
                rest.add(provider);
                break;
            }
          }
          function getProviderNoCache(O, P) {
            if (!IsUndefined(first)) {
              if (first.isProviderFor(O, P))
                return first;
              if (!IsUndefined(second)) {
                if (second.isProviderFor(O, P))
                  return first;
                if (!IsUndefined(rest)) {
                  var iterator = GetIterator(rest);
                  while (true) {
                    var next = IteratorStep(iterator);
                    if (!next) {
                      return void 0;
                    }
                    var provider = IteratorValue(next);
                    if (provider.isProviderFor(O, P)) {
                      IteratorClose(iterator);
                      return provider;
                    }
                  }
                }
              }
            }
            if (!IsUndefined(fallback) && fallback.isProviderFor(O, P)) {
              return fallback;
            }
            return void 0;
          }
          function getProvider(O, P) {
            var providerMap = targetProviderMap.get(O);
            var provider;
            if (!IsUndefined(providerMap)) {
              provider = providerMap.get(P);
            }
            if (!IsUndefined(provider)) {
              return provider;
            }
            provider = getProviderNoCache(O, P);
            if (!IsUndefined(provider)) {
              if (IsUndefined(providerMap)) {
                providerMap = new _Map();
                targetProviderMap.set(O, providerMap);
              }
              providerMap.set(P, provider);
            }
            return provider;
          }
          function hasProvider(provider) {
            if (IsUndefined(provider))
              throw new TypeError();
            return first === provider || second === provider || !IsUndefined(rest) && rest.has(provider);
          }
          function setProvider(O, P, provider) {
            if (!hasProvider(provider)) {
              throw new Error("Metadata provider not registered.");
            }
            var existingProvider = getProvider(O, P);
            if (existingProvider !== provider) {
              if (!IsUndefined(existingProvider)) {
                return false;
              }
              var providerMap = targetProviderMap.get(O);
              if (IsUndefined(providerMap)) {
                providerMap = new _Map();
                targetProviderMap.set(O, providerMap);
              }
              providerMap.set(P, provider);
            }
            return true;
          }
        }
        function GetOrCreateMetadataRegistry() {
          var metadataRegistry2;
          if (!IsUndefined(registrySymbol) && IsObject(root.Reflect) && Object.isExtensible(root.Reflect)) {
            metadataRegistry2 = root.Reflect[registrySymbol];
          }
          if (IsUndefined(metadataRegistry2)) {
            metadataRegistry2 = CreateMetadataRegistry();
          }
          if (!IsUndefined(registrySymbol) && IsObject(root.Reflect) && Object.isExtensible(root.Reflect)) {
            Object.defineProperty(root.Reflect, registrySymbol, {
              enumerable: false,
              configurable: false,
              writable: false,
              value: metadataRegistry2
            });
          }
          return metadataRegistry2;
        }
        function CreateMetadataProvider(registry) {
          var metadata2 = new _WeakMap();
          var provider = {
            isProviderFor: function(O, P) {
              var targetMetadata = metadata2.get(O);
              if (IsUndefined(targetMetadata))
                return false;
              return targetMetadata.has(P);
            },
            OrdinaryDefineOwnMetadata: OrdinaryDefineOwnMetadata2,
            OrdinaryHasOwnMetadata: OrdinaryHasOwnMetadata2,
            OrdinaryGetOwnMetadata: OrdinaryGetOwnMetadata2,
            OrdinaryOwnMetadataKeys: OrdinaryOwnMetadataKeys2,
            OrdinaryDeleteMetadata
          };
          metadataRegistry.registerProvider(provider);
          return provider;
          function GetOrCreateMetadataMap(O, P, Create) {
            var targetMetadata = metadata2.get(O);
            var createdTargetMetadata = false;
            if (IsUndefined(targetMetadata)) {
              if (!Create)
                return void 0;
              targetMetadata = new _Map();
              metadata2.set(O, targetMetadata);
              createdTargetMetadata = true;
            }
            var metadataMap = targetMetadata.get(P);
            if (IsUndefined(metadataMap)) {
              if (!Create)
                return void 0;
              metadataMap = new _Map();
              targetMetadata.set(P, metadataMap);
              if (!registry.setProvider(O, P, provider)) {
                targetMetadata.delete(P);
                if (createdTargetMetadata) {
                  metadata2.delete(O);
                }
                throw new Error("Wrong provider for target.");
              }
            }
            return metadataMap;
          }
          function OrdinaryHasOwnMetadata2(MetadataKey, O, P) {
            var metadataMap = GetOrCreateMetadataMap(
              O,
              P,
              /*Create*/
              false
            );
            if (IsUndefined(metadataMap))
              return false;
            return ToBoolean(metadataMap.has(MetadataKey));
          }
          function OrdinaryGetOwnMetadata2(MetadataKey, O, P) {
            var metadataMap = GetOrCreateMetadataMap(
              O,
              P,
              /*Create*/
              false
            );
            if (IsUndefined(metadataMap))
              return void 0;
            return metadataMap.get(MetadataKey);
          }
          function OrdinaryDefineOwnMetadata2(MetadataKey, MetadataValue, O, P) {
            var metadataMap = GetOrCreateMetadataMap(
              O,
              P,
              /*Create*/
              true
            );
            metadataMap.set(MetadataKey, MetadataValue);
          }
          function OrdinaryOwnMetadataKeys2(O, P) {
            var keys = [];
            var metadataMap = GetOrCreateMetadataMap(
              O,
              P,
              /*Create*/
              false
            );
            if (IsUndefined(metadataMap))
              return keys;
            var keysObj = metadataMap.keys();
            var iterator = GetIterator(keysObj);
            var k = 0;
            while (true) {
              var next = IteratorStep(iterator);
              if (!next) {
                keys.length = k;
                return keys;
              }
              var nextValue = IteratorValue(next);
              try {
                keys[k] = nextValue;
              } catch (e) {
                try {
                  IteratorClose(iterator);
                } finally {
                  throw e;
                }
              }
              k++;
            }
          }
          function OrdinaryDeleteMetadata(MetadataKey, O, P) {
            var metadataMap = GetOrCreateMetadataMap(
              O,
              P,
              /*Create*/
              false
            );
            if (IsUndefined(metadataMap))
              return false;
            if (!metadataMap.delete(MetadataKey))
              return false;
            if (metadataMap.size === 0) {
              var targetMetadata = metadata2.get(O);
              if (!IsUndefined(targetMetadata)) {
                targetMetadata.delete(P);
                if (targetMetadata.size === 0) {
                  metadata2.delete(targetMetadata);
                }
              }
            }
            return true;
          }
        }
        function CreateFallbackProvider(reflect) {
          var defineMetadata2 = reflect.defineMetadata, hasOwnMetadata2 = reflect.hasOwnMetadata, getOwnMetadata2 = reflect.getOwnMetadata, getOwnMetadataKeys2 = reflect.getOwnMetadataKeys, deleteMetadata2 = reflect.deleteMetadata;
          var metadataOwner = new _WeakMap();
          var provider = {
            isProviderFor: function(O, P) {
              var metadataPropertySet = metadataOwner.get(O);
              if (!IsUndefined(metadataPropertySet) && metadataPropertySet.has(P)) {
                return true;
              }
              if (getOwnMetadataKeys2(O, P).length) {
                if (IsUndefined(metadataPropertySet)) {
                  metadataPropertySet = new _Set();
                  metadataOwner.set(O, metadataPropertySet);
                }
                metadataPropertySet.add(P);
                return true;
              }
              return false;
            },
            OrdinaryDefineOwnMetadata: defineMetadata2,
            OrdinaryHasOwnMetadata: hasOwnMetadata2,
            OrdinaryGetOwnMetadata: getOwnMetadata2,
            OrdinaryOwnMetadataKeys: getOwnMetadataKeys2,
            OrdinaryDeleteMetadata: deleteMetadata2
          };
          return provider;
        }
        function GetMetadataProvider(O, P, Create) {
          var registeredProvider = metadataRegistry.getProvider(O, P);
          if (!IsUndefined(registeredProvider)) {
            return registeredProvider;
          }
          if (Create) {
            if (metadataRegistry.setProvider(O, P, metadataProvider)) {
              return metadataProvider;
            }
            throw new Error("Illegal state.");
          }
          return void 0;
        }
        function CreateMapPolyfill() {
          var cacheSentinel = {};
          var arraySentinel = [];
          var MapIterator = (
            /** @class */
            (function() {
              function MapIterator2(keys, values, selector) {
                this._index = 0;
                this._keys = keys;
                this._values = values;
                this._selector = selector;
              }
              MapIterator2.prototype["@@iterator"] = function() {
                return this;
              };
              MapIterator2.prototype[iteratorSymbol] = function() {
                return this;
              };
              MapIterator2.prototype.next = function() {
                var index = this._index;
                if (index >= 0 && index < this._keys.length) {
                  var result = this._selector(this._keys[index], this._values[index]);
                  if (index + 1 >= this._keys.length) {
                    this._index = -1;
                    this._keys = arraySentinel;
                    this._values = arraySentinel;
                  } else {
                    this._index++;
                  }
                  return { value: result, done: false };
                }
                return { value: void 0, done: true };
              };
              MapIterator2.prototype.throw = function(error) {
                if (this._index >= 0) {
                  this._index = -1;
                  this._keys = arraySentinel;
                  this._values = arraySentinel;
                }
                throw error;
              };
              MapIterator2.prototype.return = function(value) {
                if (this._index >= 0) {
                  this._index = -1;
                  this._keys = arraySentinel;
                  this._values = arraySentinel;
                }
                return { value, done: true };
              };
              return MapIterator2;
            })()
          );
          var Map2 = (
            /** @class */
            (function() {
              function Map3() {
                this._keys = [];
                this._values = [];
                this._cacheKey = cacheSentinel;
                this._cacheIndex = -2;
              }
              Object.defineProperty(Map3.prototype, "size", {
                get: function() {
                  return this._keys.length;
                },
                enumerable: true,
                configurable: true
              });
              Map3.prototype.has = function(key2) {
                return this._find(
                  key2,
                  /*insert*/
                  false
                ) >= 0;
              };
              Map3.prototype.get = function(key2) {
                var index = this._find(
                  key2,
                  /*insert*/
                  false
                );
                return index >= 0 ? this._values[index] : void 0;
              };
              Map3.prototype.set = function(key2, value) {
                var index = this._find(
                  key2,
                  /*insert*/
                  true
                );
                this._values[index] = value;
                return this;
              };
              Map3.prototype.delete = function(key2) {
                var index = this._find(
                  key2,
                  /*insert*/
                  false
                );
                if (index >= 0) {
                  var size = this._keys.length;
                  for (var i = index + 1; i < size; i++) {
                    this._keys[i - 1] = this._keys[i];
                    this._values[i - 1] = this._values[i];
                  }
                  this._keys.length--;
                  this._values.length--;
                  if (SameValueZero(key2, this._cacheKey)) {
                    this._cacheKey = cacheSentinel;
                    this._cacheIndex = -2;
                  }
                  return true;
                }
                return false;
              };
              Map3.prototype.clear = function() {
                this._keys.length = 0;
                this._values.length = 0;
                this._cacheKey = cacheSentinel;
                this._cacheIndex = -2;
              };
              Map3.prototype.keys = function() {
                return new MapIterator(this._keys, this._values, getKey);
              };
              Map3.prototype.values = function() {
                return new MapIterator(this._keys, this._values, getValue);
              };
              Map3.prototype.entries = function() {
                return new MapIterator(this._keys, this._values, getEntry);
              };
              Map3.prototype["@@iterator"] = function() {
                return this.entries();
              };
              Map3.prototype[iteratorSymbol] = function() {
                return this.entries();
              };
              Map3.prototype._find = function(key2, insert) {
                if (!SameValueZero(this._cacheKey, key2)) {
                  this._cacheIndex = -1;
                  for (var i = 0; i < this._keys.length; i++) {
                    if (SameValueZero(this._keys[i], key2)) {
                      this._cacheIndex = i;
                      break;
                    }
                  }
                }
                if (this._cacheIndex < 0 && insert) {
                  this._cacheIndex = this._keys.length;
                  this._keys.push(key2);
                  this._values.push(void 0);
                }
                return this._cacheIndex;
              };
              return Map3;
            })()
          );
          return Map2;
          function getKey(key2, _) {
            return key2;
          }
          function getValue(_, value) {
            return value;
          }
          function getEntry(key2, value) {
            return [key2, value];
          }
        }
        function CreateSetPolyfill() {
          var Set3 = (
            /** @class */
            (function() {
              function Set4() {
                this._map = new _Map();
              }
              Object.defineProperty(Set4.prototype, "size", {
                get: function() {
                  return this._map.size;
                },
                enumerable: true,
                configurable: true
              });
              Set4.prototype.has = function(value) {
                return this._map.has(value);
              };
              Set4.prototype.add = function(value) {
                return this._map.set(value, value), this;
              };
              Set4.prototype.delete = function(value) {
                return this._map.delete(value);
              };
              Set4.prototype.clear = function() {
                this._map.clear();
              };
              Set4.prototype.keys = function() {
                return this._map.keys();
              };
              Set4.prototype.values = function() {
                return this._map.keys();
              };
              Set4.prototype.entries = function() {
                return this._map.entries();
              };
              Set4.prototype["@@iterator"] = function() {
                return this.keys();
              };
              Set4.prototype[iteratorSymbol] = function() {
                return this.keys();
              };
              return Set4;
            })()
          );
          return Set3;
        }
        function CreateWeakMapPolyfill() {
          var UUID_SIZE = 16;
          var keys = HashMap.create();
          var rootKey = CreateUniqueKey();
          return (
            /** @class */
            (function() {
              function WeakMap2() {
                this._key = CreateUniqueKey();
              }
              WeakMap2.prototype.has = function(target) {
                var table = GetOrCreateWeakMapTable(
                  target,
                  /*create*/
                  false
                );
                return table !== void 0 ? HashMap.has(table, this._key) : false;
              };
              WeakMap2.prototype.get = function(target) {
                var table = GetOrCreateWeakMapTable(
                  target,
                  /*create*/
                  false
                );
                return table !== void 0 ? HashMap.get(table, this._key) : void 0;
              };
              WeakMap2.prototype.set = function(target, value) {
                var table = GetOrCreateWeakMapTable(
                  target,
                  /*create*/
                  true
                );
                table[this._key] = value;
                return this;
              };
              WeakMap2.prototype.delete = function(target) {
                var table = GetOrCreateWeakMapTable(
                  target,
                  /*create*/
                  false
                );
                return table !== void 0 ? delete table[this._key] : false;
              };
              WeakMap2.prototype.clear = function() {
                this._key = CreateUniqueKey();
              };
              return WeakMap2;
            })()
          );
          function CreateUniqueKey() {
            var key2;
            do
              key2 = "@@WeakMap@@" + CreateUUID();
            while (HashMap.has(keys, key2));
            keys[key2] = true;
            return key2;
          }
          function GetOrCreateWeakMapTable(target, create3) {
            if (!hasOwn.call(target, rootKey)) {
              if (!create3)
                return void 0;
              Object.defineProperty(target, rootKey, { value: HashMap.create() });
            }
            return target[rootKey];
          }
          function FillRandomBytes(buffer, size) {
            for (var i = 0; i < size; ++i)
              buffer[i] = Math.random() * 255 | 0;
            return buffer;
          }
          function GenRandomBytes(size) {
            if (typeof Uint8Array === "function") {
              var array = new Uint8Array(size);
              if (typeof crypto !== "undefined") {
                crypto.getRandomValues(array);
              } else if (typeof msCrypto !== "undefined") {
                msCrypto.getRandomValues(array);
              } else {
                FillRandomBytes(array, size);
              }
              return array;
            }
            return FillRandomBytes(new Array(size), size);
          }
          function CreateUUID() {
            var data = GenRandomBytes(UUID_SIZE);
            data[6] = data[6] & 79 | 64;
            data[8] = data[8] & 191 | 128;
            var result = "";
            for (var offset = 0; offset < UUID_SIZE; ++offset) {
              var byte = data[offset];
              if (offset === 4 || offset === 6 || offset === 8)
                result += "-";
              if (byte < 16)
                result += "0";
              result += byte.toString(16).toLowerCase();
            }
            return result;
          }
        }
        function MakeDictionary(obj) {
          obj.__ = void 0;
          delete obj.__;
          return obj;
        }
      });
    })(Reflect2 || (Reflect2 = {}));
  }
});

// node_modules/tsyringe/node_modules/tslib/tslib.js
var require_tslib = __commonJS({
  "node_modules/tsyringe/node_modules/tslib/tslib.js"(exports, module) {
    "use strict";
    var __extends2;
    var __assign2;
    var __rest2;
    var __decorate3;
    var __param2;
    var __metadata2;
    var __awaiter2;
    var __generator2;
    var __exportStar2;
    var __values2;
    var __read2;
    var __spread2;
    var __spreadArrays2;
    var __await2;
    var __asyncGenerator2;
    var __asyncDelegator2;
    var __asyncValues2;
    var __makeTemplateObject2;
    var __importStar2;
    var __importDefault2;
    var __classPrivateFieldGet3;
    var __classPrivateFieldSet3;
    var __createBinding2;
    (function(factory) {
      var root = typeof global === "object" ? global : typeof self === "object" ? self : typeof this === "object" ? this : {};
      if (typeof define === "function" && define.amd) {
        define("tslib", ["exports"], function(exports2) {
          factory(createExporter(root, createExporter(exports2)));
        });
      } else if (typeof module === "object" && typeof module.exports === "object") {
        factory(createExporter(root, createExporter(module.exports)));
      } else {
        factory(createExporter(root));
      }
      function createExporter(exports2, previous) {
        if (exports2 !== root) {
          if (typeof Object.create === "function") {
            Object.defineProperty(exports2, "__esModule", { value: true });
          } else {
            exports2.__esModule = true;
          }
        }
        return function(id, v) {
          return exports2[id] = previous ? previous(id, v) : v;
        };
      }
    })(function(exporter) {
      var extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
        d.__proto__ = b;
      } || function(d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
      };
      __extends2 = function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
      __assign2 = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
      __rest2 = function(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
          t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
          for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
              t[p[i]] = s[p[i]];
          }
        return t;
      };
      __decorate3 = function(decorators, target, key2, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key2) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key2, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key2, r) : d(target, key2)) || r;
        return c > 3 && r && Object.defineProperty(target, key2, r), r;
      };
      __param2 = function(paramIndex, decorator) {
        return function(target, key2) {
          decorator(target, key2, paramIndex);
        };
      };
      __metadata2 = function(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
      };
      __awaiter2 = function(thisArg, _arguments, P, generator) {
        function adopt(value) {
          return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
          });
        }
        return new (P || (P = Promise))(function(resolve, reject) {
          function fulfilled(value) {
            try {
              step(generator.next(value));
            } catch (e) {
              reject(e);
            }
          }
          function rejected(value) {
            try {
              step(generator["throw"](value));
            } catch (e) {
              reject(e);
            }
          }
          function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
          }
          step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
      };
      __generator2 = function(thisArg, body) {
        var _ = { label: 0, sent: function() {
          if (t[0] & 1) throw t[1];
          return t[1];
        }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
          return this;
        }), g;
        function verb(n) {
          return function(v) {
            return step([n, v]);
          };
        }
        function step(op) {
          if (f) throw new TypeError("Generator is already executing.");
          while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
              case 0:
              case 1:
                t = op;
                break;
              case 4:
                _.label++;
                return { value: op[1], done: false };
              case 5:
                _.label++;
                y = op[1];
                op = [0];
                continue;
              case 7:
                op = _.ops.pop();
                _.trys.pop();
                continue;
              default:
                if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                  _ = 0;
                  continue;
                }
                if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                  _.label = op[1];
                  break;
                }
                if (op[0] === 6 && _.label < t[1]) {
                  _.label = t[1];
                  t = op;
                  break;
                }
                if (t && _.label < t[2]) {
                  _.label = t[2];
                  _.ops.push(op);
                  break;
                }
                if (t[2]) _.ops.pop();
                _.trys.pop();
                continue;
            }
            op = body.call(thisArg, _);
          } catch (e) {
            op = [6, e];
            y = 0;
          } finally {
            f = t = 0;
          }
          if (op[0] & 5) throw op[1];
          return { value: op[0] ? op[1] : void 0, done: true };
        }
      };
      __createBinding2 = function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      };
      __exportStar2 = function(m, exports2) {
        for (var p in m) if (p !== "default" && !exports2.hasOwnProperty(p)) exports2[p] = m[p];
      };
      __values2 = function(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
          next: function() {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
          }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
      };
      __read2 = function(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
          while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        } catch (error) {
          e = { error };
        } finally {
          try {
            if (r && !r.done && (m = i["return"])) m.call(i);
          } finally {
            if (e) throw e.error;
          }
        }
        return ar;
      };
      __spread2 = function() {
        for (var ar = [], i = 0; i < arguments.length; i++)
          ar = ar.concat(__read2(arguments[i]));
        return ar;
      };
      __spreadArrays2 = function() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
          for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
        return r;
      };
      __await2 = function(v) {
        return this instanceof __await2 ? (this.v = v, this) : new __await2(v);
      };
      __asyncGenerator2 = function(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
          return this;
        }, i;
        function verb(n) {
          if (g[n]) i[n] = function(v) {
            return new Promise(function(a, b) {
              q.push([n, v, a, b]) > 1 || resume(n, v);
            });
          };
        }
        function resume(n, v) {
          try {
            step(g[n](v));
          } catch (e) {
            settle(q[0][3], e);
          }
        }
        function step(r) {
          r.value instanceof __await2 ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
        }
        function fulfill(value) {
          resume("next", value);
        }
        function reject(value) {
          resume("throw", value);
        }
        function settle(f, v) {
          if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
        }
      };
      __asyncDelegator2 = function(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function(e) {
          throw e;
        }), verb("return"), i[Symbol.iterator] = function() {
          return this;
        }, i;
        function verb(n, f) {
          i[n] = o[n] ? function(v) {
            return (p = !p) ? { value: __await2(o[n](v)), done: n === "return" } : f ? f(v) : v;
          } : f;
        }
      };
      __asyncValues2 = function(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values2 === "function" ? __values2(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
          return this;
        }, i);
        function verb(n) {
          i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
              v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
          };
        }
        function settle(resolve, reject, d, v) {
          Promise.resolve(v).then(function(v2) {
            resolve({ value: v2, done: d });
          }, reject);
        }
      };
      __makeTemplateObject2 = function(cooked, raw) {
        if (Object.defineProperty) {
          Object.defineProperty(cooked, "raw", { value: raw });
        } else {
          cooked.raw = raw;
        }
        return cooked;
      };
      __importStar2 = function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        }
        result["default"] = mod;
        return result;
      };
      __importDefault2 = function(mod) {
        return mod && mod.__esModule ? mod : { "default": mod };
      };
      __classPrivateFieldGet3 = function(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
          throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
      };
      __classPrivateFieldSet3 = function(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
          throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
      };
      exporter("__extends", __extends2);
      exporter("__assign", __assign2);
      exporter("__rest", __rest2);
      exporter("__decorate", __decorate3);
      exporter("__param", __param2);
      exporter("__metadata", __metadata2);
      exporter("__awaiter", __awaiter2);
      exporter("__generator", __generator2);
      exporter("__exportStar", __exportStar2);
      exporter("__createBinding", __createBinding2);
      exporter("__values", __values2);
      exporter("__read", __read2);
      exporter("__spread", __spread2);
      exporter("__spreadArrays", __spreadArrays2);
      exporter("__await", __await2);
      exporter("__asyncGenerator", __asyncGenerator2);
      exporter("__asyncDelegator", __asyncDelegator2);
      exporter("__asyncValues", __asyncValues2);
      exporter("__makeTemplateObject", __makeTemplateObject2);
      exporter("__importStar", __importStar2);
      exporter("__importDefault", __importDefault2);
      exporter("__classPrivateFieldGet", __classPrivateFieldGet3);
      exporter("__classPrivateFieldSet", __classPrivateFieldSet3);
    });
  }
});

// worker/index.ts
init_access();

// lib/product-boundary.ts
var TEAMSTEAD_DATABASE_ID = "24543c2f-3d1f-4313-b46f-0708b6db28a1";
var TEAMSTEAD_HOST = "teamstead-crew.pages.dev";
async function teamsteadBoundary(request2, database) {
  if (!database || new URL(request2.url).hostname !== TEAMSTEAD_HOST) return false;
  try {
    const identity = await database.prepare("SELECT product, database_id, active FROM product_identity WHERE id=1").first();
    return identity?.product === "teamstead-sales" && identity.database_id === TEAMSTEAD_DATABASE_ID && identity.active === 1;
  } catch {
    return false;
  }
}

// worker/index.ts
init_chat_db();

// lib/company-billing-access.ts
init_chat_db();

// lib/billing-policy.ts
var BILLING_POLICY = { trialDays: 30, graceDays: 7, retention: "until_owner_requests_deletion" };
function billingAccess(status, failedAt, now = Date.now()) {
  if (status === "active" || status === "trialing") return { allowed: true, graceEndsAt: null };
  const graceEndsAt = failedAt ? failedAt + BILLING_POLICY.graceDays * 864e5 : null;
  return { allowed: status === "past_due" && graceEndsAt !== null && now < graceEndsAt, graceEndsAt };
}

// lib/company-billing-access.ts
async function companyBillingAccess(company) {
  if (!/^c_[a-f0-9]{16}$/.test(company)) return { allowed: true, required: false };
  const registry = await rawDb().prepare("SELECT status,billing_required FROM company_registry WHERE id=?").bind(company).first();
  if (!registry || ["suspended", "archived", "deleting"].includes(registry.status)) return { allowed: false, required: true };
  if (!registry.billing_required) return { allowed: true, required: false };
  const billing = await rawDb().prepare("SELECT status,payment_failed_at FROM company_billing WHERE company_id=? AND billing_mode='live'").bind(company).first();
  return { required: true, ...billing ? billingAccess(billing.status, billing.payment_failed_at) : { allowed: false, graceEndsAt: null } };
}

// lib/r2-bridge-public.ts
var BRIDGE_PUBLIC_KEY = { "kty": "EC", "x": "7mY6YxQa4mV3gxTQOeYpcEbeg8d8j1YinXEX7NWd780", "y": "fa7RWl8OqeJEqaKqeRfg_dxd0toivq7gHYBsc5L_14g", "crv": "P-256", "key_ops": ["verify"], "ext": true };

// lib/hub-billing-attestation.ts
init_chat_db();

// lib/chat-server.ts
init_access();
init_app_errors();
init_app_errors();
init_chat_db();

// lib/file-deletions.ts
init_chat_db();
init_app_errors();
function queueDeletion(objectKey, userId, messageId) {
  return db().prepare("INSERT OR IGNORE INTO file_deletions (object_key,message_id,requested_by,requested_at) VALUES (?,?,?,?)").bind(objectKey, messageId, userId, Date.now());
}
async function pendingDeletionCount(person, messageId) {
  const where = (person.role === "owner" ? "1 = 1" : "requested_by = ?") + (messageId ? " AND message_id = ?" : "");
  const row = await db().prepare("SELECT COUNT(*) AS count FROM file_deletions WHERE " + where).bind(...person.role === "owner" ? [] : [person.id], ...messageId ? [messageId] : []).first();
  return row?.count || 0;
}
async function retryFileDeletions(person, messageId) {
  const where = (person.role === "owner" ? "1 = 1" : "requested_by = ?") + (messageId ? " AND message_id = ?" : "");
  const jobs = await db().prepare("SELECT object_key FROM file_deletions WHERE " + where + " AND NOT EXISTS (SELECT 1 FROM attachments a WHERE a.object_key = file_deletions.object_key) ORDER BY requested_at LIMIT 8").bind(...person.role === "owner" ? [] : [person.id], ...messageId ? [messageId] : []).all();
  await Promise.allSettled(jobs.results.map(async (job) => {
    try {
      await bucket().delete(job.object_key);
      await db().prepare("DELETE FROM file_deletions WHERE object_key = ?").bind(job.object_key).run();
    } catch {
      await db().prepare("UPDATE file_deletions SET attempts = attempts + 1 WHERE object_key = ?").bind(job.object_key).run();
    }
  }));
  return pendingDeletionCount(person, messageId);
}
async function deleteMessage(id, person) {
  const now = Date.now();
  const result = await db().batch([
    db().prepare("INSERT OR IGNORE INTO file_deletions (object_key,message_id,requested_by,requested_at) SELECT a.object_key,m.id,?,? FROM attachments a JOIN messages m ON m.id = a.message_id JOIN room_members rm ON rm.room_id = m.room_id WHERE m.id = ? AND m.user_id = ? AND rm.user_id = ?").bind(person.id, now, id, person.id, person.id),
    db().prepare("UPDATE messages SET deleted = 1,body = ?,pinned = 0 WHERE id = ? AND user_id = ? AND EXISTS (SELECT 1 FROM room_members WHERE room_id = messages.room_id AND user_id = ?)").bind("", id, person.id, person.id),
    db().prepare("DELETE FROM attachments WHERE message_id = ? AND EXISTS (SELECT 1 FROM messages WHERE id = attachments.message_id AND deleted = 1 AND user_id = ?)").bind(id, person.id),
    db().prepare("DELETE FROM reactions WHERE message_id = ? AND EXISTS (SELECT 1 FROM messages WHERE id = reactions.message_id AND deleted = 1 AND user_id = ?)").bind(id, person.id)
  ]);
  if (!result[1].meta.changes) fail(404, "This message is no longer available to remove.");
  return { ok: true, id, photosPending: await retryFileDeletions(person, id) };
}

// lib/chat-server.ts
function str(value, max = 1e4) {
  if (typeof value !== "string" || value.length > max) fail(400, "Please check the text and try again.");
  return value.trim();
}
function required(value, max = 100) {
  const s = str(value, max);
  if (!s) fail(400, "Please fill in the required field.");
  return s;
}
function response(data, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
}
function handleError(e) {
  if (e instanceof ChatError) return response({ error: e.message }, e.status);
  console.error("Teamstead Crew request failed", e instanceof Error ? e.message : "Unknown error");
  return response({ error: "We could not reach your workspace. Your draft is safe. Please try again." }, 503);
}
function checkOrigin(request2) {
  const origin = request2.headers.get("origin");
  let source = origin;
  if (!source) {
    const ref = request2.headers.get("referer");
    try {
      source = ref ? new URL(ref).origin : null;
    } catch {
      source = null;
    }
  }
  if (!source || source === "null" || source !== new URL(request2.url).origin || request2.headers.get("sec-fetch-site") === "cross-site") fail(403, "Please open Teamstead Crew to make this change.");
}
async function member() {
  return currentPerson();
}
async function roomAccess(id, userId) {
  const room = await db().prepare("SELECT r.* FROM rooms r JOIN room_members rm ON rm.room_id = r.id WHERE r.id = ? AND rm.user_id = ?").bind(id, userId).first();
  if (!room) fail(404, "That conversation is not available to you.");
  return room;
}
async function messageAccess(id, userId) {
  const msg = await db().prepare("SELECT m.* FROM messages m JOIN room_members rm ON rm.room_id = m.room_id WHERE m.id = ? AND rm.user_id = ?").bind(id, userId).first();
  if (!msg) fail(404, "That message is not available to you.");
  return msg;
}
async function enrich(rows, userId) {
  if (!rows.length) return [];
  if (rows.length > 80) {
    const chunks = [];
    for (let i = 0; i < rows.length; i += 80) chunks.push(await enrich(rows.slice(i, i + 80), userId));
    return chunks.flat();
  }
  const ids = rows.map((x) => String(x.id));
  const placeholders = ids.map(() => "?").join(",");
  const [files, reacts, saved] = await Promise.all([
    db().prepare("SELECT a.id,a.message_id,a.name,a.mime,a.size FROM attachments a JOIN messages m ON m.id = a.message_id WHERE m.deleted = 0 AND a.message_id IN (" + placeholders + ")").bind(...ids).all(),
    db().prepare("SELECT message_id,emoji,COUNT(*) AS count,MAX(CASE WHEN user_id = ? THEN 1 ELSE 0 END) AS mine FROM reactions WHERE message_id IN (" + placeholders + ") GROUP BY message_id,emoji").bind(userId, ...ids).all(),
    db().prepare("SELECT message_id FROM saved_messages WHERE user_id=? AND message_id IN (" + placeholders + ")").bind(userId, ...ids).all()
  ]);
  return rows.map((m) => ({ ...m, saved: !m.deleted && saved.results.some((s) => s.message_id === m.id) ? 1 : 0, attachments: files.results.filter((a) => a.message_id === m.id), reactions: m.deleted ? [] : reacts.results.filter((a) => a.message_id === m.id) }));
}
var messageSelect = "SELECT m.*,p.name AS author,(SELECT COUNT(*) FROM messages reply WHERE reply.parent_id = m.id) AS reply_count FROM messages m LEFT JOIN people p ON p.id = m.user_id ";
async function sendMessage(request2, person) {
  if (Number(request2.headers.get("content-length") || 0) > 2 * 1024 * 1024) fail(413, "Choose up to 3 photos or PDFs through the app.");
  const data = await request2.formData();
  const id = required(data.get("id"), 80), roomId = required(data.get("roomId"), 100), body = str(data.get("body") || ""), parentId = str(data.get("parentId") || "", 100) || null;
  if (!/^[a-zA-Z0-9_-]{12,80}$/.test(id)) fail(400, "The message could not be identified. Please try again.");
  const room = await roomAccess(roomId, person.id);
  const existing = await db().prepare("SELECT id,user_id,room_id FROM messages WHERE id = ?").bind(id).first();
  if (existing) {
    if (existing.user_id !== person.id || existing.room_id !== roomId) fail(409, "Please send this as a new message.");
    return response({ id: existing.id });
  }
  if (room.kind === "dm") {
    const n = await db().prepare("SELECT COUNT(*) AS count FROM room_members rm JOIN people p ON p.id = rm.user_id WHERE rm.room_id = ? AND p.active = 1").bind(roomId).first();
    if ((n?.count || 0) < 2) fail(409, "This person is no longer in the workspace.");
  }
  if (parentId) {
    const parent = await messageAccess(parentId, person.id);
    if (parent.room_id !== roomId || parent.parent_id || parent.deleted) fail(400, "Reply to an available message in this conversation.");
  }
  const files = data.getAll("files").filter((v) => typeof v !== "string" && v.size > 0);
  if (room.kind === "bot") {
    if (files.length || parentId || !["/my-jobs", "show my jobs", "my jobs"].includes(body.toLowerCase())) fail(400, "Type /my-jobs or show my jobs in your Maintenance Bot conversation.");
    const { checkJobs: checkJobs2 } = await Promise.resolve().then(() => (init_maintenance_bots(), maintenance_bots_exports));
    await checkJobs2(person.id, true, id);
    return response({ id });
  }
  if (!body && !files.length) fail(400, "Write a message or choose a file.");
  if (files.length > 3 || files.some((f) => f.size > 512 * 1024)) fail(413, "Choose up to 3 files. Stored photos and PDFs must be 512 KB or smaller.");
  const uploaded = [];
  try {
    for (const file of files) {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const mime = imageType(bytes) || (new TextDecoder().decode(bytes.slice(0, 5)) === "%PDF-" ? "application/pdf" : null);
      if (!mime) fail(415, "Use a JPG, PNG, GIF, WebP or PDF file.");
      const attachmentId = crypto.randomUUID(), key2 = "conversations/" + encodeURIComponent(roomId) + "/" + (/* @__PURE__ */ new Date()).toISOString().slice(0, 7).replace("-", "/") + "/" + attachmentId;
      uploaded.push({ id: attachmentId, key: key2, name: file.name.slice(0, 180), mime, size: file.size });
      await bucket().put(key2, bytes, { httpMetadata: { contentType: mime } });
    }
    const now = Date.now();
    await db().batch([
      db().prepare("INSERT INTO messages (id,room_id,user_id,parent_id,body,created_at) VALUES (?,?,?,?,?,?)").bind(id, roomId, person.id, parentId, body, now),
      ...uploaded.map((f) => db().prepare("INSERT INTO attachments (id,message_id,object_key,name,mime,size) VALUES (?,?,?,?,?,?)").bind(f.id, id, f.key, f.name, f.mime, f.size))
    ]);
    return response({ id, created_at: now }, 201);
  } catch (e) {
    let committed = null;
    let referencedKeys = [];
    let checked = false;
    try {
      committed = await db().prepare("SELECT id FROM messages WHERE id = ? AND user_id = ? AND room_id = ?").bind(id, person.id, roomId).first();
      const saved = await db().prepare("SELECT object_key FROM attachments WHERE message_id = ?").bind(id).all();
      referencedKeys = saved.results.map((f) => f.object_key);
      checked = true;
    } catch {
    }
    if (checked && uploaded.length) {
      const orphans = uploaded.filter((f) => !referencedKeys.includes(f.key));
      if (orphans.length) try {
        await db().batch(orphans.map((f) => queueDeletion(f.key, person.id, null)));
        await retryFileDeletions(person);
      } catch {
      }
    }
    if (committed) return response({ id });
    throw e;
  }
}
function imageType(b) {
  if (b.length < 12) return null;
  if (b[0] === 255 && b[1] === 216 && b[2] === 255) return "image/jpeg";
  if ([137, 80, 78, 71, 13, 10, 26, 10].every((n, i) => b[i] === n)) return "image/png";
  const first = String.fromCharCode(...b.slice(0, 12));
  if (first.startsWith("GIF87a") || first.startsWith("GIF89a")) return "image/gif";
  if (first.startsWith("RIFF") && first.slice(8) === "WEBP") return "image/webp";
  return null;
}

// lib/hub-billing-attestation.ts
async function hubBillingAttestation(request2) {
  try {
    const at = request2.headers.get("x-signed-at") || "", sig = request2.headers.get("x-signature") || "";
    if (request2.headers.get("origin") || !/^\d{13}$/.test(at) || Math.abs(Date.now() - Number(at)) > 6e4 || !/^[A-Za-z0-9_-]{86}$/.test(sig)) fail(401, "Access denied.");
    const body = await request2.text();
    if (body.length > 200) fail(413, "Request too large.");
    const key2 = await crypto.subtle.importKey("jwk", BRIDGE_PUBLIC_KEY, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
    const bytes = Uint8Array.from(atob(sig.replace(/-/g, "+").replace(/_/g, "/") + "=="), (x) => x.charCodeAt(0));
    if (!await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key2, bytes, new TextEncoder().encode(["pms-billing-v1", at, body].join("\n")))) fail(401, "Access denied.");
    const data = JSON.parse(body);
    if (!/^c_[a-f0-9]{16}$/.test(data.company)) fail(400, "Invalid company.");
    const company = await rawDb().prepare("SELECT COALESCE(product_package,product_bundle) AS selected_plan FROM company_registry WHERE id=?").bind(data.company).first();
    if (!company || !["hub", "combined", "hub_parts", "complete"].includes(company.selected_plan)) return response({ allowed: false });
    return response(await companyBillingAccess(data.company));
  } catch (error) {
    return handleError(error);
  }
}

// lib/company-products.ts
init_chat_db();
init_company_context();
init_app_errors();

// lib/product-plans.ts
var PRODUCT_PLANS = ["chat", "hub", "parts", "combined", "chat_parts", "hub_parts", "complete"];
function validPlan(value) {
  return typeof value === "string" && PRODUCT_PLANS.includes(value);
}
function planProducts(plan) {
  return {
    chat: plan === "chat" || plan === "combined" || plan === "chat_parts" || plan === "complete",
    hub: plan === "hub" || plan === "combined" || plan === "hub_parts" || plan === "complete",
    parts: plan === "parts" || plan === "chat_parts" || plan === "hub_parts" || plan === "complete"
  };
}

// lib/company-products.ts
async function companyProducts() {
  const id = companyId();
  if (id === "main" || id === "demo" || id === "pilot") return { plan: "complete", ...planProducts("complete") };
  const row = await rawDb().prepare("SELECT COALESCE(product_package,product_bundle) AS product_plan FROM company_registry WHERE id=?").bind(id).first();
  if (!row || !validPlan(row.product_plan)) fail(403, "Company plan is unavailable.");
  return { plan: row.product_plan, ...planProducts(row.product_plan) };
}

// app/api/checkout/route.ts
var route_exports = {};
__export(route_exports, {
  GET: () => GET,
  POST: () => POST
});
init_access();
import { env as env9 } from "cloudflare:workers";
init_company_context();
init_chat_db();

// lib/stripe-checkout.ts
function checkoutParameters(price, successUrl, cancelUrl) {
  return new URLSearchParams({
    ui_mode: "hosted_page",
    mode: "subscription",
    "subscription_data[trial_period_days]": "30",
    billing_address_collection: "auto",
    "phone_number_collection[enabled]": "false",
    "automatic_tax[enabled]": "false",
    allow_promotion_codes: "false",
    payment_method_collection: "always",
    submit_type: "auto",
    integration_identifier: "hosted_web_0001",
    origin_context: "web",
    success_url: successUrl,
    cancel_url: cancelUrl,
    "line_items[0][price]": price,
    "line_items[0][quantity]": "1"
  });
}

// lib/stripe-billing.ts
init_app_errors();
import { env as env8 } from "cloudflare:workers";
function stripeLive() {
  return env8.STRIPE_MODE === "live";
}
function requireStripeConfiguration() {
  const prefixes = stripeLive() ? ["sk_live_", "rk_live_"] : ["sk_test_", "rk_test_"];
  if (!prefixes.some((prefix) => env8.STRIPE_SECRET_KEY?.startsWith(prefix))) fail(503, "Payments are not configured for this environment.");
}
async function stripeCall(path, params, idempotencyKey) {
  requireStripeConfiguration();
  const headers2 = { Authorization: `Bearer ${env8.STRIPE_SECRET_KEY}` };
  if (params) headers2["Content-Type"] = "application/x-www-form-urlencoded";
  if (idempotencyKey) headers2["Idempotency-Key"] = idempotencyKey;
  const res = await fetch("https://api.stripe.com/v1/" + path, { method: params ? "POST" : "GET", headers: headers2, body: params, signal: AbortSignal.timeout(15e3) });
  if (!res.ok) fail(502, "Stripe could not complete this request. Please try again.");
  return await res.json();
}
async function verifyStripeSignature(body, header, secret, now = Math.floor(Date.now() / 1e3)) {
  const parts = (header || "").split(",").map((s) => s.split("="));
  const times = parts.filter(([key3]) => key3 === "t").map(([, value]) => Number(value));
  const signatures = parts.filter(([key3]) => key3 === "v1").map(([, value]) => value);
  if (times.length !== 1 || !Number.isSafeInteger(times[0]) || Math.abs(now - times[0]) > 300) return false;
  const key2 = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  const message = new TextEncoder().encode(`${times[0]}.${body}`);
  for (const signature of signatures) {
    if (!/^[a-f0-9]{64}$/.test(signature || "")) continue;
    const bytes = Uint8Array.from(signature.match(/../g), (pair) => parseInt(pair, 16));
    if (await crypto.subtle.verify("HMAC", key2, bytes, message)) return true;
  }
  return false;
}
function configuredPrice(priceId) {
  for (const plan of PRODUCT_PLANS) for (const interval of ["month", "year"]) {
    const key2 = `STRIPE_PRICE_${plan.toUpperCase()}_${interval.toUpperCase()}`;
    const legacyKey = `${key2}_LEGACY`;
    if (env8[key2] === priceId || env8[legacyKey] === priceId) return { plan, interval };
  }
  return null;
}

// app/api/checkout/route.ts
async function GET() {
  try {
    const me = await currentPerson();
    if (me.role !== "owner") fail(403, "Only the owner can view billing.");
    const billing = await rawDb().prepare("SELECT status,billing_interval,updated_at,payment_failed_at,trial_ends_at,cancel_at_period_end FROM company_billing WHERE company_id=?").bind(companyId()).first();
    return response({ policy: BILLING_POLICY, access: billing ? billingAccess(String(billing.status), Number(billing.payment_failed_at) || null) : null, billing: billing || { status: "not_started" }, testMode: !stripeLive(), eligible: /^c_/.test(companyId()) });
  } catch (error) {
    return handleError(error);
  }
}
async function POST(request2) {
  try {
    checkOrigin(request2);
    const owner3 = await requireRecent();
    if (owner3.role !== "owner") fail(403, "Only the company owner can start billing.");
    const co = companyId();
    if (!/^c_/.test(co)) fail(403, "Billing tests are for newly created company workspaces.");
    requireStripeConfiguration();
    if (!env9.STRIPE_WEBHOOK_SECRET?.startsWith("whsec_")) fail(503, "Verified payment notifications are not configured.");
    if (!request2.headers.get("content-type")?.startsWith("application/json")) fail(415, "Use JSON.");
    const data = await request2.json();
    if (!data) fail(400, "Choose billing options.");
    const db3 = rawDb(), now = Date.now(), mode = stripeLive() ? "live" : "test";
    const prior = await db3.prepare("SELECT * FROM company_billing WHERE company_id=?").bind(co).first();
    if (prior && prior.billing_mode !== mode) fail(409, "This workspace has sandbox billing. Create a new company for live payments.");
    if (data.action === "portal") {
      if (!prior?.customer_id) fail(400, "Start a subscription first.");
      const portal = await stripeCall("billing_portal/sessions", new URLSearchParams({ customer: prior.customer_id, return_url: new URL(companyPath("/billing/"), request2.url).href }));
      if (!portal.url.startsWith("https://billing.stripe.com/")) fail(502, "Unexpected billing portal.");
      return response({ url: portal.url });
    }
    if (!["month", "year"].includes(String(data.interval))) fail(400, "Choose monthly or yearly billing.");
    if (prior?.subscription_id && !["canceled", "incomplete_expired"].includes(prior.status)) fail(409, "A subscription already exists. Manage it in the billing portal.");
    const { plan } = await companyProducts();
    const key2 = `STRIPE_PRICE_${plan.toUpperCase()}_${String(data.interval).toUpperCase()}`;
    const price = env9[key2];
    if (typeof price !== "string" || !/^price_[A-Za-z0-9]+$/.test(price)) fail(503, "This price is not configured.");
    if (prior?.checkout_url && prior.checkout_expires_at > now && prior.status === "checkout_pending") {
      if (prior.price_id !== price) fail(409, "A checkout is already open. Finish it or wait for it to expire before changing billing frequency.");
      return response({ url: prior.checkout_url });
    }
    const reuse = prior?.checkout_attempt && prior.checkout_started_at > now - 23 * 36e5 && !prior.checkout_id;
    const attempt = reuse ? prior.checkout_attempt : crypto.randomUUID();
    if (reuse && prior.price_id !== price) fail(409, "Retry the same billing frequency while checkout is being prepared.");
    if (!reuse) {
      await db3.prepare("INSERT INTO company_billing(company_id,checkout_attempt,checkout_started_at,price_id,status,updated_at,billing_mode) VALUES(?,?,?,?, 'checkout_pending',?,?) ON CONFLICT(company_id) DO UPDATE SET checkout_attempt=excluded.checkout_attempt,checkout_started_at=excluded.checkout_started_at,checkout_id=NULL,checkout_url=NULL,checkout_expires_at=0,subscription_id=NULL,status='checkout_pending',last_event_created=0,price_id=excluded.price_id,billing_mode=excluded.billing_mode,updated_at=excluded.updated_at WHERE (company_billing.checkout_id IS NOT NULL AND company_billing.checkout_expires_at<=? AND company_billing.status='checkout_pending') OR company_billing.checkout_started_at<=? OR company_billing.status IN ('canceled','incomplete_expired')").bind(co, attempt, now, price, now, mode, now, now - 23 * 36e5).run();
      const claimed = await db3.prepare("SELECT checkout_attempt FROM company_billing WHERE company_id=?").bind(co).first();
      if (claimed?.checkout_attempt !== attempt) fail(409, "Checkout is being prepared. Please retry.");
    }
    const success = new URL(companyPath("/billing/?result=success"), request2.url);
    success.searchParams.set("session_id", "{CHECKOUT_SESSION_ID}");
    const cancel = new URL(companyPath("/billing/?result=cancel"), request2.url);
    const params = checkoutParameters(price, success.href.replace("%7BCHECKOUT_SESSION_ID%7D", "{CHECKOUT_SESSION_ID}"), cancel.href);
    if (prior?.customer_id) {
      params.delete("subscription_data[trial_period_days]");
      params.set("customer", prior.customer_id);
    }
    params.set("client_reference_id", co);
    params.set("metadata[company_id]", co);
    params.set("metadata[attempt]", attempt);
    params.set("subscription_data[metadata][company_id]", co);
    params.set("subscription_data[metadata][attempt]", attempt);
    const session = await stripeCall("checkout/sessions", params, `company-checkout-${co}-${attempt}`);
    if (session.livemode !== stripeLive() || !session.id?.startsWith(stripeLive() ? "cs_live_" : "cs_test_") || !session.url?.startsWith("https://checkout.stripe.com/")) fail(502, "Stripe returned an unexpected checkout.");
    await db3.prepare("UPDATE company_billing SET checkout_id=?,checkout_url=?,checkout_expires_at=?,billing_interval=?,updated_at=? WHERE company_id=? AND checkout_attempt=?").bind(session.id, session.url, session.expires_at * 1e3, data.interval, now, co, attempt).run();
    if (stripeLive()) await db3.prepare("UPDATE company_registry SET billing_required=1 WHERE id=?").bind(co).run();
    return response({ url: session.url });
  } catch (error) {
    return handleError(error);
  }
}

// app/api/stripe-webhook/route.ts
var route_exports2 = {};
__export(route_exports2, {
  POST: () => POST2
});
init_chat_db();
import { env as env10 } from "cloudflare:workers";
async function POST2(request2) {
  try {
    if (!env10.STRIPE_WEBHOOK_SECRET?.startsWith("whsec_")) fail(503, "Payment notifications are not configured.");
    const body = await request2.text();
    if (body.length > 2e5) fail(413, "Event too large.");
    if (!await verifyStripeSignature(body, request2.headers.get("stripe-signature"), env10.STRIPE_WEBHOOK_SECRET)) fail(400, "Invalid Stripe signature.");
    const event = JSON.parse(body);
    if (event.livemode !== stripeLive() || !/^evt_[A-Za-z0-9]+$/.test(event.id) || !Number.isSafeInteger(event.created)) fail(400, "Unexpected Stripe environment.");
    const db3 = rawDb();
    if (await db3.prepare("SELECT id FROM stripe_billing_events WHERE id=?").bind(event.id).first()) return response({ received: true });
    const obj = event.data.object;
    let subId;
    if (event.type.startsWith("customer.subscription.")) subId = obj.id;
    else if (event.type === "checkout.session.completed" || event.type === "checkout.session.async_payment_succeeded") subId = obj.subscription;
    else if (["invoice.paid", "invoice.payment_failed", "invoice.payment_action_required"].includes(event.type)) subId = obj.subscription || obj.parent?.subscription_details?.subscription;
    else return response({ received: true, ignored: true });
    if (!subId || !/^sub_[A-Za-z0-9]+$/.test(subId)) return response({ received: true, ignored: true });
    const sub = await stripeCall("subscriptions/" + encodeURIComponent(subId));
    const co = sub.metadata?.company_id, attempt = sub.metadata?.attempt;
    if (sub.livemode !== stripeLive() || !co || !/^c_[a-f0-9]{16}$/.test(co) || !attempt) return response({ received: true, ignored: true });
    const row = await db3.prepare("SELECT billing_mode,checkout_attempt,subscription_id,last_event_created FROM company_billing WHERE company_id=?").bind(co).first();
    if (!row || row.billing_mode !== (stripeLive() ? "live" : "test") || row.checkout_attempt !== attempt || row.subscription_id && row.subscription_id !== sub.id) return response({ received: true, ignored: true });
    const item = sub.items.data[0], mapped = item && configuredPrice(item.price.id);
    const company = await db3.prepare("SELECT COALESCE(product_package,product_bundle) AS selected_plan FROM company_registry WHERE id=?").bind(co).first();
    if (sub.items.data.length !== 1 || item.quantity !== 1 || !mapped || mapped.plan !== company?.selected_plan || mapped.interval !== item.price.recurring.interval) fail(409, "Subscription does not match the company plan.");
    const now = Date.now();
    await db3.batch([
      db3.prepare("UPDATE company_billing SET payment_failed_at=CASE WHEN ? IN ('past_due','unpaid') THEN COALESCE(payment_failed_at,?) ELSE NULL END,trial_ends_at=?,cancel_at_period_end=?,customer_id=?,subscription_id=?,status=?,price_id=?,billing_interval=?,last_event_created=?,updated_at=? WHERE company_id=? AND checkout_attempt=? AND last_event_created<=? AND NOT EXISTS(SELECT 1 FROM stripe_billing_events WHERE id=?)").bind(sub.status, event.created * 1e3, sub.trial_end ? sub.trial_end * 1e3 : null, sub.cancel_at_period_end ? 1 : 0, sub.customer, sub.id, sub.status, item.price.id, mapped.interval, event.created, now, co, attempt, event.created, event.id),
      db3.prepare("INSERT OR IGNORE INTO stripe_billing_events(id,company_id,created,processed_at) VALUES(?,?,?,?)").bind(event.id, co, event.created, now)
    ]);
    return response({ received: true });
  } catch (error) {
    return handleError(error);
  }
}

// app/api/roster/route.ts
var route_exports4 = {};
__export(route_exports4, {
  GET: () => GET3,
  POST: () => POST4
});

// app/api/workspaces/route.ts
var route_exports3 = {};
__export(route_exports3, {
  GET: () => GET2,
  POST: () => POST3,
  companySetup: () => companySetup
});
init_company_context();
init_chat_db();
init_access();
init_security_events();
init_company_context();
init_request_context();
init_maintenance_links();
var endpoint = "https://fhqmnlpgqslllzrovxbp.supabase.co/functions/v1/company-setup";
async function companySetup(data) {
  const h = await headers(), scope = companyId();
  const r = await fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...data, scope, cookie: h.get("cookie") || "", viewer: h.get("X-Project-User") || "" }), signal: AbortSignal.timeout(3e4) });
  const result = await r.json();
  if (!r.ok) fail(r.status, String(result.error || "Company setup is unavailable."));
  return result;
}
async function GET2() {
  try {
    const me = await currentPerson();
    if (me.role !== "owner") fail(403, "Only the owner can manage company setup.");
    const row = await db().prepare("SELECT name,owner_id FROM workspace WHERE id=?").bind("main").first();
    if (row?.owner_id !== me.id) fail(403, "Owner access required.");
    return response({ companies: [{ id: companyId(), name: row.name, kind: "Your company", ready: true }], scope: companyId() });
  } catch (e) {
    return handleError(e);
  }
}
async function POST3(request2) {
  try {
    checkOrigin(request2);
    const me = await requireRecent(), scope = companyId();
    if (me.role !== "owner") fail(403, "Only the company owner can manage setup.");
    const owner3 = await db().prepare("SELECT owner_id FROM workspace WHERE id=?").bind("main").first();
    if (owner3?.owner_id !== me.id) fail(403, "Owner access required.");
    const data = await request2.json();
    if (!data || Array.isArray(data)) fail(400, "Check the company information.");
    const co = required(data.company, 18);
    if (!validCompany(co) || scope !== "main" && scope !== co) fail(403, "Company unavailable.");
    const registry = await rawDb().prepare("SELECT status FROM company_registry WHERE id=?").bind(co).first();
    if (registry && ["deleting", "archived"].includes(registry.status)) fail(403, "Company access is blocked. Restore an archived company from Platform Administration.");
    const action = required(data.action, 30);
    const products = await companyProducts();
    if (!products.hub && ["assets", "save_assets"].includes(action)) fail(403, "Maintenance Hub is not included in your plan.");
    if (action === "finish_signup") {
      if (scope !== co || !/^c_[a-f0-9]{16}$/.test(co)) fail(403, "Open your company workspace.");
      const workspace = await db().prepare("SELECT name FROM workspace WHERE id=?").bind("main").first();
      if (!products.hub) {
        await rawDb().prepare("UPDATE company_registry SET status='active' WHERE id=? AND owner_id=? AND status='owner_setup'").bind(co, me.id).run();
        return response({ ok: true });
      }
      const result = await companySetup({ action: "provision", company: co, name: workspace.name, ownerName: me.name, ownerChatId: me.id });
      await requireRecent();
      const encrypted = await encryptCompanyConnection(me.id, result.url, co);
      await db().prepare("INSERT INTO maintenance_links(user_id,environment,ciphertext,iv,connected_at) VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET ciphertext=excluded.ciphertext,iv=excluded.iv,connected_at=excluded.connected_at").bind(me.id, "live", encrypted.ciphertext, encrypted.iv, Date.now()).run();
      await rawDb().prepare("UPDATE company_registry SET status='active',hub_ready=1 WHERE id=? AND owner_id=? AND status NOT IN ('suspended','archived','deleting')").bind(co, me.id).run();
      return response({ ok: true });
    }
    if (action === "company_name") {
      if (scope !== co) fail(403, "Open your company administration.");
      const name = required(data.name, 60);
      if (co !== "main" && products.hub) {
        await companySetup({ action: "provision", company: co, name, ownerName: me.name, ownerChatId: me.id });
      }
      await db().prepare("UPDATE workspace SET name=? WHERE id=? AND owner_id=?").bind(name, "main", me.id).run();
      await rawDb().prepare("UPDATE company_registry SET name=? WHERE id=? AND owner_id=?").bind(name, co, me.id).run();
      return response({ ok: true });
    }
    if (co === "main") fail(400, "PMS assets are managed in the live Maintenance Hub.");
    if (action === "activate") {
      if (scope !== "main" || !["demo", "pilot"].includes(co)) fail(403, "Only Demo and Pilot use platform owner setup.");
      const name = required(data.name, 60), prefix = co + "_", now = Date.now();
      const existing = await rawDb().prepare("SELECT owner_id FROM " + prefix + "workspace WHERE id=?").bind("main").first(), ownerId = existing?.owner_id || crypto.randomUUID(), token = newToken(), gate = securityGate(me, "company_activated", ownerId);
      const batch = await rawDb().batch([
        gate.statement,
        rawDb().prepare("INSERT INTO " + prefix + "workspace (id,name,owner_id,created_at,access_bootstrapped,ai_enabled) SELECT ?,?,?,?,1,0 WHERE " + gate.condition + " ON CONFLICT(id) DO UPDATE SET name=excluded.name").bind("main", name, ownerId, now),
        rawDb().prepare("INSERT OR IGNORE INTO " + prefix + "people (id,email,name,role,active,joined_at,auth_version) SELECT owner_id,?,?,?,1,0,1 FROM " + prefix + "workspace WHERE id=? AND owner_id=? AND " + gate.condition).bind("", me.name, "owner", "main", ownerId),
        rawDb().prepare("INSERT INTO " + prefix + "access_tokens (token_hash,user_id,created_at,expires_at,purpose) SELECT ?,id,?,?,? FROM " + prefix + "people WHERE id=? AND passkey_enrolled=0 AND " + gate.condition + " ON CONFLICT(user_id) DO UPDATE SET token_hash=excluded.token_hash,created_at=excluded.created_at,expires_at=excluded.expires_at,purpose=excluded.purpose,used_at=0").bind(await tokenHash(token), now, now + INVITE_AGE, "invite", ownerId),
        ...["general", "maintenance", "announcements"].flatMap((n) => [rawDb().prepare("INSERT OR IGNORE INTO " + prefix + "rooms (id,name,description,kind,visibility,created_by,created_at) SELECT ?,?,?,?,?,?,? WHERE " + gate.condition).bind("room-" + n, n, "Your company\u2019s " + n + " conversation.", "channel", "shared", ownerId, now), rawDb().prepare("INSERT OR IGNORE INTO " + prefix + "room_members (room_id,user_id,read_at) SELECT ?,?,0 WHERE " + gate.condition).bind("room-" + n, ownerId)])
      ]);
      if (!batch[0].meta.changes) fail(401, "Your owner session changed. Sign in again.");
      const claimed = await rawDb().prepare("SELECT owner_id FROM " + prefix + "workspace WHERE id=?").bind("main").first();
      if (claimed?.owner_id !== ownerId) fail(409, "Company setup started in another window. Retry.");
      const result = await companySetup({ action: "provision", company: co, name, ownerName: me.name, ownerChatId: ownerId });
      await requireRecent();
      const encrypted = await encryptCompanyConnection(ownerId, result.url, co);
      await rawDb().prepare("INSERT INTO " + prefix + "maintenance_links (user_id,environment,ciphertext,iv,connected_at) VALUES (?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET ciphertext=excluded.ciphertext,iv=excluded.iv,connected_at=excluded.connected_at").bind(ownerId, "live", encrypted.ciphertext, encrypted.iv, now).run();
      await rawDb().prepare("INSERT INTO company_registry(id,name,owner_id,status,created_at,hub_ready) VALUES(?,?,?,'active',?,1) ON CONFLICT(id) DO UPDATE SET name=excluded.name,hub_ready=1").bind(co, name, ownerId, now).run();
      const enrolled = await rawDb().prepare("SELECT passkey_enrolled FROM " + prefix + "people WHERE id=?").bind(ownerId).first();
      return response({ ok: true, url: "/?company=" + co + (enrolled?.passkey_enrolled ? "" : "#access=" + token), name, needsPasskey: !enrolled?.passkey_enrolled });
    }
    if (action === "assets") return response(await companySetup({ action: "assets", company: co }));
    if (action === "save_assets") {
      if (!Array.isArray(data.assets) || data.assets.length < 1 || data.assets.length > 100) fail(400, "Add between 1 and 100 assets.");
      return response(await companySetup({ action: "save_assets", company: co, assets: data.assets }));
    }
    fail(400, "Unknown company setup action.");
  } catch (e) {
    return handleError(e);
  }
}

// app/api/roster/route.ts
init_chat_db();
init_company_context();
init_access();
init_security_events();
init_maintenance_links();

// lib/member-policy.ts
var MAX_ACTIVE_MEMBERS = 10;

// app/api/roster/route.ts
async function owner() {
  const me = await requireRecent();
  const w = await db().prepare("SELECT owner_id FROM workspace WHERE id=?").bind("main").first();
  if (me.role !== "owner" || w?.owner_id !== me.id) fail(403, "Only the company owner can invite employees.");
  return me;
}
async function roster() {
  return await companySetup({ action: "roster_list", company: companyId() });
}
async function GET3() {
  try {
    await owner();
    const list = await roster();
    const people = await db().prepare("SELECT id,name,email,active,passkey_enrolled,role FROM people").all();
    return response({ ...list, people: people.results });
  } catch (e) {
    return handleError(e);
  }
}
async function POST4(request2) {
  try {
    checkOrigin(request2);
    const me = await owner(), data = await request2.json();
    if (data.action !== "prepare") fail(400, "Choose an invitation action.");
    const employeeId = required(data.employeeId, 36), employees = (await roster()).employees, e = employees.find((x) => x.id === employeeId);
    if (!e || !e.eligible || !["employee", "shop", "manager"].includes(e.role) || !e.name) fail(403, "This employee is not eligible. Review access in the Hub.");
    const database = db(), co = companyId();
    let id = e.chatId || required(data.chatId, 36);
    if (id === "new") {
      id = e.id;
      const matches = await database.prepare("SELECT id FROM people WHERE lower(trim(name))=lower(trim(?)) OR (?<>? AND lower(trim(email))=lower(trim(?)))").bind(e.name, e.email || "", "", e.email || "").all();
      if (matches.results.some((p) => p.id !== id)) fail(409, "An existing Chat account may match. Choose it in the preview.");
      if (!await database.prepare("SELECT id FROM people WHERE id=?").bind(id).first()) {
        const gate2 = securityGate(me, "roster_member_created", id);
        const created = await database.batch([gate2.statement, database.prepare("INSERT OR IGNORE INTO people(id,email,name,role,active,joined_at,auth_version) SELECT ?,?,?,?,0,0,1 WHERE " + gate2.condition).bind(id, e.email || "", e.name, "member"), database.prepare("INSERT OR IGNORE INTO room_members(room_id,user_id,read_at) SELECT id,?,0 FROM rooms WHERE kind=? AND visibility=? AND " + gate2.condition).bind(id, "channel", "shared")]);
        if (!created[0].meta.changes) fail(401, "Sign in again.");
      }
    }
    const person = await database.prepare("SELECT name,active,passkey_enrolled,role FROM people WHERE id=?").bind(id).first();
    if (!person) fail(400, "Choose a Chat account.");
    if (!person.active && person.passkey_enrolled) fail(403, "This Chat account is disabled. Review it before linking.");
    if (person.role === "owner") fail(400, "Owner accounts cannot be mapped by the employee rollout.");
    if (!person.active) {
      const count = await database.prepare("SELECT COUNT(*) n FROM people WHERE active=1").first();
      if ((count?.n || 0) >= MAX_ACTIVE_MEMBERS) fail(409, "This company has reached its 10-member plan limit.");
    }
    const link = await companySetup({ action: "roster_link", company: co, employeeId: e.id, userId: id });
    const fresh = await owner(), gate = securityGate(fresh, "roster_invitation_prepared", id);
    const base = co === "main" ? "https://pms-company-hub.pages.dev" : "https://pms-company-hub.pages.dev", encrypted = await encryptCompanyConnection(id, base + "/#hub=" + encodeURIComponent(link.token), co), now = Date.now(), token = person.passkey_enrolled ? "" : newToken(), expiresAt = now + INVITE_AGE;
    const statements = [gate.statement, database.prepare("INSERT INTO maintenance_links(user_id,environment,ciphertext,iv,connected_at) SELECT ?,?,?,?,? WHERE " + gate.condition + " ON CONFLICT(user_id) DO UPDATE SET ciphertext=excluded.ciphertext,iv=excluded.iv,connected_at=excluded.connected_at").bind(id, "live", encrypted.ciphertext, encrypted.iv, now), database.prepare("UPDATE people SET active=1 WHERE id=? AND " + gate.condition).bind(id), database.prepare("INSERT INTO company_member_links(company,user_id,hub_role,request_key,created_at,status) SELECT ?,?,?,?,?,? WHERE " + gate.condition + " ON CONFLICT(company,user_id) DO UPDATE SET hub_role=excluded.hub_role,status=excluded.status").bind(co, id, link.role, e.id, now, "ready")];
    if (token) statements.push(database.prepare("INSERT INTO access_tokens(token_hash,user_id,created_at,expires_at,purpose) SELECT ?,?,?,?,? WHERE " + gate.condition + " ON CONFLICT(user_id) DO UPDATE SET token_hash=excluded.token_hash,created_at=excluded.created_at,expires_at=excluded.expires_at,used_at=0,purpose=excluded.purpose").bind(await tokenHash(token), id, now, expiresAt, "invite"));
    const result = await database.batch(statements);
    if (!result[0].meta.changes) fail(401, "Confirm owner access and retry.");
    const url = "https://teamstead-crew.pages.dev/" + (co === "main" ? "" : "?company=" + co) + (token ? "#access=" + token : "");
    return response({ employeeId: e.id, name: e.name, role: link.role, email: e.email, phone: e.phone, url, expiresAt: token ? expiresAt : null, alreadyJoined: !!person.passkey_enrolled });
  } catch (e) {
    return handleError(e);
  }
}

// worker/index.ts
init_app_errors();

// app/api/signup/route.ts
var route_exports5 = {};
__export(route_exports5, {
  POST: () => POST5
});
init_chat_db();

// lib/company-template.ts
var companyTemplate = [
  "CREATE TABLE IF NOT EXISTS `__CO___attachments` (\n	`id` text PRIMARY KEY NOT NULL,\n	`message_id` text NOT NULL,\n	`object_key` text NOT NULL,\n	`name` text NOT NULL,\n	`mime` text NOT NULL,\n	`size` integer NOT NULL,\n	FOREIGN KEY (`message_id`) REFERENCES `__CO___messages`(`id`) ON UPDATE no action ON DELETE no action\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___invitations` (\n	`email` text PRIMARY KEY NOT NULL,\n	`name` text NOT NULL,\n	`room_ids` text DEFAULT '[]' NOT NULL,\n	`created_at` integer NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___messages` (\n	`id` text PRIMARY KEY NOT NULL,\n	`room_id` text NOT NULL,\n	`user_id` text NOT NULL,\n	`parent_id` text,\n	`body` text NOT NULL,\n	`created_at` integer NOT NULL,\n	`edited_at` integer,\n	`deleted` integer DEFAULT 0 NOT NULL,\n	`pinned` integer DEFAULT 0 NOT NULL,\n	FOREIGN KEY (`room_id`) REFERENCES `__CO___rooms`(`id`) ON UPDATE no action ON DELETE no action,\n	FOREIGN KEY (`user_id`) REFERENCES `__CO___people`(`id`) ON UPDATE no action ON DELETE no action\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___people` (\n	`id` text PRIMARY KEY NOT NULL,\n	`email` text NOT NULL,\n	`name` text NOT NULL,\n	`role` text DEFAULT 'member' NOT NULL,\n	`active` integer DEFAULT 1 NOT NULL,\n	`joined_at` integer NOT NULL\n, `auth_version` integer DEFAULT 1 NOT NULL, `passkey_enrolled` integer DEFAULT 0 NOT NULL, `webauthn_user_id` text)",
  "CREATE TABLE IF NOT EXISTS `__CO___reactions` (\n	`message_id` text NOT NULL,\n	`user_id` text NOT NULL,\n	`emoji` text NOT NULL,\n	PRIMARY KEY(`message_id`, `user_id`, `emoji`),\n	FOREIGN KEY (`message_id`) REFERENCES `__CO___messages`(`id`) ON UPDATE no action ON DELETE no action,\n	FOREIGN KEY (`user_id`) REFERENCES `__CO___people`(`id`) ON UPDATE no action ON DELETE no action\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___room_members` (\n	`room_id` text NOT NULL,\n	`user_id` text NOT NULL,\n	`read_at` integer DEFAULT 0 NOT NULL,\n	PRIMARY KEY(`room_id`, `user_id`),\n	FOREIGN KEY (`room_id`) REFERENCES `__CO___rooms`(`id`) ON UPDATE no action ON DELETE no action,\n	FOREIGN KEY (`user_id`) REFERENCES `__CO___people`(`id`) ON UPDATE no action ON DELETE no action\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___rooms` (\n	`id` text PRIMARY KEY NOT NULL,\n	`name` text NOT NULL,\n	`description` text DEFAULT '' NOT NULL,\n	`kind` text DEFAULT 'channel' NOT NULL,\n	`visibility` text DEFAULT 'private' NOT NULL,\n	`dm_key` text,\n	`created_by` text NOT NULL,\n	`created_at` integer NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___workspace` (\n	`id` text PRIMARY KEY NOT NULL,\n	`name` text NOT NULL,\n	`owner_id` text NOT NULL,\n	`created_at` integer NOT NULL\n, `access_bootstrapped` integer DEFAULT 0 NOT NULL, `ai_enabled` integer DEFAULT 1 NOT NULL, logo_data text)",
  "CREATE TABLE IF NOT EXISTS `__CO___maintenance_links` (\n	`user_id` text PRIMARY KEY NOT NULL,\n	`environment` text NOT NULL,\n	`ciphertext` text NOT NULL,\n	`iv` text NOT NULL,\n	`connected_at` integer NOT NULL,\n	FOREIGN KEY (`user_id`) REFERENCES `__CO___people`(`id`) ON UPDATE no action ON DELETE no action\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___access_tokens` (\n	`token_hash` text PRIMARY KEY NOT NULL,\n	`user_id` text NOT NULL,\n	`created_at` integer NOT NULL, `expires_at` integer DEFAULT 0 NOT NULL, `used_at` integer DEFAULT 0 NOT NULL, `purpose` text DEFAULT 'invite' NOT NULL,\n	FOREIGN KEY (`user_id`) REFERENCES `__CO___people`(`id`) ON UPDATE no action ON DELETE no action\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___sessions` (\n	`session_hash` text PRIMARY KEY NOT NULL,\n	`user_id` text NOT NULL,\n	`auth_version` integer NOT NULL,\n	`expires_at` integer NOT NULL, `id` text, `auth_level` text DEFAULT 'legacy' NOT NULL, `setup_token_hash` text, `created_at` integer DEFAULT 0 NOT NULL, `verified_at` integer DEFAULT 0 NOT NULL, `last_seen_at` integer DEFAULT 0 NOT NULL, `device_label` text DEFAULT 'Browser' NOT NULL,\n	FOREIGN KEY (`user_id`) REFERENCES `__CO___people`(`id`) ON UPDATE no action ON DELETE no action\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___file_deletions` (\n	`object_key` text PRIMARY KEY NOT NULL,\n	`message_id` text,\n	`requested_by` text NOT NULL,\n	`requested_at` integer NOT NULL,\n	`attempts` integer DEFAULT 0 NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___passkey_challenges` (\n	`id` text PRIMARY KEY NOT NULL,\n	`challenge` text NOT NULL,\n	`purpose` text NOT NULL,\n	`browser_hash` text NOT NULL,\n	`user_id` text,\n	`session_hash` text,\n	`auth_version` integer,\n	`expires_at` integer NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___passkeys` (\n	`id` text PRIMARY KEY NOT NULL,\n	`user_id` text NOT NULL,\n	`public_key` text NOT NULL,\n	`webauthn_user_id` text NOT NULL,\n	`counter` integer DEFAULT 0 NOT NULL,\n	`transports` text DEFAULT '[]' NOT NULL,\n	`device_type` text NOT NULL,\n	`backed_up` integer DEFAULT 0 NOT NULL,\n	`name` text NOT NULL,\n	`created_at` integer NOT NULL,\n	`last_used_at` integer,\n	`last_challenge_id` text NOT NULL,\n	FOREIGN KEY (`user_id`) REFERENCES `__CO___people`(`id`) ON UPDATE no action ON DELETE no action\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___security_events` (\n	`id` text PRIMARY KEY NOT NULL,\n	`actor_id` text NOT NULL,\n	`target_id` text,\n	`action` text NOT NULL,\n	`at` integer NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___photo_budget` (\n	`id` integer PRIMARY KEY NOT NULL,\n	`used_bytes` integer DEFAULT 0 NOT NULL,\n	`limit_bytes` integer DEFAULT 67108864 NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS `__CO___photo_objects` (\n	`object_key` text PRIMARY KEY NOT NULL,\n	`size` integer NOT NULL,\n	`body` blob NOT NULL,\n	`created_at` integer NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS __CO___bot_preferences (user_id TEXT PRIMARY KEY REFERENCES __CO___people(id), enabled INTEGER NOT NULL DEFAULT 0, auth_version INTEGER NOT NULL, connection_iv TEXT NOT NULL, room_id TEXT NOT NULL UNIQUE REFERENCES __CO___rooms(id), actor_id TEXT, snapshot TEXT NOT NULL DEFAULT '[]', last_attempt INTEGER NOT NULL DEFAULT 0, last_checked INTEGER NOT NULL DEFAULT 0, last_error TEXT NOT NULL DEFAULT '', lease_until INTEGER NOT NULL DEFAULT 0, lease_token TEXT NOT NULL DEFAULT '', enabled_at INTEGER NOT NULL)",
  "CREATE TABLE IF NOT EXISTS __CO___bot_events (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES __CO___people(id), message_id TEXT NOT NULL REFERENCES __CO___messages(id), created_at INTEGER NOT NULL, push_done INTEGER NOT NULL DEFAULT 0)",
  "CREATE TABLE IF NOT EXISTS __CO___push_devices (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES __CO___people(id), auth_version INTEGER NOT NULL, subscription TEXT NOT NULL, created_at INTEGER NOT NULL, last_sent INTEGER NOT NULL DEFAULT 0)",
  "CREATE TABLE IF NOT EXISTS __CO___chat_notification_preferences (user_id TEXT PRIMARY KEY REFERENCES __CO___people(id), auth_version INTEGER NOT NULL, enabled INTEGER NOT NULL DEFAULT 0, enabled_at INTEGER NOT NULL, quiet_start INTEGER NOT NULL DEFAULT 1320, quiet_end INTEGER NOT NULL DEFAULT 420, quiet_enabled INTEGER NOT NULL DEFAULT 0, timezone TEXT NOT NULL DEFAULT 'UTC', muted_rooms TEXT NOT NULL DEFAULT '[]', last_attempt INTEGER NOT NULL DEFAULT 0, lease_until INTEGER NOT NULL DEFAULT 0, lease_token TEXT NOT NULL DEFAULT '')",
  "CREATE TABLE IF NOT EXISTS __CO___chat_push_receipts (device_id TEXT NOT NULL REFERENCES __CO___push_devices(id) ON DELETE CASCADE, message_id TEXT NOT NULL REFERENCES __CO___messages(id), created_at INTEGER NOT NULL, PRIMARY KEY(device_id,message_id))",
  "CREATE TABLE IF NOT EXISTS __CO___employee_status (user_id TEXT PRIMARY KEY REFERENCES __CO___people(id), status TEXT NOT NULL CHECK(status IN ('available','working','away','driving')), expires_at INTEGER NOT NULL, auth_version INTEGER NOT NULL)",
  "CREATE TABLE IF NOT EXISTS __CO___conversation_preferences (\n user_id TEXT NOT NULL REFERENCES __CO___people(id), room_id TEXT NOT NULL REFERENCES __CO___rooms(id),\n favorite INTEGER NOT NULL DEFAULT 0, section TEXT NOT NULL DEFAULT '',\n notification TEXT NOT NULL DEFAULT 'mentions' CHECK(notification IN ('all','mentions','muted')),\n PRIMARY KEY(user_id,room_id)\n)",
  "CREATE TABLE IF NOT EXISTS __CO___saved_messages (\n user_id TEXT NOT NULL REFERENCES __CO___people(id), message_id TEXT NOT NULL REFERENCES __CO___messages(id),\n saved_at INTEGER NOT NULL, PRIMARY KEY(user_id,message_id)\n)",
  "CREATE TABLE IF NOT EXISTS __CO___crew_profiles (\n user_id TEXT PRIMARY KEY REFERENCES __CO___people(id), job_title TEXT NOT NULL DEFAULT '',\n photo BLOB, photo_mime TEXT NOT NULL DEFAULT '', updated_at INTEGER NOT NULL DEFAULT 0\n, r2_key TEXT)",
  "CREATE INDEX IF NOT EXISTS `__CO___idx_attachments_message` ON `__CO___attachments` (`message_id`)",
  "CREATE INDEX IF NOT EXISTS `__CO___idx_messages_room_parent_created` ON `__CO___messages` (`room_id`,`parent_id`,`created_at`,`id`)",
  "CREATE INDEX IF NOT EXISTS `__CO___idx_messages_parent` ON `__CO___messages` (`parent_id`)",
  "CREATE INDEX IF NOT EXISTS `__CO___idx_room_members_user` ON `__CO___room_members` (`user_id`,`room_id`)",
  "CREATE UNIQUE INDEX IF NOT EXISTS `__CO___idx_rooms_dm_key` ON `__CO___rooms` (`dm_key`)",
  "CREATE UNIQUE INDEX IF NOT EXISTS `__CO___idx_access_tokens_user` ON `__CO___access_tokens` (`user_id`)",
  "CREATE INDEX IF NOT EXISTS `__CO___idx_sessions_user` ON `__CO___sessions` (`user_id`)",
  "CREATE INDEX IF NOT EXISTS `__CO___idx_sessions_expiry` ON `__CO___sessions` (`expires_at`)",
  "CREATE INDEX IF NOT EXISTS `__CO___idx_file_deletions_requester` ON `__CO___file_deletions` (`requested_by`)",
  "CREATE INDEX IF NOT EXISTS `__CO___idx_passkey_challenges_expiry` ON `__CO___passkey_challenges` (`expires_at`)",
  "CREATE INDEX IF NOT EXISTS `__CO___idx_passkeys_user` ON `__CO___passkeys` (`user_id`)",
  "CREATE INDEX IF NOT EXISTS `__CO___idx_security_events_at` ON `__CO___security_events` (`at`)",
  "CREATE INDEX IF NOT EXISTS `__CO___idx_security_events_target` ON `__CO___security_events` (`target_id`,`at`)",
  "CREATE INDEX IF NOT EXISTS __CO___idx_bot_events_push ON __CO___bot_events(push_done,created_at)",
  "CREATE INDEX IF NOT EXISTS __CO___idx_push_devices_user ON __CO___push_devices(user_id)",
  "CREATE TRIGGER IF NOT EXISTS __CO___photo_objects_validate BEFORE INSERT ON __CO___photo_objects\nWHEN NEW.size < 1 OR NEW.size > 524288 OR length(NEW.body) <> NEW.size\nBEGIN\n  SELECT RAISE(ABORT, 'PHOTO_SIZE_INVALID');\nEND",
  "CREATE TRIGGER IF NOT EXISTS __CO___photo_objects_quota BEFORE INSERT ON __CO___photo_objects\nWHEN COALESCE((SELECT limit_bytes - used_bytes FROM __CO___photo_budget WHERE id = 1), -1) < NEW.size\nBEGIN\n  SELECT RAISE(ABORT, 'PHOTO_BUDGET_FULL');\nEND",
  "CREATE TRIGGER IF NOT EXISTS __CO___photo_objects_account_insert AFTER INSERT ON __CO___photo_objects\nBEGIN\n  UPDATE __CO___photo_budget SET used_bytes = used_bytes + NEW.size WHERE id = 1;\nEND",
  "CREATE TRIGGER IF NOT EXISTS __CO___photo_objects_account_delete AFTER DELETE ON __CO___photo_objects\nBEGIN\n  UPDATE __CO___photo_budget SET used_bytes = used_bytes - OLD.size WHERE id = 1;\nEND",
  "CREATE TRIGGER IF NOT EXISTS __CO___photo_objects_no_update BEFORE UPDATE ON __CO___photo_objects\nBEGIN\n  SELECT RAISE(ABORT, 'PHOTO_REPLACEMENT_NOT_ALLOWED');\nEND"
];

// app/api/signup/route.ts
init_company_context();
init_access();
async function POST5(request2) {
  try {
    checkOrigin(request2);
    if (companyId() !== "main") fail(400, "Open the public signup page.");
    const raw = await request2.text();
    if (raw.length > 4e3) fail(413, "Check company information.");
    const data = JSON.parse(raw);
    if (!data || Array.isArray(data)) fail(400, "Check company information.");
    const secret = required(data.setupToken, 43);
    if (!/^[A-Za-z0-9_-]{43}$/.test(secret)) fail(400, "Reload signup and try again.");
    const hash = await tokenHash(secret), database = rawDb(), now = Date.now();
    if (data.action === "start") {
      const plan = data.plan ?? "combined";
      if (!validPlan(plan)) fail(400, "Choose Chat, Maintenance Hub, Parts Finder, or a bundle.");
      if (data.website) fail(400, "Check company information.");
      const name = required(data.name, 60), ownerName2 = required(data.ownerName, 60), co2 = "c_" + crypto.randomUUID().replaceAll("-", "").slice(0, 16), owner3 = crypto.randomUUID(), day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10), ip = await tokenHash("signup:" + day + ":" + (request2.headers.get("cf-connecting-ip") || "local"));
      const prior = await database.prepare("SELECT id,status FROM company_registry WHERE signup_key=?").bind(hash).first();
      if (prior) return response({ company: prior.id, status: prior.status });
      const legacyPlan = plan === "parts" ? "chat" : plan === "chat_parts" ? "chat" : plan === "hub_parts" ? "hub" : plan === "complete" ? "combined" : plan;
      const legacyBundle = plan === "chat_parts" ? "chat" : plan === "hub_parts" ? "hub" : plan;
      const statements = [database.prepare("INSERT INTO signup_limits(ip_hash,day,count) VALUES(?,?,1) ON CONFLICT(ip_hash,day) DO UPDATE SET count=count+1").bind(ip, day), database.prepare("INSERT INTO company_registry(id,name,owner_id,status,created_at,setup_hash,setup_expires,signup_key,product_plan,product_bundle,product_package,billing_required) SELECT ?,?,?,'building',?,?,?,?,?,?,?,? WHERE (SELECT signup_enabled FROM platform_settings WHERE id=1)=1 AND (SELECT COUNT(*) FROM company_registry WHERE id<>'main')<(SELECT company_limit FROM platform_settings WHERE id=1) AND (SELECT count FROM signup_limits WHERE ip_hash=? AND day=?)<=3").bind(co2, name, owner3, now, hash, now + 864e5, hash, legacyPlan, legacyBundle, plan, stripeLive() ? 1 : 0, ip, day)];
      const result = await database.batch(statements);
      if (!result[1].meta.changes) fail(429, "Company signup is temporarily at capacity. Contact the product owner or try again later.");
      return response({ company: co2, ownerName: ownerName2, status: "building" });
    }
    const co = required(data.company, 18);
    if (!/^c_[a-f0-9]{16}$/.test(co)) fail(400, "Check company selection.");
    const row = await database.prepare("SELECT *,COALESCE(product_package,product_bundle) AS selected_plan FROM company_registry WHERE id=? AND setup_hash=? AND setup_expires>?").bind(co, hash, now).first();
    if (!row) fail(401, "Signup expired. Open a new signup page.");
    if (["suspended", "archived", "deleting"].includes(row.status)) fail(403, "Company access is paused.");
    if (row.setup_cursor < companyTemplate.length) {
      const end = Math.min(row.setup_cursor + 16, companyTemplate.length);
      await database.batch([...companyTemplate.slice(row.setup_cursor, end).map((sql) => database.prepare(sql.replaceAll("__CO__", co))), database.prepare("UPDATE company_registry SET setup_cursor=max(setup_cursor,?) WHERE id=? AND setup_hash=?").bind(end, co, hash)]);
      return response({ company: co, status: "building", progress: Math.round(end / companyTemplate.length * 100) });
    }
    const ownerName = required(data.ownerName, 60), prefix = co + "_", invite = toBase64url(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode("company-owner:" + co + ":" + secret))));
    await database.batch([
      database.prepare("INSERT OR IGNORE INTO " + prefix + "workspace(id,name,owner_id,created_at,access_bootstrapped,ai_enabled) VALUES(?,?,?,?,1,0)").bind("main", row.name, row.owner_id, now),
      database.prepare("INSERT OR IGNORE INTO " + prefix + "people(id,email,name,role,active,joined_at,auth_version) VALUES(?,?,?,?,1,0,1)").bind(row.owner_id, "", ownerName, "owner"),
      database.prepare("INSERT OR IGNORE INTO " + prefix + "photo_budget(id,limit_bytes,used_bytes) VALUES(1,67108864,0)"),
      database.prepare("INSERT OR IGNORE INTO " + prefix + "access_tokens(token_hash,user_id,created_at,expires_at,purpose) VALUES(?,?,?,?,?)").bind(await tokenHash(invite), row.owner_id, now, now + INVITE_AGE, "invite"),
      ...(!["chat", "combined", "chat_parts", "complete"].includes(row.selected_plan) ? [] : ["chat", "chat_parts"].includes(row.selected_plan) ? ["general", "announcements"] : ["general", "maintenance", "announcements"]).flatMap((n) => [database.prepare("INSERT OR IGNORE INTO " + prefix + "rooms(id,name,description,kind,visibility,created_by,created_at) VALUES(?,?,?,?,?,?,?)").bind("room-" + n, n, "Your company\u2019s " + n + " conversation.", "channel", "shared", row.owner_id, now), database.prepare("INSERT OR IGNORE INTO " + prefix + "room_members(room_id,user_id,read_at) VALUES(?,?,0)").bind("room-" + n, row.owner_id)]),
      database.prepare("UPDATE company_registry SET status='owner_setup' WHERE id=? AND status='building'").bind(co)
    ]);
    return response({ company: co, status: "owner_setup", url: "/?company=" + co + "#access=" + invite });
  } catch (e) {
    return handleError(e);
  }
}

// app/api/platform/route.ts
var route_exports6 = {};
__export(route_exports6, {
  GET: () => GET4,
  POST: () => POST6
});

// lib/company-delete.ts
init_chat_db();
init_company_context();
import { env as env11 } from "cloudflare:workers";
init_app_errors();
var tableSql = companyTemplate.filter((s) => s.startsWith("CREATE TABLE"));
var remaining = tableSql.map((sql) => ({ name: sql.match(/__CO___([a-z_]+)/)[1], parents: [...sql.matchAll(/REFERENCES\s+`?__CO___([a-z_]+)/g)].map((m) => m[1]) }));
var deletionOrder = [];
while (remaining.length) {
  const i = remaining.findIndex((t) => !remaining.some((child) => child.name !== t.name && child.parents.includes(t.name)));
  if (i < 0) throw Error("Company table dependency cycle");
  deletionOrder.push(remaining.splice(i, 1)[0].name);
}
async function deleteCompany(co, confirmName, confirmed) {
  if (!validCompany(co) || co === "main") fail(400, "PMS cannot be deleted.");
  const database = rawDb(), row = await database.prepare("SELECT name,status,hub_ready,setup_cursor FROM company_registry WHERE id=?").bind(co).first();
  if (!row) fail(404, "Company not found.");
  if (confirmName !== row.name || confirmed !== true) fail(400, "Confirm permanent deletion with the company name.");
  if (!["archived", "deleting"].includes(row.status)) fail(409, "Archive the company before permanently deleting it.");
  const billing = await database.prepare("SELECT subscription_id,status FROM company_billing WHERE company_id=?").bind(co).first();
  if (billing?.subscription_id && !["canceled", "incomplete_expired"].includes(billing.status)) fail(409, "Cancel the company subscription before deleting it.");
  const lease = crypto.randomUUID();
  const lock = await database.prepare("UPDATE company_registry SET setup_hash=?,setup_expires=?,setup_cursor=CASE WHEN status='archived' THEN 0 ELSE setup_cursor END,status='deleting' WHERE id=? AND (status='archived' OR setup_expires<?) RETURNING id").bind(lease, Date.now() + 12e4, co, Date.now()).first();
  if (!lock) fail(409, "Company deletion is already running. Wait before resuming.");
  try {
    await companySetup({ action: "delete_begin", company: co });
    if (row.status === "archived") row.setup_cursor = 0;
    const prefix = "companies/" + co + "/";
    for (const bucket2 of [env11.CHAT_PHOTOS, env11.MAINTENANCE_PHOTOS]) {
      if (!bucket2) fail(503, "File storage is unavailable. Retry deletion later.");
      const page = await bucket2.list({ prefix, limit: 100 });
      if (page.objects.length) {
        const keys = page.objects.map((o) => o.key);
        if (keys.some((k) => !k.startsWith(prefix))) fail(500, "Company file boundary error.");
        await bucket2.delete(keys);
        await removeLedger(keys);
        return { done: false };
      }
    }
    {
      const result = await companySetup({ action: "delete_files", company: co, offset: row.setup_cursor });
      const keys = result.files;
      if (!Array.isArray(keys) || keys.length > 100 || keys.some((k) => typeof k !== "string" || !(/^(work-orders\/[0-9a-f-]{36}\/(problem|completion)|parts\/[0-9a-f-]{36})\/[0-9a-f-]{36}\.jpg$/.test(k) || /^manuals\/rides\/[0-9a-f-]{36}\.pdf$/.test(k)))) fail(500, "Company maintenance file boundary error.");
      if (keys.length) {
        await env11.MAINTENANCE_PHOTOS.delete(keys);
        await removeLedger(keys);
        await database.prepare("UPDATE company_registry SET setup_cursor=setup_cursor+? WHERE id=? AND status='deleting'").bind(keys.length, co).run();
        return { done: false };
      }
      await companySetup({ action: "delete_records", company: co });
    }
    const tables = await database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND substr(name,1,?)=?").bind(co.length + 1, co + "_").all();
    const present = new Set(tables.results.map((t) => t.name));
    const allowed = new Set(deletionOrder.map((t) => co + "_" + t));
    if ([...present].some((t) => !allowed.has(t))) fail(409, "An unknown company table needs review before deletion.");
    await database.batch([...deletionOrder.filter((t) => present.has(co + "_" + t)).map((t) => database.prepare('DROP TABLE "' + co + "_" + t + '"')), database.prepare("DELETE FROM company_member_links WHERE company=?").bind(co), database.prepare("DELETE FROM stripe_billing_events WHERE company_id=?").bind(co), database.prepare("DELETE FROM company_billing WHERE company_id=?").bind(co), database.prepare("DELETE FROM company_registry WHERE id=?").bind(co)]);
    return { done: true };
  } finally {
    await database.prepare("UPDATE company_registry SET setup_expires=0 WHERE id=? AND setup_hash=?").bind(co, lease).run();
  }
}
async function removeLedger(keys) {
  const database = rawDb();
  for (const table of ["r2_objects", "r2_manual_objects"]) await database.prepare("DELETE FROM " + table + " WHERE object_key IN (" + keys.map(() => "?").join(",") + ")").bind(...keys).run();
}

// lib/billing-connection-check.ts
init_chat_db();
import { env as env12 } from "cloudflare:workers";
init_app_errors();
async function billingConnectionCheck() {
  const prices2 = [];
  for (const plan of PRODUCT_PLANS) for (const interval of ["month", "year"]) {
    const name = `STRIPE_PRICE_${plan.toUpperCase()}_${interval.toUpperCase()}`;
    const id = env12[name];
    if (typeof id !== "string" || !/^price_[A-Za-z0-9]+$/.test(id)) fail(503, "A billing price is not configured.");
    const p = await stripeCall(`prices/${id}`);
    prices2.push({ plan, interval, verified: p.object === "price" && p.id === id && p.active === true && p.livemode === stripeLive() && p.recurring?.interval === interval });
  }
  const rows = await rawDb().prepare("SELECT company_id,customer_id,subscription_id,price_id,checkout_attempt,status,cancel_at_period_end FROM company_billing WHERE billing_mode=? AND subscription_id IS NOT NULL LIMIT 21").bind(stripeLive() ? "live" : "test").all();
  if (rows.results.length > 20) fail(503, "Review billing capacity before continuing.");
  const subscriptions = [];
  for (const row of rows.results) {
    if (!/^sub_[A-Za-z0-9]+$/.test(row.subscription_id)) fail(503, "A subscription mapping is invalid.");
    const s = await stripeCall(`subscriptions/${row.subscription_id}`);
    subscriptions.push({ company: row.company_id, status: s.status, verified: s.object === "subscription" && s.id === row.subscription_id && s.livemode === stripeLive() && s.customer === row.customer_id && s.metadata?.company_id === row.company_id && s.metadata?.attempt === row.checkout_attempt && s.status === row.status && s.cancel_at_period_end === !!row.cancel_at_period_end && s.items?.data.some((i) => i.price.id === row.price_id) });
  }
  return { readOnly: true, stripeMode: stripeLive() ? "live" : "test", verified: prices2.every((p) => p.verified) && subscriptions.every((s) => s.verified), prices: prices2, subscriptions, webhookSecretConfigured: !!env12.STRIPE_WEBHOOK_SECRET?.startsWith("whsec_"), webhookSignatureDeliveryVerified: false };
}

// app/api/platform/route.ts
init_chat_db();
init_company_context();
init_access();
async function owner2(recent = false) {
  const me = recent ? await requireRecent() : await currentPerson();
  if (companyId() !== "main" || me.role !== "owner") fail(403, "Platform owner access required.");
  const row = await rawDb().prepare("SELECT owner_id FROM workspace WHERE id=?").bind("main").first();
  if (row?.owner_id !== me.id) fail(403, "Platform owner access required.");
  return me;
}
async function GET4(request2) {
  try {
    await owner2();
    if (new URL(request2.url).searchParams.get("billingCheck") === "1") return response(await billingConnectionCheck());
    const rows = await rawDb().prepare("SELECT id,name,status,created_at,hub_ready FROM company_registry ORDER BY created_at").all();
    const existing = new Set(rows.results.map((r) => r.id));
    const companies = [...rows.results, ...["demo", "pilot"].filter((id) => !existing.has(id)).map((id) => ({ id, name: id === "demo" ? "Demo Company" : "Pilot Company", status: "not_created", hub_ready: 0 }))];
    const settings = await rawDb().prepare("SELECT signup_enabled,company_limit FROM platform_settings WHERE id=1").first();
    return response({ companies, settings });
  } catch (e) {
    return handleError(e);
  }
}
async function POST6(request2) {
  try {
    checkOrigin(request2);
    await owner2(true);
    const data = await request2.json();
    if (data.action === "company_delete") {
      const co = required(data.company, 18);
      return response(await deleteCompany(co, data.confirmName, data.confirmed));
    }
    if (data.action === "signup_settings") {
      const limit = Number(data.companyLimit);
      if (!Number.isInteger(limit) || limit < 1 || limit > 20) fail(400, "Choose a pilot capacity between 1 and 20 companies.");
      await rawDb().prepare("UPDATE platform_settings SET signup_enabled=?,company_limit=? WHERE id=1").bind(data.enabled ? 1 : 0, limit).run();
      return response({ ok: true });
    }
    if (data.action === "company_archive" || data.action === "company_restore") {
      const co = required(data.company, 18);
      if (!validCompany(co) || co === "main") fail(400, "PMS cannot be archived.");
      const row = await rawDb().prepare("SELECT name,status,hub_ready FROM company_registry WHERE id=?").bind(co).first();
      if (!row) fail(404, "Company not found.");
      if (row.status === "deleting") fail(409, "Deletion has started and cannot be restored.");
      if (row.status === "building") fail(409, "Wait for company setup to finish.");
      const restore = data.action === "company_restore";
      if (restore && row.status !== "archived") fail(409, "Company is not archived.");
      if (!restore && data.confirmName !== row.name) fail(400, "Enter the company name to confirm.");
      if (row.hub_ready) await companySetup({ action: "platform_status", company: co, active: restore });
      await owner2(true);
      await rawDb().prepare("UPDATE company_registry SET status=? WHERE id=?").bind(restore ? row.hub_ready ? "active" : "owner_setup" : "archived", co).run();
      return response({ ok: true });
    }
    if (data.action === "company_status") {
      const co = required(data.company, 18);
      if (!validCompany(co) || co === "main") fail(400, "Choose a customer company.");
      const row = await rawDb().prepare("SELECT hub_ready,status FROM company_registry WHERE id=?").bind(co).first();
      if (!row) fail(404, "Company not found.");
      if (["archived", "deleting"].includes(row.status)) fail(409, "Restore the archived company first.");
      const active = data.active === true;
      if (row.hub_ready) await companySetup({ action: "platform_status", company: co, active });
      await owner2(true);
      await rawDb().prepare("UPDATE company_registry SET status=? WHERE id=?").bind(active ? row.hub_ready ? "active" : "owner_setup" : "suspended", co).run();
      return response({ ok: true });
    }
    fail(400, "Choose a supported platform action.");
  } catch (e) {
    return handleError(e);
  }
}

// worker/index.ts
init_company_context();

// lib/workspace-attestation.ts
init_company_context();
init_access();
init_chat_db();
init_company_context();
async function workspaceAttestation(request2) {
  try {
    const at = request2.headers.get("x-signed-at") || "", sig = request2.headers.get("x-signature") || "";
    if (!/^\d{13}$/.test(at) || Math.abs(Date.now() - Number(at)) > 6e4 || !/^[A-Za-z0-9_-]{86}$/.test(sig)) fail(401, "Access denied.");
    const body = await request2.text();
    if (body.length > 12e3) fail(413, "Request too large.");
    const hex2 = async (text) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text))), (v) => v.toString(16).padStart(2, "0")).join("");
    const signed = new TextEncoder().encode(["pms-company-v1", at, await hex2(request2.headers.get("cookie") || ""), await hex2(body)].join("\n"));
    const key2 = await crypto.subtle.importKey("jwk", BRIDGE_PUBLIC_KEY, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
    if (!await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key2, Uint8Array.from(atob(sig.replace(/-/g, "+").replace(/_/g, "/") + "=="), (x) => x.charCodeAt(0)), signed)) fail(401, "Access denied.");
    const data = JSON.parse(body), me = await currentSession(), scope = companyId();
    if (me.verified_at < Date.now() - 3e5) fail(428, "Confirm your passkey to continue.");
    const owner3 = await db().prepare("SELECT owner_id FROM workspace WHERE id=?").bind("main").first();
    if (me.role !== "owner" || owner3?.owner_id !== me.id || !validCompany(data.company) || scope !== "main" && scope !== data.company) fail(403, "Only this company\u2019s owner can manage its setup.");
    return response({ ok: true, company: data.company, actor: { id: me.id, name: me.name }, scope, platform: scope === "main" });
  } catch (e) {
    return handleError(e);
  }
}

// app/api/access/route.ts
var route_exports7 = {};
__export(route_exports7, {
  GET: () => GET5,
  POST: () => POST7,
  dynamic: () => dynamic
});

// lib/company-members.ts
init_company_context();
init_chat_db();
init_access();
init_maintenance_links();
init_access();
init_security_events();
async function connectCombinedMember(id, name, hubRole) {
  const co = companyId(), result = await companySetup({ action: "member_invite", company: co, userId: id, name, hubRole });
  await requireRecent();
  const url = (co === "main" ? "https://pms-company-hub.pages.dev" : "https://pms-company-hub.pages.dev") + "/#hub=" + encodeURIComponent(result.token);
  {
    const encrypted = await encryptCompanyConnection(id, url, co);
    await db().prepare("INSERT INTO maintenance_links(user_id,environment,ciphertext,iv,connected_at) VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET ciphertext=excluded.ciphertext,iv=excluded.iv,connected_at=excluded.connected_at").bind(id, "live", encrypted.ciphertext, encrypted.iv, Date.now()).run();
  }
  await rawDb().prepare("UPDATE company_member_links SET status='ready' WHERE company=? AND user_id=?").bind(co, id).run();
  return true;
}
async function revokeCombinedMember(id) {
  const row = await rawDb().prepare("SELECT user_id FROM company_member_links WHERE company=? AND user_id=?").bind(companyId(), id).first();
  if (!row) return;
  if ((await companyProducts()).hub) await companySetup({ action: "member_revoke", company: companyId(), userId: id });
  await rawDb().prepare("UPDATE company_member_links SET status='revoked' WHERE company=? AND user_id=?").bind(companyId(), id).run();
}
async function createCombinedInvitation(me, data) {
  const name = required(data.name, 60), hubRole = required(data.hubRole, 10), requestKey = required(data.requestKey, 36);
  if (!["employee", "shop", "manager"].includes(hubRole) || !/^[a-f0-9-]{36}$/.test(requestKey)) fail(400, "Choose an employee role.");
  const co = companyId(), database = db(), prior = await rawDb().prepare("SELECT user_id,hub_role FROM company_member_links WHERE company=? AND request_key=?").bind(co, requestKey).first(), id = prior?.user_id || crypto.randomUUID(), now = Date.now();
  if (prior) {
    const person2 = await database.prepare("SELECT name,passkey_enrolled FROM people WHERE id=?").bind(id).first();
    if (!person2 || person2.passkey_enrolled) fail(409, "This invitation has already been accepted.");
  } else {
    const count = await database.prepare("SELECT COUNT(*) n FROM people WHERE active=1").first();
    if ((count?.n || 0) >= MAX_ACTIVE_MEMBERS) fail(409, "This company has reached its 10-member plan limit.");
    const roomIds = Array.isArray(data.roomIds) ? Array.from(new Set(data.roomIds.filter((v) => typeof v === "string"))).slice(0, 20) : [];
    for (const roomId of roomIds) if (!await database.prepare("SELECT r.id FROM rooms r JOIN room_members rm ON rm.room_id=r.id WHERE r.id=? AND rm.user_id=? AND r.kind=?").bind(roomId, me.id, "channel").first()) fail(400, "Choose your company\u2019s channels.");
    const gate2 = securityGate(me, "combined_invitation_created", id);
    const result = await database.batch([gate2.statement, database.prepare("INSERT INTO people(id,email,name,role,active,joined_at,auth_version) SELECT ?,?,?,?,0,0,1 WHERE " + gate2.condition).bind(id, "", name, "member"), database.prepare("INSERT INTO company_member_links(company,user_id,hub_role,request_key,created_at) SELECT ?,?,?,?,? WHERE " + gate2.condition).bind(co, id, hubRole, requestKey, now), database.prepare("INSERT OR IGNORE INTO room_members(room_id,user_id,read_at) SELECT id,?,0 FROM rooms WHERE kind=? AND visibility=? AND " + gate2.condition).bind(id, "channel", "shared"), ...roomIds.map((roomId) => database.prepare("INSERT OR IGNORE INTO room_members(room_id,user_id,read_at) SELECT ?,?,0 WHERE " + gate2.condition).bind(roomId, id))]);
    if (!result[0].meta.changes) fail(401, "Your session changed. Sign in again.");
  }
  const products = await companyProducts();
  const person = await database.prepare("SELECT name FROM people WHERE id=?").bind(id).first();
  if (products.hub) await connectCombinedMember(id, person.name, prior?.hub_role || hubRole);
  const fresh = await requireRecent(), gate = securityGate(fresh, "combined_invitation_ready", id), token = newToken(), expiresAt = now + INVITE_AGE;
  const ready = await database.batch([gate.statement, database.prepare("UPDATE people SET active=1 WHERE id=? AND " + gate.condition).bind(id), database.prepare("INSERT INTO access_tokens(token_hash,user_id,created_at,expires_at,purpose) SELECT ?,?,?,?,? WHERE " + gate.condition + " ON CONFLICT(user_id) DO UPDATE SET token_hash=excluded.token_hash,created_at=excluded.created_at,expires_at=excluded.expires_at,used_at=0").bind(await tokenHash(token), id, now, expiresAt, "invite")]);
  if (!ready[0].meta.changes) fail(401, "Confirm owner access and retry.");
  return { id, name: person.name, token, expiresAt, maintenanceConnected: products.hub, maintenanceError: null };
}

// app/api/access/route.ts
init_chat_db();
init_access();
init_maintenance_links();
init_security_events();
var dynamic = "force-dynamic";
var accessWindows = /* @__PURE__ */ new Map();
function limitExchange(request2) {
  const identity = request2.headers.get("cf-connecting-ip") || "local";
  const now = Date.now(), prior = accessWindows.get(identity);
  if (prior && now - prior.start < 6e4) {
    if (++prior.count > 120) fail(429, "Too many sign-in attempts. Wait a minute and try again.");
  } else {
    if (accessWindows.size > 2e3) accessWindows.clear();
    accessWindows.set(identity, { start: now, count: 1 });
  }
}
async function GET5() {
  try {
    const p = await currentSession(true);
    return response({ level: p.auth_level, user: { id: p.id, name: p.name } });
  } catch (e) {
    if (e instanceof ChatError && e.status === 401) return response({ level: "signed_out" });
    return handleError(e);
  }
}
async function POST7(request2) {
  try {
    checkOrigin(request2);
    if (!request2.headers.get("content-type")?.startsWith("application/json")) fail(415, "Use a supported sign-in format.");
    const raw = await request2.text();
    if (raw.length > 1e4) fail(413, "This request is too large.");
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      fail(400, "Please try again.");
    }
    if (!data || typeof data !== "object" || Array.isArray(data)) fail(400, "Please try again.");
    if (data.action === "inspect_link") {
      limitExchange(request2);
      return response(await inspectPersonalLink(data.token));
    }
    if (data.action === "login") {
      limitExchange(request2);
      const result = await exchangePersonalLink(data.token);
      const res = response({ ok: true, level: "setup" });
      res.headers.set("Set-Cookie", result.cookie);
      return res;
    }
    if (data.action === "logout") {
      const cookie = await signOut();
      const res = response({ ok: true });
      res.headers.set("Set-Cookie", cookie);
      return res;
    }
    const me = await requireRecent();
    if (!["owner", "admin"].includes(me.role)) fail(403, "Only an owner or admin can manage invitations.");
    if (data.action === "set_member_role") {
      if (me.role !== "owner") fail(403, "Only the owner can grant or remove admin access.");
      const userId = required(data.userId), role = required(data.role, 10);
      if (!["member", "admin"].includes(role)) fail(400, "Choose Member or Admin.");
      if (userId === me.id) fail(400, "The owner must retain owner access.");
      const gate = securityGate(me, "member_role_" + role, userId);
      const result = await db().batch([gate.statement, db().prepare("UPDATE people SET role=? WHERE id=? AND active=1 AND role IN ('member','admin') AND " + gate.condition).bind(role, userId)]);
      if (!result[0].meta.changes) fail(401, "Your session changed. Sign in again.");
      if (!result[1].meta.changes) fail(404, "Choose an active member or admin.");
      return response({ ok: true });
    }
    if (me.role === "admin") {
      if (data.combined === true || data.maintenanceLink) fail(403, "Ask the owner to manage Maintenance Hub invitations.");
      if (data.action === "reset_link") {
        const target = await db().prepare("SELECT role FROM people WHERE id=? AND active=1").bind(required(data.userId)).first();
        if (!target || target.role !== "member") fail(403, "Admins can reset member access only.");
      }
    }
    if (data.action === "create_member") {
      if (data.combined === true) return response(await createCombinedInvitation(me, data), 201);
      const name = required(data.name, 60), id = crypto.randomUUID(), token = newToken(), now = Date.now(), expiresAt = now + INVITE_AGE;
      const roomIds = Array.isArray(data.roomIds) ? Array.from(new Set(data.roomIds.filter((v) => typeof v === "string"))).slice(0, 80) : [];
      for (const roomId of roomIds) if (!await db().prepare("SELECT r.id FROM rooms r JOIN room_members rm ON rm.room_id = r.id WHERE r.id = ? AND rm.user_id = ? AND r.kind = ?").bind(roomId, me.id, "channel").first()) fail(400, "Choose channels you belong to.");
      if (data.maintenanceLink) parsePersonalLink(data.maintenanceLink);
      const gate = securityGate(me, "invitation_created", id);
      const result = await db().batch([
        gate.statement,
        db().prepare("INSERT INTO people (id,email,name,role,active,joined_at,auth_version) SELECT ?,?,?,?,1,0,1 WHERE " + gate.condition).bind(id, "", name, "member"),
        db().prepare("INSERT INTO access_tokens (token_hash,user_id,created_at,expires_at,purpose) SELECT ?,?,?,?,? WHERE " + gate.condition).bind(await tokenHash(token), id, now, expiresAt, "invite"),
        db().prepare("INSERT OR IGNORE INTO room_members (room_id,user_id,read_at) SELECT id,?,0 FROM rooms WHERE kind = ? AND visibility = ? AND " + gate.condition).bind(id, "channel", "shared"),
        ...roomIds.map((roomId) => db().prepare("INSERT OR IGNORE INTO room_members (room_id,user_id,read_at) SELECT ?,?,0 WHERE " + gate.condition).bind(roomId, id))
      ]);
      if (!result[0].meta.changes) fail(401, "Your session changed. Sign in again to add a person.");
      let maintenanceConnected = false, maintenanceError = null;
      if (data.maintenanceLink) try {
        await requireRecent();
        await saveConnection(id, data.maintenanceLink, me);
        maintenanceConnected = true;
      } catch {
        maintenanceError = "The invitation was created, but the Maintenance link could not be saved. Connect it from Maintenance after sign-in.";
      }
      return response({ id, name, token, expiresAt, maintenanceConnected, maintenanceError }, 201);
    }
    if (data.action === "reset_link") {
      if (data.confirmRecovery !== true) fail(400, "Confirm that the person requested account recovery before continuing.");
      const userId = required(data.userId);
      const result = await resetPersonalLink(userId, me);
      return response({ ...result, userId });
    }
    fail(400, "Unknown access change.");
  } catch (e) {
    return handleError(e);
  }
}

// app/api/passkeys/route.ts
var route_exports8 = {};
__export(route_exports8, {
  POST: () => POST8,
  dynamic: () => dynamic2
});

// lib/passkeys.ts
init_company_context();
init_request_context();
import { env as env13 } from "cloudflare:workers";

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoBase64URL.js
var isoBase64URL_exports = {};
__export(isoBase64URL_exports, {
  fromBuffer: () => fromBuffer,
  fromUTF8String: () => fromUTF8String,
  isBase64: () => isBase64,
  isBase64URL: () => isBase64URL,
  toBase64: () => toBase64,
  toBuffer: () => toBuffer,
  toUTF8String: () => toUTF8String,
  trimPadding: () => trimPadding
});

// node_modules/@hexagon/base64/src/base64.js
var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var charsUrl = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
var genLookup = (target) => {
  const lookupTemp = typeof Uint8Array === "undefined" ? [] : new Uint8Array(256);
  const len = chars.length;
  for (let i = 0; i < len; i++) {
    lookupTemp[target.charCodeAt(i)] = i;
  }
  return lookupTemp;
};
var lookup = genLookup(chars);
var lookupUrl = genLookup(charsUrl);
var base64UrlPattern = /^[-A-Za-z0-9\-_]*$/;
var base64Pattern = /^[-A-Za-z0-9+/]*={0,3}$/;
var base642 = {};
base642.toArrayBuffer = (data, urlMode) => {
  const len = data.length;
  let bufferLength = data.length * 0.75, i, p = 0, encoded1, encoded2, encoded3, encoded4;
  if (data[data.length - 1] === "=") {
    bufferLength--;
    if (data[data.length - 2] === "=") {
      bufferLength--;
    }
  }
  const arraybuffer = new ArrayBuffer(bufferLength), bytes = new Uint8Array(arraybuffer), target = urlMode ? lookupUrl : lookup;
  for (i = 0; i < len; i += 4) {
    encoded1 = target[data.charCodeAt(i)];
    encoded2 = target[data.charCodeAt(i + 1)];
    encoded3 = target[data.charCodeAt(i + 2)];
    encoded4 = target[data.charCodeAt(i + 3)];
    bytes[p++] = encoded1 << 2 | encoded2 >> 4;
    bytes[p++] = (encoded2 & 15) << 4 | encoded3 >> 2;
    bytes[p++] = (encoded3 & 3) << 6 | encoded4 & 63;
  }
  return arraybuffer;
};
base642.fromArrayBuffer = (arrBuf, urlMode) => {
  const bytes = new Uint8Array(arrBuf);
  let i, result = "";
  const len = bytes.length, target = urlMode ? charsUrl : chars;
  for (i = 0; i < len; i += 3) {
    result += target[bytes[i] >> 2];
    result += target[(bytes[i] & 3) << 4 | bytes[i + 1] >> 4];
    result += target[(bytes[i + 1] & 15) << 2 | bytes[i + 2] >> 6];
    result += target[bytes[i + 2] & 63];
  }
  const remainder = len % 3;
  if (remainder === 2) {
    result = result.substring(0, result.length - 1) + (urlMode ? "" : "=");
  } else if (remainder === 1) {
    result = result.substring(0, result.length - 2) + (urlMode ? "" : "==");
  }
  return result;
};
base642.toString = (str2, urlMode) => {
  return new TextDecoder().decode(base642.toArrayBuffer(str2, urlMode));
};
base642.fromString = (str2, urlMode) => {
  return base642.fromArrayBuffer(new TextEncoder().encode(str2), urlMode);
};
base642.validate = (encoded, urlMode) => {
  if (!(typeof encoded === "string" || encoded instanceof String)) {
    return false;
  }
  try {
    return urlMode ? base64UrlPattern.test(encoded) : base64Pattern.test(encoded);
  } catch (_e) {
    return false;
  }
};
base642.base64 = base642;
var base64_default = base642;

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoBase64URL.js
function toBuffer(base64urlString, from = "base64url") {
  const _buffer = base64_default.toArrayBuffer(base64urlString, from === "base64url");
  return new Uint8Array(_buffer);
}
function fromBuffer(buffer, to = "base64url") {
  const _normalized = new Uint8Array(buffer);
  return base64_default.fromArrayBuffer(_normalized.buffer, to === "base64url");
}
function toBase64(base64urlString) {
  const fromBase64Url = base64_default.toArrayBuffer(base64urlString, true);
  const toBase642 = base64_default.fromArrayBuffer(fromBase64Url);
  return toBase642;
}
function fromUTF8String(utf8String) {
  return base64_default.fromString(utf8String, true);
}
function toUTF8String(base64urlString) {
  return base64_default.toString(base64urlString, true);
}
function isBase64(input) {
  return base64_default.validate(input, false);
}
function isBase64URL(input) {
  input = trimPadding(input);
  return base64_default.validate(input, true);
}
function trimPadding(input) {
  return input.replace(/=/g, "");
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCBOR.js
var isoCBOR_exports = {};
__export(isoCBOR_exports, {
  decodeFirst: () => decodeFirst,
  encode: () => encode
});

// node_modules/@levischuck/tiny-cbor/esm/cbor/cbor_internal.js
function decodeLength(data, argument, index) {
  if (argument < 24) {
    return [argument, 1];
  }
  const remainingDataLength = data.byteLength - index - 1;
  const view = new DataView(data.buffer, index + 1);
  let output;
  let bytes = 0;
  switch (argument) {
    case 24: {
      if (remainingDataLength > 0) {
        output = view.getUint8(0);
        bytes = 2;
      }
      break;
    }
    case 25: {
      if (remainingDataLength > 1) {
        output = view.getUint16(0, false);
        bytes = 3;
      }
      break;
    }
    case 26: {
      if (remainingDataLength > 3) {
        output = view.getUint32(0, false);
        bytes = 5;
      }
      break;
    }
    case 27: {
      if (remainingDataLength > 7) {
        const bigOutput = view.getBigUint64(0, false);
        if (bigOutput >= 24n && bigOutput <= Number.MAX_SAFE_INTEGER) {
          return [Number(bigOutput), 9];
        }
      }
      break;
    }
  }
  if (output && output >= 24) {
    return [output, bytes];
  }
  throw new Error("Length not supported or not well formed");
}
var MAJOR_TYPE_UNSIGNED_INTEGER = 0;
var MAJOR_TYPE_NEGATIVE_INTEGER = 1;
var MAJOR_TYPE_BYTE_STRING = 2;
var MAJOR_TYPE_TEXT_STRING = 3;
var MAJOR_TYPE_ARRAY = 4;
var MAJOR_TYPE_MAP = 5;
var MAJOR_TYPE_TAG = 6;
var MAJOR_TYPE_SIMPLE_OR_FLOAT = 7;
function encodeLength(major, argument) {
  const majorEncoded = major << 5;
  if (argument < 0) {
    throw new Error("CBOR Data Item argument must not be negative");
  }
  let bigintArgument;
  if (typeof argument == "number") {
    if (!Number.isInteger(argument)) {
      throw new Error("CBOR Data Item argument must be an integer");
    }
    bigintArgument = BigInt(argument);
  } else {
    bigintArgument = argument;
  }
  if (major == MAJOR_TYPE_NEGATIVE_INTEGER) {
    if (bigintArgument == 0n) {
      throw new Error("CBOR Data Item argument cannot be zero when negative");
    }
    bigintArgument = bigintArgument - 1n;
  }
  if (bigintArgument > 18446744073709551615n) {
    throw new Error("CBOR number out of range");
  }
  const buffer = new Uint8Array(8);
  const view = new DataView(buffer.buffer);
  view.setBigUint64(0, bigintArgument, false);
  if (bigintArgument <= 23) {
    return [majorEncoded | buffer[7]];
  } else if (bigintArgument <= 255) {
    return [majorEncoded | 24, buffer[7]];
  } else if (bigintArgument <= 65535) {
    return [majorEncoded | 25, ...buffer.slice(6)];
  } else if (bigintArgument <= 4294967295) {
    return [
      majorEncoded | 26,
      ...buffer.slice(4)
    ];
  } else {
    return [
      majorEncoded | 27,
      ...buffer
    ];
  }
}

// node_modules/@levischuck/tiny-cbor/esm/cbor/cbor.js
var CBORTag = class {
  /**
   * Wrap a value with a tag number.
   * When encoded, this tag will be attached to the value.
   *
   * @param tag Tag number
   * @param value Wrapped value
   */
  constructor(tag, value) {
    Object.defineProperty(this, "tagId", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "tagValue", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    this.tagId = tag;
    this.tagValue = value;
  }
  /**
   * Read the tag number
   */
  get tag() {
    return this.tagId;
  }
  /**
   * Read the value
   */
  get value() {
    return this.tagValue;
  }
};
function decodeUnsignedInteger(data, argument, index) {
  return decodeLength(data, argument, index);
}
function decodeNegativeInteger(data, argument, index) {
  const [value, length] = decodeUnsignedInteger(data, argument, index);
  return [-value - 1, length];
}
function decodeByteString(data, argument, index) {
  const [lengthValue, lengthConsumed] = decodeLength(data, argument, index);
  const dataStartIndex = index + lengthConsumed;
  return [
    new Uint8Array(data.buffer.slice(dataStartIndex, dataStartIndex + lengthValue)),
    lengthConsumed + lengthValue
  ];
}
var TEXT_DECODER = new TextDecoder();
function decodeString(data, argument, index) {
  const [value, length] = decodeByteString(data, argument, index);
  return [TEXT_DECODER.decode(value), length];
}
function decodeArray(data, argument, index) {
  if (argument === 0) {
    return [[], 1];
  }
  const [length, lengthConsumed] = decodeLength(data, argument, index);
  let consumedLength = lengthConsumed;
  const value = [];
  for (let i = 0; i < length; i++) {
    const remainingDataLength = data.byteLength - index - consumedLength;
    if (remainingDataLength <= 0) {
      throw new Error("array is not supported or well formed");
    }
    const [decodedValue, consumed] = decodeNext(data, index + consumedLength);
    value.push(decodedValue);
    consumedLength += consumed;
  }
  return [value, consumedLength];
}
var MAP_ERROR = "Map is not supported or well formed";
function decodeMap(data, argument, index) {
  if (argument === 0) {
    return [/* @__PURE__ */ new Map(), 1];
  }
  const [length, lengthConsumed] = decodeLength(data, argument, index);
  let consumedLength = lengthConsumed;
  const result = /* @__PURE__ */ new Map();
  for (let i = 0; i < length; i++) {
    let remainingDataLength = data.byteLength - index - consumedLength;
    if (remainingDataLength <= 0) {
      throw new Error(MAP_ERROR);
    }
    const [key2, keyConsumed] = decodeNext(data, index + consumedLength);
    consumedLength += keyConsumed;
    remainingDataLength -= keyConsumed;
    if (remainingDataLength <= 0) {
      throw new Error(MAP_ERROR);
    }
    if (typeof key2 !== "string" && typeof key2 !== "number") {
      throw new Error(MAP_ERROR);
    }
    if (result.has(key2)) {
      throw new Error(MAP_ERROR);
    }
    const [value, valueConsumed] = decodeNext(data, index + consumedLength);
    consumedLength += valueConsumed;
    result.set(key2, value);
  }
  return [result, consumedLength];
}
function decodeFloat16(data, index) {
  if (index + 3 > data.byteLength) {
    throw new Error("CBOR stream ended before end of Float 16");
  }
  const result = data.getUint16(index + 1, false);
  if (result == 31744) {
    return [Infinity, 3];
  } else if (result == 32256) {
    return [NaN, 3];
  } else if (result == 64512) {
    return [-Infinity, 3];
  }
  throw new Error("Float16 data is unsupported");
}
function decodeFloat32(data, index) {
  if (index + 5 > data.byteLength) {
    throw new Error("CBOR stream ended before end of Float 32");
  }
  const result = data.getFloat32(index + 1, false);
  return [result, 5];
}
function decodeFloat64(data, index) {
  if (index + 9 > data.byteLength) {
    throw new Error("CBOR stream ended before end of Float 64");
  }
  const result = data.getFloat64(index + 1, false);
  return [result, 9];
}
function decodeTag(data, argument, index) {
  const [tag, tagBytes] = decodeLength(data, argument, index);
  const [value, valueBytes] = decodeNext(data, index + tagBytes);
  return [new CBORTag(tag, value), tagBytes + valueBytes];
}
function decodeNext(data, index) {
  if (index >= data.byteLength) {
    throw new Error("CBOR stream ended before tag value");
  }
  const byte = data.getUint8(index);
  const majorType = byte >> 5;
  const argument = byte & 31;
  switch (majorType) {
    case MAJOR_TYPE_UNSIGNED_INTEGER: {
      return decodeUnsignedInteger(data, argument, index);
    }
    case MAJOR_TYPE_NEGATIVE_INTEGER: {
      return decodeNegativeInteger(data, argument, index);
    }
    case MAJOR_TYPE_BYTE_STRING: {
      return decodeByteString(data, argument, index);
    }
    case MAJOR_TYPE_TEXT_STRING: {
      return decodeString(data, argument, index);
    }
    case MAJOR_TYPE_ARRAY: {
      return decodeArray(data, argument, index);
    }
    case MAJOR_TYPE_MAP: {
      return decodeMap(data, argument, index);
    }
    case MAJOR_TYPE_TAG: {
      return decodeTag(data, argument, index);
    }
    case MAJOR_TYPE_SIMPLE_OR_FLOAT: {
      switch (argument) {
        case 20:
          return [false, 1];
        case 21:
          return [true, 1];
        case 22:
          return [null, 1];
        case 23:
          return [void 0, 1];
        // 24: Simple value (value 32..255 in following byte)
        case 25:
          return decodeFloat16(data, index);
        case 26:
          return decodeFloat32(data, index);
        case 27:
          return decodeFloat64(data, index);
      }
    }
  }
  throw new Error(`Unsupported or not well formed at ${index}`);
}
function encodeSimple(data) {
  if (data === true) {
    return 245;
  } else if (data === false) {
    return 244;
  } else if (data === null) {
    return 246;
  }
  return 247;
}
function encodeFloat(data) {
  if (Math.fround(data) == data || !Number.isFinite(data) || Number.isNaN(data)) {
    const output = new Uint8Array(5);
    output[0] = 250;
    const view = new DataView(output.buffer);
    view.setFloat32(1, data, false);
    return output;
  } else {
    const output = new Uint8Array(9);
    output[0] = 251;
    const view = new DataView(output.buffer);
    view.setFloat64(1, data, false);
    return output;
  }
}
function encodeNumber(data) {
  if (typeof data == "number") {
    if (Number.isSafeInteger(data)) {
      if (data < 0) {
        return encodeLength(MAJOR_TYPE_NEGATIVE_INTEGER, Math.abs(data));
      } else {
        return encodeLength(MAJOR_TYPE_UNSIGNED_INTEGER, data);
      }
    }
    return [encodeFloat(data)];
  } else {
    if (data < 0n) {
      return encodeLength(MAJOR_TYPE_NEGATIVE_INTEGER, data * -1n);
    } else {
      return encodeLength(MAJOR_TYPE_UNSIGNED_INTEGER, data);
    }
  }
}
var ENCODER = new TextEncoder();
function encodeString(data, output) {
  output.push(...encodeLength(MAJOR_TYPE_TEXT_STRING, data.length));
  output.push(ENCODER.encode(data));
}
function encodeBytes(data, output) {
  output.push(...encodeLength(MAJOR_TYPE_BYTE_STRING, data.length));
  output.push(data);
}
function encodeArray(data, output) {
  output.push(...encodeLength(MAJOR_TYPE_ARRAY, data.length));
  for (const element of data) {
    encodePartialCBOR(element, output);
  }
}
function encodeMap(data, output) {
  output.push(new Uint8Array(encodeLength(MAJOR_TYPE_MAP, data.size)));
  for (const [key2, value] of data.entries()) {
    encodePartialCBOR(key2, output);
    encodePartialCBOR(value, output);
  }
}
function encodeTag(tag, output) {
  output.push(...encodeLength(MAJOR_TYPE_TAG, tag.tag));
  encodePartialCBOR(tag.value, output);
}
function encodePartialCBOR(data, output) {
  if (typeof data == "boolean" || data === null || data == void 0) {
    output.push(encodeSimple(data));
    return;
  }
  if (typeof data == "number" || typeof data == "bigint") {
    output.push(...encodeNumber(data));
    return;
  }
  if (typeof data == "string") {
    encodeString(data, output);
    return;
  }
  if (data instanceof Uint8Array) {
    encodeBytes(data, output);
    return;
  }
  if (Array.isArray(data)) {
    encodeArray(data, output);
    return;
  }
  if (data instanceof Map) {
    encodeMap(data, output);
    return;
  }
  if (data instanceof CBORTag) {
    encodeTag(data, output);
    return;
  }
  throw new Error("Not implemented");
}
function decodePartialCBOR(data, index) {
  if (data.byteLength === 0 || data.byteLength <= index || index < 0) {
    throw new Error("No data");
  }
  if (data instanceof Uint8Array) {
    return decodeNext(new DataView(data.buffer), index);
  } else if (data instanceof ArrayBuffer) {
    return decodeNext(new DataView(data), index);
  }
  return decodeNext(data, index);
}
function encodeCBOR(data) {
  const results = [];
  encodePartialCBOR(data, results);
  let length = 0;
  for (const result of results) {
    if (typeof result == "number") {
      length += 1;
    } else {
      length += result.length;
    }
  }
  const output = new Uint8Array(length);
  let index = 0;
  for (const result of results) {
    if (typeof result == "number") {
      output[index] = result;
      index += 1;
    } else {
      output.set(result, index);
      index += result.length;
    }
  }
  return output;
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCBOR.js
function decodeFirst(input) {
  const _input = new Uint8Array(input);
  const decoded = decodePartialCBOR(_input, 0);
  const [first] = decoded;
  return first;
}
function encode(input) {
  return encodeCBOR(input);
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/index.js
var isoCrypto_exports = {};
__export(isoCrypto_exports, {
  digest: () => digest2,
  getRandomValues: () => getRandomValues,
  verify: () => verify
});

// node_modules/@simplewebauthn/server/esm/helpers/cose.js
function isCOSEPublicKeyOKP(cosePublicKey) {
  const kty = cosePublicKey.get(COSEKEYS.kty);
  return isCOSEKty(kty) && kty === COSEKTY.OKP;
}
function isCOSEPublicKeyEC2(cosePublicKey) {
  const kty = cosePublicKey.get(COSEKEYS.kty);
  return isCOSEKty(kty) && kty === COSEKTY.EC2;
}
function isCOSEPublicKeyRSA(cosePublicKey) {
  const kty = cosePublicKey.get(COSEKEYS.kty);
  return isCOSEKty(kty) && kty === COSEKTY.RSA;
}
function isCOSEPublicKeyAKP(cosePublicKey) {
  const kty = cosePublicKey.get(COSEKEYS.kty);
  return isCOSEKty(kty) && kty === COSEKTY.AKP;
}
var COSEKEYS;
(function(COSEKEYS2) {
  COSEKEYS2[COSEKEYS2["kty"] = 1] = "kty";
  COSEKEYS2[COSEKEYS2["alg"] = 3] = "alg";
  COSEKEYS2[COSEKEYS2["crv"] = -1] = "crv";
  COSEKEYS2[COSEKEYS2["x"] = -2] = "x";
  COSEKEYS2[COSEKEYS2["y"] = -3] = "y";
  COSEKEYS2[COSEKEYS2["n"] = -1] = "n";
  COSEKEYS2[COSEKEYS2["e"] = -2] = "e";
  COSEKEYS2[COSEKEYS2["pub"] = -1] = "pub";
})(COSEKEYS || (COSEKEYS = {}));
var COSEKTY;
(function(COSEKTY2) {
  COSEKTY2[COSEKTY2["OKP"] = 1] = "OKP";
  COSEKTY2[COSEKTY2["EC2"] = 2] = "EC2";
  COSEKTY2[COSEKTY2["RSA"] = 3] = "RSA";
  COSEKTY2[COSEKTY2["AKP"] = 7] = "AKP";
})(COSEKTY || (COSEKTY = {}));
function isCOSEKty(kty) {
  return Object.values(COSEKTY).indexOf(kty) >= 0;
}
var COSECRV;
(function(COSECRV2) {
  COSECRV2[COSECRV2["P256"] = 1] = "P256";
  COSECRV2[COSECRV2["P384"] = 2] = "P384";
  COSECRV2[COSECRV2["P521"] = 3] = "P521";
  COSECRV2[COSECRV2["ED25519"] = 6] = "ED25519";
  COSECRV2[COSECRV2["SECP256K1"] = 8] = "SECP256K1";
})(COSECRV || (COSECRV = {}));
function isCOSECrv(crv) {
  return Object.values(COSECRV).indexOf(crv) >= 0;
}
var COSEALG;
(function(COSEALG2) {
  COSEALG2[COSEALG2["ES256"] = -7] = "ES256";
  COSEALG2[COSEALG2["EdDSA"] = -8] = "EdDSA";
  COSEALG2[COSEALG2["ES384"] = -35] = "ES384";
  COSEALG2[COSEALG2["ES512"] = -36] = "ES512";
  COSEALG2[COSEALG2["PS256"] = -37] = "PS256";
  COSEALG2[COSEALG2["PS384"] = -38] = "PS384";
  COSEALG2[COSEALG2["PS512"] = -39] = "PS512";
  COSEALG2[COSEALG2["ES256K"] = -47] = "ES256K";
  COSEALG2[COSEALG2["ML_DSA_44"] = -48] = "ML_DSA_44";
  COSEALG2[COSEALG2["ML_DSA_65"] = -49] = "ML_DSA_65";
  COSEALG2[COSEALG2["ML_DSA_87"] = -50] = "ML_DSA_87";
  COSEALG2[COSEALG2["RS256"] = -257] = "RS256";
  COSEALG2[COSEALG2["RS384"] = -258] = "RS384";
  COSEALG2[COSEALG2["RS512"] = -259] = "RS512";
  COSEALG2[COSEALG2["RS1"] = -65535] = "RS1";
})(COSEALG || (COSEALG = {}));
function isCOSEAlg(alg) {
  return Object.values(COSEALG).indexOf(alg) >= 0;
}
function isPQCCOSEAlg(alg) {
  return [COSEALG.ML_DSA_44, COSEALG.ML_DSA_65, COSEALG.ML_DSA_87].indexOf(alg) >= 0;
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/mapCoseAlgToWebCryptoHashAlgName.js
function mapCoseAlgToWebCryptoHashAlgName(alg) {
  if ([COSEALG.RS1].indexOf(alg) >= 0) {
    return "SHA-1";
  } else if ([COSEALG.ES256, COSEALG.PS256, COSEALG.RS256].indexOf(alg) >= 0) {
    return "SHA-256";
  } else if ([COSEALG.ES384, COSEALG.PS384, COSEALG.RS384].indexOf(alg) >= 0) {
    return "SHA-384";
  } else if ([COSEALG.ES512, COSEALG.PS512, COSEALG.RS512, COSEALG.EdDSA].indexOf(alg) >= 0) {
    return "SHA-512";
  }
  throw new Error(`Could not map COSE alg value of ${alg} to a WebCrypto hash alg name`);
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/getWebCrypto.js
var webCrypto = void 0;
function getWebCrypto() {
  const toResolve = new Promise((resolve, reject) => {
    if (webCrypto) {
      return resolve(webCrypto);
    }
    const _globalThisCrypto = _getWebCryptoInternals.stubThisGlobalThisCrypto();
    if (_globalThisCrypto) {
      webCrypto = _globalThisCrypto;
      return resolve(webCrypto);
    }
    return reject(new MissingWebCrypto());
  });
  return toResolve;
}
var MissingWebCrypto = class extends Error {
  constructor() {
    const message = "An instance of the Crypto API could not be located";
    super(message);
    this.name = "MissingWebCrypto";
  }
};
var _getWebCryptoInternals = {
  stubThisGlobalThisCrypto: () => globalThis.crypto,
  // Make it possible to reset the `webCrypto` at the top of the file
  setCachedCrypto: (newCrypto) => {
    webCrypto = newCrypto;
  }
};

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/digest.js
async function digest2(data, algorithm) {
  const WebCrypto = await getWebCrypto();
  const subtleAlgorithm = mapCoseAlgToWebCryptoHashAlgName(algorithm);
  const hashed = await WebCrypto.subtle.digest(subtleAlgorithm, data);
  return new Uint8Array(hashed);
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/getRandomValues.js
async function getRandomValues(array) {
  const WebCrypto = await getWebCrypto();
  WebCrypto.getRandomValues(array);
  return array;
}

// node_modules/@simplewebauthn/server/esm/helpers/convertAAGUIDToString.js
function convertAAGUIDToString(aaguid) {
  const hex2 = isoUint8Array_exports.toHex(aaguid);
  const segments = [
    hex2.slice(0, 8),
    // 8
    hex2.slice(8, 12),
    // 4
    hex2.slice(12, 16),
    // 4
    hex2.slice(16, 20),
    // 4
    hex2.slice(20, 32)
    // 8
  ];
  return segments.join("-");
}

// node_modules/@simplewebauthn/server/esm/helpers/convertCOSEtoPKCS.js
function convertCOSEtoPKCS(cosePublicKey) {
  const struct = isoCBOR_exports.decodeFirst(cosePublicKey);
  const tag = Uint8Array.from([4]);
  const x = struct.get(COSEKEYS.x);
  const y = struct.get(COSEKEYS.y);
  if (!x) {
    throw new Error("COSE public key was missing x");
  }
  if (y) {
    return isoUint8Array_exports.concat([tag, x, y]);
  }
  return isoUint8Array_exports.concat([tag, x]);
}

// node_modules/@simplewebauthn/server/esm/helpers/decodeAttestationObject.js
function decodeAttestationObject(attestationObject) {
  return _decodeAttestationObjectInternals.stubThis(isoCBOR_exports.decodeFirst(attestationObject));
}
var _decodeAttestationObjectInternals = {
  stubThis: (value) => value
};

// node_modules/@simplewebauthn/server/esm/helpers/decodeClientDataJSON.js
function decodeClientDataJSON(data) {
  const toString = isoBase64URL_exports.toUTF8String(data);
  const clientData = JSON.parse(toString);
  return _decodeClientDataJSONInternals.stubThis(clientData);
}
var _decodeClientDataJSONInternals = {
  stubThis: (value) => value
};

// node_modules/@simplewebauthn/server/esm/helpers/decodeCredentialPublicKey.js
function decodeCredentialPublicKey(publicKey) {
  return _decodeCredentialPublicKeyInternals.stubThis(isoCBOR_exports.decodeFirst(publicKey));
}
var _decodeCredentialPublicKeyInternals = {
  stubThis: (value) => value
};

// node_modules/@simplewebauthn/server/esm/helpers/generateChallenge.js
async function generateChallenge() {
  const challenge = new Uint8Array(32);
  await isoCrypto_exports.getRandomValues(challenge);
  return _generateChallengeInternals.stubThis(challenge);
}
var _generateChallengeInternals = {
  stubThis: (value) => value
};

// node_modules/@simplewebauthn/server/esm/helpers/generateUserID.js
async function generateUserID() {
  const newUserID = new Uint8Array(32);
  await isoCrypto_exports.getRandomValues(newUserID);
  return _generateUserIDInternals.stubThis(newUserID);
}
var _generateUserIDInternals = {
  stubThis: (value) => value
};

// node_modules/asn1js/build/index.es.js
var index_es_exports = {};
__export(index_es_exports, {
  Any: () => Any,
  BaseBlock: () => BaseBlock,
  BaseStringBlock: () => BaseStringBlock,
  BitString: () => BitString,
  BmpString: () => BmpString,
  Boolean: () => Boolean2,
  CharacterString: () => CharacterString,
  Choice: () => Choice,
  Constructed: () => Constructed,
  DATE: () => DATE,
  DEFAULT_MAX_CONTENT_LENGTH: () => DEFAULT_MAX_CONTENT_LENGTH,
  DEFAULT_MAX_DEPTH: () => DEFAULT_MAX_DEPTH,
  DEFAULT_MAX_NODES: () => DEFAULT_MAX_NODES,
  DateTime: () => DateTime,
  Duration: () => Duration,
  EndOfContent: () => EndOfContent,
  Enumerated: () => Enumerated,
  GeneralString: () => GeneralString,
  GeneralizedTime: () => GeneralizedTime,
  GraphicString: () => GraphicString,
  HexBlock: () => HexBlock,
  IA5String: () => IA5String,
  Integer: () => Integer,
  Null: () => Null,
  NumericString: () => NumericString,
  ObjectIdentifier: () => ObjectIdentifier,
  OctetString: () => OctetString,
  Primitive: () => Primitive,
  PrintableString: () => PrintableString,
  RawData: () => RawData,
  RelativeObjectIdentifier: () => RelativeObjectIdentifier,
  Repeated: () => Repeated,
  Sequence: () => Sequence,
  Set: () => Set2,
  TIME: () => TIME,
  TeletexString: () => TeletexString,
  TimeOfDay: () => TimeOfDay,
  UTCTime: () => UTCTime,
  UniversalString: () => UniversalString,
  Utf8String: () => Utf8String,
  ValueBlock: () => ValueBlock,
  VideotexString: () => VideotexString,
  ViewWriter: () => ViewWriter,
  VisibleString: () => VisibleString,
  compareSchema: () => compareSchema,
  fromBER: () => fromBER,
  verifySchema: () => verifySchema
});
var pvtsutils = __toESM(require_build());

// node_modules/pvutils/build/utils.es.js
function utilFromBase(inputBuffer, inputBase) {
  let result = 0;
  if (inputBuffer.length === 1) {
    return inputBuffer[0];
  }
  for (let i = inputBuffer.length - 1; i >= 0; i--) {
    result += inputBuffer[inputBuffer.length - 1 - i] * Math.pow(2, inputBase * i);
  }
  return result;
}
function utilToBase(value, base, reserved = -1) {
  const internalReserved = reserved;
  let internalValue = value;
  let result = 0;
  let biggest = Math.pow(2, base);
  for (let i = 1; i < 8; i++) {
    if (value < biggest) {
      let retBuf;
      if (internalReserved < 0) {
        retBuf = new ArrayBuffer(i);
        result = i;
      } else {
        if (internalReserved < i) {
          return new ArrayBuffer(0);
        }
        retBuf = new ArrayBuffer(internalReserved);
        result = internalReserved;
      }
      const retView = new Uint8Array(retBuf);
      for (let j = i - 1; j >= 0; j--) {
        const basis = Math.pow(2, j * base);
        retView[result - j - 1] = Math.floor(internalValue / basis);
        internalValue -= retView[result - j - 1] * basis;
      }
      return retBuf;
    }
    biggest *= Math.pow(2, base);
  }
  return new ArrayBuffer(0);
}
function utilConcatView(...views) {
  let outputLength = 0;
  let prevLength = 0;
  for (const view of views) {
    outputLength += view.length;
  }
  const retBuf = new ArrayBuffer(outputLength);
  const retView = new Uint8Array(retBuf);
  for (const view of views) {
    retView.set(view, prevLength);
    prevLength += view.length;
  }
  return retView;
}
function utilDecodeTC() {
  const buf = new Uint8Array(this.valueHex);
  if (this.valueHex.byteLength >= 2) {
    const condition1 = buf[0] === 255 && buf[1] & 128;
    const condition2 = buf[0] === 0 && (buf[1] & 128) === 0;
    if (condition1 || condition2) {
      this.warnings.push("Needlessly long format");
    }
  }
  const bigIntBuffer = new ArrayBuffer(this.valueHex.byteLength);
  const bigIntView = new Uint8Array(bigIntBuffer);
  for (let i = 0; i < this.valueHex.byteLength; i++) {
    bigIntView[i] = 0;
  }
  bigIntView[0] = buf[0] & 128;
  const bigInt = utilFromBase(bigIntView, 8);
  const smallIntBuffer = new ArrayBuffer(this.valueHex.byteLength);
  const smallIntView = new Uint8Array(smallIntBuffer);
  for (let j = 0; j < this.valueHex.byteLength; j++) {
    smallIntView[j] = buf[j];
  }
  smallIntView[0] &= 127;
  const smallInt = utilFromBase(smallIntView, 8);
  return smallInt - bigInt;
}
function utilEncodeTC(value) {
  const modValue = value < 0 ? value * -1 : value;
  let bigInt = 128;
  for (let i = 1; i < 8; i++) {
    if (modValue <= bigInt) {
      if (value < 0) {
        const smallInt = bigInt - modValue;
        const retBuf2 = utilToBase(smallInt, 8, i);
        const retView2 = new Uint8Array(retBuf2);
        retView2[0] |= 128;
        return retBuf2;
      }
      let retBuf = utilToBase(modValue, 8, i);
      let retView = new Uint8Array(retBuf);
      if (retView[0] & 128) {
        const tempBuf = retBuf.slice(0);
        const tempView = new Uint8Array(tempBuf);
        retBuf = new ArrayBuffer(retBuf.byteLength + 1);
        retView = new Uint8Array(retBuf);
        for (let k = 0; k < tempBuf.byteLength; k++) {
          retView[k + 1] = tempView[k];
        }
        retView[0] = 0;
      }
      return retBuf;
    }
    bigInt *= Math.pow(2, 8);
  }
  return new ArrayBuffer(0);
}
function isEqualBuffer(inputBuffer1, inputBuffer2) {
  if (inputBuffer1.byteLength !== inputBuffer2.byteLength) {
    return false;
  }
  const view1 = new Uint8Array(inputBuffer1);
  const view2 = new Uint8Array(inputBuffer2);
  for (let i = 0; i < view1.length; i++) {
    if (view1[i] !== view2[i]) {
      return false;
    }
  }
  return true;
}
function padNumber(inputNumber, fullLength) {
  const str2 = inputNumber.toString(10);
  if (fullLength < str2.length) {
    return "";
  }
  const dif = fullLength - str2.length;
  const padding = Array.from({ length: dif });
  for (let i = 0; i < dif; i++) {
    padding[i] = "0";
  }
  const paddingString = padding.join("");
  return paddingString.concat(str2);
}
var log2 = Math.log(2);

// node_modules/asn1js/build/index.es.js
function assertBigInt() {
  if (typeof BigInt === "undefined") {
    throw new Error("BigInt is not defined. Your environment doesn't implement BigInt.");
  }
}
function concat(buffers) {
  let outputLength = 0;
  let prevLength = 0;
  for (let i = 0; i < buffers.length; i++) {
    const buffer = buffers[i];
    outputLength += buffer.byteLength;
  }
  const retView = new Uint8Array(outputLength);
  for (let i = 0; i < buffers.length; i++) {
    const buffer = buffers[i];
    retView.set(new Uint8Array(buffer), prevLength);
    prevLength += buffer.byteLength;
  }
  return retView.buffer;
}
function checkBufferParams(baseBlock, inputBuffer, inputOffset, inputLength) {
  if (!(inputBuffer instanceof Uint8Array)) {
    baseBlock.error = "Wrong parameter: inputBuffer must be 'Uint8Array'";
    return false;
  }
  if (!inputBuffer.byteLength) {
    baseBlock.error = "Wrong parameter: inputBuffer has zero length";
    return false;
  }
  if (inputOffset < 0) {
    baseBlock.error = "Wrong parameter: inputOffset less than zero";
    return false;
  }
  if (inputLength < 0) {
    baseBlock.error = "Wrong parameter: inputLength less than zero";
    return false;
  }
  if (inputBuffer.byteLength - inputOffset - inputLength < 0) {
    baseBlock.error = "End of input reached before message was fully decoded (inconsistent offset and length values)";
    return false;
  }
  return true;
}
var ViewWriter = class {
  constructor() {
    this.items = [];
  }
  write(buf) {
    this.items.push(buf);
  }
  final() {
    return concat(this.items);
  }
};
var powers2 = [new Uint8Array([1])];
var digitsString = "0123456789";
var NAME = "name";
var VALUE_HEX_VIEW = "valueHexView";
var IS_HEX_ONLY = "isHexOnly";
var ID_BLOCK = "idBlock";
var TAG_CLASS = "tagClass";
var TAG_NUMBER = "tagNumber";
var IS_CONSTRUCTED = "isConstructed";
var FROM_BER = "fromBER";
var TO_BER = "toBER";
var LOCAL = "local";
var EMPTY_STRING = "";
var EMPTY_BUFFER = new ArrayBuffer(0);
var EMPTY_VIEW = new Uint8Array(0);
var END_OF_CONTENT_NAME = "EndOfContent";
var OCTET_STRING_NAME = "OCTET STRING";
var BIT_STRING_NAME = "BIT STRING";
function HexBlock(BaseClass) {
  var _a3;
  return _a3 = class Some extends BaseClass {
    get valueHex() {
      return this.valueHexView.slice().buffer;
    }
    set valueHex(value) {
      this.valueHexView = new Uint8Array(value);
    }
    constructor(...args) {
      var _b;
      super(...args);
      const params = args[0] || {};
      this.isHexOnly = (_b = params.isHexOnly) !== null && _b !== void 0 ? _b : false;
      this.valueHexView = params.valueHex ? pvtsutils.BufferSourceConverter.toUint8Array(params.valueHex) : EMPTY_VIEW;
    }
    fromBER(inputBuffer, inputOffset, inputLength, _context) {
      const view = inputBuffer instanceof ArrayBuffer ? new Uint8Array(inputBuffer) : inputBuffer;
      if (!checkBufferParams(this, view, inputOffset, inputLength)) {
        return -1;
      }
      const endLength = inputOffset + inputLength;
      this.valueHexView = view.subarray(inputOffset, endLength);
      if (!this.valueHexView.length) {
        this.warnings.push("Zero buffer length");
        return inputOffset;
      }
      this.blockLength = inputLength;
      return endLength;
    }
    toBER(sizeOnly = false) {
      if (!this.isHexOnly) {
        this.error = "Flag 'isHexOnly' is not set, abort";
        return EMPTY_BUFFER;
      }
      if (sizeOnly) {
        return new ArrayBuffer(this.valueHexView.byteLength);
      }
      return this.valueHexView.byteLength === this.valueHexView.buffer.byteLength ? this.valueHexView.buffer : this.valueHexView.slice().buffer;
    }
    toJSON() {
      return {
        ...super.toJSON(),
        isHexOnly: this.isHexOnly,
        valueHex: pvtsutils.Convert.ToHex(this.valueHexView)
      };
    }
  }, _a3.NAME = "hexBlock", _a3;
}
var LocalBaseBlock = class {
  static blockName() {
    return this.NAME;
  }
  get valueBeforeDecode() {
    return this.valueBeforeDecodeView.slice().buffer;
  }
  set valueBeforeDecode(value) {
    this.valueBeforeDecodeView = new Uint8Array(value);
  }
  constructor({ blockLength = 0, error = EMPTY_STRING, warnings = [], valueBeforeDecode = EMPTY_VIEW } = {}) {
    this.blockLength = blockLength;
    this.error = error;
    this.warnings = warnings;
    this.valueBeforeDecodeView = pvtsutils.BufferSourceConverter.toUint8Array(valueBeforeDecode);
  }
  toJSON() {
    return {
      blockName: this.constructor.NAME,
      blockLength: this.blockLength,
      error: this.error,
      warnings: this.warnings,
      valueBeforeDecode: pvtsutils.Convert.ToHex(this.valueBeforeDecodeView)
    };
  }
};
LocalBaseBlock.NAME = "baseBlock";
var ValueBlock = class extends LocalBaseBlock {
  fromBER(_inputBuffer, _inputOffset, _inputLength, _context) {
    throw TypeError("User need to make a specific function in a class which extends 'ValueBlock'");
  }
  toBER(_sizeOnly, _writer) {
    throw TypeError("User need to make a specific function in a class which extends 'ValueBlock'");
  }
};
ValueBlock.NAME = "valueBlock";
var LocalIdentificationBlock = class extends HexBlock(LocalBaseBlock) {
  constructor({ idBlock = {} } = {}) {
    var _a3, _b, _c, _d;
    super();
    if (idBlock) {
      this.isHexOnly = (_a3 = idBlock.isHexOnly) !== null && _a3 !== void 0 ? _a3 : false;
      this.valueHexView = idBlock.valueHex ? pvtsutils.BufferSourceConverter.toUint8Array(idBlock.valueHex) : EMPTY_VIEW;
      this.tagClass = (_b = idBlock.tagClass) !== null && _b !== void 0 ? _b : -1;
      this.tagNumber = (_c = idBlock.tagNumber) !== null && _c !== void 0 ? _c : -1;
      this.isConstructed = (_d = idBlock.isConstructed) !== null && _d !== void 0 ? _d : false;
    } else {
      this.tagClass = -1;
      this.tagNumber = -1;
      this.isConstructed = false;
    }
  }
  toBER(sizeOnly = false) {
    let firstOctet = 0;
    switch (this.tagClass) {
      case 1:
        firstOctet |= 0;
        break;
      case 2:
        firstOctet |= 64;
        break;
      case 3:
        firstOctet |= 128;
        break;
      case 4:
        firstOctet |= 192;
        break;
      default:
        this.error = "Unknown tag class";
        return EMPTY_BUFFER;
    }
    if (this.isConstructed)
      firstOctet |= 32;
    if (this.tagNumber < 31 && !this.isHexOnly) {
      const retView2 = new Uint8Array(1);
      if (!sizeOnly) {
        let number = this.tagNumber;
        number &= 31;
        firstOctet |= number;
        retView2[0] = firstOctet;
      }
      return retView2.buffer;
    }
    if (!this.isHexOnly) {
      const encodedBuf = utilToBase(this.tagNumber, 7);
      const encodedView = new Uint8Array(encodedBuf);
      const size = encodedBuf.byteLength;
      const retView2 = new Uint8Array(size + 1);
      retView2[0] = firstOctet | 31;
      if (!sizeOnly) {
        for (let i = 0; i < size - 1; i++)
          retView2[i + 1] = encodedView[i] | 128;
        retView2[size] = encodedView[size - 1];
      }
      return retView2.buffer;
    }
    const retView = new Uint8Array(this.valueHexView.byteLength + 1);
    retView[0] = firstOctet | 31;
    if (!sizeOnly) {
      const curView = this.valueHexView;
      for (let i = 0; i < curView.length - 1; i++)
        retView[i + 1] = curView[i] | 128;
      retView[this.valueHexView.byteLength] = curView[curView.length - 1];
    }
    return retView.buffer;
  }
  fromBER(inputBuffer, inputOffset, inputLength) {
    const inputView = pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer);
    if (!checkBufferParams(this, inputView, inputOffset, inputLength)) {
      return -1;
    }
    const intBuffer = inputView.subarray(inputOffset, inputOffset + inputLength);
    if (intBuffer.length === 0) {
      this.error = "Zero buffer length";
      return -1;
    }
    const tagClassMask = intBuffer[0] & 192;
    switch (tagClassMask) {
      case 0:
        this.tagClass = 1;
        break;
      case 64:
        this.tagClass = 2;
        break;
      case 128:
        this.tagClass = 3;
        break;
      case 192:
        this.tagClass = 4;
        break;
      default:
        this.error = "Unknown tag class";
        return -1;
    }
    this.isConstructed = (intBuffer[0] & 32) === 32;
    this.isHexOnly = false;
    const tagNumberMask = intBuffer[0] & 31;
    if (tagNumberMask !== 31) {
      this.tagNumber = tagNumberMask;
      this.blockLength = 1;
    } else {
      let count = 0;
      while (true) {
        const tagByteIndex = count + 1;
        if (tagByteIndex >= intBuffer.length) {
          this.error = "End of input reached before message was fully decoded";
          return -1;
        }
        count++;
        if ((intBuffer[tagByteIndex] & 128) === 0)
          break;
      }
      this.blockLength = count + 1;
      const intTagNumberBuffer = this.valueHexView = new Uint8Array(count);
      for (let i = 0; i < count; i++)
        intTagNumberBuffer[i] = intBuffer[i + 1] & 127;
      if (this.blockLength <= 9)
        this.tagNumber = utilFromBase(intTagNumberBuffer, 7);
      else {
        this.isHexOnly = true;
        this.warnings.push("Tag too long, represented as hex-coded");
      }
    }
    if (this.tagClass === 1 && this.isConstructed) {
      switch (this.tagNumber) {
        case 1:
        case 2:
        case 5:
        case 6:
        case 9:
        case 13:
        case 14:
        case 23:
        case 24:
        case 31:
        case 32:
        case 33:
        case 34:
          this.error = "Constructed encoding used for primitive type";
          return -1;
      }
    }
    return inputOffset + this.blockLength;
  }
  toJSON() {
    return {
      ...super.toJSON(),
      tagClass: this.tagClass,
      tagNumber: this.tagNumber,
      isConstructed: this.isConstructed
    };
  }
};
LocalIdentificationBlock.NAME = "identificationBlock";
var LocalLengthBlock = class extends LocalBaseBlock {
  constructor({ lenBlock = {} } = {}) {
    var _a3, _b, _c;
    super();
    this.isIndefiniteForm = (_a3 = lenBlock.isIndefiniteForm) !== null && _a3 !== void 0 ? _a3 : false;
    this.longFormUsed = (_b = lenBlock.longFormUsed) !== null && _b !== void 0 ? _b : false;
    this.length = (_c = lenBlock.length) !== null && _c !== void 0 ? _c : 0;
  }
  fromBER(inputBuffer, inputOffset, inputLength) {
    const view = pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer);
    if (!checkBufferParams(this, view, inputOffset, inputLength)) {
      return -1;
    }
    const intBuffer = view.subarray(inputOffset, inputOffset + inputLength);
    if (intBuffer.length === 0) {
      this.error = "Zero buffer length";
      return -1;
    }
    if (intBuffer[0] === 255) {
      this.error = "Length block 0xFF is reserved by standard";
      return -1;
    }
    this.isIndefiniteForm = intBuffer[0] === 128;
    if (this.isIndefiniteForm) {
      this.blockLength = 1;
      return inputOffset + this.blockLength;
    }
    this.longFormUsed = !!(intBuffer[0] & 128);
    if (this.longFormUsed === false) {
      this.length = intBuffer[0];
      this.blockLength = 1;
      return inputOffset + this.blockLength;
    }
    const count = intBuffer[0] & 127;
    if (count > 8) {
      this.error = "Too big integer";
      return -1;
    }
    if (count + 1 > intBuffer.length) {
      this.error = "End of input reached before message was fully decoded";
      return -1;
    }
    const lenOffset = inputOffset + 1;
    const lengthBufferView = view.subarray(lenOffset, lenOffset + count);
    if (lengthBufferView[count - 1] === 0)
      this.warnings.push("Needlessly long encoded length");
    this.length = utilFromBase(lengthBufferView, 8);
    if (this.longFormUsed && this.length <= 127)
      this.warnings.push("Unnecessary usage of long length form");
    this.blockLength = count + 1;
    return inputOffset + this.blockLength;
  }
  toBER(sizeOnly = false) {
    let retBuf;
    let retView;
    if (this.length > 127)
      this.longFormUsed = true;
    if (this.isIndefiniteForm) {
      retBuf = new ArrayBuffer(1);
      if (sizeOnly === false) {
        retView = new Uint8Array(retBuf);
        retView[0] = 128;
      }
      return retBuf;
    }
    if (this.longFormUsed) {
      const encodedBuf = utilToBase(this.length, 8);
      if (encodedBuf.byteLength > 127) {
        this.error = "Too big length";
        return EMPTY_BUFFER;
      }
      retBuf = new ArrayBuffer(encodedBuf.byteLength + 1);
      if (sizeOnly)
        return retBuf;
      const encodedView = new Uint8Array(encodedBuf);
      retView = new Uint8Array(retBuf);
      retView[0] = encodedBuf.byteLength | 128;
      for (let i = 0; i < encodedBuf.byteLength; i++)
        retView[i + 1] = encodedView[i];
      return retBuf;
    }
    retBuf = new ArrayBuffer(1);
    if (sizeOnly === false) {
      retView = new Uint8Array(retBuf);
      retView[0] = this.length;
    }
    return retBuf;
  }
  toJSON() {
    return {
      ...super.toJSON(),
      isIndefiniteForm: this.isIndefiniteForm,
      longFormUsed: this.longFormUsed,
      length: this.length
    };
  }
};
LocalLengthBlock.NAME = "lengthBlock";
var typeStore = {};
var BaseBlock = class extends LocalBaseBlock {
  constructor({ name = EMPTY_STRING, optional = false, primitiveSchema, ...parameters } = {}, valueBlockType) {
    super(parameters);
    this.name = name;
    this.optional = optional;
    if (primitiveSchema) {
      this.primitiveSchema = primitiveSchema;
    }
    this.idBlock = new LocalIdentificationBlock(parameters);
    this.lenBlock = new LocalLengthBlock(parameters);
    this.valueBlock = valueBlockType ? new valueBlockType(parameters) : new ValueBlock(parameters);
  }
  fromBER(inputBuffer, inputOffset, inputLength, context3) {
    const resultOffset = this.valueBlock.fromBER(inputBuffer, inputOffset, this.lenBlock.isIndefiniteForm ? inputLength : this.lenBlock.length, context3);
    if (resultOffset === -1) {
      this.error = this.valueBlock.error;
      return resultOffset;
    }
    if (!this.idBlock.error.length)
      this.blockLength += this.idBlock.blockLength;
    if (!this.lenBlock.error.length)
      this.blockLength += this.lenBlock.blockLength;
    if (!this.valueBlock.error.length)
      this.blockLength += this.valueBlock.blockLength;
    return resultOffset;
  }
  toBER(sizeOnly, writer) {
    const _writer = writer || new ViewWriter();
    if (!writer) {
      prepareIndefiniteForm(this);
    }
    const idBlockBuf = this.idBlock.toBER(sizeOnly);
    _writer.write(idBlockBuf);
    if (this.lenBlock.isIndefiniteForm) {
      _writer.write(new Uint8Array([128]).buffer);
      this.valueBlock.toBER(sizeOnly, _writer);
      _writer.write(new ArrayBuffer(2));
    } else {
      const valueBlockBuf = this.valueBlock.toBER(sizeOnly);
      this.lenBlock.length = valueBlockBuf.byteLength;
      const lenBlockBuf = this.lenBlock.toBER(sizeOnly);
      _writer.write(lenBlockBuf);
      _writer.write(valueBlockBuf);
    }
    if (!writer) {
      return _writer.final();
    }
    return EMPTY_BUFFER;
  }
  toJSON() {
    const object = {
      ...super.toJSON(),
      idBlock: this.idBlock.toJSON(),
      lenBlock: this.lenBlock.toJSON(),
      valueBlock: this.valueBlock.toJSON(),
      name: this.name,
      optional: this.optional
    };
    if (this.primitiveSchema)
      object.primitiveSchema = this.primitiveSchema.toJSON();
    return object;
  }
  toString(encoding = "ascii") {
    if (encoding === "ascii") {
      return this.onAsciiEncoding();
    }
    return pvtsutils.Convert.ToHex(this.toBER());
  }
  onAsciiEncoding() {
    const name = this.constructor.NAME;
    const value = pvtsutils.Convert.ToHex(this.valueBlock.valueBeforeDecodeView);
    return `${name} : ${value}`;
  }
  isEqual(other) {
    if (this === other) {
      return true;
    }
    if (!(other instanceof this.constructor)) {
      return false;
    }
    const thisRaw = this.toBER();
    const otherRaw = other.toBER();
    return isEqualBuffer(thisRaw, otherRaw);
  }
};
BaseBlock.NAME = "BaseBlock";
function prepareIndefiniteForm(baseBlock) {
  var _a3;
  if (baseBlock instanceof typeStore.Constructed) {
    for (const value of baseBlock.valueBlock.value) {
      if (prepareIndefiniteForm(value)) {
        baseBlock.lenBlock.isIndefiniteForm = true;
      }
    }
  }
  return !!((_a3 = baseBlock.lenBlock) === null || _a3 === void 0 ? void 0 : _a3.isIndefiniteForm);
}
var BaseStringBlock = class extends BaseBlock {
  getValue() {
    return this.valueBlock.value;
  }
  setValue(value) {
    this.valueBlock.value = value;
  }
  constructor({ value = EMPTY_STRING, ...parameters } = {}, stringValueBlockType) {
    super(parameters, stringValueBlockType);
    if (value) {
      this.fromString(value);
    }
  }
  fromBER(inputBuffer, inputOffset, inputLength) {
    const resultOffset = this.valueBlock.fromBER(inputBuffer, inputOffset, this.lenBlock.isIndefiniteForm ? inputLength : this.lenBlock.length);
    if (resultOffset === -1) {
      this.error = this.valueBlock.error;
      return resultOffset;
    }
    this.fromBuffer(this.valueBlock.valueHexView);
    if (!this.idBlock.error.length)
      this.blockLength += this.idBlock.blockLength;
    if (!this.lenBlock.error.length)
      this.blockLength += this.lenBlock.blockLength;
    if (!this.valueBlock.error.length)
      this.blockLength += this.valueBlock.blockLength;
    return resultOffset;
  }
  onAsciiEncoding() {
    return `${this.constructor.NAME} : '${this.valueBlock.value}'`;
  }
};
BaseStringBlock.NAME = "BaseStringBlock";
var LocalPrimitiveValueBlock = class extends HexBlock(ValueBlock) {
  constructor({ isHexOnly = true, ...parameters } = {}) {
    super(parameters);
    this.isHexOnly = isHexOnly;
  }
};
LocalPrimitiveValueBlock.NAME = "PrimitiveValueBlock";
var _a$w;
var Primitive = class extends BaseBlock {
  constructor(parameters = {}) {
    super(parameters, LocalPrimitiveValueBlock);
    this.idBlock.isConstructed = false;
  }
};
_a$w = Primitive;
(() => {
  typeStore.Primitive = _a$w;
})();
Primitive.NAME = "PRIMITIVE";
var DEFAULT_MAX_DEPTH = 100;
var DEFAULT_MAX_NODES = 1e4;
var DEFAULT_MAX_CONTENT_LENGTH = 16 * 1024 * 1024;
var MAX_DEPTH_EXCEEDED_ERROR = "Maximum ASN.1 nesting depth exceeded";
var MAX_NODES_EXCEEDED_ERROR = "Maximum ASN.1 node count exceeded";
var MAX_CONTENT_LENGTH_EXCEEDED_ERROR = "Maximum ASN.1 content length exceeded";
function createFromBerContext(options = {}) {
  var _a3, _b, _c;
  return {
    depth: 0,
    maxDepth: (_a3 = options.maxDepth) !== null && _a3 !== void 0 ? _a3 : DEFAULT_MAX_DEPTH,
    nodesCount: 0,
    maxNodes: (_b = options.maxNodes) !== null && _b !== void 0 ? _b : DEFAULT_MAX_NODES,
    maxContentLength: (_c = options.maxContentLength) !== null && _c !== void 0 ? _c : DEFAULT_MAX_CONTENT_LENGTH
  };
}
function createErrorResult(error) {
  const result = new BaseBlock({}, ValueBlock);
  result.error = error;
  return {
    offset: -1,
    result
  };
}
function checkNodesLimit(context3) {
  context3.nodesCount += 1;
  if (context3.nodesCount > context3.maxNodes) {
    return MAX_NODES_EXCEEDED_ERROR;
  }
  return void 0;
}
function checkContentLengthLimit(inputLength, context3) {
  if (inputLength > context3.maxContentLength) {
    return MAX_CONTENT_LENGTH_EXCEEDED_ERROR;
  }
  return void 0;
}
function localFromBERWithChildContext(inputBuffer, inputOffset, inputLength, context3) {
  const childDepth = context3.depth + 1;
  if (childDepth > context3.maxDepth) {
    return createErrorResult(MAX_DEPTH_EXCEEDED_ERROR);
  }
  context3.depth = childDepth;
  try {
    return localFromBER(inputBuffer, inputOffset, inputLength, context3);
  } finally {
    context3.depth -= 1;
  }
}
function localChangeType(inputObject, newType) {
  if (inputObject instanceof newType) {
    return inputObject;
  }
  const newObject = new newType();
  newObject.idBlock = inputObject.idBlock;
  newObject.lenBlock = inputObject.lenBlock;
  newObject.warnings = inputObject.warnings;
  newObject.valueBeforeDecodeView = inputObject.valueBeforeDecodeView;
  return newObject;
}
function localFromBER(inputBuffer, inputOffset = 0, inputLength = inputBuffer.length, context3 = createFromBerContext()) {
  const incomingOffset = inputOffset;
  let returnObject = new BaseBlock({}, ValueBlock);
  const baseBlock = new LocalBaseBlock();
  if (!checkBufferParams(baseBlock, inputBuffer, inputOffset, inputLength)) {
    returnObject.error = baseBlock.error;
    return {
      offset: -1,
      result: returnObject
    };
  }
  const intBuffer = inputBuffer.subarray(inputOffset, inputOffset + inputLength);
  if (!intBuffer.length) {
    returnObject.error = "Zero buffer length";
    return {
      offset: -1,
      result: returnObject
    };
  }
  const nodesLimitError = checkNodesLimit(context3);
  if (nodesLimitError) {
    returnObject.error = nodesLimitError;
    return {
      offset: -1,
      result: returnObject
    };
  }
  let resultOffset = returnObject.idBlock.fromBER(inputBuffer, inputOffset, inputLength);
  if (returnObject.idBlock.warnings.length) {
    returnObject.warnings.concat(returnObject.idBlock.warnings);
  }
  if (resultOffset === -1) {
    returnObject.error = returnObject.idBlock.error;
    return {
      offset: -1,
      result: returnObject
    };
  }
  inputOffset = resultOffset;
  inputLength -= returnObject.idBlock.blockLength;
  resultOffset = returnObject.lenBlock.fromBER(inputBuffer, inputOffset, inputLength);
  if (returnObject.lenBlock.warnings.length) {
    returnObject.warnings.concat(returnObject.lenBlock.warnings);
  }
  if (resultOffset === -1) {
    returnObject.error = returnObject.lenBlock.error;
    return {
      offset: -1,
      result: returnObject
    };
  }
  inputOffset = resultOffset;
  inputLength -= returnObject.lenBlock.blockLength;
  const valueLength = returnObject.lenBlock.isIndefiniteForm ? inputLength : returnObject.lenBlock.length;
  const contentLengthError = checkContentLengthLimit(valueLength, context3);
  if (contentLengthError) {
    returnObject.error = contentLengthError;
    return {
      offset: -1,
      result: returnObject
    };
  }
  if (!returnObject.idBlock.isConstructed && returnObject.lenBlock.isIndefiniteForm) {
    returnObject.error = "Indefinite length form used for primitive encoding form";
    return {
      offset: -1,
      result: returnObject
    };
  }
  let newASN1Type = BaseBlock;
  switch (returnObject.idBlock.tagClass) {
    case 1:
      if (returnObject.idBlock.tagNumber >= 37 && returnObject.idBlock.isHexOnly === false) {
        returnObject.error = "UNIVERSAL 37 and upper tags are reserved by ASN.1 standard";
        return {
          offset: -1,
          result: returnObject
        };
      }
      switch (returnObject.idBlock.tagNumber) {
        case 0:
          if (returnObject.idBlock.isConstructed && returnObject.lenBlock.length > 0) {
            returnObject.error = "Type [UNIVERSAL 0] is reserved";
            return {
              offset: -1,
              result: returnObject
            };
          }
          newASN1Type = typeStore.EndOfContent;
          break;
        case 1:
          newASN1Type = typeStore.Boolean;
          break;
        case 2:
          newASN1Type = typeStore.Integer;
          break;
        case 3:
          newASN1Type = typeStore.BitString;
          break;
        case 4:
          newASN1Type = typeStore.OctetString;
          break;
        case 5:
          newASN1Type = typeStore.Null;
          break;
        case 6:
          newASN1Type = typeStore.ObjectIdentifier;
          break;
        case 10:
          newASN1Type = typeStore.Enumerated;
          break;
        case 12:
          newASN1Type = typeStore.Utf8String;
          break;
        case 13:
          newASN1Type = typeStore.RelativeObjectIdentifier;
          break;
        case 14:
          newASN1Type = typeStore.TIME;
          break;
        case 15:
          returnObject.error = "[UNIVERSAL 15] is reserved by ASN.1 standard";
          return {
            offset: -1,
            result: returnObject
          };
        case 16:
          newASN1Type = typeStore.Sequence;
          break;
        case 17:
          newASN1Type = typeStore.Set;
          break;
        case 18:
          newASN1Type = typeStore.NumericString;
          break;
        case 19:
          newASN1Type = typeStore.PrintableString;
          break;
        case 20:
          newASN1Type = typeStore.TeletexString;
          break;
        case 21:
          newASN1Type = typeStore.VideotexString;
          break;
        case 22:
          newASN1Type = typeStore.IA5String;
          break;
        case 23:
          newASN1Type = typeStore.UTCTime;
          break;
        case 24:
          newASN1Type = typeStore.GeneralizedTime;
          break;
        case 25:
          newASN1Type = typeStore.GraphicString;
          break;
        case 26:
          newASN1Type = typeStore.VisibleString;
          break;
        case 27:
          newASN1Type = typeStore.GeneralString;
          break;
        case 28:
          newASN1Type = typeStore.UniversalString;
          break;
        case 29:
          newASN1Type = typeStore.CharacterString;
          break;
        case 30:
          newASN1Type = typeStore.BmpString;
          break;
        case 31:
          newASN1Type = typeStore.DATE;
          break;
        case 32:
          newASN1Type = typeStore.TimeOfDay;
          break;
        case 33:
          newASN1Type = typeStore.DateTime;
          break;
        case 34:
          newASN1Type = typeStore.Duration;
          break;
        default: {
          const newObject = returnObject.idBlock.isConstructed ? new typeStore.Constructed() : new typeStore.Primitive();
          newObject.idBlock = returnObject.idBlock;
          newObject.lenBlock = returnObject.lenBlock;
          newObject.warnings = returnObject.warnings;
          returnObject = newObject;
        }
      }
      break;
    case 2:
    case 3:
    case 4:
    default: {
      newASN1Type = returnObject.idBlock.isConstructed ? typeStore.Constructed : typeStore.Primitive;
    }
  }
  returnObject = localChangeType(returnObject, newASN1Type);
  resultOffset = returnObject.fromBER(inputBuffer, inputOffset, valueLength, context3);
  returnObject.valueBeforeDecodeView = inputBuffer.subarray(incomingOffset, incomingOffset + returnObject.blockLength);
  return {
    offset: resultOffset,
    result: returnObject
  };
}
function fromBER(inputBuffer, options = {}) {
  if (!inputBuffer.byteLength) {
    const result = new BaseBlock({}, ValueBlock);
    result.error = "Input buffer has zero length";
    return {
      offset: -1,
      result
    };
  }
  return localFromBER(pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer).slice(), 0, inputBuffer.byteLength, createFromBerContext(options));
}
function checkLen(indefiniteLength, length) {
  if (indefiniteLength) {
    return 1;
  }
  return length;
}
var LocalConstructedValueBlock = class extends ValueBlock {
  constructor({ value = [], isIndefiniteForm = false, ...parameters } = {}) {
    super(parameters);
    this.value = value;
    this.isIndefiniteForm = isIndefiniteForm;
  }
  fromBER(inputBuffer, inputOffset, inputLength, context3) {
    const view = pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer);
    const parseContext = context3 !== null && context3 !== void 0 ? context3 : createFromBerContext();
    if (!checkBufferParams(this, view, inputOffset, inputLength)) {
      return -1;
    }
    this.valueBeforeDecodeView = view.subarray(inputOffset, inputOffset + inputLength);
    if (this.valueBeforeDecodeView.length === 0) {
      this.warnings.push("Zero buffer length");
      return inputOffset;
    }
    let currentOffset = inputOffset;
    while (checkLen(this.isIndefiniteForm, inputLength) > 0) {
      const returnObject = localFromBERWithChildContext(view, currentOffset, inputLength, parseContext);
      if (returnObject.offset === -1) {
        this.error = returnObject.result.error;
        this.warnings.concat(returnObject.result.warnings);
        return -1;
      }
      currentOffset = returnObject.offset;
      this.blockLength += returnObject.result.blockLength;
      inputLength -= returnObject.result.blockLength;
      this.value.push(returnObject.result);
      if (this.isIndefiniteForm && returnObject.result.constructor.NAME === END_OF_CONTENT_NAME) {
        break;
      }
    }
    if (this.isIndefiniteForm) {
      if (this.value[this.value.length - 1].constructor.NAME === END_OF_CONTENT_NAME) {
        this.value.pop();
      } else {
        this.warnings.push("No EndOfContent block encoded");
      }
    }
    return currentOffset;
  }
  toBER(sizeOnly, writer) {
    const _writer = writer || new ViewWriter();
    for (let i = 0; i < this.value.length; i++) {
      this.value[i].toBER(sizeOnly, _writer);
    }
    if (!writer) {
      return _writer.final();
    }
    return EMPTY_BUFFER;
  }
  toJSON() {
    const object = {
      ...super.toJSON(),
      isIndefiniteForm: this.isIndefiniteForm,
      value: []
    };
    for (const value of this.value) {
      object.value.push(value.toJSON());
    }
    return object;
  }
};
LocalConstructedValueBlock.NAME = "ConstructedValueBlock";
var _a$v;
var Constructed = class extends BaseBlock {
  constructor(parameters = {}) {
    super(parameters, LocalConstructedValueBlock);
    this.idBlock.isConstructed = true;
  }
  fromBER(inputBuffer, inputOffset, inputLength, context3) {
    this.valueBlock.isIndefiniteForm = this.lenBlock.isIndefiniteForm;
    const resultOffset = this.valueBlock.fromBER(inputBuffer, inputOffset, this.lenBlock.isIndefiniteForm ? inputLength : this.lenBlock.length, context3);
    if (resultOffset === -1) {
      this.error = this.valueBlock.error;
      return resultOffset;
    }
    if (!this.idBlock.error.length)
      this.blockLength += this.idBlock.blockLength;
    if (!this.lenBlock.error.length)
      this.blockLength += this.lenBlock.blockLength;
    if (!this.valueBlock.error.length)
      this.blockLength += this.valueBlock.blockLength;
    return resultOffset;
  }
  onAsciiEncoding() {
    const values = [];
    for (const value of this.valueBlock.value) {
      values.push(value.toString("ascii").split("\n").map((o) => `  ${o}`).join("\n"));
    }
    const blockName = this.idBlock.tagClass === 3 ? `[${this.idBlock.tagNumber}]` : this.constructor.NAME;
    return values.length ? `${blockName} :
${values.join("\n")}` : `${blockName} :`;
  }
};
_a$v = Constructed;
(() => {
  typeStore.Constructed = _a$v;
})();
Constructed.NAME = "CONSTRUCTED";
var LocalEndOfContentValueBlock = class extends ValueBlock {
  fromBER(inputBuffer, inputOffset, _inputLength) {
    return inputOffset;
  }
  toBER(_sizeOnly) {
    return EMPTY_BUFFER;
  }
};
LocalEndOfContentValueBlock.override = "EndOfContentValueBlock";
var _a$u;
var EndOfContent = class extends BaseBlock {
  constructor(parameters = {}) {
    super(parameters, LocalEndOfContentValueBlock);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 0;
  }
};
_a$u = EndOfContent;
(() => {
  typeStore.EndOfContent = _a$u;
})();
EndOfContent.NAME = END_OF_CONTENT_NAME;
var _a$t;
var Null = class extends BaseBlock {
  constructor(parameters = {}) {
    super(parameters, ValueBlock);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 5;
  }
  fromBER(inputBuffer, inputOffset, inputLength) {
    if (this.lenBlock.length > 0)
      this.warnings.push("Non-zero length of value block for Null type");
    if (!this.idBlock.error.length)
      this.blockLength += this.idBlock.blockLength;
    if (!this.lenBlock.error.length)
      this.blockLength += this.lenBlock.blockLength;
    this.blockLength += inputLength;
    if (inputOffset + inputLength > inputBuffer.byteLength) {
      this.error = "End of input reached before message was fully decoded (inconsistent offset and length values)";
      return -1;
    }
    return inputOffset + inputLength;
  }
  toBER(sizeOnly, writer) {
    const retBuf = new ArrayBuffer(2);
    if (!sizeOnly) {
      const retView = new Uint8Array(retBuf);
      retView[0] = 5;
      retView[1] = 0;
    }
    if (writer) {
      writer.write(retBuf);
    }
    return retBuf;
  }
  onAsciiEncoding() {
    return `${this.constructor.NAME}`;
  }
};
_a$t = Null;
(() => {
  typeStore.Null = _a$t;
})();
Null.NAME = "NULL";
var LocalBooleanValueBlock = class extends HexBlock(ValueBlock) {
  get value() {
    for (const octet of this.valueHexView) {
      if (octet > 0) {
        return true;
      }
    }
    return false;
  }
  set value(value) {
    this.valueHexView[0] = value ? 255 : 0;
  }
  constructor({ value, ...parameters } = {}) {
    super(parameters);
    if (parameters.valueHex) {
      this.valueHexView = pvtsutils.BufferSourceConverter.toUint8Array(parameters.valueHex);
    } else {
      this.valueHexView = new Uint8Array(1);
    }
    if (value) {
      this.value = value;
    }
  }
  fromBER(inputBuffer, inputOffset, inputLength) {
    const inputView = pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer);
    if (!checkBufferParams(this, inputView, inputOffset, inputLength)) {
      return -1;
    }
    this.valueHexView = inputView.subarray(inputOffset, inputOffset + inputLength);
    if (inputLength > 1)
      this.warnings.push("Boolean value encoded in more then 1 octet");
    this.isHexOnly = true;
    utilDecodeTC.call(this);
    this.blockLength = inputLength;
    return inputOffset + inputLength;
  }
  toBER() {
    return this.valueHexView.slice();
  }
  toJSON() {
    return {
      ...super.toJSON(),
      value: this.value
    };
  }
};
LocalBooleanValueBlock.NAME = "BooleanValueBlock";
var _a$s;
var Boolean2 = class extends BaseBlock {
  getValue() {
    return this.valueBlock.value;
  }
  setValue(value) {
    this.valueBlock.value = value;
  }
  constructor(parameters = {}) {
    super(parameters, LocalBooleanValueBlock);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 1;
  }
  onAsciiEncoding() {
    return `${this.constructor.NAME} : ${this.getValue}`;
  }
};
_a$s = Boolean2;
(() => {
  typeStore.Boolean = _a$s;
})();
Boolean2.NAME = "BOOLEAN";
var LocalOctetStringValueBlock = class extends HexBlock(LocalConstructedValueBlock) {
  constructor({ isConstructed = false, ...parameters } = {}) {
    super(parameters);
    this.isConstructed = isConstructed;
  }
  fromBER(inputBuffer, inputOffset, inputLength, context3) {
    let resultOffset = 0;
    if (this.isConstructed) {
      this.isHexOnly = false;
      resultOffset = LocalConstructedValueBlock.prototype.fromBER.call(this, inputBuffer, inputOffset, inputLength, context3);
      if (resultOffset === -1)
        return resultOffset;
      for (let i = 0; i < this.value.length; i++) {
        const currentBlockName = this.value[i].constructor.NAME;
        if (currentBlockName === END_OF_CONTENT_NAME) {
          if (this.isIndefiniteForm)
            break;
          else {
            this.error = "EndOfContent is unexpected, OCTET STRING may consists of OCTET STRINGs only";
            return -1;
          }
        }
        if (currentBlockName !== OCTET_STRING_NAME) {
          this.error = "OCTET STRING may consists of OCTET STRINGs only";
          return -1;
        }
      }
    } else {
      this.isHexOnly = true;
      resultOffset = super.fromBER(inputBuffer, inputOffset, inputLength);
      this.blockLength = inputLength;
    }
    return resultOffset;
  }
  toBER(sizeOnly, writer) {
    if (this.isConstructed)
      return LocalConstructedValueBlock.prototype.toBER.call(this, sizeOnly, writer);
    return sizeOnly ? new ArrayBuffer(this.valueHexView.byteLength) : this.valueHexView.slice().buffer;
  }
  toJSON() {
    return {
      ...super.toJSON(),
      isConstructed: this.isConstructed
    };
  }
};
LocalOctetStringValueBlock.NAME = "OctetStringValueBlock";
var _a$r;
var OctetString = class extends BaseBlock {
  constructor({ idBlock = {}, lenBlock = {}, ...parameters } = {}) {
    var _b, _c;
    (_b = parameters.isConstructed) !== null && _b !== void 0 ? _b : parameters.isConstructed = !!((_c = parameters.value) === null || _c === void 0 ? void 0 : _c.length);
    super({
      idBlock: {
        isConstructed: parameters.isConstructed,
        ...idBlock
      },
      lenBlock: {
        ...lenBlock,
        isIndefiniteForm: !!parameters.isIndefiniteForm
      },
      ...parameters
    }, LocalOctetStringValueBlock);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 4;
  }
  fromBER(inputBuffer, inputOffset, inputLength, context3) {
    this.valueBlock.isConstructed = this.idBlock.isConstructed;
    this.valueBlock.isIndefiniteForm = this.lenBlock.isIndefiniteForm;
    if (inputLength === 0) {
      if (this.idBlock.error.length === 0)
        this.blockLength += this.idBlock.blockLength;
      if (this.lenBlock.error.length === 0)
        this.blockLength += this.lenBlock.blockLength;
      return inputOffset;
    }
    if (!this.valueBlock.isConstructed) {
      const view = inputBuffer instanceof ArrayBuffer ? new Uint8Array(inputBuffer) : inputBuffer;
      const buf = view.subarray(inputOffset, inputOffset + inputLength);
      try {
        if (buf.byteLength) {
          const parseContext = context3 !== null && context3 !== void 0 ? context3 : createFromBerContext();
          const asn = localFromBERWithChildContext(buf, 0, buf.byteLength, parseContext);
          if (asn.offset !== -1 && asn.offset === inputLength) {
            this.valueBlock.value = [asn.result];
          }
        }
      } catch {
      }
    }
    return super.fromBER(inputBuffer, inputOffset, inputLength, context3);
  }
  onAsciiEncoding() {
    if (this.valueBlock.isConstructed || this.valueBlock.value && this.valueBlock.value.length) {
      return Constructed.prototype.onAsciiEncoding.call(this);
    }
    const name = this.constructor.NAME;
    const value = pvtsutils.Convert.ToHex(this.valueBlock.valueHexView);
    return `${name} : ${value}`;
  }
  getValue() {
    if (!this.idBlock.isConstructed) {
      return this.valueBlock.valueHexView.slice().buffer;
    }
    const array = [];
    for (const content of this.valueBlock.value) {
      if (content instanceof _a$r) {
        array.push(content.valueBlock.valueHexView);
      }
    }
    return pvtsutils.BufferSourceConverter.concat(array);
  }
};
_a$r = OctetString;
(() => {
  typeStore.OctetString = _a$r;
})();
OctetString.NAME = OCTET_STRING_NAME;
var LocalBitStringValueBlock = class extends HexBlock(LocalConstructedValueBlock) {
  constructor({ unusedBits = 0, isConstructed = false, ...parameters } = {}) {
    super(parameters);
    this.unusedBits = unusedBits;
    this.isConstructed = isConstructed;
    this.blockLength = this.valueHexView.byteLength;
  }
  fromBER(inputBuffer, inputOffset, inputLength, context3) {
    if (!inputLength) {
      return inputOffset;
    }
    let resultOffset = -1;
    if (this.isConstructed) {
      resultOffset = LocalConstructedValueBlock.prototype.fromBER.call(this, inputBuffer, inputOffset, inputLength, context3);
      if (resultOffset === -1)
        return resultOffset;
      for (const value of this.value) {
        const currentBlockName = value.constructor.NAME;
        if (currentBlockName === END_OF_CONTENT_NAME) {
          if (this.isIndefiniteForm)
            break;
          else {
            this.error = "EndOfContent is unexpected, BIT STRING may consists of BIT STRINGs only";
            return -1;
          }
        }
        if (currentBlockName !== BIT_STRING_NAME) {
          this.error = "BIT STRING may consists of BIT STRINGs only";
          return -1;
        }
        const valueBlock = value.valueBlock;
        if (this.unusedBits > 0 && valueBlock.unusedBits > 0) {
          this.error = 'Using of "unused bits" inside constructive BIT STRING allowed for least one only';
          return -1;
        }
        this.unusedBits = valueBlock.unusedBits;
      }
      return resultOffset;
    }
    const inputView = pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer);
    if (!checkBufferParams(this, inputView, inputOffset, inputLength)) {
      return -1;
    }
    const intBuffer = inputView.subarray(inputOffset, inputOffset + inputLength);
    this.unusedBits = intBuffer[0];
    if (this.unusedBits > 7) {
      this.error = "Unused bits for BitString must be in range 0-7";
      return -1;
    }
    if (!this.unusedBits) {
      const buf = intBuffer.subarray(1);
      try {
        if (buf.byteLength) {
          const parseContext = context3 !== null && context3 !== void 0 ? context3 : createFromBerContext();
          const asn = localFromBERWithChildContext(buf, 0, buf.byteLength, parseContext);
          if (asn.offset !== -1 && asn.offset === inputLength - 1) {
            this.value = [asn.result];
          }
        }
      } catch {
      }
    }
    this.valueHexView = intBuffer.subarray(1);
    this.blockLength = intBuffer.length;
    return inputOffset + inputLength;
  }
  toBER(sizeOnly, writer) {
    if (this.isConstructed) {
      return LocalConstructedValueBlock.prototype.toBER.call(this, sizeOnly, writer);
    }
    if (sizeOnly) {
      return new ArrayBuffer(this.valueHexView.byteLength + 1);
    }
    if (!this.valueHexView.byteLength) {
      const empty = new Uint8Array(1);
      empty[0] = 0;
      return empty.buffer;
    }
    const retView = new Uint8Array(this.valueHexView.length + 1);
    retView[0] = this.unusedBits;
    retView.set(this.valueHexView, 1);
    return retView.buffer;
  }
  toJSON() {
    return {
      ...super.toJSON(),
      unusedBits: this.unusedBits,
      isConstructed: this.isConstructed
    };
  }
};
LocalBitStringValueBlock.NAME = "BitStringValueBlock";
var _a$q;
var BitString = class extends BaseBlock {
  constructor({ idBlock = {}, lenBlock = {}, ...parameters } = {}) {
    var _b, _c;
    (_b = parameters.isConstructed) !== null && _b !== void 0 ? _b : parameters.isConstructed = !!((_c = parameters.value) === null || _c === void 0 ? void 0 : _c.length);
    super({
      idBlock: {
        isConstructed: parameters.isConstructed,
        ...idBlock
      },
      lenBlock: {
        ...lenBlock,
        isIndefiniteForm: !!parameters.isIndefiniteForm
      },
      ...parameters
    }, LocalBitStringValueBlock);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 3;
  }
  fromBER(inputBuffer, inputOffset, inputLength, context3) {
    this.valueBlock.isConstructed = this.idBlock.isConstructed;
    this.valueBlock.isIndefiniteForm = this.lenBlock.isIndefiniteForm;
    return super.fromBER(inputBuffer, inputOffset, inputLength, context3);
  }
  onAsciiEncoding() {
    if (this.valueBlock.isConstructed || this.valueBlock.value && this.valueBlock.value.length) {
      return Constructed.prototype.onAsciiEncoding.call(this);
    } else {
      const bits = [];
      const valueHex = this.valueBlock.valueHexView;
      for (const byte of valueHex) {
        bits.push(byte.toString(2).padStart(8, "0"));
      }
      const bitsStr = bits.join("");
      const name = this.constructor.NAME;
      const value = bitsStr.substring(0, bitsStr.length - this.valueBlock.unusedBits);
      return `${name} : ${value}`;
    }
  }
};
_a$q = BitString;
(() => {
  typeStore.BitString = _a$q;
})();
BitString.NAME = BIT_STRING_NAME;
var _a$p;
function viewAdd(first, second) {
  const c = new Uint8Array([0]);
  const firstView = new Uint8Array(first);
  const secondView = new Uint8Array(second);
  let firstViewCopy = firstView.slice(0);
  const firstViewCopyLength = firstViewCopy.length - 1;
  const secondViewCopy = secondView.slice(0);
  const secondViewCopyLength = secondViewCopy.length - 1;
  let value = 0;
  const max = secondViewCopyLength < firstViewCopyLength ? firstViewCopyLength : secondViewCopyLength;
  let counter = 0;
  for (let i = max; i >= 0; i--, counter++) {
    switch (true) {
      case counter < secondViewCopy.length:
        value = firstViewCopy[firstViewCopyLength - counter] + secondViewCopy[secondViewCopyLength - counter] + c[0];
        break;
      default:
        value = firstViewCopy[firstViewCopyLength - counter] + c[0];
    }
    c[0] = value / 10;
    switch (true) {
      case counter >= firstViewCopy.length:
        firstViewCopy = utilConcatView(new Uint8Array([value % 10]), firstViewCopy);
        break;
      default:
        firstViewCopy[firstViewCopyLength - counter] = value % 10;
    }
  }
  if (c[0] > 0)
    firstViewCopy = utilConcatView(c, firstViewCopy);
  return firstViewCopy;
}
function power2(n) {
  if (n >= powers2.length) {
    for (let p = powers2.length; p <= n; p++) {
      const c = new Uint8Array([0]);
      let digits = powers2[p - 1].slice(0);
      for (let i = digits.length - 1; i >= 0; i--) {
        const newValue = new Uint8Array([(digits[i] << 1) + c[0]]);
        c[0] = newValue[0] / 10;
        digits[i] = newValue[0] % 10;
      }
      if (c[0] > 0)
        digits = utilConcatView(c, digits);
      powers2.push(digits);
    }
  }
  return powers2[n];
}
function viewSub(first, second) {
  let b = 0;
  const firstView = new Uint8Array(first);
  const secondView = new Uint8Array(second);
  const firstViewCopy = firstView.slice(0);
  const firstViewCopyLength = firstViewCopy.length - 1;
  const secondViewCopy = secondView.slice(0);
  const secondViewCopyLength = secondViewCopy.length - 1;
  let value;
  let counter = 0;
  for (let i = secondViewCopyLength; i >= 0; i--, counter++) {
    value = firstViewCopy[firstViewCopyLength - counter] - secondViewCopy[secondViewCopyLength - counter] - b;
    switch (true) {
      case value < 0:
        b = 1;
        firstViewCopy[firstViewCopyLength - counter] = value + 10;
        break;
      default:
        b = 0;
        firstViewCopy[firstViewCopyLength - counter] = value;
    }
  }
  if (b > 0) {
    for (let i = firstViewCopyLength - secondViewCopyLength + 1; i >= 0; i--, counter++) {
      value = firstViewCopy[firstViewCopyLength - counter] - b;
      if (value < 0) {
        b = 1;
        firstViewCopy[firstViewCopyLength - counter] = value + 10;
      } else {
        b = 0;
        firstViewCopy[firstViewCopyLength - counter] = value;
        break;
      }
    }
  }
  return firstViewCopy.slice();
}
var LocalIntegerValueBlock = class extends HexBlock(ValueBlock) {
  setValueHex() {
    if (this.valueHexView.length >= 4) {
      this.warnings.push("Too big Integer for decoding, hex only");
      this.isHexOnly = true;
      this._valueDec = 0;
    } else {
      this.isHexOnly = false;
      if (this.valueHexView.length > 0) {
        this._valueDec = utilDecodeTC.call(this);
      }
    }
  }
  constructor({ value, ...parameters } = {}) {
    super(parameters);
    this._valueDec = 0;
    if (parameters.valueHex) {
      this.setValueHex();
    }
    if (value !== void 0) {
      this.valueDec = value;
    }
  }
  set valueDec(v) {
    this._valueDec = v;
    this.isHexOnly = false;
    this.valueHexView = new Uint8Array(utilEncodeTC(v));
  }
  get valueDec() {
    return this._valueDec;
  }
  fromDER(inputBuffer, inputOffset, inputLength, expectedLength = 0) {
    const offset = this.fromBER(inputBuffer, inputOffset, inputLength);
    if (offset === -1)
      return offset;
    const view = this.valueHexView;
    if (view[0] === 0 && (view[1] & 128) !== 0) {
      this.valueHexView = view.subarray(1);
    } else {
      if (expectedLength !== 0) {
        if (view.length < expectedLength) {
          if (expectedLength - view.length > 1)
            expectedLength = view.length + 1;
          this.valueHexView = view.subarray(expectedLength - view.length);
        }
      }
    }
    return offset;
  }
  toDER(sizeOnly = false) {
    const view = this.valueHexView;
    switch (true) {
      case (view[0] & 128) !== 0:
        {
          const updatedView = new Uint8Array(this.valueHexView.length + 1);
          updatedView[0] = 0;
          updatedView.set(view, 1);
          this.valueHexView = updatedView;
        }
        break;
      case (view[0] === 0 && (view[1] & 128) === 0):
        {
          this.valueHexView = this.valueHexView.subarray(1);
        }
        break;
    }
    return this.toBER(sizeOnly);
  }
  fromBER(inputBuffer, inputOffset, inputLength) {
    const resultOffset = super.fromBER(inputBuffer, inputOffset, inputLength);
    if (resultOffset === -1) {
      return resultOffset;
    }
    this.setValueHex();
    return resultOffset;
  }
  toBER(sizeOnly) {
    return sizeOnly ? new ArrayBuffer(this.valueHexView.length) : this.valueHexView.slice().buffer;
  }
  toJSON() {
    return {
      ...super.toJSON(),
      valueDec: this.valueDec
    };
  }
  toString() {
    const firstBit = this.valueHexView.length * 8 - 1;
    let digits = new Uint8Array(this.valueHexView.length * 8 / 3);
    let bitNumber = 0;
    let currentByte;
    const asn1View = this.valueHexView;
    let result = "";
    let flag = false;
    for (let byteNumber = asn1View.byteLength - 1; byteNumber >= 0; byteNumber--) {
      currentByte = asn1View[byteNumber];
      for (let i = 0; i < 8; i++) {
        if ((currentByte & 1) === 1) {
          switch (bitNumber) {
            case firstBit:
              digits = viewSub(power2(bitNumber), digits);
              result = "-";
              break;
            default:
              digits = viewAdd(digits, power2(bitNumber));
          }
        }
        bitNumber++;
        currentByte >>= 1;
      }
    }
    for (let i = 0; i < digits.length; i++) {
      if (digits[i])
        flag = true;
      if (flag)
        result += digitsString.charAt(digits[i]);
    }
    if (flag === false)
      result += digitsString.charAt(0);
    return result;
  }
};
_a$p = LocalIntegerValueBlock;
LocalIntegerValueBlock.NAME = "IntegerValueBlock";
(() => {
  Object.defineProperty(_a$p.prototype, "valueHex", {
    set: function(v) {
      this.valueHexView = new Uint8Array(v);
      this.setValueHex();
    },
    get: function() {
      return this.valueHexView.slice().buffer;
    }
  });
})();
var _a$o;
var Integer = class extends BaseBlock {
  constructor(parameters = {}) {
    super(parameters, LocalIntegerValueBlock);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 2;
  }
  toBigInt() {
    assertBigInt();
    return BigInt(this.valueBlock.toString());
  }
  static fromBigInt(value) {
    assertBigInt();
    const bigIntValue = BigInt(value);
    const writer = new ViewWriter();
    const hex2 = bigIntValue.toString(16).replace(/^-/, "");
    const view = new Uint8Array(pvtsutils.Convert.FromHex(hex2));
    if (bigIntValue < 0) {
      const first = new Uint8Array(view.length + (view[0] & 128 ? 1 : 0));
      first[0] |= 128;
      const firstInt = BigInt(`0x${pvtsutils.Convert.ToHex(first)}`);
      const secondInt = firstInt + bigIntValue;
      const second = pvtsutils.BufferSourceConverter.toUint8Array(pvtsutils.Convert.FromHex(secondInt.toString(16)));
      second[0] |= 128;
      writer.write(second);
    } else {
      if (view[0] & 128) {
        writer.write(new Uint8Array([0]));
      }
      writer.write(view);
    }
    const res = new _a$o({ valueHex: writer.final() });
    return res;
  }
  convertToDER() {
    const integer = new _a$o({ valueHex: this.valueBlock.valueHexView });
    integer.valueBlock.toDER();
    return integer;
  }
  convertFromDER() {
    return new _a$o({
      valueHex: this.valueBlock.valueHexView[0] === 0 ? this.valueBlock.valueHexView.subarray(1) : this.valueBlock.valueHexView
    });
  }
  onAsciiEncoding() {
    return `${this.constructor.NAME} : ${this.valueBlock.toString()}`;
  }
};
_a$o = Integer;
(() => {
  typeStore.Integer = _a$o;
})();
Integer.NAME = "INTEGER";
var _a$n;
var Enumerated = class extends Integer {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 10;
  }
};
_a$n = Enumerated;
(() => {
  typeStore.Enumerated = _a$n;
})();
Enumerated.NAME = "ENUMERATED";
var LocalSidValueBlock = class extends HexBlock(ValueBlock) {
  constructor({ valueDec = -1, isFirstSid = false, ...parameters } = {}) {
    super(parameters);
    this.valueDec = valueDec;
    this.isFirstSid = isFirstSid;
  }
  fromBER(inputBuffer, inputOffset, inputLength) {
    if (!inputLength) {
      return inputOffset;
    }
    const inputView = pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer);
    if (!checkBufferParams(this, inputView, inputOffset, inputLength)) {
      return -1;
    }
    const intBuffer = inputView.subarray(inputOffset, inputOffset + inputLength);
    this.valueHexView = new Uint8Array(inputLength);
    for (let i = 0; i < inputLength; i++) {
      this.valueHexView[i] = intBuffer[i] & 127;
      this.blockLength++;
      if ((intBuffer[i] & 128) === 0)
        break;
    }
    const tempView = new Uint8Array(this.blockLength);
    for (let i = 0; i < this.blockLength; i++) {
      tempView[i] = this.valueHexView[i];
    }
    this.valueHexView = tempView;
    if ((intBuffer[this.blockLength - 1] & 128) !== 0) {
      this.error = "End of input reached before message was fully decoded";
      return -1;
    }
    if (this.valueHexView[0] === 0)
      this.warnings.push("Needlessly long format of SID encoding");
    if (this.blockLength <= 8)
      this.valueDec = utilFromBase(this.valueHexView, 7);
    else {
      this.isHexOnly = true;
      this.warnings.push("Too big SID for decoding, hex only");
    }
    return inputOffset + this.blockLength;
  }
  set valueBigInt(value) {
    assertBigInt();
    let bits = BigInt(value).toString(2);
    while (bits.length % 7) {
      bits = "0" + bits;
    }
    const bytes = new Uint8Array(bits.length / 7);
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = parseInt(bits.slice(i * 7, i * 7 + 7), 2) + (i + 1 < bytes.length ? 128 : 0);
    }
    this.fromBER(bytes.buffer, 0, bytes.length);
  }
  toBER(sizeOnly) {
    if (this.isHexOnly) {
      if (sizeOnly)
        return new ArrayBuffer(this.valueHexView.byteLength);
      const curView = this.valueHexView;
      const retView2 = new Uint8Array(this.blockLength);
      for (let i = 0; i < this.blockLength - 1; i++)
        retView2[i] = curView[i] | 128;
      retView2[this.blockLength - 1] = curView[this.blockLength - 1];
      return retView2.buffer;
    }
    const encodedBuf = utilToBase(this.valueDec, 7);
    if (encodedBuf.byteLength === 0) {
      this.error = "Error during encoding SID value";
      return EMPTY_BUFFER;
    }
    const retView = new Uint8Array(encodedBuf.byteLength);
    if (!sizeOnly) {
      const encodedView = new Uint8Array(encodedBuf);
      const len = encodedBuf.byteLength - 1;
      for (let i = 0; i < len; i++)
        retView[i] = encodedView[i] | 128;
      retView[len] = encodedView[len];
    }
    return retView;
  }
  toString() {
    let result = "";
    if (this.isHexOnly)
      result = pvtsutils.Convert.ToHex(this.valueHexView);
    else {
      if (this.isFirstSid) {
        let sidValue = this.valueDec;
        if (this.valueDec <= 39)
          result = "0.";
        else {
          if (this.valueDec <= 79) {
            result = "1.";
            sidValue -= 40;
          } else {
            result = "2.";
            sidValue -= 80;
          }
        }
        result += sidValue.toString();
      } else
        result = this.valueDec.toString();
    }
    return result;
  }
  toJSON() {
    return {
      ...super.toJSON(),
      valueDec: this.valueDec,
      isFirstSid: this.isFirstSid
    };
  }
};
LocalSidValueBlock.NAME = "sidBlock";
var LocalObjectIdentifierValueBlock = class extends ValueBlock {
  constructor({ value = EMPTY_STRING, ...parameters } = {}) {
    super(parameters);
    this.value = [];
    if (value) {
      this.fromString(value);
    }
  }
  fromBER(inputBuffer, inputOffset, inputLength) {
    let resultOffset = inputOffset;
    while (inputLength > 0) {
      const sidBlock = new LocalSidValueBlock();
      resultOffset = sidBlock.fromBER(inputBuffer, resultOffset, inputLength);
      if (resultOffset === -1) {
        this.blockLength = 0;
        this.error = sidBlock.error;
        return resultOffset;
      }
      if (this.value.length === 0)
        sidBlock.isFirstSid = true;
      this.blockLength += sidBlock.blockLength;
      inputLength -= sidBlock.blockLength;
      this.value.push(sidBlock);
    }
    return resultOffset;
  }
  toBER(sizeOnly) {
    const retBuffers = [];
    for (let i = 0; i < this.value.length; i++) {
      const valueBuf = this.value[i].toBER(sizeOnly);
      if (valueBuf.byteLength === 0) {
        this.error = this.value[i].error;
        return EMPTY_BUFFER;
      }
      retBuffers.push(valueBuf);
    }
    return concat(retBuffers);
  }
  fromString(string) {
    this.value = [];
    let pos1 = 0;
    let pos2 = 0;
    let sid = "";
    let flag = false;
    do {
      pos2 = string.indexOf(".", pos1);
      if (pos2 === -1)
        sid = string.substring(pos1);
      else
        sid = string.substring(pos1, pos2);
      pos1 = pos2 + 1;
      if (flag) {
        const sidBlock = this.value[0];
        let plus = 0;
        switch (sidBlock.valueDec) {
          case 0:
            break;
          case 1:
            plus = 40;
            break;
          case 2:
            plus = 80;
            break;
          default:
            this.value = [];
            return;
        }
        const parsedSID = parseInt(sid, 10);
        if (isNaN(parsedSID))
          return;
        sidBlock.valueDec = parsedSID + plus;
        flag = false;
      } else {
        const sidBlock = new LocalSidValueBlock();
        if (sid > Number.MAX_SAFE_INTEGER) {
          assertBigInt();
          const sidValue = BigInt(sid);
          sidBlock.valueBigInt = sidValue;
        } else {
          sidBlock.valueDec = parseInt(sid, 10);
          if (isNaN(sidBlock.valueDec))
            return;
        }
        if (!this.value.length) {
          sidBlock.isFirstSid = true;
          flag = true;
        }
        this.value.push(sidBlock);
      }
    } while (pos2 !== -1);
  }
  toString() {
    let result = "";
    let isHexOnly = false;
    for (let i = 0; i < this.value.length; i++) {
      isHexOnly = this.value[i].isHexOnly;
      let sidStr = this.value[i].toString();
      if (i !== 0)
        result = `${result}.`;
      if (isHexOnly) {
        sidStr = `{${sidStr}}`;
        if (this.value[i].isFirstSid)
          result = `2.{${sidStr} - 80}`;
        else
          result += sidStr;
      } else
        result += sidStr;
    }
    return result;
  }
  toJSON() {
    const object = {
      ...super.toJSON(),
      value: this.toString(),
      sidArray: []
    };
    for (let i = 0; i < this.value.length; i++) {
      object.sidArray.push(this.value[i].toJSON());
    }
    return object;
  }
};
LocalObjectIdentifierValueBlock.NAME = "ObjectIdentifierValueBlock";
var _a$m;
var ObjectIdentifier = class extends BaseBlock {
  getValue() {
    return this.valueBlock.toString();
  }
  setValue(value) {
    this.valueBlock.fromString(value);
  }
  constructor(parameters = {}) {
    super(parameters, LocalObjectIdentifierValueBlock);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 6;
  }
  onAsciiEncoding() {
    return `${this.constructor.NAME} : ${this.valueBlock.toString() || "empty"}`;
  }
  toJSON() {
    return {
      ...super.toJSON(),
      value: this.getValue()
    };
  }
};
_a$m = ObjectIdentifier;
(() => {
  typeStore.ObjectIdentifier = _a$m;
})();
ObjectIdentifier.NAME = "OBJECT IDENTIFIER";
var LocalRelativeSidValueBlock = class extends HexBlock(LocalBaseBlock) {
  constructor({ valueDec = 0, ...parameters } = {}) {
    super(parameters);
    this.valueDec = valueDec;
  }
  fromBER(inputBuffer, inputOffset, inputLength) {
    if (inputLength === 0)
      return inputOffset;
    const inputView = pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer);
    if (!checkBufferParams(this, inputView, inputOffset, inputLength))
      return -1;
    const intBuffer = inputView.subarray(inputOffset, inputOffset + inputLength);
    this.valueHexView = new Uint8Array(inputLength);
    for (let i = 0; i < inputLength; i++) {
      this.valueHexView[i] = intBuffer[i] & 127;
      this.blockLength++;
      if ((intBuffer[i] & 128) === 0)
        break;
    }
    const tempView = new Uint8Array(this.blockLength);
    for (let i = 0; i < this.blockLength; i++)
      tempView[i] = this.valueHexView[i];
    this.valueHexView = tempView;
    if ((intBuffer[this.blockLength - 1] & 128) !== 0) {
      this.error = "End of input reached before message was fully decoded";
      return -1;
    }
    if (this.valueHexView[0] === 0)
      this.warnings.push("Needlessly long format of SID encoding");
    if (this.blockLength <= 8)
      this.valueDec = utilFromBase(this.valueHexView, 7);
    else {
      this.isHexOnly = true;
      this.warnings.push("Too big SID for decoding, hex only");
    }
    return inputOffset + this.blockLength;
  }
  toBER(sizeOnly) {
    if (this.isHexOnly) {
      if (sizeOnly)
        return new ArrayBuffer(this.valueHexView.byteLength);
      const curView = this.valueHexView;
      const retView2 = new Uint8Array(this.blockLength);
      for (let i = 0; i < this.blockLength - 1; i++)
        retView2[i] = curView[i] | 128;
      retView2[this.blockLength - 1] = curView[this.blockLength - 1];
      return retView2.buffer;
    }
    const encodedBuf = utilToBase(this.valueDec, 7);
    if (encodedBuf.byteLength === 0) {
      this.error = "Error during encoding SID value";
      return EMPTY_BUFFER;
    }
    const retView = new Uint8Array(encodedBuf.byteLength);
    if (!sizeOnly) {
      const encodedView = new Uint8Array(encodedBuf);
      const len = encodedBuf.byteLength - 1;
      for (let i = 0; i < len; i++)
        retView[i] = encodedView[i] | 128;
      retView[len] = encodedView[len];
    }
    return retView.buffer;
  }
  toString() {
    let result = "";
    if (this.isHexOnly)
      result = pvtsutils.Convert.ToHex(this.valueHexView);
    else {
      result = this.valueDec.toString();
    }
    return result;
  }
  toJSON() {
    return {
      ...super.toJSON(),
      valueDec: this.valueDec
    };
  }
};
LocalRelativeSidValueBlock.NAME = "relativeSidBlock";
var LocalRelativeObjectIdentifierValueBlock = class extends ValueBlock {
  constructor({ value = EMPTY_STRING, ...parameters } = {}) {
    super(parameters);
    this.value = [];
    if (value) {
      this.fromString(value);
    }
  }
  fromBER(inputBuffer, inputOffset, inputLength) {
    let resultOffset = inputOffset;
    while (inputLength > 0) {
      const sidBlock = new LocalRelativeSidValueBlock();
      resultOffset = sidBlock.fromBER(inputBuffer, resultOffset, inputLength);
      if (resultOffset === -1) {
        this.blockLength = 0;
        this.error = sidBlock.error;
        return resultOffset;
      }
      this.blockLength += sidBlock.blockLength;
      inputLength -= sidBlock.blockLength;
      this.value.push(sidBlock);
    }
    return resultOffset;
  }
  toBER(sizeOnly, _writer) {
    const retBuffers = [];
    for (let i = 0; i < this.value.length; i++) {
      const valueBuf = this.value[i].toBER(sizeOnly);
      if (valueBuf.byteLength === 0) {
        this.error = this.value[i].error;
        return EMPTY_BUFFER;
      }
      retBuffers.push(valueBuf);
    }
    return concat(retBuffers);
  }
  fromString(string) {
    this.value = [];
    let pos1 = 0;
    let pos2 = 0;
    let sid = "";
    do {
      pos2 = string.indexOf(".", pos1);
      if (pos2 === -1)
        sid = string.substring(pos1);
      else
        sid = string.substring(pos1, pos2);
      pos1 = pos2 + 1;
      const sidBlock = new LocalRelativeSidValueBlock();
      sidBlock.valueDec = parseInt(sid, 10);
      if (isNaN(sidBlock.valueDec))
        return true;
      this.value.push(sidBlock);
    } while (pos2 !== -1);
    return true;
  }
  toString() {
    let result = "";
    let isHexOnly = false;
    for (let i = 0; i < this.value.length; i++) {
      isHexOnly = this.value[i].isHexOnly;
      let sidStr = this.value[i].toString();
      if (i !== 0)
        result = `${result}.`;
      if (isHexOnly) {
        sidStr = `{${sidStr}}`;
        result += sidStr;
      } else
        result += sidStr;
    }
    return result;
  }
  toJSON() {
    const object = {
      ...super.toJSON(),
      value: this.toString(),
      sidArray: []
    };
    for (let i = 0; i < this.value.length; i++)
      object.sidArray.push(this.value[i].toJSON());
    return object;
  }
};
LocalRelativeObjectIdentifierValueBlock.NAME = "RelativeObjectIdentifierValueBlock";
var _a$l;
var RelativeObjectIdentifier = class extends BaseBlock {
  getValue() {
    return this.valueBlock.toString();
  }
  setValue(value) {
    this.valueBlock.fromString(value);
  }
  constructor(parameters = {}) {
    super(parameters, LocalRelativeObjectIdentifierValueBlock);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 13;
  }
  onAsciiEncoding() {
    return `${this.constructor.NAME} : ${this.valueBlock.toString() || "empty"}`;
  }
  toJSON() {
    return {
      ...super.toJSON(),
      value: this.getValue()
    };
  }
};
_a$l = RelativeObjectIdentifier;
(() => {
  typeStore.RelativeObjectIdentifier = _a$l;
})();
RelativeObjectIdentifier.NAME = "RelativeObjectIdentifier";
var _a$k;
var Sequence = class extends Constructed {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 16;
  }
};
_a$k = Sequence;
(() => {
  typeStore.Sequence = _a$k;
})();
Sequence.NAME = "SEQUENCE";
var _a$j;
var Set2 = class extends Constructed {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 17;
  }
};
_a$j = Set2;
(() => {
  typeStore.Set = _a$j;
})();
Set2.NAME = "SET";
var LocalStringValueBlock = class extends HexBlock(ValueBlock) {
  constructor({ ...parameters } = {}) {
    super(parameters);
    this.isHexOnly = true;
    this.value = EMPTY_STRING;
  }
  toJSON() {
    return {
      ...super.toJSON(),
      value: this.value
    };
  }
};
LocalStringValueBlock.NAME = "StringValueBlock";
var LocalSimpleStringValueBlock = class extends LocalStringValueBlock {
};
LocalSimpleStringValueBlock.NAME = "SimpleStringValueBlock";
var LocalSimpleStringBlock = class extends BaseStringBlock {
  constructor({ ...parameters } = {}) {
    super(parameters, LocalSimpleStringValueBlock);
  }
  fromBuffer(inputBuffer) {
    this.valueBlock.value = String.fromCharCode.apply(null, pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer));
  }
  fromString(inputString) {
    const strLen = inputString.length;
    const view = this.valueBlock.valueHexView = new Uint8Array(strLen);
    for (let i = 0; i < strLen; i++)
      view[i] = inputString.charCodeAt(i);
    this.valueBlock.value = inputString;
  }
};
LocalSimpleStringBlock.NAME = "SIMPLE STRING";
var LocalUtf8StringValueBlock = class extends LocalSimpleStringBlock {
  fromBuffer(inputBuffer) {
    this.valueBlock.valueHexView = pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer);
    try {
      this.valueBlock.value = pvtsutils.Convert.ToUtf8String(inputBuffer);
    } catch (ex) {
      this.warnings.push(`Error during "decodeURIComponent": ${ex}, using raw string`);
      this.valueBlock.value = pvtsutils.Convert.ToBinary(inputBuffer);
    }
  }
  fromString(inputString) {
    this.valueBlock.valueHexView = new Uint8Array(pvtsutils.Convert.FromUtf8String(inputString));
    this.valueBlock.value = inputString;
  }
};
LocalUtf8StringValueBlock.NAME = "Utf8StringValueBlock";
var _a$i;
var Utf8String = class extends LocalUtf8StringValueBlock {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 12;
  }
};
_a$i = Utf8String;
(() => {
  typeStore.Utf8String = _a$i;
})();
Utf8String.NAME = "UTF8String";
var LocalBmpStringValueBlock = class extends LocalSimpleStringBlock {
  fromBuffer(inputBuffer) {
    this.valueBlock.value = pvtsutils.Convert.ToUtf16String(inputBuffer);
    this.valueBlock.valueHexView = pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer);
  }
  fromString(inputString) {
    this.valueBlock.value = inputString;
    this.valueBlock.valueHexView = new Uint8Array(pvtsutils.Convert.FromUtf16String(inputString));
  }
};
LocalBmpStringValueBlock.NAME = "BmpStringValueBlock";
var _a$h;
var BmpString = class extends LocalBmpStringValueBlock {
  constructor({ ...parameters } = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 30;
  }
};
_a$h = BmpString;
(() => {
  typeStore.BmpString = _a$h;
})();
BmpString.NAME = "BMPString";
var LocalUniversalStringValueBlock = class extends LocalSimpleStringBlock {
  fromBuffer(inputBuffer) {
    const copyBuffer = ArrayBuffer.isView(inputBuffer) ? inputBuffer.slice().buffer : inputBuffer.slice(0);
    const valueView = new Uint8Array(copyBuffer);
    for (let i = 0; i < valueView.length; i += 4) {
      valueView[i] = valueView[i + 3];
      valueView[i + 1] = valueView[i + 2];
      valueView[i + 2] = 0;
      valueView[i + 3] = 0;
    }
    this.valueBlock.value = String.fromCharCode.apply(null, new Uint32Array(copyBuffer));
  }
  fromString(inputString) {
    const strLength = inputString.length;
    const valueHexView = this.valueBlock.valueHexView = new Uint8Array(strLength * 4);
    for (let i = 0; i < strLength; i++) {
      const codeBuf = utilToBase(inputString.charCodeAt(i), 8);
      const codeView = new Uint8Array(codeBuf);
      if (codeView.length > 4)
        continue;
      const dif = 4 - codeView.length;
      for (let j = codeView.length - 1; j >= 0; j--)
        valueHexView[i * 4 + j + dif] = codeView[j];
    }
    this.valueBlock.value = inputString;
  }
};
LocalUniversalStringValueBlock.NAME = "UniversalStringValueBlock";
var _a$g;
var UniversalString = class extends LocalUniversalStringValueBlock {
  constructor({ ...parameters } = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 28;
  }
};
_a$g = UniversalString;
(() => {
  typeStore.UniversalString = _a$g;
})();
UniversalString.NAME = "UniversalString";
var _a$f;
var NumericString = class extends LocalSimpleStringBlock {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 18;
  }
};
_a$f = NumericString;
(() => {
  typeStore.NumericString = _a$f;
})();
NumericString.NAME = "NumericString";
var _a$e;
var PrintableString = class extends LocalSimpleStringBlock {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 19;
  }
};
_a$e = PrintableString;
(() => {
  typeStore.PrintableString = _a$e;
})();
PrintableString.NAME = "PrintableString";
var _a$d;
var TeletexString = class extends LocalSimpleStringBlock {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 20;
  }
};
_a$d = TeletexString;
(() => {
  typeStore.TeletexString = _a$d;
})();
TeletexString.NAME = "TeletexString";
var _a$c;
var VideotexString = class extends LocalSimpleStringBlock {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 21;
  }
};
_a$c = VideotexString;
(() => {
  typeStore.VideotexString = _a$c;
})();
VideotexString.NAME = "VideotexString";
var _a$b;
var IA5String = class extends LocalSimpleStringBlock {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 22;
  }
};
_a$b = IA5String;
(() => {
  typeStore.IA5String = _a$b;
})();
IA5String.NAME = "IA5String";
var _a$a;
var GraphicString = class extends LocalSimpleStringBlock {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 25;
  }
};
_a$a = GraphicString;
(() => {
  typeStore.GraphicString = _a$a;
})();
GraphicString.NAME = "GraphicString";
var _a$9;
var VisibleString = class extends LocalSimpleStringBlock {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 26;
  }
};
_a$9 = VisibleString;
(() => {
  typeStore.VisibleString = _a$9;
})();
VisibleString.NAME = "VisibleString";
var _a$8;
var GeneralString = class extends LocalSimpleStringBlock {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 27;
  }
};
_a$8 = GeneralString;
(() => {
  typeStore.GeneralString = _a$8;
})();
GeneralString.NAME = "GeneralString";
var _a$7;
var CharacterString = class extends LocalSimpleStringBlock {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 29;
  }
};
_a$7 = CharacterString;
(() => {
  typeStore.CharacterString = _a$7;
})();
CharacterString.NAME = "CharacterString";
var _a$6;
var UTCTime = class extends VisibleString {
  constructor({ value, valueDate, ...parameters } = {}) {
    super(parameters);
    this.year = 0;
    this.month = 0;
    this.day = 0;
    this.hour = 0;
    this.minute = 0;
    this.second = 0;
    if (value) {
      this.fromString(value);
      this.valueBlock.valueHexView = new Uint8Array(value.length);
      for (let i = 0; i < value.length; i++)
        this.valueBlock.valueHexView[i] = value.charCodeAt(i);
    }
    if (valueDate) {
      this.fromDate(valueDate);
      this.valueBlock.valueHexView = new Uint8Array(this.toBuffer());
    }
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 23;
  }
  fromBuffer(inputBuffer) {
    this.fromString(String.fromCharCode.apply(null, pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer)));
  }
  toBuffer() {
    const str2 = this.toString();
    const buffer = new ArrayBuffer(str2.length);
    const view = new Uint8Array(buffer);
    for (let i = 0; i < str2.length; i++)
      view[i] = str2.charCodeAt(i);
    return buffer;
  }
  fromDate(inputDate) {
    this.year = inputDate.getUTCFullYear();
    this.month = inputDate.getUTCMonth() + 1;
    this.day = inputDate.getUTCDate();
    this.hour = inputDate.getUTCHours();
    this.minute = inputDate.getUTCMinutes();
    this.second = inputDate.getUTCSeconds();
  }
  toDate() {
    return new Date(Date.UTC(this.year, this.month - 1, this.day, this.hour, this.minute, this.second));
  }
  fromString(inputString) {
    const parser = /(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})Z/ig;
    const parserArray = parser.exec(inputString);
    if (parserArray === null) {
      this.error = "Wrong input string for conversion";
      return;
    }
    const year = parseInt(parserArray[1], 10);
    if (year >= 50)
      this.year = 1900 + year;
    else
      this.year = 2e3 + year;
    this.month = parseInt(parserArray[2], 10);
    this.day = parseInt(parserArray[3], 10);
    this.hour = parseInt(parserArray[4], 10);
    this.minute = parseInt(parserArray[5], 10);
    this.second = parseInt(parserArray[6], 10);
  }
  toString(encoding = "iso") {
    if (encoding === "iso") {
      const outputArray = new Array(7);
      outputArray[0] = padNumber(this.year < 2e3 ? this.year - 1900 : this.year - 2e3, 2);
      outputArray[1] = padNumber(this.month, 2);
      outputArray[2] = padNumber(this.day, 2);
      outputArray[3] = padNumber(this.hour, 2);
      outputArray[4] = padNumber(this.minute, 2);
      outputArray[5] = padNumber(this.second, 2);
      outputArray[6] = "Z";
      return outputArray.join("");
    }
    return super.toString(encoding);
  }
  onAsciiEncoding() {
    return `${this.constructor.NAME} : ${this.toDate().toISOString()}`;
  }
  toJSON() {
    return {
      ...super.toJSON(),
      year: this.year,
      month: this.month,
      day: this.day,
      hour: this.hour,
      minute: this.minute,
      second: this.second
    };
  }
};
_a$6 = UTCTime;
(() => {
  typeStore.UTCTime = _a$6;
})();
UTCTime.NAME = "UTCTime";
var _a$5;
var GeneralizedTime = class extends UTCTime {
  constructor(parameters = {}) {
    var _b;
    super(parameters);
    (_b = this.millisecond) !== null && _b !== void 0 ? _b : this.millisecond = 0;
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 24;
  }
  fromDate(inputDate) {
    super.fromDate(inputDate);
    this.millisecond = inputDate.getUTCMilliseconds();
  }
  toDate() {
    const utcDate = Date.UTC(this.year, this.month - 1, this.day, this.hour, this.minute, this.second, this.millisecond);
    return new Date(utcDate);
  }
  fromString(inputString) {
    let isUTC = false;
    let timeString = "";
    let dateTimeString = "";
    let fractionPart = 0;
    let parser;
    let hourDifference = 0;
    let minuteDifference = 0;
    if (inputString[inputString.length - 1] === "Z") {
      timeString = inputString.substring(0, inputString.length - 1);
      isUTC = true;
    } else {
      const number = new Number(inputString[inputString.length - 1]);
      if (isNaN(number.valueOf()))
        throw new Error("Wrong input string for conversion");
      timeString = inputString;
    }
    if (isUTC) {
      if (timeString.indexOf("+") !== -1)
        throw new Error("Wrong input string for conversion");
      if (timeString.indexOf("-") !== -1)
        throw new Error("Wrong input string for conversion");
    } else {
      let multiplier = 1;
      let differencePosition = timeString.indexOf("+");
      let differenceString = "";
      if (differencePosition === -1) {
        differencePosition = timeString.indexOf("-");
        multiplier = -1;
      }
      if (differencePosition !== -1) {
        differenceString = timeString.substring(differencePosition + 1);
        timeString = timeString.substring(0, differencePosition);
        if (differenceString.length !== 2 && differenceString.length !== 4)
          throw new Error("Wrong input string for conversion");
        let number = parseInt(differenceString.substring(0, 2), 10);
        if (isNaN(number.valueOf()))
          throw new Error("Wrong input string for conversion");
        hourDifference = multiplier * number;
        if (differenceString.length === 4) {
          number = parseInt(differenceString.substring(2, 4), 10);
          if (isNaN(number.valueOf()))
            throw new Error("Wrong input string for conversion");
          minuteDifference = multiplier * number;
        }
      }
    }
    let fractionPointPosition = timeString.indexOf(".");
    if (fractionPointPosition === -1)
      fractionPointPosition = timeString.indexOf(",");
    if (fractionPointPosition !== -1) {
      const fractionPartCheck = new Number(`0${timeString.substring(fractionPointPosition)}`);
      if (isNaN(fractionPartCheck.valueOf()))
        throw new Error("Wrong input string for conversion");
      fractionPart = fractionPartCheck.valueOf();
      dateTimeString = timeString.substring(0, fractionPointPosition);
    } else
      dateTimeString = timeString;
    switch (true) {
      case dateTimeString.length === 8:
        parser = /(\d{4})(\d{2})(\d{2})/ig;
        if (fractionPointPosition !== -1)
          throw new Error("Wrong input string for conversion");
        break;
      case dateTimeString.length === 10:
        parser = /(\d{4})(\d{2})(\d{2})(\d{2})/ig;
        if (fractionPointPosition !== -1) {
          let fractionResult = 60 * fractionPart;
          this.minute = Math.floor(fractionResult);
          fractionResult = 60 * (fractionResult - this.minute);
          this.second = Math.floor(fractionResult);
          fractionResult = 1e3 * (fractionResult - this.second);
          this.millisecond = Math.floor(fractionResult);
        }
        break;
      case dateTimeString.length === 12:
        parser = /(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})/ig;
        if (fractionPointPosition !== -1) {
          let fractionResult = 60 * fractionPart;
          this.second = Math.floor(fractionResult);
          fractionResult = 1e3 * (fractionResult - this.second);
          this.millisecond = Math.floor(fractionResult);
        }
        break;
      case dateTimeString.length === 14:
        parser = /(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/ig;
        if (fractionPointPosition !== -1) {
          const fractionResult = 1e3 * fractionPart;
          this.millisecond = Math.floor(fractionResult);
        }
        break;
      default:
        throw new Error("Wrong input string for conversion");
    }
    const parserArray = parser.exec(dateTimeString);
    if (parserArray === null)
      throw new Error("Wrong input string for conversion");
    for (let j = 1; j < parserArray.length; j++) {
      switch (j) {
        case 1:
          this.year = parseInt(parserArray[j], 10);
          break;
        case 2:
          this.month = parseInt(parserArray[j], 10);
          break;
        case 3:
          this.day = parseInt(parserArray[j], 10);
          break;
        case 4:
          this.hour = parseInt(parserArray[j], 10) + hourDifference;
          break;
        case 5:
          this.minute = parseInt(parserArray[j], 10) + minuteDifference;
          break;
        case 6:
          this.second = parseInt(parserArray[j], 10);
          break;
        default:
          throw new Error("Wrong input string for conversion");
      }
    }
    if (isUTC === false) {
      const tempDate = new Date(this.year, this.month, this.day, this.hour, this.minute, this.second, this.millisecond);
      this.year = tempDate.getUTCFullYear();
      this.month = tempDate.getUTCMonth();
      this.day = tempDate.getUTCDay();
      this.hour = tempDate.getUTCHours();
      this.minute = tempDate.getUTCMinutes();
      this.second = tempDate.getUTCSeconds();
      this.millisecond = tempDate.getUTCMilliseconds();
    }
  }
  toString(encoding = "iso") {
    if (encoding === "iso") {
      const outputArray = [];
      outputArray.push(padNumber(this.year, 4));
      outputArray.push(padNumber(this.month, 2));
      outputArray.push(padNumber(this.day, 2));
      outputArray.push(padNumber(this.hour, 2));
      outputArray.push(padNumber(this.minute, 2));
      outputArray.push(padNumber(this.second, 2));
      if (this.millisecond !== 0) {
        outputArray.push(".");
        outputArray.push(padNumber(this.millisecond, 3));
      }
      outputArray.push("Z");
      return outputArray.join("");
    }
    return super.toString(encoding);
  }
  toJSON() {
    return {
      ...super.toJSON(),
      millisecond: this.millisecond
    };
  }
};
_a$5 = GeneralizedTime;
(() => {
  typeStore.GeneralizedTime = _a$5;
})();
GeneralizedTime.NAME = "GeneralizedTime";
var _a$4;
var DATE = class extends Utf8String {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 31;
  }
};
_a$4 = DATE;
(() => {
  typeStore.DATE = _a$4;
})();
DATE.NAME = "DATE";
var _a$3;
var TimeOfDay = class extends Utf8String {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 32;
  }
};
_a$3 = TimeOfDay;
(() => {
  typeStore.TimeOfDay = _a$3;
})();
TimeOfDay.NAME = "TimeOfDay";
var _a$2;
var DateTime = class extends Utf8String {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 33;
  }
};
_a$2 = DateTime;
(() => {
  typeStore.DateTime = _a$2;
})();
DateTime.NAME = "DateTime";
var _a$1;
var Duration = class extends Utf8String {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 34;
  }
};
_a$1 = Duration;
(() => {
  typeStore.Duration = _a$1;
})();
Duration.NAME = "Duration";
var _a;
var TIME = class extends Utf8String {
  constructor(parameters = {}) {
    super(parameters);
    this.idBlock.tagClass = 1;
    this.idBlock.tagNumber = 14;
  }
};
_a = TIME;
(() => {
  typeStore.TIME = _a;
})();
TIME.NAME = "TIME";
var Any = class {
  constructor({ name = EMPTY_STRING, optional = false } = {}) {
    this.name = name;
    this.optional = optional;
  }
};
var Choice = class extends Any {
  constructor({ value = [], ...parameters } = {}) {
    super(parameters);
    this.value = value;
  }
};
var Repeated = class extends Any {
  constructor({ value = new Any(), local = false, ...parameters } = {}) {
    super(parameters);
    this.value = value;
    this.local = local;
  }
};
var RawData = class {
  get data() {
    return this.dataView.slice().buffer;
  }
  set data(value) {
    this.dataView = pvtsutils.BufferSourceConverter.toUint8Array(value);
  }
  constructor({ data = EMPTY_VIEW } = {}) {
    this.dataView = pvtsutils.BufferSourceConverter.toUint8Array(data);
  }
  fromBER(inputBuffer, inputOffset, inputLength) {
    const endLength = inputOffset + inputLength;
    this.dataView = pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer).subarray(inputOffset, endLength);
    return endLength;
  }
  toBER(_sizeOnly) {
    return this.dataView.slice().buffer;
  }
};
function compareSchema(root, inputData, inputSchema) {
  if (inputSchema instanceof Choice) {
    for (const element of inputSchema.value) {
      const result = compareSchema(root, inputData, element);
      if (result.verified) {
        return {
          verified: true,
          result: root
        };
      }
    }
    {
      const _result = {
        verified: false,
        result: { error: "Wrong values for Choice type" }
      };
      if (inputSchema.hasOwnProperty(NAME))
        _result.name = inputSchema.name;
      return _result;
    }
  }
  if (inputSchema instanceof Any) {
    if (inputSchema.hasOwnProperty(NAME))
      root[inputSchema.name] = inputData;
    return {
      verified: true,
      result: root
    };
  }
  if (root instanceof Object === false) {
    return {
      verified: false,
      result: { error: "Wrong root object" }
    };
  }
  if (inputData instanceof Object === false) {
    return {
      verified: false,
      result: { error: "Wrong ASN.1 data" }
    };
  }
  if (inputSchema instanceof Object === false) {
    return {
      verified: false,
      result: { error: "Wrong ASN.1 schema" }
    };
  }
  if (ID_BLOCK in inputSchema === false) {
    return {
      verified: false,
      result: { error: "Wrong ASN.1 schema" }
    };
  }
  if (FROM_BER in inputSchema.idBlock === false) {
    return {
      verified: false,
      result: { error: "Wrong ASN.1 schema" }
    };
  }
  if (TO_BER in inputSchema.idBlock === false) {
    return {
      verified: false,
      result: { error: "Wrong ASN.1 schema" }
    };
  }
  const encodedId = inputSchema.idBlock.toBER(false);
  if (encodedId.byteLength === 0) {
    return {
      verified: false,
      result: { error: "Error encoding idBlock for ASN.1 schema" }
    };
  }
  const decodedOffset = inputSchema.idBlock.fromBER(encodedId, 0, encodedId.byteLength);
  if (decodedOffset === -1) {
    return {
      verified: false,
      result: { error: "Error decoding idBlock for ASN.1 schema" }
    };
  }
  if (inputSchema.idBlock.hasOwnProperty(TAG_CLASS) === false) {
    return {
      verified: false,
      result: { error: "Wrong ASN.1 schema" }
    };
  }
  if (inputSchema.idBlock.tagClass !== inputData.idBlock.tagClass) {
    return {
      verified: false,
      result: root
    };
  }
  if (inputSchema.idBlock.hasOwnProperty(TAG_NUMBER) === false) {
    return {
      verified: false,
      result: { error: "Wrong ASN.1 schema" }
    };
  }
  if (inputSchema.idBlock.tagNumber !== inputData.idBlock.tagNumber) {
    return {
      verified: false,
      result: root
    };
  }
  if (inputSchema.idBlock.hasOwnProperty(IS_CONSTRUCTED) === false) {
    return {
      verified: false,
      result: { error: "Wrong ASN.1 schema" }
    };
  }
  if (inputSchema.idBlock.isConstructed !== inputData.idBlock.isConstructed) {
    return {
      verified: false,
      result: root
    };
  }
  if (!(IS_HEX_ONLY in inputSchema.idBlock)) {
    return {
      verified: false,
      result: { error: "Wrong ASN.1 schema" }
    };
  }
  if (inputSchema.idBlock.isHexOnly !== inputData.idBlock.isHexOnly) {
    return {
      verified: false,
      result: root
    };
  }
  if (inputSchema.idBlock.isHexOnly) {
    if (VALUE_HEX_VIEW in inputSchema.idBlock === false) {
      return {
        verified: false,
        result: { error: "Wrong ASN.1 schema" }
      };
    }
    const schemaView = inputSchema.idBlock.valueHexView;
    const asn1View = inputData.idBlock.valueHexView;
    if (schemaView.length !== asn1View.length) {
      return {
        verified: false,
        result: root
      };
    }
    for (let i = 0; i < schemaView.length; i++) {
      if (schemaView[i] !== asn1View[1]) {
        return {
          verified: false,
          result: root
        };
      }
    }
  }
  if (inputSchema.name) {
    inputSchema.name = inputSchema.name.replace(/^\s+|\s+$/g, EMPTY_STRING);
    if (inputSchema.name)
      root[inputSchema.name] = inputData;
  }
  if (inputSchema instanceof typeStore.Constructed) {
    let admission = 0;
    let result = {
      verified: false,
      result: { error: "Unknown error" }
    };
    let maxLength = inputSchema.valueBlock.value.length;
    if (maxLength > 0) {
      if (inputSchema.valueBlock.value[0] instanceof Repeated) {
        maxLength = inputData.valueBlock.value.length;
      }
    }
    if (maxLength === 0) {
      return {
        verified: true,
        result: root
      };
    }
    if (inputData.valueBlock.value.length === 0 && inputSchema.valueBlock.value.length !== 0) {
      let _optional = true;
      for (let i = 0; i < inputSchema.valueBlock.value.length; i++)
        _optional = _optional && (inputSchema.valueBlock.value[i].optional || false);
      if (_optional) {
        return {
          verified: true,
          result: root
        };
      }
      if (inputSchema.name) {
        inputSchema.name = inputSchema.name.replace(/^\s+|\s+$/g, EMPTY_STRING);
        if (inputSchema.name)
          delete root[inputSchema.name];
      }
      root.error = "Inconsistent object length";
      return {
        verified: false,
        result: root
      };
    }
    for (let i = 0; i < maxLength; i++) {
      if (i - admission >= inputData.valueBlock.value.length) {
        if (inputSchema.valueBlock.value[i].optional === false) {
          const _result = {
            verified: false,
            result: root
          };
          root.error = "Inconsistent length between ASN.1 data and schema";
          if (inputSchema.name) {
            inputSchema.name = inputSchema.name.replace(/^\s+|\s+$/g, EMPTY_STRING);
            if (inputSchema.name) {
              delete root[inputSchema.name];
              _result.name = inputSchema.name;
            }
          }
          return _result;
        }
      } else {
        if (inputSchema.valueBlock.value[0] instanceof Repeated) {
          result = compareSchema(root, inputData.valueBlock.value[i], inputSchema.valueBlock.value[0].value);
          if (result.verified === false) {
            if (inputSchema.valueBlock.value[0].optional)
              admission++;
            else {
              if (inputSchema.name) {
                inputSchema.name = inputSchema.name.replace(/^\s+|\s+$/g, EMPTY_STRING);
                if (inputSchema.name)
                  delete root[inputSchema.name];
              }
              return result;
            }
          }
          if (NAME in inputSchema.valueBlock.value[0] && inputSchema.valueBlock.value[0].name.length > 0) {
            let arrayRoot = {};
            if (LOCAL in inputSchema.valueBlock.value[0] && inputSchema.valueBlock.value[0].local)
              arrayRoot = inputData;
            else
              arrayRoot = root;
            if (typeof arrayRoot[inputSchema.valueBlock.value[0].name] === "undefined")
              arrayRoot[inputSchema.valueBlock.value[0].name] = [];
            arrayRoot[inputSchema.valueBlock.value[0].name].push(inputData.valueBlock.value[i]);
          }
        } else {
          result = compareSchema(root, inputData.valueBlock.value[i - admission], inputSchema.valueBlock.value[i]);
          if (result.verified === false) {
            if (inputSchema.valueBlock.value[i].optional)
              admission++;
            else {
              if (inputSchema.name) {
                inputSchema.name = inputSchema.name.replace(/^\s+|\s+$/g, EMPTY_STRING);
                if (inputSchema.name)
                  delete root[inputSchema.name];
              }
              return result;
            }
          }
        }
      }
    }
    if (result.verified === false) {
      const _result = {
        verified: false,
        result: root
      };
      if (inputSchema.name) {
        inputSchema.name = inputSchema.name.replace(/^\s+|\s+$/g, EMPTY_STRING);
        if (inputSchema.name) {
          delete root[inputSchema.name];
          _result.name = inputSchema.name;
        }
      }
      return _result;
    }
    return {
      verified: true,
      result: root
    };
  }
  if (inputSchema.primitiveSchema && VALUE_HEX_VIEW in inputData.valueBlock) {
    const asn1 = localFromBER(inputData.valueBlock.valueHexView);
    if (asn1.offset === -1) {
      const _result = {
        verified: false,
        result: asn1.result
      };
      if (inputSchema.name) {
        inputSchema.name = inputSchema.name.replace(/^\s+|\s+$/g, EMPTY_STRING);
        if (inputSchema.name) {
          delete root[inputSchema.name];
          _result.name = inputSchema.name;
        }
      }
      return _result;
    }
    return compareSchema(root, asn1.result, inputSchema.primitiveSchema);
  }
  return {
    verified: true,
    result: root
  };
}
function verifySchema(inputBuffer, inputSchema) {
  if (inputSchema instanceof Object === false) {
    return {
      verified: false,
      result: { error: "Wrong ASN.1 schema type" }
    };
  }
  const asn1 = localFromBER(pvtsutils.BufferSourceConverter.toUint8Array(inputBuffer));
  if (asn1.offset === -1) {
    return {
      verified: false,
      result: asn1.result
    };
  }
  return compareSchema(asn1.result, asn1.result, inputSchema);
}

// node_modules/@peculiar/utils/build/esm/bytes/buffer-source.js
var ARRAY_BUFFER_TAG = "[object ArrayBuffer]";
var SHARED_ARRAY_BUFFER_TAG = "[object SharedArrayBuffer]";
function tagOf(value) {
  return Object.prototype.toString.call(value);
}
function isArrayBufferViewLike(value) {
  if (ArrayBuffer.isView(value)) {
    return true;
  }
  if (!value || typeof value !== "object") {
    return false;
  }
  const view = value;
  return typeof view.byteOffset === "number" && typeof view.byteLength === "number" && isArrayBufferLike(view.buffer);
}
function isArrayBuffer(value) {
  return tagOf(value) === ARRAY_BUFFER_TAG;
}
function isSharedArrayBuffer(value) {
  return typeof SharedArrayBuffer !== "undefined" && tagOf(value) === SHARED_ARRAY_BUFFER_TAG;
}
function isArrayBufferLike(value) {
  return isArrayBuffer(value) || isSharedArrayBuffer(value);
}
function isArrayBufferView(value) {
  return isArrayBufferViewLike(value);
}
function isBufferSource(value) {
  return isArrayBufferLike(value) || isArrayBufferView(value);
}
function assertBufferSource(value) {
  if (!isBufferSource(value)) {
    throw new TypeError("Expected ArrayBuffer, SharedArrayBuffer, or ArrayBufferView");
  }
}
function toUint8Array(data) {
  assertBufferSource(data);
  if (isArrayBufferLike(data)) {
    return new Uint8Array(data);
  }
  return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
}
function toArrayBuffer(data) {
  assertBufferSource(data);
  if (isArrayBuffer(data)) {
    return data;
  }
  const buffer = new ArrayBuffer(data.byteLength);
  new Uint8Array(buffer).set(toUint8Array(data));
  return buffer;
}

// node_modules/@peculiar/utils/build/esm/bytes/equal.js
function equal(a, b, options = {}) {
  const left = toUint8Array(a);
  const right = toUint8Array(b);
  if (!options.constantTime && left.byteLength !== right.byteLength) {
    return false;
  }
  const length = Math.max(left.byteLength, right.byteLength);
  let diff = left.byteLength ^ right.byteLength;
  for (let i = 0; i < length; i++) {
    diff |= (left[i] ?? 0) ^ (right[i] ?? 0);
  }
  return diff === 0;
}

// node_modules/@peculiar/utils/build/esm/encoding/binary.js
var binary_exports = {};
__export(binary_exports, {
  binary: () => binary,
  decode: () => decode,
  encode: () => encode2,
  is: () => is
});
function encode2(data) {
  const bytes = toUint8Array(data);
  let result = "";
  for (const byte of bytes) {
    result += String.fromCharCode(byte);
  }
  return result;
}
function decode(text) {
  const result = new Uint8Array(text.length);
  for (let i = 0; i < text.length; i++) {
    result[i] = text.charCodeAt(i) & 255;
  }
  return result;
}
function is(text) {
  return typeof text === "string";
}
var binary = { encode: encode2, decode, is };

// node_modules/@peculiar/utils/build/esm/encoding/hex.js
var hex_exports = {};
__export(hex_exports, {
  decode: () => decode2,
  encode: () => encode3,
  format: () => format,
  formats: () => formats,
  hex: () => hex,
  is: () => is2,
  normalize: () => normalize,
  parse: () => parse
});
var HEX_CHARACTER_REGEX = /^[0-9a-f]$/i;
var COMMON_SEPARATORS = [" ", "	", "\n", "\r", ":", "-", "."];
function resolveSeparators(options) {
  if (options.separators === "none") {
    return [];
  }
  if (!options.separators || options.separators === "common") {
    return COMMON_SEPARATORS;
  }
  return options.separators;
}
function validateSeparator(separator) {
  if (!separator) {
    throw new TypeError("Hex separators must be non-empty strings");
  }
}
function matchSeparator(text, index, separators) {
  for (const separator of separators) {
    if (text.startsWith(separator, index)) {
      return separator;
    }
  }
  return void 0;
}
function detectCase(text) {
  const hasUpper = /[A-F]/.test(text);
  const hasLower = /[a-f]/.test(text);
  return hasUpper && !hasLower ? "upper" : "lower";
}
function detectLineSeparator(text) {
  const match = /\r\n|\n/.exec(text);
  if (!match) {
    return void 0;
  }
  return match[0] === "\r\n" ? "\r\n" : "\n";
}
function compactForDetection(text) {
  return text.replace(/[^0-9a-f]/gi, "");
}
function detectGroup(text) {
  const segments = text.match(/[0-9A-Fa-f]+|[^0-9A-Fa-f]+/g) ?? [];
  if (segments.length < 3) {
    return void 0;
  }
  const hexSegments = segments.filter((_, index) => index % 2 === 0);
  const separators = segments.filter((_, index) => index % 2 === 1);
  const separator = separators[0];
  if (!separator || separators.some((item) => item !== separator)) {
    return void 0;
  }
  if (hexSegments.some((segment) => segment.length === 0 || segment.length % 2 !== 0)) {
    return void 0;
  }
  const firstLength = hexSegments[0]?.length ?? 0;
  if (!firstLength) {
    return void 0;
  }
  if (hexSegments.slice(0, -1).some((segment) => segment.length !== firstLength)) {
    return void 0;
  }
  if ((hexSegments[hexSegments.length - 1]?.length ?? 0) > firstLength) {
    return void 0;
  }
  return {
    size: firstLength / 2,
    separator
  };
}
function detectFormat(text) {
  const trimmed = text.trim();
  const prefix = /^0x/i.test(trimmed) ? "0x" : "";
  const body = prefix ? trimmed.slice(2) : trimmed;
  const lineSeparator = detectLineSeparator(body);
  const lines = body.split(/\r\n|\n/).filter((line) => line.length > 0);
  const sampleLine = lines[0]?.trim() ?? "";
  const group = detectGroup(sampleLine);
  const format4 = {
    case: detectCase(trimmed),
    prefix
  };
  if (group) {
    format4.group = group;
  }
  if (lineSeparator && lines.length > 1) {
    const firstLineBytes = compactForDetection(lines[0] ?? "").length / 2;
    if (firstLineBytes > 0 && lines.slice(0, -1).every((line) => compactForDetection(line).length / 2 === firstLineBytes)) {
      format4.line = {
        bytesPerLine: firstLineBytes,
        separator: lineSeparator
      };
    }
  }
  return format4;
}
function normalizeText(text, options) {
  const allowPrefix = options.allowPrefix ?? true;
  const separators = [...resolveSeparators(options)].sort((left, right) => right.length - left.length);
  for (const separator of separators) {
    validateSeparator(separator);
  }
  let working = text.trim();
  if (/^0x/i.test(working)) {
    if (!allowPrefix) {
      throw new TypeError("Hexadecimal text must not include a 0x prefix");
    }
    working = working.slice(2);
  }
  let normalized = "";
  let lastTokenWasSeparator = false;
  for (let index = 0; index < working.length; ) {
    const character = working[index] ?? "";
    if (HEX_CHARACTER_REGEX.test(character)) {
      normalized += character;
      lastTokenWasSeparator = false;
      index += 1;
      continue;
    }
    const separator = matchSeparator(working, index, separators);
    if (!separator) {
      throw new TypeError("Input is not valid hexadecimal text");
    }
    if (options.strict && (lastTokenWasSeparator || normalized.length === 0)) {
      throw new TypeError("Hexadecimal text contains misplaced separators");
    }
    lastTokenWasSeparator = true;
    index += separator.length;
  }
  if (options.strict && lastTokenWasSeparator && normalized.length > 0) {
    throw new TypeError("Hexadecimal text must not end with a separator");
  }
  if (normalized.length % 2 !== 0) {
    if (!options.allowOddLength) {
      throw new TypeError("Hexadecimal text must contain an even number of characters");
    }
    normalized = `0${normalized}`;
  }
  return normalized.toLowerCase();
}
function groupPairs(pairs, group) {
  if (!group) {
    return pairs.join("");
  }
  if (!Number.isInteger(group.size) || group.size < 1) {
    throw new RangeError("Hex group size must be a positive integer");
  }
  const chunks = [];
  for (let index = 0; index < pairs.length; index += group.size) {
    chunks.push(pairs.slice(index, index + group.size).join(""));
  }
  return chunks.join(group.separator);
}
function normalize(text, options = {}) {
  return normalizeText(text, options);
}
function is2(text, options = {}) {
  if (typeof text !== "string") {
    return false;
  }
  try {
    normalize(text, options);
    return true;
  } catch {
    return false;
  }
}
function encode3(data, options = {}) {
  const bytes = toUint8Array(data);
  const casing = options.case ?? "lower";
  const pairs = Array.from(bytes, (byte) => {
    const text = byte.toString(16).padStart(2, "0");
    return casing === "upper" ? text.toUpperCase() : text;
  });
  let body = "";
  if (options.line) {
    const bytesPerLine = options.line.bytesPerLine;
    if (!Number.isInteger(bytesPerLine) || bytesPerLine < 1) {
      throw new RangeError("Hex bytesPerLine must be a positive integer");
    }
    const separator = options.line.separator ?? "\n";
    const lines = [];
    for (let index = 0; index < pairs.length; index += bytesPerLine) {
      lines.push(groupPairs(pairs.slice(index, index + bytesPerLine), options.group));
    }
    body = lines.join(separator);
  } else {
    body = groupPairs(pairs, options.group);
  }
  return `${options.prefix ?? ""}${body}`;
}
function decode2(text, options = {}) {
  const normalized = normalize(text, options);
  const result = new Uint8Array(normalized.length / 2);
  for (let i = 0; i < normalized.length; i += 2) {
    result[i / 2] = Number.parseInt(normalized.slice(i, i + 2), 16);
  }
  return result;
}
function parse(text, options = {}) {
  const normalized = normalize(text, options);
  return {
    bytes: decode2(normalized),
    format: detectFormat(text),
    normalized
  };
}
function format(data, value) {
  return encode3(data, value);
}
var formats = {
  compact: Object.freeze({}),
  upper: Object.freeze({ case: "upper" }),
  colon: Object.freeze({ group: { size: 1, separator: ":" } }),
  colonUpper: Object.freeze({ case: "upper", group: { size: 1, separator: ":" } }),
  groupsOf4: Object.freeze({ group: { size: 4, separator: " " } }),
  prefixed: Object.freeze({ prefix: "0x" })
};
var hex = { encode: encode3, decode: decode2, format, formats, is: is2, normalize, parse };

// node_modules/@peculiar/utils/build/esm/encoding/utf8.js
var utf8_exports = {};
__export(utf8_exports, {
  decode: () => decode3,
  encode: () => encode4,
  utf8: () => utf8
});
function encode4(text) {
  return new TextEncoder().encode(text);
}
function decode3(data) {
  return new TextDecoder("utf-8", { fatal: false }).decode(toUint8Array(data));
}
var utf8 = { encode: encode4, decode: decode3 };

// node_modules/@peculiar/utils/build/esm/encoding/utf16.js
var utf16_exports = {};
__export(utf16_exports, {
  decode: () => decode4,
  encode: () => encode5,
  utf16: () => utf16
});
function encode5(text, options = {}) {
  const result = new ArrayBuffer(text.length * 2);
  const view = new DataView(result);
  for (let i = 0; i < text.length; i++) {
    view.setUint16(i * 2, text.charCodeAt(i), options.littleEndian ?? false);
  }
  return new Uint8Array(result);
}
function decode4(data, options = {}) {
  const buffer = toArrayBuffer(data);
  const view = new DataView(buffer);
  let result = "";
  for (let i = 0; i < buffer.byteLength; i += 2) {
    result += String.fromCharCode(view.getUint16(i, options.littleEndian ?? false));
  }
  return result;
}
var utf16 = { encode: encode5, decode: decode4 };

// node_modules/@peculiar/utils/build/esm/encoding/base64.js
var base64_exports = {};
__export(base64_exports, {
  base64: () => base643,
  decode: () => decode5,
  encode: () => encode6,
  is: () => is3,
  normalize: () => normalize2,
  pad: () => pad
});
var BASE64_REGEX = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
function nodeBuffer() {
  return globalThis.Buffer;
}
function normalize2(text) {
  return text.replace(/[\n\r\t ]/g, "");
}
function pad(text) {
  const remainder = text.length % 4;
  return remainder ? text + "=".repeat(4 - remainder) : text;
}
function is3(text) {
  if (typeof text !== "string") {
    return false;
  }
  const normalized = normalize2(text);
  return normalized === "" || BASE64_REGEX.test(normalized);
}
function encode6(data, _options) {
  const bytes = toUint8Array(data);
  const buffer = nodeBuffer();
  if (buffer) {
    return buffer.from(bytes).toString("base64");
  }
  return btoa(encode2(bytes));
}
function decode5(text, _options) {
  const normalized = normalize2(text);
  if (!is3(normalized)) {
    throw new TypeError("Input is not valid Base64 text");
  }
  const buffer = nodeBuffer();
  if (buffer) {
    return new Uint8Array(buffer.from(normalized, "base64"));
  }
  return decode(atob(normalized));
}
var base643 = { encode: encode6, decode: decode5, is: is3, normalize: normalize2, pad };

// node_modules/@peculiar/utils/build/esm/encoding/base64url.js
var base64url_exports = {};
__export(base64url_exports, {
  base64url: () => base64url,
  decode: () => decode6,
  encode: () => encode7,
  is: () => is4,
  normalize: () => normalize3
});
var BASE64URL_REGEX = /^[A-Za-z0-9_-]*$/;
function normalize3(text) {
  return text.replace(/[\n\r\t ]/g, "");
}
function is4(text) {
  return typeof text === "string" && BASE64URL_REGEX.test(normalize3(text));
}
function encode7(data, _options) {
  return base643.encode(data).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function decode6(text, _options) {
  const normalized = normalize3(text);
  if (!is4(normalized)) {
    throw new TypeError("Input is not valid Base64Url text");
  }
  return base643.decode(base643.pad(normalized.replace(/-/g, "+").replace(/_/g, "/")));
}
var base64url = { encode: encode7, decode: decode6, is: is4, normalize: normalize3 };

// node_modules/@peculiar/utils/build/esm/pem/pem.js
var LABEL_REGEX = /^[A-Z0-9][A-Z0-9 ._-]*[A-Z0-9]$/i;
var PEM_BLOCK_REGEX = /-----BEGIN ([^-]+)-----([\s\S]*?)-----END \1-----/g;
function assertLabel(label) {
  if (!LABEL_REGEX.test(label)) {
    throw new TypeError(`Invalid PEM label '${label}'`);
  }
}
function wrap(text, lineLength) {
  const result = [];
  for (let i = 0; i < text.length; i += lineLength) {
    result.push(text.slice(i, i + lineLength));
  }
  return result;
}
function parseBody(body) {
  const normalized = body.trim().replace(/\r\n/g, "\n");
  const lines = normalized.split("\n").map((line) => line.trim()).filter(Boolean);
  const headers2 = {};
  let index = 0;
  for (; index < lines.length; index++) {
    const line = lines[index];
    const separator = line.indexOf(":");
    if (separator <= 0) {
      break;
    }
    headers2[line.slice(0, separator).trim()] = line.slice(separator + 1).trim();
  }
  return {
    headers: Object.keys(headers2).length ? headers2 : void 0,
    base64Lines: lines.slice(index),
    base64Text: lines.slice(index).join("")
  };
}
function detectNewline(text) {
  return /\r\n/.test(text) ? "\r\n" : "\n";
}
function collectBlocks(text, options = {}) {
  const blocks = [];
  const requestedLabel = options.label;
  let match;
  PEM_BLOCK_REGEX.lastIndex = 0;
  while (match = PEM_BLOCK_REGEX.exec(text)) {
    const label = match[1].trim();
    if (requestedLabel && label !== requestedLabel) {
      continue;
    }
    assertLabel(label);
    const parsed = parseBody(match[2]);
    blocks.push({
      label,
      data: base643.decode(parsed.base64Text),
      headers: parsed.headers,
      lineLength: parsed.base64Lines[0]?.length ?? 64,
      newline: detectNewline(match[0])
    });
  }
  if (options.strict && blocks.length === 0) {
    throw new TypeError(requestedLabel ? `No PEM block with label '${requestedLabel}' was found` : "No PEM blocks were found");
  }
  return blocks;
}
function encode8(label, data, options = {}) {
  assertLabel(label);
  const lineLength = options.lineLength ?? 64;
  if (!Number.isInteger(lineLength) || lineLength < 1) {
    throw new RangeError("PEM lineLength must be a positive integer");
  }
  const newline = options.newline ?? "\n";
  const lines = [`-----BEGIN ${label}-----`];
  if (options.headers) {
    for (const [name, value] of Object.entries(options.headers)) {
      lines.push(`${name}: ${value}`);
    }
    lines.push("");
  }
  lines.push(...wrap(base643.encode(data), lineLength));
  lines.push(`-----END ${label}-----`);
  return `${lines.join(newline)}${newline}`;
}
function decode7(text, options = {}) {
  return collectBlocks(text, options).map(({ lineLength: _lineLength, newline: _newline, ...block }) => block);
}
function decodeFirst2(text, label) {
  const [block] = decode7(text, { label, strict: true });
  return block.data;
}
function parse2(text, options = {}) {
  const [block] = collectBlocks(text, { ...options, strict: true });
  const format4 = {
    label: block.label,
    headers: block.headers,
    lineLength: block.lineLength,
    newline: block.newline
  };
  return {
    bytes: block.data,
    format: format4,
    normalized: encode8(block.label, block.data, format4)
  };
}
function format2(data, value) {
  return encode8(value.label, data, value);
}
var pemConverter = {
  name: "pem",
  encode: (data, options) => {
    if (!options?.label) {
      throw new TypeError("PEM label is required");
    }
    return encode8(options.label, data, options);
  },
  decode: (text, options) => decodeFirst2(text, options?.label),
  format: format2,
  is: (text) => typeof text === "string" && /-----BEGIN [^-]+-----/.test(text),
  parse: parse2
};

// node_modules/@peculiar/utils/build/esm/converters/registry.js
function keyOf(name) {
  return name.trim().toLowerCase();
}
function toError(error) {
  return error instanceof Error ? error : new Error(String(error));
}
function removeConverter(converters, primaryNames, converter) {
  for (const alias of [converter.name, ...converter.aliases ?? []]) {
    converters.delete(keyOf(alias));
  }
  primaryNames.delete(keyOf(converter.name));
}
function requireCapability(converter, name, capability) {
  const method = converter[capability];
  if (typeof method !== "function") {
    throw new Error(`Converter '${name}' does not support ${capability}()`);
  }
  return method;
}
function detectConfidence(name, text, converter) {
  const normalizedName = keyOf(converter.name || name);
  const trimmed = text.trim();
  if (!trimmed) {
    return 0;
  }
  let accepted = false;
  if (converter.is) {
    accepted = converter.is(text);
  }
  let decodable = false;
  try {
    converter.decode(text);
    decodable = true;
  } catch {
    decodable = false;
  }
  if (!accepted && !decodable) {
    return 0;
  }
  switch (normalizedName) {
    case "pem":
      return /-----BEGIN [^-]+-----/.test(text) ? 1 : 0;
    case "hex": {
      const compact = trimmed.replace(/^0x/i, "").replace(/[\s:.-]/g, "");
      if (!compact || /[^0-9a-f]/i.test(compact) || compact.length % 2 !== 0) {
        return 0;
      }
      if (/^0x/i.test(trimmed) || /[:\s.-]/.test(trimmed)) {
        return 0.95;
      }
      if (/[a-f]/.test(trimmed) || /[A-F]/.test(trimmed)) {
        return 0.8;
      }
      return 0.45;
    }
    case "base64url":
      if (/[-_]/.test(trimmed)) {
        return 0.95;
      }
      if (/=/.test(trimmed)) {
        return 0.1;
      }
      return 0.6;
    case "base64":
      if (/[+/=]/.test(trimmed)) {
        return 0.9;
      }
      return 0.55;
    case "binary":
    case "utf8":
    case "utf16be":
    case "utf16le":
      return 0;
    default:
      return accepted && decodable ? 0.75 : 0.5;
  }
}
function createConverterRegistry(initialConverters = []) {
  const converters = /* @__PURE__ */ new Map();
  const primaryNames = /* @__PURE__ */ new Set();
  const api = {
    register(converter, options = {}) {
      if (!converter.name || !keyOf(converter.name)) {
        throw new TypeError("Converter name is required");
      }
      const names2 = [...new Set([converter.name, ...converter.aliases ?? []].map(keyOf))];
      const conflicts = /* @__PURE__ */ new Set();
      for (const name of names2) {
        const existing = converters.get(name);
        if (!existing) {
          continue;
        }
        if (!options.override) {
          throw new Error(`Converter '${name}' is already registered`);
        }
        conflicts.add(existing);
      }
      for (const conflicting of conflicts) {
        removeConverter(converters, primaryNames, conflicting);
      }
      for (const name of names2) {
        converters.set(name, converter);
      }
      primaryNames.add(keyOf(converter.name));
      return this;
    },
    unregister(name) {
      const converter = converters.get(keyOf(name));
      if (!converter) {
        return false;
      }
      removeConverter(converters, primaryNames, converter);
      return true;
    },
    has(name) {
      return converters.has(keyOf(name));
    },
    get(name) {
      const converter = converters.get(keyOf(name));
      if (!converter) {
        throw new Error(`Converter '${name}' is not registered`);
      }
      return converter;
    },
    list() {
      return [...primaryNames].map((name) => this.get(name));
    },
    encode(name, data, options) {
      return this.get(name).encode(data, options);
    },
    decode(name, text, options) {
      return this.get(name).decode(text, options);
    },
    tryDecode(name, text, options) {
      try {
        return { ok: true, bytes: this.decode(name, text, options) };
      } catch (error) {
        return { ok: false, error: toError(error) };
      }
    },
    normalize(name, text, options) {
      const converter = this.get(name);
      return requireCapability(converter, name, "normalize").call(converter, text, options);
    },
    parse(name, text, options) {
      const converter = this.get(name);
      return requireCapability(converter, name, "parse").call(converter, text, options);
    },
    format(name, data, format4) {
      const converter = this.get(name);
      return requireCapability(converter, name, "format").call(converter, data, format4);
    },
    transcode(text, options) {
      const bytes = this.decode(options.from, text, options.fromOptions);
      return this.encode(options.to, bytes, options.toOptions);
    },
    detect(text, options = {}) {
      const formatNames = options.formats?.length ? options.formats.map((name) => String(name)) : this.list().map((converter) => converter.name).filter((name) => !["binary", "utf8", "utf16be", "utf16le"].includes(keyOf(name)));
      const detections = /* @__PURE__ */ new Map();
      for (const requestedName of formatNames) {
        const converter = this.get(requestedName);
        const confidence = detectConfidence(requestedName, text, converter);
        if (confidence <= 0) {
          continue;
        }
        const format4 = converter.name;
        const current = detections.get(format4);
        if (!current || confidence > current.confidence) {
          detections.set(format4, { format: format4, confidence });
        }
      }
      return [...detections.values()].sort((left, right) => right.confidence - left.confidence);
    }
  };
  for (const converter of initialConverters) {
    api.register(converter);
  }
  return api;
}

// node_modules/@peculiar/utils/build/esm/converters/defaults.js
var binaryConverter = {
  name: "binary",
  aliases: ["latin1"],
  encode: binary_exports.encode,
  decode: binary_exports.decode,
  is: binary_exports.is
};
var hexConverter = {
  name: "hex",
  encode: hex_exports.encode,
  decode: hex_exports.decode,
  format: hex_exports.format,
  is: hex_exports.is,
  normalize: hex_exports.normalize,
  parse: hex_exports.parse
};
var base64Converter = {
  name: "base64",
  aliases: ["b64"],
  encode: base64_exports.encode,
  decode: base64_exports.decode,
  is: base64_exports.is,
  normalize: base64_exports.normalize
};
var base64urlConverter = {
  name: "base64url",
  aliases: ["base64-url", "b64url"],
  encode: base64url_exports.encode,
  decode: base64url_exports.decode,
  is: base64url_exports.is,
  normalize: base64url_exports.normalize
};
var utf8Converter = {
  name: "utf8",
  aliases: ["utf-8"],
  encode: (data) => utf8_exports.decode(data),
  decode: (text) => utf8_exports.encode(text),
  is: (text) => typeof text === "string"
};
var utf16beConverter = {
  name: "utf16be",
  aliases: ["utf16", "utf-16", "utf-16be"],
  encode: (data) => utf16_exports.decode(data),
  decode: (text) => utf16_exports.encode(text),
  is: (text) => typeof text === "string"
};
var utf16leConverter = {
  name: "utf16le",
  aliases: ["utf-16le", "ucs2", "usc2"],
  encode: (data) => utf16_exports.decode(data, { littleEndian: true }),
  decode: (text) => utf16_exports.encode(text, { littleEndian: true }),
  is: (text) => typeof text === "string"
};
var defaultConverters = [
  binaryConverter,
  hexConverter,
  base64Converter,
  base64urlConverter,
  utf8Converter,
  utf16beConverter,
  utf16leConverter,
  pemConverter
];
var defaultConverterRegistry = createConverterRegistry(defaultConverters);

// node_modules/@peculiar/utils/build/esm/converters/convert.js
function encode9(name, data, ...args) {
  return defaultConverterRegistry.encode(name, data, ...args);
}
function decode8(name, text, ...args) {
  return defaultConverterRegistry.decode(name, text, ...args);
}
function tryDecode(name, text, ...args) {
  return defaultConverterRegistry.tryDecode(name, text, ...args);
}
function normalize4(name, text, ...args) {
  return defaultConverterRegistry.normalize(name, text, ...args);
}
function parse3(name, text, ...args) {
  return defaultConverterRegistry.parse(name, text, ...args);
}
function format3(name, data, value) {
  return defaultConverterRegistry.format(name, data, value);
}
function transcode(text, options) {
  return defaultConverterRegistry.transcode(text, options);
}
function detect(text, options) {
  return defaultConverterRegistry.detect(text, options);
}
function normalizeEncodingName(encoding) {
  return encoding.toLowerCase();
}
var convert = {
  encode: encode9,
  decode: decode8,
  tryDecode,
  normalize: normalize4,
  parse: parse3,
  format: format3,
  transcode,
  detect,
  to(format4, data, ...args) {
    return encode9(format4, data, ...args);
  },
  from(format4, text, ...args) {
    return decode8(format4, text, ...args);
  },
  toString(data, encoding = "utf8") {
    return encode9(encoding, data);
  },
  fromString(text, encoding = "utf8") {
    if (normalizeEncodingName(encoding) === "hex") {
      return toArrayBuffer(hex_exports.decode(text, { allowOddLength: true }));
    }
    return toArrayBuffer(decode8(encoding, text));
  },
  toBase64: base64_exports.encode,
  fromBase64: (text) => toArrayBuffer(base64_exports.decode(text)),
  toBase64Url: base64url_exports.encode,
  fromBase64Url: (text) => toArrayBuffer(base64url_exports.decode(text)),
  toHex: hex_exports.encode,
  fromHex: (text) => toArrayBuffer(hex_exports.decode(text, { allowOddLength: true })),
  toBinary: binary_exports.encode,
  fromBinary: (text) => toArrayBuffer(binary_exports.decode(text)),
  toUtf8String: utf8_exports.decode,
  fromUtf8String: (text) => toArrayBuffer(utf8_exports.encode(text)),
  toUtf16String: (data, littleEndian = false) => utf16_exports.decode(data, { littleEndian }),
  fromUtf16String: (text, littleEndian = false) => toArrayBuffer(utf16_exports.encode(text, { littleEndian })),
  isHex: hex_exports.is,
  isBase64: base64_exports.is,
  isBase64Url: base64url_exports.is,
  formatString: base64_exports.normalize
};

// node_modules/@peculiar/asn1-schema/build/es2015/enums.js
var AsnTypeTypes;
(function(AsnTypeTypes2) {
  AsnTypeTypes2[AsnTypeTypes2["Sequence"] = 0] = "Sequence";
  AsnTypeTypes2[AsnTypeTypes2["Set"] = 1] = "Set";
  AsnTypeTypes2[AsnTypeTypes2["Choice"] = 2] = "Choice";
})(AsnTypeTypes || (AsnTypeTypes = {}));
var AsnPropTypes;
(function(AsnPropTypes2) {
  AsnPropTypes2[AsnPropTypes2["Any"] = 1] = "Any";
  AsnPropTypes2[AsnPropTypes2["Boolean"] = 2] = "Boolean";
  AsnPropTypes2[AsnPropTypes2["OctetString"] = 3] = "OctetString";
  AsnPropTypes2[AsnPropTypes2["BitString"] = 4] = "BitString";
  AsnPropTypes2[AsnPropTypes2["Integer"] = 5] = "Integer";
  AsnPropTypes2[AsnPropTypes2["Enumerated"] = 6] = "Enumerated";
  AsnPropTypes2[AsnPropTypes2["ObjectIdentifier"] = 7] = "ObjectIdentifier";
  AsnPropTypes2[AsnPropTypes2["Utf8String"] = 8] = "Utf8String";
  AsnPropTypes2[AsnPropTypes2["BmpString"] = 9] = "BmpString";
  AsnPropTypes2[AsnPropTypes2["UniversalString"] = 10] = "UniversalString";
  AsnPropTypes2[AsnPropTypes2["NumericString"] = 11] = "NumericString";
  AsnPropTypes2[AsnPropTypes2["PrintableString"] = 12] = "PrintableString";
  AsnPropTypes2[AsnPropTypes2["TeletexString"] = 13] = "TeletexString";
  AsnPropTypes2[AsnPropTypes2["VideotexString"] = 14] = "VideotexString";
  AsnPropTypes2[AsnPropTypes2["IA5String"] = 15] = "IA5String";
  AsnPropTypes2[AsnPropTypes2["GraphicString"] = 16] = "GraphicString";
  AsnPropTypes2[AsnPropTypes2["VisibleString"] = 17] = "VisibleString";
  AsnPropTypes2[AsnPropTypes2["GeneralString"] = 18] = "GeneralString";
  AsnPropTypes2[AsnPropTypes2["CharacterString"] = 19] = "CharacterString";
  AsnPropTypes2[AsnPropTypes2["UTCTime"] = 20] = "UTCTime";
  AsnPropTypes2[AsnPropTypes2["GeneralizedTime"] = 21] = "GeneralizedTime";
  AsnPropTypes2[AsnPropTypes2["DATE"] = 22] = "DATE";
  AsnPropTypes2[AsnPropTypes2["TimeOfDay"] = 23] = "TimeOfDay";
  AsnPropTypes2[AsnPropTypes2["DateTime"] = 24] = "DateTime";
  AsnPropTypes2[AsnPropTypes2["Duration"] = 25] = "Duration";
  AsnPropTypes2[AsnPropTypes2["TIME"] = 26] = "TIME";
  AsnPropTypes2[AsnPropTypes2["Null"] = 27] = "Null";
  AsnPropTypes2[AsnPropTypes2["RelativeObjectIdentifier"] = 28] = "RelativeObjectIdentifier";
})(AsnPropTypes || (AsnPropTypes = {}));

// node_modules/@peculiar/asn1-schema/build/es2015/types/bit_string.js
var BitString2 = class {
  unusedBits = 0;
  value = new ArrayBuffer(0);
  constructor(params, unusedBits = 0) {
    if (params) {
      if (typeof params === "number") {
        this.fromNumber(params);
      } else if (isBufferSource(params)) {
        this.unusedBits = unusedBits;
        this.value = toArrayBuffer(params);
      } else {
        throw TypeError("Unsupported type of 'params' argument for BitString");
      }
    }
  }
  fromASN(asn) {
    if (!(asn instanceof BitString)) {
      throw new TypeError("Argument 'asn' is not instance of ASN.1 BitString");
    }
    this.unusedBits = asn.valueBlock.unusedBits;
    this.value = toArrayBuffer(asn.valueBlock.valueHex);
    return this;
  }
  toASN() {
    return new BitString({
      unusedBits: this.unusedBits,
      valueHex: this.value
    });
  }
  toSchema(name) {
    return new BitString({ name });
  }
  toNumber() {
    let res = "";
    const uintArray = new Uint8Array(this.value);
    for (const octet of uintArray) {
      res += octet.toString(2).padStart(8, "0");
    }
    res = res.split("").reverse().join("");
    if (this.unusedBits) {
      res = res.slice(this.unusedBits).padStart(this.unusedBits, "0");
    }
    return parseInt(res, 2);
  }
  fromNumber(value) {
    let bits = value.toString(2);
    const octetSize = bits.length + 7 >> 3;
    this.unusedBits = (octetSize << 3) - bits.length;
    const octets = new Uint8Array(octetSize);
    bits = bits.padStart(octetSize << 3, "0").split("").reverse().join("");
    let index = 0;
    while (index < octetSize) {
      octets[index] = parseInt(bits.slice(index << 3, (index << 3) + 8), 2);
      index++;
    }
    this.value = octets.buffer;
  }
};

// node_modules/@peculiar/asn1-schema/build/es2015/types/octet_string.js
var OctetString2 = class {
  buffer;
  get byteLength() {
    return this.buffer.byteLength;
  }
  get byteOffset() {
    return 0;
  }
  constructor(param) {
    if (typeof param === "number") {
      this.buffer = new ArrayBuffer(param);
    } else {
      if (isBufferSource(param)) {
        this.buffer = toArrayBuffer(param);
      } else if (Array.isArray(param)) {
        this.buffer = new Uint8Array(param).buffer;
      } else {
        this.buffer = new ArrayBuffer(0);
      }
    }
  }
  fromASN(asn) {
    if (!(asn instanceof OctetString)) {
      throw new TypeError("Argument 'asn' is not instance of ASN.1 OctetString");
    }
    this.buffer = toArrayBuffer(asn.valueBlock.valueHex);
    return this;
  }
  toASN() {
    return new OctetString({ valueHex: this.buffer });
  }
  toSchema(name) {
    return new OctetString({ name });
  }
};

// node_modules/@peculiar/asn1-schema/build/es2015/converters.js
var AsnAnyConverter = {
  fromASN: (value) => value instanceof Null ? null : toArrayBuffer(value.valueBeforeDecodeView),
  toASN: (value) => {
    if (value === null) {
      return new Null();
    }
    const schema = fromBER(value);
    if (schema.result.error) {
      throw new Error(schema.result.error);
    }
    return schema.result;
  }
};
var AsnIntegerConverter = {
  fromASN: (value) => value.valueBlock.valueHexView.byteLength >= 4 ? value.valueBlock.toString() : value.valueBlock.valueDec,
  toASN: (value) => new Integer({ value: +value })
};
var AsnEnumeratedConverter = {
  fromASN: (value) => value.valueBlock.valueDec,
  toASN: (value) => new Enumerated({ value })
};
var AsnIntegerArrayBufferConverter = {
  fromASN: (value) => toArrayBuffer(value.valueBlock.valueHexView),
  toASN: (value) => new Integer({ valueHex: value })
};
var AsnBitStringConverter = {
  fromASN: (value) => toArrayBuffer(value.valueBlock.valueHexView),
  toASN: (value) => new BitString({ valueHex: value })
};
var AsnObjectIdentifierConverter = {
  fromASN: (value) => value.valueBlock.toString(),
  toASN: (value) => new ObjectIdentifier({ value })
};
var AsnRelativeObjectIdentifierConverter = {
  fromASN: (value) => value.valueBlock.toString(),
  toASN: (value) => new RelativeObjectIdentifier({ value })
};
var AsnBooleanConverter = {
  fromASN: (value) => value.valueBlock.value,
  toASN: (value) => new Boolean2({ value })
};
var AsnOctetStringConverter = {
  fromASN: (value) => toArrayBuffer(value.valueBlock.valueHexView),
  toASN: (value) => new OctetString({ valueHex: value })
};
var AsnConstructedOctetStringConverter = {
  fromASN: (value) => new OctetString2(value.getValue()),
  toASN: (value) => value.toASN()
};
function createStringConverter(Asn1Type) {
  return {
    fromASN: (value) => value.valueBlock.value,
    toASN: (value) => new Asn1Type({ value })
  };
}
var AsnUtf8StringConverter = createStringConverter(Utf8String);
var AsnBmpStringConverter = createStringConverter(BmpString);
var AsnUniversalStringConverter = createStringConverter(UniversalString);
var AsnNumericStringConverter = createStringConverter(NumericString);
var AsnPrintableStringConverter = createStringConverter(PrintableString);
var AsnTeletexStringConverter = createStringConverter(TeletexString);
var AsnVideotexStringConverter = createStringConverter(VideotexString);
var AsnIA5StringConverter = createStringConverter(IA5String);
var AsnGraphicStringConverter = createStringConverter(GraphicString);
var AsnVisibleStringConverter = createStringConverter(VisibleString);
var AsnGeneralStringConverter = createStringConverter(GeneralString);
var AsnCharacterStringConverter = createStringConverter(CharacterString);
var AsnUTCTimeConverter = {
  fromASN: (value) => value.toDate(),
  toASN: (value) => new UTCTime({ valueDate: value })
};
var AsnGeneralizedTimeConverter = {
  fromASN: (value) => value.toDate(),
  toASN: (value) => new GeneralizedTime({ valueDate: value })
};
var AsnNullConverter = {
  fromASN: () => null,
  toASN: () => {
    return new Null();
  }
};
function defaultConverter(type) {
  switch (type) {
    case AsnPropTypes.Any:
      return AsnAnyConverter;
    case AsnPropTypes.BitString:
      return AsnBitStringConverter;
    case AsnPropTypes.BmpString:
      return AsnBmpStringConverter;
    case AsnPropTypes.Boolean:
      return AsnBooleanConverter;
    case AsnPropTypes.CharacterString:
      return AsnCharacterStringConverter;
    case AsnPropTypes.Enumerated:
      return AsnEnumeratedConverter;
    case AsnPropTypes.GeneralString:
      return AsnGeneralStringConverter;
    case AsnPropTypes.GeneralizedTime:
      return AsnGeneralizedTimeConverter;
    case AsnPropTypes.GraphicString:
      return AsnGraphicStringConverter;
    case AsnPropTypes.IA5String:
      return AsnIA5StringConverter;
    case AsnPropTypes.Integer:
      return AsnIntegerConverter;
    case AsnPropTypes.Null:
      return AsnNullConverter;
    case AsnPropTypes.NumericString:
      return AsnNumericStringConverter;
    case AsnPropTypes.ObjectIdentifier:
      return AsnObjectIdentifierConverter;
    case AsnPropTypes.RelativeObjectIdentifier:
      return AsnRelativeObjectIdentifierConverter;
    case AsnPropTypes.OctetString:
      return AsnOctetStringConverter;
    case AsnPropTypes.PrintableString:
      return AsnPrintableStringConverter;
    case AsnPropTypes.TeletexString:
      return AsnTeletexStringConverter;
    case AsnPropTypes.UTCTime:
      return AsnUTCTimeConverter;
    case AsnPropTypes.UniversalString:
      return AsnUniversalStringConverter;
    case AsnPropTypes.Utf8String:
      return AsnUtf8StringConverter;
    case AsnPropTypes.VideotexString:
      return AsnVideotexStringConverter;
    case AsnPropTypes.VisibleString:
      return AsnVisibleStringConverter;
    default:
      return null;
  }
}

// node_modules/@peculiar/asn1-schema/build/es2015/helper.js
function isConvertible(target) {
  if (typeof target === "function" && target.prototype) {
    if (target.prototype.toASN && target.prototype.fromASN) {
      return true;
    } else {
      return isConvertible(target.prototype);
    }
  } else {
    return !!(target && typeof target === "object" && "toASN" in target && "fromASN" in target);
  }
}
function isTypeOfArray(target) {
  if (target) {
    const proto = Object.getPrototypeOf(target);
    if (proto?.prototype?.constructor === Array) {
      return true;
    }
    return isTypeOfArray(proto);
  }
  return false;
}
function isArrayEqual(bytes1, bytes2) {
  if (!(bytes1 && bytes2)) {
    return false;
  }
  if (bytes1.byteLength !== bytes2.byteLength) {
    return false;
  }
  const b1 = new Uint8Array(bytes1);
  const b2 = new Uint8Array(bytes2);
  for (let i = 0; i < bytes1.byteLength; i++) {
    if (b1[i] !== b2[i]) {
      return false;
    }
  }
  return true;
}

// node_modules/@peculiar/asn1-schema/build/es2015/schema.js
var AsnSchemaStorage = class {
  items = /* @__PURE__ */ new WeakMap();
  has(target) {
    return this.items.has(target);
  }
  get(target, checkSchema = false) {
    const schema = this.items.get(target);
    if (!schema) {
      throw new Error(`Cannot get schema for '${target.prototype.constructor.name}' target`);
    }
    if (checkSchema && !schema.schema) {
      throw new Error(`Schema '${target.prototype.constructor.name}' doesn't contain ASN.1 schema. Call 'AsnSchemaStorage.cache'.`);
    }
    return schema;
  }
  cache(target) {
    const schema = this.get(target);
    if (!schema.schema) {
      schema.schema = this.create(target, true);
    }
  }
  createDefault(target) {
    const schema = {
      type: AsnTypeTypes.Sequence,
      items: {}
    };
    const parentSchema = this.findParentSchema(target);
    if (parentSchema) {
      Object.assign(schema, parentSchema);
      schema.items = Object.assign({}, schema.items, parentSchema.items);
    }
    return schema;
  }
  create(target, useNames) {
    const schema = this.items.get(target) || this.createDefault(target);
    const asn1Value = [];
    for (const key2 in schema.items) {
      const item = schema.items[key2];
      const name = useNames ? key2 : "";
      let asn1Item;
      if (typeof item.type === "number") {
        const Asn1TypeName = AsnPropTypes[item.type];
        const Asn1Type = index_es_exports[Asn1TypeName];
        if (!Asn1Type) {
          throw new Error(`Cannot get ASN1 class by name '${Asn1TypeName}'`);
        }
        asn1Item = new Asn1Type({ name });
      } else if (isConvertible(item.type)) {
        const instance2 = new item.type();
        asn1Item = instance2.toSchema(name);
      } else if (item.optional) {
        const itemSchema = this.get(item.type);
        if (itemSchema.type === AsnTypeTypes.Choice) {
          asn1Item = new Any({ name });
        } else {
          asn1Item = this.create(item.type, false);
          asn1Item.name = name;
        }
      } else {
        asn1Item = new Any({ name });
      }
      const optional = !!item.optional || item.defaultValue !== void 0;
      if (item.repeated) {
        asn1Item.name = "";
        const Container = item.repeated === "set" ? Set2 : Sequence;
        asn1Item = new Container({
          name: "",
          value: [
            new Repeated({
              name,
              value: asn1Item
            })
          ]
        });
      }
      if (item.context !== null && item.context !== void 0) {
        if (item.implicit) {
          if (typeof item.type === "number" || isConvertible(item.type)) {
            const Container = item.repeated ? Constructed : Primitive;
            asn1Value.push(new Container({
              name,
              optional,
              idBlock: {
                tagClass: 3,
                tagNumber: item.context
              }
            }));
          } else {
            this.cache(item.type);
            const isRepeated = !!item.repeated;
            let value = !isRepeated ? this.get(item.type, true).schema : asn1Item;
            value = "valueBlock" in value ? value.valueBlock.value : value.value;
            asn1Value.push(new Constructed({
              name: !isRepeated ? name : "",
              optional,
              idBlock: {
                tagClass: 3,
                tagNumber: item.context
              },
              value
            }));
          }
        } else {
          asn1Value.push(new Constructed({
            optional,
            idBlock: {
              tagClass: 3,
              tagNumber: item.context
            },
            value: [asn1Item]
          }));
        }
      } else {
        asn1Item.optional = optional;
        asn1Value.push(asn1Item);
      }
    }
    switch (schema.type) {
      case AsnTypeTypes.Sequence:
        return new Sequence({
          value: asn1Value,
          name: ""
        });
      case AsnTypeTypes.Set:
        return new Set2({
          value: asn1Value,
          name: ""
        });
      case AsnTypeTypes.Choice:
        return new Choice({
          value: asn1Value,
          name: ""
        });
      default:
        throw new Error("Unsupported ASN1 type in use");
    }
  }
  set(target, schema) {
    this.items.set(target, schema);
    return this;
  }
  findParentSchema(target) {
    const parent = Object.getPrototypeOf(target);
    if (parent) {
      const schema = this.items.get(parent);
      return schema || this.findParentSchema(parent);
    }
    return null;
  }
};

// node_modules/@peculiar/asn1-schema/build/es2015/storage.js
var schemaStorage = new AsnSchemaStorage();

// node_modules/@peculiar/asn1-schema/build/es2015/decorators.js
var AsnType = (options) => (target) => {
  let schema;
  if (!schemaStorage.has(target)) {
    schema = schemaStorage.createDefault(target);
    schemaStorage.set(target, schema);
  } else {
    schema = schemaStorage.get(target);
  }
  Object.assign(schema, options);
};
var AsnProp = (options) => (target, propertyKey) => {
  let schema;
  if (!schemaStorage.has(target.constructor)) {
    schema = schemaStorage.createDefault(target.constructor);
    schemaStorage.set(target.constructor, schema);
  } else {
    schema = schemaStorage.get(target.constructor);
  }
  const copyOptions = Object.assign({}, options);
  if (typeof copyOptions.type === "number" && !copyOptions.converter) {
    const defaultConverter2 = defaultConverter(options.type);
    if (!defaultConverter2) {
      throw new Error(`Cannot get default converter for property '${propertyKey}' of ${target.constructor.name}`);
    }
    copyOptions.converter = defaultConverter2;
  }
  copyOptions.raw = options.raw;
  schema.items[propertyKey] = copyOptions;
};

// node_modules/@peculiar/asn1-schema/build/es2015/errors/schema_validation.js
var AsnSchemaValidationError = class extends Error {
  schemas = [];
};

// node_modules/@peculiar/asn1-schema/build/es2015/parser.js
var AsnParser = class {
  static parse(data, target, options) {
    const asn1Parsed = fromBER(toArrayBuffer(data), options?.berOptions);
    if (asn1Parsed.result.error) {
      throw new Error(asn1Parsed.result.error);
    }
    const res = this.fromASN(asn1Parsed.result, target, options);
    return res;
  }
  static fromASN(asn1Schema, target, options) {
    try {
      if (isConvertible(target)) {
        const value = new target();
        return value.fromASN(asn1Schema);
      }
      const schema = schemaStorage.get(target);
      schemaStorage.cache(target);
      let targetSchema = schema.schema;
      const choiceResult = this.handleChoiceTypes(asn1Schema, schema, target, targetSchema, options);
      if (choiceResult?.result) {
        return choiceResult.result;
      }
      if (choiceResult?.targetSchema) {
        targetSchema = choiceResult.targetSchema;
      }
      const sequenceResult = this.handleSequenceTypes(asn1Schema, schema, target, targetSchema);
      const res = new target();
      if (isTypeOfArray(target)) {
        return this.handleArrayTypes(asn1Schema, schema, target, options);
      }
      this.processSchemaItems(schema, sequenceResult, res, options);
      return res;
    } catch (error) {
      if (error instanceof AsnSchemaValidationError) {
        error.schemas.push(target.name);
      }
      throw error;
    }
  }
  static handleChoiceTypes(asn1Schema, schema, target, targetSchema, options) {
    if (asn1Schema.constructor === Constructed && schema.type === AsnTypeTypes.Choice && asn1Schema.idBlock.tagClass === 3) {
      for (const key2 in schema.items) {
        const schemaItem = schema.items[key2];
        if (schemaItem.context === asn1Schema.idBlock.tagNumber && schemaItem.implicit) {
          if (typeof schemaItem.type === "function" && schemaStorage.has(schemaItem.type)) {
            const fieldSchema = schemaStorage.get(schemaItem.type);
            if (fieldSchema && fieldSchema.type === AsnTypeTypes.Sequence) {
              const newSeq = new Sequence();
              if ("value" in asn1Schema.valueBlock && Array.isArray(asn1Schema.valueBlock.value) && "value" in newSeq.valueBlock) {
                newSeq.valueBlock.value = asn1Schema.valueBlock.value;
                const fieldValue = this.fromASN(newSeq, schemaItem.type, options);
                const res = new target();
                res[key2] = fieldValue;
                return { result: res };
              }
            }
          }
        }
      }
    } else if (asn1Schema.constructor === Constructed && schema.type !== AsnTypeTypes.Choice) {
      const newTargetSchema = new Constructed({
        idBlock: {
          tagClass: 3,
          tagNumber: asn1Schema.idBlock.tagNumber
        },
        value: schema.schema.valueBlock.value
      });
      for (const key2 in schema.items) {
        delete asn1Schema[key2];
      }
      return { targetSchema: newTargetSchema };
    }
    return null;
  }
  static handleSequenceTypes(asn1Schema, schema, target, targetSchema) {
    if (schema.type === AsnTypeTypes.Sequence) {
      const asn1ComparedSchema = compareSchema({}, asn1Schema, targetSchema);
      if (!asn1ComparedSchema.verified) {
        throw new AsnSchemaValidationError(`Data does not match to ${target.name} ASN1 schema.${asn1ComparedSchema.result.error ? ` ${asn1ComparedSchema.result.error}` : ""}`);
      }
      return asn1ComparedSchema;
    } else {
      const asn1ComparedSchema = compareSchema({}, asn1Schema, targetSchema);
      if (!asn1ComparedSchema.verified) {
        throw new AsnSchemaValidationError(`Data does not match to ${target.name} ASN1 schema.${asn1ComparedSchema.result.error ? ` ${asn1ComparedSchema.result.error}` : ""}`);
      }
      return asn1ComparedSchema;
    }
  }
  static processRepeatedField(asn1Elements, asn1Index, schemaItem) {
    let elementsToProcess = asn1Elements.slice(asn1Index);
    if (elementsToProcess.length === 1 && elementsToProcess[0].constructor.name === "Sequence") {
      const seq = elementsToProcess[0];
      if (seq.valueBlock && seq.valueBlock.value && Array.isArray(seq.valueBlock.value)) {
        elementsToProcess = seq.valueBlock.value;
      }
    }
    if (typeof schemaItem.type === "number") {
      const converter = defaultConverter(schemaItem.type);
      if (!converter)
        throw new Error(`No converter for ASN.1 type ${schemaItem.type}`);
      return elementsToProcess.filter((el) => el && el.valueBlock).map((el) => {
        try {
          return converter.fromASN(el);
        } catch {
          return void 0;
        }
      }).filter((v) => v !== void 0);
    } else {
      return elementsToProcess.filter((el) => el && el.valueBlock).map((el) => {
        try {
          return this.fromASN(el, schemaItem.type);
        } catch {
          return void 0;
        }
      }).filter((v) => v !== void 0);
    }
  }
  static processPrimitiveField(asn1Element, schemaItem) {
    const converter = defaultConverter(schemaItem.type);
    if (!converter)
      throw new Error(`No converter for ASN.1 type ${schemaItem.type}`);
    return converter.fromASN(asn1Element);
  }
  static isOptionalChoiceField(schemaItem) {
    return schemaItem.optional && typeof schemaItem.type === "function" && schemaStorage.has(schemaItem.type) && schemaStorage.get(schemaItem.type).type === AsnTypeTypes.Choice;
  }
  static processOptionalChoiceField(asn1Element, schemaItem) {
    try {
      const value = this.fromASN(asn1Element, schemaItem.type);
      return {
        processed: true,
        value
      };
    } catch (err) {
      if (err instanceof AsnSchemaValidationError && /Wrong values for Choice type/.test(err.message)) {
        return { processed: false };
      }
      throw err;
    }
  }
  static handleArrayTypes(asn1Schema, schema, target, options) {
    if (!("value" in asn1Schema.valueBlock && Array.isArray(asn1Schema.valueBlock.value))) {
      throw new Error("Cannot get items from the ASN.1 parsed value. ASN.1 object is not constructed.");
    }
    const itemType = schema.itemType;
    if (typeof itemType === "number") {
      const converter = defaultConverter(itemType);
      if (!converter) {
        throw new Error(`Cannot get default converter for array item of ${target.name} ASN1 schema`);
      }
      return target.from(asn1Schema.valueBlock.value, (element) => converter.fromASN(element));
    } else {
      return target.from(asn1Schema.valueBlock.value, (element) => this.fromASN(element, itemType, options));
    }
  }
  static processSchemaItems(schema, asn1ComparedSchema, res, options) {
    for (const key2 in schema.items) {
      const asn1SchemaValue = asn1ComparedSchema.result[key2];
      if (!asn1SchemaValue) {
        continue;
      }
      const schemaItem = schema.items[key2];
      const schemaItemType = schemaItem.type;
      let parsedValue;
      if (typeof schemaItemType === "number" || isConvertible(schemaItemType)) {
        parsedValue = this.processPrimitiveSchemaItem(asn1SchemaValue, schemaItem, schemaItemType, options);
      } else {
        parsedValue = this.processComplexSchemaItem(asn1SchemaValue, schemaItem, schemaItemType, options);
      }
      if (parsedValue && typeof parsedValue === "object" && "value" in parsedValue && "raw" in parsedValue) {
        res[key2] = parsedValue.value;
        res[`${key2}Raw`] = parsedValue.raw;
      } else {
        res[key2] = parsedValue;
      }
    }
  }
  static processPrimitiveSchemaItem(asn1SchemaValue, schemaItem, schemaItemType, options) {
    const converter = schemaItem.converter ?? (isConvertible(schemaItemType) ? new schemaItemType() : null);
    if (!converter) {
      throw new Error("Converter is empty");
    }
    if (schemaItem.repeated) {
      return this.processRepeatedPrimitiveItem(asn1SchemaValue, schemaItem, converter, options);
    } else {
      return this.processSinglePrimitiveItem(asn1SchemaValue, schemaItem, schemaItemType, converter, options);
    }
  }
  static processRepeatedPrimitiveItem(asn1SchemaValue, schemaItem, converter, options) {
    if (schemaItem.implicit) {
      const Container = schemaItem.repeated === "sequence" ? Sequence : Set2;
      const newItem = new Container();
      newItem.valueBlock = asn1SchemaValue.valueBlock;
      const newItemAsn = fromBER(newItem.toBER(false), options?.berOptions);
      if (newItemAsn.offset === -1) {
        throw new Error(`Cannot parse the child item. ${newItemAsn.result.error}`);
      }
      if (!("value" in newItemAsn.result.valueBlock && Array.isArray(newItemAsn.result.valueBlock.value))) {
        throw new Error("Cannot get items from the ASN.1 parsed value. ASN.1 object is not constructed.");
      }
      const value = newItemAsn.result.valueBlock.value;
      return Array.from(value, (element) => converter.fromASN(element));
    } else {
      return Array.from(asn1SchemaValue, (element) => converter.fromASN(element));
    }
  }
  static processSinglePrimitiveItem(asn1SchemaValue, schemaItem, schemaItemType, converter, options) {
    let value = asn1SchemaValue;
    if (schemaItem.implicit) {
      let newItem;
      if (isConvertible(schemaItemType)) {
        newItem = new schemaItemType().toSchema("");
      } else {
        const Asn1TypeName = AsnPropTypes[schemaItemType];
        const Asn1Type = index_es_exports[Asn1TypeName];
        if (!Asn1Type) {
          throw new Error(`Cannot get '${Asn1TypeName}' class from asn1js module`);
        }
        newItem = new Asn1Type();
      }
      newItem.valueBlock = value.valueBlock;
      value = fromBER(newItem.toBER(false), options?.berOptions).result;
    }
    return converter.fromASN(value);
  }
  static processComplexSchemaItem(asn1SchemaValue, schemaItem, schemaItemType, options) {
    if (schemaItem.repeated) {
      if (!Array.isArray(asn1SchemaValue)) {
        throw new Error("Cannot get list of items from the ASN.1 parsed value. ASN.1 value should be iterable.");
      }
      return Array.from(asn1SchemaValue, (element) => this.fromASN(element, schemaItemType, options));
    } else {
      const valueToProcess = this.handleImplicitTagging(asn1SchemaValue, schemaItem, schemaItemType);
      if (this.isOptionalChoiceField(schemaItem)) {
        try {
          return this.fromASN(valueToProcess, schemaItemType, options);
        } catch (err) {
          if (err instanceof AsnSchemaValidationError && /Wrong values for Choice type/.test(err.message)) {
            return void 0;
          }
          throw err;
        }
      } else {
        const parsedValue = this.fromASN(valueToProcess, schemaItemType, options);
        if (schemaItem.raw) {
          return {
            value: parsedValue,
            raw: asn1SchemaValue.valueBeforeDecodeView
          };
        }
        return parsedValue;
      }
    }
  }
  static handleImplicitTagging(asn1SchemaValue, schemaItem, schemaItemType) {
    if (schemaItem.implicit && typeof schemaItem.context === "number") {
      const schema = schemaStorage.get(schemaItemType);
      if (schema.type === AsnTypeTypes.Sequence) {
        const newSeq = new Sequence();
        if ("value" in asn1SchemaValue.valueBlock && Array.isArray(asn1SchemaValue.valueBlock.value) && "value" in newSeq.valueBlock) {
          newSeq.valueBlock.value = asn1SchemaValue.valueBlock.value;
          return newSeq;
        }
      } else if (schema.type === AsnTypeTypes.Set) {
        const newSet = new Set2();
        if ("value" in asn1SchemaValue.valueBlock && Array.isArray(asn1SchemaValue.valueBlock.value) && "value" in newSet.valueBlock) {
          newSet.valueBlock.value = asn1SchemaValue.valueBlock.value;
          return newSet;
        }
      }
    }
    return asn1SchemaValue;
  }
};

// node_modules/@peculiar/asn1-schema/build/es2015/serializer.js
var AsnSerializer = class _AsnSerializer {
  static serialize(obj) {
    if (obj instanceof BaseBlock) {
      return obj.toBER(false);
    }
    return this.toASN(obj).toBER(false);
  }
  static toASN(obj) {
    if (obj && typeof obj === "object" && isConvertible(obj)) {
      return obj.toASN();
    }
    if (!(obj && typeof obj === "object")) {
      throw new TypeError("Parameter 1 should be type of Object.");
    }
    const target = obj.constructor;
    const schema = schemaStorage.get(target);
    schemaStorage.cache(target);
    let asn1Value = [];
    if (schema.itemType) {
      if (!Array.isArray(obj)) {
        throw new TypeError("Parameter 1 should be type of Array.");
      }
      if (typeof schema.itemType === "number") {
        const converter = defaultConverter(schema.itemType);
        if (!converter) {
          throw new Error(`Cannot get default converter for array item of ${target.name} ASN1 schema`);
        }
        asn1Value = obj.map((o) => converter.toASN(o));
      } else {
        asn1Value = obj.map((o) => this.toAsnItem({ type: schema.itemType }, "[]", target, o));
      }
    } else {
      for (const key2 in schema.items) {
        const schemaItem = schema.items[key2];
        const objProp = obj[key2];
        if (objProp === void 0 || schemaItem.defaultValue === objProp || typeof schemaItem.defaultValue === "object" && typeof objProp === "object" && isArrayEqual(this.serialize(schemaItem.defaultValue), this.serialize(objProp))) {
          continue;
        }
        const asn1Item = _AsnSerializer.toAsnItem(schemaItem, key2, target, objProp);
        if (typeof schemaItem.context === "number") {
          if (schemaItem.implicit) {
            if (!schemaItem.repeated && (typeof schemaItem.type === "number" || isConvertible(schemaItem.type))) {
              const value = {};
              value.valueHex = asn1Item instanceof Null ? toArrayBuffer(asn1Item.valueBeforeDecodeView) : asn1Item.valueBlock.toBER();
              asn1Value.push(new Primitive({
                optional: schemaItem.optional,
                idBlock: {
                  tagClass: 3,
                  tagNumber: schemaItem.context
                },
                ...value
              }));
            } else {
              asn1Value.push(new Constructed({
                optional: schemaItem.optional,
                idBlock: {
                  tagClass: 3,
                  tagNumber: schemaItem.context
                },
                value: asn1Item.valueBlock.value
              }));
            }
          } else {
            asn1Value.push(new Constructed({
              optional: schemaItem.optional,
              idBlock: {
                tagClass: 3,
                tagNumber: schemaItem.context
              },
              value: [asn1Item]
            }));
          }
        } else if (schemaItem.repeated) {
          asn1Value = asn1Value.concat(asn1Item);
        } else {
          asn1Value.push(asn1Item);
        }
      }
    }
    let asnSchema;
    switch (schema.type) {
      case AsnTypeTypes.Sequence:
        asnSchema = new Sequence({ value: asn1Value });
        break;
      case AsnTypeTypes.Set:
        asnSchema = new Set2({ value: asn1Value });
        break;
      case AsnTypeTypes.Choice:
        if (!asn1Value[0]) {
          throw new Error(`Schema '${target.name}' has wrong data. Choice cannot be empty.`);
        }
        asnSchema = asn1Value[0];
        break;
    }
    return asnSchema;
  }
  static toAsnItem(schemaItem, key2, target, objProp) {
    let asn1Item;
    if (typeof schemaItem.type === "number") {
      const converter = schemaItem.converter;
      if (!converter) {
        throw new Error(`Property '${key2}' doesn't have converter for type ${AsnPropTypes[schemaItem.type]} in schema '${target.name}'`);
      }
      if (schemaItem.repeated) {
        if (!Array.isArray(objProp)) {
          throw new TypeError("Parameter 'objProp' should be type of Array.");
        }
        const items = Array.from(objProp, (element) => converter.toASN(element));
        const Container = schemaItem.repeated === "sequence" ? Sequence : Set2;
        asn1Item = new Container({ value: items });
      } else {
        asn1Item = converter.toASN(objProp);
      }
    } else {
      if (schemaItem.repeated) {
        if (!Array.isArray(objProp)) {
          throw new TypeError("Parameter 'objProp' should be type of Array.");
        }
        const items = Array.from(objProp, (element) => this.toASN(element));
        const Container = schemaItem.repeated === "sequence" ? Sequence : Set2;
        asn1Item = new Container({ value: items });
      } else {
        asn1Item = this.toASN(objProp);
      }
    }
    return asn1Item;
  }
};

// node_modules/@peculiar/asn1-schema/build/es2015/objects.js
var AsnArray = class extends Array {
  constructor(items = []) {
    if (typeof items === "number") {
      super(items);
    } else {
      super();
      for (const item of items) {
        this.push(item);
      }
    }
  }
};

// node_modules/@peculiar/asn1-schema/build/es2015/convert.js
var AsnConvert = class _AsnConvert {
  static serialize(obj) {
    return AsnSerializer.serialize(obj);
  }
  static parse(data, target, options) {
    return AsnParser.parse(data, target, options);
  }
  static toString(data, options) {
    const buf = isBufferSource(data) ? toArrayBuffer(data) : _AsnConvert.serialize(data);
    const asn = fromBER(buf, options?.berOptions);
    if (asn.offset === -1) {
      throw new Error(`Cannot decode ASN.1 data. ${asn.result.error}`);
    }
    return asn.result.toString();
  }
};

// node_modules/tslib/tslib.es6.mjs
function __decorate(decorators, target, key2, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key2) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key2, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key2, r) : d(target, key2)) || r;
  return c > 3 && r && Object.defineProperty(target, key2, r), r;
}
function __classPrivateFieldGet(receiver, state, kind, f) {
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}
function __classPrivateFieldSet(receiver, state, value, kind, f) {
  if (kind === "m") throw new TypeError("Private method is not writable");
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
}

// node_modules/@peculiar/asn1-x509/build/es2015/ip_converter.js
var IpConverter = class {
  static isIPv4(ip) {
    return /^(\d{1,3}\.){3}\d{1,3}$/.test(ip);
  }
  static parseIPv4(ip) {
    const parts = ip.split(".");
    if (parts.length !== 4) {
      throw new Error("Invalid IPv4 address");
    }
    return parts.map((part) => {
      const num = parseInt(part, 10);
      if (isNaN(num) || num < 0 || num > 255) {
        throw new Error("Invalid IPv4 address part");
      }
      return num;
    });
  }
  static parseIPv6(ip) {
    const expandedIP = this.expandIPv6(ip);
    const parts = expandedIP.split(":");
    if (parts.length !== 8) {
      throw new Error("Invalid IPv6 address");
    }
    return parts.reduce((bytes, part) => {
      const num = parseInt(part, 16);
      if (isNaN(num) || num < 0 || num > 65535) {
        throw new Error("Invalid IPv6 address part");
      }
      bytes.push(num >> 8 & 255);
      bytes.push(num & 255);
      return bytes;
    }, []);
  }
  static expandIPv6(ip) {
    if (!ip.includes("::")) {
      return ip;
    }
    const parts = ip.split("::");
    if (parts.length > 2) {
      throw new Error("Invalid IPv6 address");
    }
    const left = parts[0] ? parts[0].split(":") : [];
    const right = parts[1] ? parts[1].split(":") : [];
    const missing = 8 - (left.length + right.length);
    if (missing < 0) {
      throw new Error("Invalid IPv6 address");
    }
    return [...left, ...Array(missing).fill("0"), ...right].join(":");
  }
  static formatIPv6(bytes) {
    const parts = [];
    for (let i = 0; i < 16; i += 2) {
      parts.push((bytes[i] << 8 | bytes[i + 1]).toString(16));
    }
    return this.compressIPv6(parts.join(":"));
  }
  static compressIPv6(ip) {
    const parts = ip.split(":");
    let longestZeroStart = -1;
    let longestZeroLength = 0;
    let currentZeroStart = -1;
    let currentZeroLength = 0;
    for (let i = 0; i < parts.length; i++) {
      if (parts[i] === "0") {
        if (currentZeroStart === -1) {
          currentZeroStart = i;
        }
        currentZeroLength++;
      } else {
        if (currentZeroLength > longestZeroLength) {
          longestZeroStart = currentZeroStart;
          longestZeroLength = currentZeroLength;
        }
        currentZeroStart = -1;
        currentZeroLength = 0;
      }
    }
    if (currentZeroLength > longestZeroLength) {
      longestZeroStart = currentZeroStart;
      longestZeroLength = currentZeroLength;
    }
    if (longestZeroLength > 1) {
      const before = parts.slice(0, longestZeroStart).join(":");
      const after = parts.slice(longestZeroStart + longestZeroLength).join(":");
      return `${before}::${after}`;
    }
    return ip;
  }
  static parseCIDR(text) {
    const [addr, prefixStr] = text.split("/");
    const prefix = parseInt(prefixStr, 10);
    if (this.isIPv4(addr)) {
      if (prefix < 0 || prefix > 32) {
        throw new Error("Invalid IPv4 prefix length");
      }
      return [this.parseIPv4(addr), prefix];
    } else {
      if (prefix < 0 || prefix > 128) {
        throw new Error("Invalid IPv6 prefix length");
      }
      return [this.parseIPv6(addr), prefix];
    }
  }
  static decodeIP(value) {
    if (value.length === 64 && parseInt(value, 16) === 0) {
      return "::/0";
    }
    if (value.length !== 16) {
      return value;
    }
    const mask = parseInt(value.slice(8), 16).toString(2).split("").reduce((a, k) => a + +k, 0);
    let ip = value.slice(0, 8).replace(/(.{2})/g, (match) => `${parseInt(match, 16)}.`);
    ip = ip.slice(0, -1);
    return `${ip}/${mask}`;
  }
  static toString(buf) {
    const uint8 = new Uint8Array(buf);
    if (uint8.length === 4) {
      return Array.from(uint8).join(".");
    }
    if (uint8.length === 16) {
      return this.formatIPv6(uint8);
    }
    if (uint8.length === 8 || uint8.length === 32) {
      const half = uint8.length / 2;
      const addrBytes = uint8.slice(0, half);
      const maskBytes = uint8.slice(half);
      const isAllZeros = uint8.every((byte) => byte === 0);
      if (isAllZeros) {
        return uint8.length === 8 ? "0.0.0.0/0" : "::/0";
      }
      const prefixLen = maskBytes.reduce((a, b) => a + (b.toString(2).match(/1/g) || []).length, 0);
      if (uint8.length === 8) {
        const addrStr = Array.from(addrBytes).join(".");
        return `${addrStr}/${prefixLen}`;
      } else {
        const addrStr = this.formatIPv6(addrBytes);
        return `${addrStr}/${prefixLen}`;
      }
    }
    return this.decodeIP(hex_exports.encode(buf));
  }
  static fromString(text) {
    if (text.includes("/")) {
      const [addr, prefix] = this.parseCIDR(text);
      const maskBytes = new Uint8Array(addr.length);
      let bitsLeft = prefix;
      for (let i = 0; i < maskBytes.length; i++) {
        if (bitsLeft >= 8) {
          maskBytes[i] = 255;
          bitsLeft -= 8;
        } else if (bitsLeft > 0) {
          maskBytes[i] = 255 << 8 - bitsLeft;
          bitsLeft = 0;
        }
      }
      const out = new Uint8Array(addr.length * 2);
      out.set(addr, 0);
      out.set(maskBytes, addr.length);
      return out.buffer;
    }
    const bytes = this.isIPv4(text) ? this.parseIPv4(text) : this.parseIPv6(text);
    return new Uint8Array(bytes).buffer;
  }
};

// node_modules/@peculiar/asn1-x509/build/es2015/name.js
var RelativeDistinguishedName_1;
var RDNSequence_1;
var Name_1;
var DirectoryString = class DirectoryString2 {
  teletexString;
  printableString;
  universalString;
  utf8String;
  bmpString;
  constructor(params = {}) {
    Object.assign(this, params);
  }
  toString() {
    return this.bmpString || this.printableString || this.teletexString || this.universalString || this.utf8String || "";
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.TeletexString })
], DirectoryString.prototype, "teletexString", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.PrintableString })
], DirectoryString.prototype, "printableString", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.UniversalString })
], DirectoryString.prototype, "universalString", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Utf8String })
], DirectoryString.prototype, "utf8String", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.BmpString })
], DirectoryString.prototype, "bmpString", void 0);
DirectoryString = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], DirectoryString);
var AttributeValue = class AttributeValue2 extends DirectoryString {
  ia5String;
  anyValue;
  constructor(params = {}) {
    super(params);
    Object.assign(this, params);
  }
  toString() {
    return this.ia5String || (this.anyValue ? hex_exports.encode(this.anyValue) : super.toString());
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.IA5String })
], AttributeValue.prototype, "ia5String", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Any })
], AttributeValue.prototype, "anyValue", void 0);
AttributeValue = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], AttributeValue);
var AttributeTypeAndValue = class {
  type = "";
  value = new AttributeValue();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], AttributeTypeAndValue.prototype, "type", void 0);
__decorate([
  AsnProp({ type: AttributeValue })
], AttributeTypeAndValue.prototype, "value", void 0);
var RelativeDistinguishedName = RelativeDistinguishedName_1 = class RelativeDistinguishedName2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, RelativeDistinguishedName_1.prototype);
  }
};
RelativeDistinguishedName = RelativeDistinguishedName_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Set,
    itemType: AttributeTypeAndValue
  })
], RelativeDistinguishedName);
var RDNSequence = RDNSequence_1 = class RDNSequence2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, RDNSequence_1.prototype);
  }
};
RDNSequence = RDNSequence_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: RelativeDistinguishedName
  })
], RDNSequence);
var Name = Name_1 = class Name2 extends RDNSequence {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, Name_1.prototype);
  }
};
Name = Name_1 = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], Name);

// node_modules/@peculiar/asn1-x509/build/es2015/general_name.js
var AsnIpConverter = {
  fromASN: (value) => IpConverter.toString(AsnOctetStringConverter.fromASN(value)),
  toASN: (value) => AsnOctetStringConverter.toASN(IpConverter.fromString(value))
};
var OtherName = class {
  typeId = "";
  value = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], OtherName.prototype, "typeId", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    context: 0
  })
], OtherName.prototype, "value", void 0);
var EDIPartyName = class {
  nameAssigner;
  partyName = new DirectoryString();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: DirectoryString,
    optional: true,
    context: 0,
    implicit: true
  })
], EDIPartyName.prototype, "nameAssigner", void 0);
__decorate([
  AsnProp({
    type: DirectoryString,
    context: 1,
    implicit: true
  })
], EDIPartyName.prototype, "partyName", void 0);
var GeneralName = class GeneralName2 {
  otherName;
  rfc822Name;
  dNSName;
  x400Address;
  directoryName;
  ediPartyName;
  uniformResourceIdentifier;
  iPAddress;
  registeredID;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: OtherName,
    context: 0,
    implicit: true
  })
], GeneralName.prototype, "otherName", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.IA5String,
    context: 1,
    implicit: true
  })
], GeneralName.prototype, "rfc822Name", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.IA5String,
    context: 2,
    implicit: true
  })
], GeneralName.prototype, "dNSName", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    context: 3,
    implicit: true
  })
], GeneralName.prototype, "x400Address", void 0);
__decorate([
  AsnProp({
    type: Name,
    context: 4,
    implicit: false
  })
], GeneralName.prototype, "directoryName", void 0);
__decorate([
  AsnProp({
    type: EDIPartyName,
    context: 5
  })
], GeneralName.prototype, "ediPartyName", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.IA5String,
    context: 6,
    implicit: true
  })
], GeneralName.prototype, "uniformResourceIdentifier", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.OctetString,
    context: 7,
    implicit: true,
    converter: AsnIpConverter
  })
], GeneralName.prototype, "iPAddress", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.ObjectIdentifier,
    context: 8,
    implicit: true
  })
], GeneralName.prototype, "registeredID", void 0);
GeneralName = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], GeneralName);

// node_modules/@peculiar/asn1-x509/build/es2015/object_identifiers.js
var id_pkix = "1.3.6.1.5.5.7";
var id_pe = `${id_pkix}.1`;
var id_qt = `${id_pkix}.2`;
var id_kp = `${id_pkix}.3`;
var id_ad = `${id_pkix}.48`;
var id_qt_csp = `${id_qt}.1`;
var id_qt_unotice = `${id_qt}.2`;
var id_ad_ocsp = `${id_ad}.1`;
var id_ad_caIssuers = `${id_ad}.2`;
var id_ad_timeStamping = `${id_ad}.3`;
var id_ad_caRepository = `${id_ad}.5`;
var id_ce = "2.5.29";

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/authority_information_access.js
var AuthorityInfoAccessSyntax_1;
var id_pe_authorityInfoAccess = `${id_pe}.1`;
var AccessDescription = class {
  accessMethod = "";
  accessLocation = new GeneralName();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], AccessDescription.prototype, "accessMethod", void 0);
__decorate([
  AsnProp({ type: GeneralName })
], AccessDescription.prototype, "accessLocation", void 0);
var AuthorityInfoAccessSyntax = AuthorityInfoAccessSyntax_1 = class AuthorityInfoAccessSyntax2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, AuthorityInfoAccessSyntax_1.prototype);
  }
};
AuthorityInfoAccessSyntax = AuthorityInfoAccessSyntax_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: AccessDescription
  })
], AuthorityInfoAccessSyntax);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/authority_key_identifier.js
var id_ce_authorityKeyIdentifier = `${id_ce}.35`;
var KeyIdentifier = class extends OctetString2 {
};
var AuthorityKeyIdentifier = class {
  keyIdentifier;
  authorityCertIssuer;
  authorityCertSerialNumber;
  constructor(params = {}) {
    if (params) {
      Object.assign(this, params);
    }
  }
};
__decorate([
  AsnProp({
    type: KeyIdentifier,
    context: 0,
    optional: true,
    implicit: true
  })
], AuthorityKeyIdentifier.prototype, "keyIdentifier", void 0);
__decorate([
  AsnProp({
    type: GeneralName,
    context: 1,
    optional: true,
    implicit: true,
    repeated: "sequence"
  })
], AuthorityKeyIdentifier.prototype, "authorityCertIssuer", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    context: 2,
    optional: true,
    implicit: true,
    converter: AsnIntegerArrayBufferConverter
  })
], AuthorityKeyIdentifier.prototype, "authorityCertSerialNumber", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/basic_constraints.js
var id_ce_basicConstraints = `${id_ce}.19`;
var BasicConstraints = class {
  cA = false;
  pathLenConstraint;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.Boolean,
    defaultValue: false
  })
], BasicConstraints.prototype, "cA", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    optional: true
  })
], BasicConstraints.prototype, "pathLenConstraint", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/general_names.js
var GeneralNames_1;
var GeneralNames = GeneralNames_1 = class GeneralNames2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, GeneralNames_1.prototype);
  }
};
GeneralNames = GeneralNames_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: GeneralName
  })
], GeneralNames);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/certificate_issuer.js
var CertificateIssuer_1;
var id_ce_certificateIssuer = `${id_ce}.29`;
var CertificateIssuer = CertificateIssuer_1 = class CertificateIssuer2 extends GeneralNames {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, CertificateIssuer_1.prototype);
  }
};
CertificateIssuer = CertificateIssuer_1 = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], CertificateIssuer);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/certificate_policies.js
var CertificatePolicies_1;
var id_ce_certificatePolicies = `${id_ce}.32`;
var id_ce_certificatePolicies_anyPolicy = `${id_ce_certificatePolicies}.0`;
var DisplayText = class DisplayText2 {
  ia5String;
  visibleString;
  bmpString;
  utf8String;
  constructor(params = {}) {
    Object.assign(this, params);
  }
  toString() {
    return this.ia5String || this.visibleString || this.bmpString || this.utf8String || "";
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.IA5String })
], DisplayText.prototype, "ia5String", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.VisibleString })
], DisplayText.prototype, "visibleString", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.BmpString })
], DisplayText.prototype, "bmpString", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Utf8String })
], DisplayText.prototype, "utf8String", void 0);
DisplayText = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], DisplayText);
var NoticeReference = class {
  organization = new DisplayText();
  noticeNumbers = [];
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: DisplayText })
], NoticeReference.prototype, "organization", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    repeated: "sequence"
  })
], NoticeReference.prototype, "noticeNumbers", void 0);
var UserNotice = class {
  noticeRef;
  explicitText;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: NoticeReference,
    optional: true
  })
], UserNotice.prototype, "noticeRef", void 0);
__decorate([
  AsnProp({
    type: DisplayText,
    optional: true
  })
], UserNotice.prototype, "explicitText", void 0);
var Qualifier = class Qualifier2 {
  cPSuri;
  userNotice;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.IA5String })
], Qualifier.prototype, "cPSuri", void 0);
__decorate([
  AsnProp({ type: UserNotice })
], Qualifier.prototype, "userNotice", void 0);
Qualifier = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], Qualifier);
var PolicyQualifierInfo = class {
  policyQualifierId = "";
  qualifier = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], PolicyQualifierInfo.prototype, "policyQualifierId", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Any })
], PolicyQualifierInfo.prototype, "qualifier", void 0);
var PolicyInformation = class {
  policyIdentifier = "";
  policyQualifiers;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], PolicyInformation.prototype, "policyIdentifier", void 0);
__decorate([
  AsnProp({
    type: PolicyQualifierInfo,
    repeated: "sequence",
    optional: true
  })
], PolicyInformation.prototype, "policyQualifiers", void 0);
var CertificatePolicies = CertificatePolicies_1 = class CertificatePolicies2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, CertificatePolicies_1.prototype);
  }
};
CertificatePolicies = CertificatePolicies_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: PolicyInformation
  })
], CertificatePolicies);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/crl_number.js
var id_ce_cRLNumber = `${id_ce}.20`;
var CRLNumber = class CRLNumber2 {
  value;
  constructor(value = 0) {
    this.value = value;
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], CRLNumber.prototype, "value", void 0);
CRLNumber = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], CRLNumber);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/crl_delta_indicator.js
var id_ce_deltaCRLIndicator = `${id_ce}.27`;
var BaseCRLNumber = class BaseCRLNumber2 extends CRLNumber {
};
BaseCRLNumber = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], BaseCRLNumber);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/crl_distribution_points.js
var CRLDistributionPoints_1;
var id_ce_cRLDistributionPoints = `${id_ce}.31`;
var ReasonFlags;
(function(ReasonFlags2) {
  ReasonFlags2[ReasonFlags2["unused"] = 1] = "unused";
  ReasonFlags2[ReasonFlags2["keyCompromise"] = 2] = "keyCompromise";
  ReasonFlags2[ReasonFlags2["cACompromise"] = 4] = "cACompromise";
  ReasonFlags2[ReasonFlags2["affiliationChanged"] = 8] = "affiliationChanged";
  ReasonFlags2[ReasonFlags2["superseded"] = 16] = "superseded";
  ReasonFlags2[ReasonFlags2["cessationOfOperation"] = 32] = "cessationOfOperation";
  ReasonFlags2[ReasonFlags2["certificateHold"] = 64] = "certificateHold";
  ReasonFlags2[ReasonFlags2["privilegeWithdrawn"] = 128] = "privilegeWithdrawn";
  ReasonFlags2[ReasonFlags2["aACompromise"] = 256] = "aACompromise";
})(ReasonFlags || (ReasonFlags = {}));
var Reason = class extends BitString2 {
  toJSON() {
    const res = [];
    const flags = this.toNumber();
    if (flags & ReasonFlags.aACompromise) {
      res.push("aACompromise");
    }
    if (flags & ReasonFlags.affiliationChanged) {
      res.push("affiliationChanged");
    }
    if (flags & ReasonFlags.cACompromise) {
      res.push("cACompromise");
    }
    if (flags & ReasonFlags.certificateHold) {
      res.push("certificateHold");
    }
    if (flags & ReasonFlags.cessationOfOperation) {
      res.push("cessationOfOperation");
    }
    if (flags & ReasonFlags.keyCompromise) {
      res.push("keyCompromise");
    }
    if (flags & ReasonFlags.privilegeWithdrawn) {
      res.push("privilegeWithdrawn");
    }
    if (flags & ReasonFlags.superseded) {
      res.push("superseded");
    }
    if (flags & ReasonFlags.unused) {
      res.push("unused");
    }
    return res;
  }
  toString() {
    return `[${this.toJSON().join(", ")}]`;
  }
};
var DistributionPointName = class DistributionPointName2 {
  fullName;
  nameRelativeToCRLIssuer;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: GeneralName,
    context: 0,
    repeated: "sequence",
    implicit: true
  })
], DistributionPointName.prototype, "fullName", void 0);
__decorate([
  AsnProp({
    type: RelativeDistinguishedName,
    context: 1,
    implicit: true
  })
], DistributionPointName.prototype, "nameRelativeToCRLIssuer", void 0);
DistributionPointName = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], DistributionPointName);
var DistributionPoint = class {
  distributionPoint;
  reasons;
  cRLIssuer;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: DistributionPointName,
    context: 0,
    optional: true
  })
], DistributionPoint.prototype, "distributionPoint", void 0);
__decorate([
  AsnProp({
    type: Reason,
    context: 1,
    optional: true,
    implicit: true
  })
], DistributionPoint.prototype, "reasons", void 0);
__decorate([
  AsnProp({
    type: GeneralName,
    context: 2,
    optional: true,
    repeated: "sequence",
    implicit: true
  })
], DistributionPoint.prototype, "cRLIssuer", void 0);
var CRLDistributionPoints = CRLDistributionPoints_1 = class CRLDistributionPoints2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, CRLDistributionPoints_1.prototype);
  }
};
CRLDistributionPoints = CRLDistributionPoints_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: DistributionPoint
  })
], CRLDistributionPoints);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/crl_freshest.js
var FreshestCRL_1;
var id_ce_freshestCRL = `${id_ce}.46`;
var FreshestCRL = FreshestCRL_1 = class FreshestCRL2 extends CRLDistributionPoints {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, FreshestCRL_1.prototype);
  }
};
FreshestCRL = FreshestCRL_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: DistributionPoint
  })
], FreshestCRL);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/crl_issuing_distribution_point.js
var id_ce_issuingDistributionPoint = `${id_ce}.28`;
var IssuingDistributionPoint = class _IssuingDistributionPoint {
  static ONLY = false;
  distributionPoint;
  onlyContainsUserCerts = _IssuingDistributionPoint.ONLY;
  onlyContainsCACerts = _IssuingDistributionPoint.ONLY;
  onlySomeReasons;
  indirectCRL = _IssuingDistributionPoint.ONLY;
  onlyContainsAttributeCerts = _IssuingDistributionPoint.ONLY;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: DistributionPointName,
    context: 0,
    optional: true
  })
], IssuingDistributionPoint.prototype, "distributionPoint", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Boolean,
    context: 1,
    defaultValue: IssuingDistributionPoint.ONLY,
    implicit: true
  })
], IssuingDistributionPoint.prototype, "onlyContainsUserCerts", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Boolean,
    context: 2,
    defaultValue: IssuingDistributionPoint.ONLY,
    implicit: true
  })
], IssuingDistributionPoint.prototype, "onlyContainsCACerts", void 0);
__decorate([
  AsnProp({
    type: Reason,
    context: 3,
    optional: true,
    implicit: true
  })
], IssuingDistributionPoint.prototype, "onlySomeReasons", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Boolean,
    context: 4,
    defaultValue: IssuingDistributionPoint.ONLY,
    implicit: true
  })
], IssuingDistributionPoint.prototype, "indirectCRL", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Boolean,
    context: 5,
    defaultValue: IssuingDistributionPoint.ONLY,
    implicit: true
  })
], IssuingDistributionPoint.prototype, "onlyContainsAttributeCerts", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/crl_reason.js
var id_ce_cRLReasons = `${id_ce}.21`;
var CRLReasons;
(function(CRLReasons2) {
  CRLReasons2[CRLReasons2["unspecified"] = 0] = "unspecified";
  CRLReasons2[CRLReasons2["keyCompromise"] = 1] = "keyCompromise";
  CRLReasons2[CRLReasons2["cACompromise"] = 2] = "cACompromise";
  CRLReasons2[CRLReasons2["affiliationChanged"] = 3] = "affiliationChanged";
  CRLReasons2[CRLReasons2["superseded"] = 4] = "superseded";
  CRLReasons2[CRLReasons2["cessationOfOperation"] = 5] = "cessationOfOperation";
  CRLReasons2[CRLReasons2["certificateHold"] = 6] = "certificateHold";
  CRLReasons2[CRLReasons2["removeFromCRL"] = 8] = "removeFromCRL";
  CRLReasons2[CRLReasons2["privilegeWithdrawn"] = 9] = "privilegeWithdrawn";
  CRLReasons2[CRLReasons2["aACompromise"] = 10] = "aACompromise";
})(CRLReasons || (CRLReasons = {}));
var CRLReason = class CRLReason2 {
  reason = CRLReasons.unspecified;
  constructor(reason = CRLReasons.unspecified) {
    this.reason = reason;
  }
  toJSON() {
    return CRLReasons[this.reason];
  }
  toString() {
    return this.toJSON();
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Enumerated })
], CRLReason.prototype, "reason", void 0);
CRLReason = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], CRLReason);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/extended_key_usage.js
var ExtendedKeyUsage_1;
var id_ce_extKeyUsage = `${id_ce}.37`;
var ExtendedKeyUsage = ExtendedKeyUsage_1 = class ExtendedKeyUsage2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, ExtendedKeyUsage_1.prototype);
  }
};
ExtendedKeyUsage = ExtendedKeyUsage_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: AsnPropTypes.ObjectIdentifier
  })
], ExtendedKeyUsage);
var anyExtendedKeyUsage = `${id_ce_extKeyUsage}.0`;
var id_kp_serverAuth = `${id_kp}.1`;
var id_kp_clientAuth = `${id_kp}.2`;
var id_kp_codeSigning = `${id_kp}.3`;
var id_kp_emailProtection = `${id_kp}.4`;
var id_kp_timeStamping = `${id_kp}.8`;
var id_kp_OCSPSigning = `${id_kp}.9`;

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/inhibit_any_policy.js
var id_ce_inhibitAnyPolicy = `${id_ce}.54`;
var InhibitAnyPolicy = class InhibitAnyPolicy2 {
  value;
  constructor(value = new ArrayBuffer(0)) {
    this.value = value;
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], InhibitAnyPolicy.prototype, "value", void 0);
InhibitAnyPolicy = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], InhibitAnyPolicy);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/invalidity_date.js
var id_ce_invalidityDate = `${id_ce}.24`;
var InvalidityDate = class InvalidityDate2 {
  value = /* @__PURE__ */ new Date();
  constructor(value) {
    if (value) {
      this.value = value;
    }
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.GeneralizedTime })
], InvalidityDate.prototype, "value", void 0);
InvalidityDate = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], InvalidityDate);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/issuer_alternative_name.js
var IssueAlternativeName_1;
var id_ce_issuerAltName = `${id_ce}.18`;
var IssueAlternativeName = IssueAlternativeName_1 = class IssueAlternativeName2 extends GeneralNames {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, IssueAlternativeName_1.prototype);
  }
};
IssueAlternativeName = IssueAlternativeName_1 = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], IssueAlternativeName);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/key_usage.js
var id_ce_keyUsage = `${id_ce}.15`;
var KeyUsageFlags;
(function(KeyUsageFlags3) {
  KeyUsageFlags3[KeyUsageFlags3["digitalSignature"] = 1] = "digitalSignature";
  KeyUsageFlags3[KeyUsageFlags3["nonRepudiation"] = 2] = "nonRepudiation";
  KeyUsageFlags3[KeyUsageFlags3["keyEncipherment"] = 4] = "keyEncipherment";
  KeyUsageFlags3[KeyUsageFlags3["dataEncipherment"] = 8] = "dataEncipherment";
  KeyUsageFlags3[KeyUsageFlags3["keyAgreement"] = 16] = "keyAgreement";
  KeyUsageFlags3[KeyUsageFlags3["keyCertSign"] = 32] = "keyCertSign";
  KeyUsageFlags3[KeyUsageFlags3["cRLSign"] = 64] = "cRLSign";
  KeyUsageFlags3[KeyUsageFlags3["encipherOnly"] = 128] = "encipherOnly";
  KeyUsageFlags3[KeyUsageFlags3["decipherOnly"] = 256] = "decipherOnly";
})(KeyUsageFlags || (KeyUsageFlags = {}));
var KeyUsage = class extends BitString2 {
  toJSON() {
    const flag = this.toNumber();
    const res = [];
    if (flag & KeyUsageFlags.cRLSign) {
      res.push("crlSign");
    }
    if (flag & KeyUsageFlags.dataEncipherment) {
      res.push("dataEncipherment");
    }
    if (flag & KeyUsageFlags.decipherOnly) {
      res.push("decipherOnly");
    }
    if (flag & KeyUsageFlags.digitalSignature) {
      res.push("digitalSignature");
    }
    if (flag & KeyUsageFlags.encipherOnly) {
      res.push("encipherOnly");
    }
    if (flag & KeyUsageFlags.keyAgreement) {
      res.push("keyAgreement");
    }
    if (flag & KeyUsageFlags.keyCertSign) {
      res.push("keyCertSign");
    }
    if (flag & KeyUsageFlags.keyEncipherment) {
      res.push("keyEncipherment");
    }
    if (flag & KeyUsageFlags.nonRepudiation) {
      res.push("nonRepudiation");
    }
    return res;
  }
  toString() {
    return `[${this.toJSON().join(", ")}]`;
  }
};

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/name_constraints.js
var GeneralSubtrees_1;
var id_ce_nameConstraints = `${id_ce}.30`;
var GeneralSubtree = class {
  base = new GeneralName();
  minimum = 0;
  maximum;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: GeneralName })
], GeneralSubtree.prototype, "base", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    context: 0,
    defaultValue: 0,
    implicit: true
  })
], GeneralSubtree.prototype, "minimum", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    context: 1,
    optional: true,
    implicit: true
  })
], GeneralSubtree.prototype, "maximum", void 0);
var GeneralSubtrees = GeneralSubtrees_1 = class GeneralSubtrees2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, GeneralSubtrees_1.prototype);
  }
};
GeneralSubtrees = GeneralSubtrees_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: GeneralSubtree
  })
], GeneralSubtrees);
var NameConstraints = class {
  permittedSubtrees;
  excludedSubtrees;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: GeneralSubtrees,
    context: 0,
    optional: true,
    implicit: true
  })
], NameConstraints.prototype, "permittedSubtrees", void 0);
__decorate([
  AsnProp({
    type: GeneralSubtrees,
    context: 1,
    optional: true,
    implicit: true
  })
], NameConstraints.prototype, "excludedSubtrees", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/policy_constraints.js
var id_ce_policyConstraints = `${id_ce}.36`;
var PolicyConstraints = class {
  requireExplicitPolicy;
  inhibitPolicyMapping;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    context: 0,
    implicit: true,
    optional: true,
    converter: AsnIntegerArrayBufferConverter
  })
], PolicyConstraints.prototype, "requireExplicitPolicy", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    context: 1,
    implicit: true,
    optional: true,
    converter: AsnIntegerArrayBufferConverter
  })
], PolicyConstraints.prototype, "inhibitPolicyMapping", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/policy_mappings.js
var PolicyMappings_1;
var id_ce_policyMappings = `${id_ce}.33`;
var PolicyMapping = class {
  issuerDomainPolicy = "";
  subjectDomainPolicy = "";
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], PolicyMapping.prototype, "issuerDomainPolicy", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], PolicyMapping.prototype, "subjectDomainPolicy", void 0);
var PolicyMappings = PolicyMappings_1 = class PolicyMappings2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, PolicyMappings_1.prototype);
  }
};
PolicyMappings = PolicyMappings_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: PolicyMapping
  })
], PolicyMappings);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/subject_alternative_name.js
var SubjectAlternativeName_1;
var id_ce_subjectAltName = `${id_ce}.17`;
var SubjectAlternativeName = SubjectAlternativeName_1 = class SubjectAlternativeName2 extends GeneralNames {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, SubjectAlternativeName_1.prototype);
  }
};
SubjectAlternativeName = SubjectAlternativeName_1 = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], SubjectAlternativeName);

// node_modules/@peculiar/asn1-x509/build/es2015/attribute.js
var Attribute = class {
  type = "";
  values = [];
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], Attribute.prototype, "type", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    repeated: "set"
  })
], Attribute.prototype, "values", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/subject_directory_attributes.js
var SubjectDirectoryAttributes_1;
var id_ce_subjectDirectoryAttributes = `${id_ce}.9`;
var SubjectDirectoryAttributes = SubjectDirectoryAttributes_1 = class SubjectDirectoryAttributes2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, SubjectDirectoryAttributes_1.prototype);
  }
};
SubjectDirectoryAttributes = SubjectDirectoryAttributes_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: Attribute
  })
], SubjectDirectoryAttributes);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/subject_key_identifier.js
var id_ce_subjectKeyIdentifier = `${id_ce}.14`;
var SubjectKeyIdentifier = class extends KeyIdentifier {
};

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/private_key_usage_period.js
var id_ce_privateKeyUsagePeriod = `${id_ce}.16`;
var PrivateKeyUsagePeriod = class {
  notBefore;
  notAfter;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.GeneralizedTime,
    context: 0,
    implicit: true,
    optional: true
  })
], PrivateKeyUsagePeriod.prototype, "notBefore", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.GeneralizedTime,
    context: 1,
    implicit: true,
    optional: true
  })
], PrivateKeyUsagePeriod.prototype, "notAfter", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/entrust_version_info.js
var EntrustInfoFlags;
(function(EntrustInfoFlags2) {
  EntrustInfoFlags2[EntrustInfoFlags2["keyUpdateAllowed"] = 1] = "keyUpdateAllowed";
  EntrustInfoFlags2[EntrustInfoFlags2["newExtensions"] = 2] = "newExtensions";
  EntrustInfoFlags2[EntrustInfoFlags2["pKIXCertificate"] = 4] = "pKIXCertificate";
})(EntrustInfoFlags || (EntrustInfoFlags = {}));
var EntrustInfo = class extends BitString2 {
  toJSON() {
    const res = [];
    const flags = this.toNumber();
    if (flags & EntrustInfoFlags.pKIXCertificate) {
      res.push("pKIXCertificate");
    }
    if (flags & EntrustInfoFlags.newExtensions) {
      res.push("newExtensions");
    }
    if (flags & EntrustInfoFlags.keyUpdateAllowed) {
      res.push("keyUpdateAllowed");
    }
    return res;
  }
  toString() {
    return `[${this.toJSON().join(", ")}]`;
  }
};
var EntrustVersionInfo = class {
  entrustVers = "";
  entrustInfoFlags = new EntrustInfo();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.GeneralString })
], EntrustVersionInfo.prototype, "entrustVers", void 0);
__decorate([
  AsnProp({ type: EntrustInfo })
], EntrustVersionInfo.prototype, "entrustInfoFlags", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/extensions/subject_info_access.js
var SubjectInfoAccessSyntax_1;
var id_pe_subjectInfoAccess = `${id_pe}.11`;
var SubjectInfoAccessSyntax = SubjectInfoAccessSyntax_1 = class SubjectInfoAccessSyntax2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, SubjectInfoAccessSyntax_1.prototype);
  }
};
SubjectInfoAccessSyntax = SubjectInfoAccessSyntax_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: AccessDescription
  })
], SubjectInfoAccessSyntax);

// node_modules/@peculiar/asn1-x509/build/es2015/algorithm_identifier.js
var AlgorithmIdentifier = class _AlgorithmIdentifier {
  algorithm = "";
  parameters;
  constructor(params = {}) {
    Object.assign(this, params);
  }
  isEqual(data) {
    return data instanceof _AlgorithmIdentifier && data.algorithm == this.algorithm && (data.parameters && this.parameters && equal(data.parameters, this.parameters) || data.parameters === this.parameters);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], AlgorithmIdentifier.prototype, "algorithm", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    optional: true
  })
], AlgorithmIdentifier.prototype, "parameters", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/subject_public_key_info.js
var SubjectPublicKeyInfo = class {
  algorithm = new AlgorithmIdentifier();
  subjectPublicKey = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], SubjectPublicKeyInfo.prototype, "algorithm", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.BitString })
], SubjectPublicKeyInfo.prototype, "subjectPublicKey", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/time.js
var Time = class Time2 {
  utcTime;
  generalTime;
  constructor(time) {
    if (time) {
      if (typeof time === "string" || typeof time === "number" || time instanceof Date) {
        const date = new Date(time);
        date.setMilliseconds(0);
        if (date.getUTCFullYear() > 2049) {
          this.generalTime = date;
        } else {
          this.utcTime = date;
        }
      } else {
        Object.assign(this, time);
      }
    }
  }
  getTime() {
    const time = this.utcTime || this.generalTime;
    if (!time) {
      throw new Error("Cannot get time from CHOICE object");
    }
    return time;
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.UTCTime })
], Time.prototype, "utcTime", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.GeneralizedTime })
], Time.prototype, "generalTime", void 0);
Time = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], Time);

// node_modules/@peculiar/asn1-x509/build/es2015/validity.js
var Validity = class {
  notBefore = new Time(/* @__PURE__ */ new Date());
  notAfter = new Time(/* @__PURE__ */ new Date());
  constructor(params) {
    if (params) {
      this.notBefore = new Time(params.notBefore);
      this.notAfter = new Time(params.notAfter);
    }
  }
};
__decorate([
  AsnProp({ type: Time })
], Validity.prototype, "notBefore", void 0);
__decorate([
  AsnProp({ type: Time })
], Validity.prototype, "notAfter", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/extension.js
var Extensions_1;
var Extension = class _Extension {
  static CRITICAL = false;
  extnID = "";
  critical = _Extension.CRITICAL;
  extnValue = new OctetString2();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], Extension.prototype, "extnID", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Boolean,
    defaultValue: Extension.CRITICAL
  })
], Extension.prototype, "critical", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], Extension.prototype, "extnValue", void 0);
var Extensions = Extensions_1 = class Extensions2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, Extensions_1.prototype);
  }
};
Extensions = Extensions_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: Extension
  })
], Extensions);

// node_modules/@peculiar/asn1-x509/build/es2015/types.js
var Version;
(function(Version5) {
  Version5[Version5["v1"] = 0] = "v1";
  Version5[Version5["v2"] = 1] = "v2";
  Version5[Version5["v3"] = 2] = "v3";
})(Version || (Version = {}));

// node_modules/@peculiar/asn1-x509/build/es2015/tbs_certificate.js
var TBSCertificate = class {
  version = Version.v1;
  serialNumber = new ArrayBuffer(0);
  signature = new AlgorithmIdentifier();
  issuer = new Name();
  validity = new Validity();
  subject = new Name();
  subjectPublicKeyInfo = new SubjectPublicKeyInfo();
  issuerUniqueID;
  subjectUniqueID;
  extensions;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    context: 0,
    defaultValue: Version.v1
  })
], TBSCertificate.prototype, "version", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], TBSCertificate.prototype, "serialNumber", void 0);
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], TBSCertificate.prototype, "signature", void 0);
__decorate([
  AsnProp({ type: Name })
], TBSCertificate.prototype, "issuer", void 0);
__decorate([
  AsnProp({ type: Validity })
], TBSCertificate.prototype, "validity", void 0);
__decorate([
  AsnProp({ type: Name })
], TBSCertificate.prototype, "subject", void 0);
__decorate([
  AsnProp({ type: SubjectPublicKeyInfo })
], TBSCertificate.prototype, "subjectPublicKeyInfo", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.BitString,
    context: 1,
    implicit: true,
    optional: true
  })
], TBSCertificate.prototype, "issuerUniqueID", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.BitString,
    context: 2,
    implicit: true,
    optional: true
  })
], TBSCertificate.prototype, "subjectUniqueID", void 0);
__decorate([
  AsnProp({
    type: Extensions,
    context: 3,
    optional: true
  })
], TBSCertificate.prototype, "extensions", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/certificate.js
var Certificate = class {
  tbsCertificate = new TBSCertificate();
  tbsCertificateRaw;
  signatureAlgorithm = new AlgorithmIdentifier();
  signatureValue = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: TBSCertificate,
    raw: true
  })
], Certificate.prototype, "tbsCertificate", void 0);
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], Certificate.prototype, "signatureAlgorithm", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.BitString })
], Certificate.prototype, "signatureValue", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/tbs_cert_list.js
var RevokedCertificate = class {
  userCertificate = new ArrayBuffer(0);
  revocationDate = new Time();
  crlEntryExtensions;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], RevokedCertificate.prototype, "userCertificate", void 0);
__decorate([
  AsnProp({ type: Time })
], RevokedCertificate.prototype, "revocationDate", void 0);
__decorate([
  AsnProp({
    type: Extension,
    optional: true,
    repeated: "sequence"
  })
], RevokedCertificate.prototype, "crlEntryExtensions", void 0);
var TBSCertList = class {
  version;
  signature = new AlgorithmIdentifier();
  issuer = new Name();
  thisUpdate = new Time();
  nextUpdate;
  revokedCertificates;
  crlExtensions;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    optional: true
  })
], TBSCertList.prototype, "version", void 0);
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], TBSCertList.prototype, "signature", void 0);
__decorate([
  AsnProp({ type: Name })
], TBSCertList.prototype, "issuer", void 0);
__decorate([
  AsnProp({ type: Time })
], TBSCertList.prototype, "thisUpdate", void 0);
__decorate([
  AsnProp({
    type: Time,
    optional: true
  })
], TBSCertList.prototype, "nextUpdate", void 0);
__decorate([
  AsnProp({
    type: RevokedCertificate,
    repeated: "sequence",
    optional: true
  })
], TBSCertList.prototype, "revokedCertificates", void 0);
__decorate([
  AsnProp({
    type: Extension,
    optional: true,
    context: 0,
    repeated: "sequence"
  })
], TBSCertList.prototype, "crlExtensions", void 0);

// node_modules/@peculiar/asn1-x509/build/es2015/certificate_list.js
var CertificateList = class {
  tbsCertList = new TBSCertList();
  tbsCertListRaw;
  signatureAlgorithm = new AlgorithmIdentifier();
  signature = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: TBSCertList,
    raw: true
  })
], CertificateList.prototype, "tbsCertList", void 0);
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], CertificateList.prototype, "signatureAlgorithm", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.BitString })
], CertificateList.prototype, "signature", void 0);

// node_modules/@simplewebauthn/server/esm/helpers/getCertificateInfo.js
var issuerSubjectIDKey = {
  "2.5.4.6": "C",
  "2.5.4.10": "O",
  "2.5.4.11": "OU",
  "2.5.4.3": "CN"
};
function getCertificateInfo(leafCertBuffer) {
  const x509 = AsnParser.parse(leafCertBuffer, Certificate);
  const parsedCert = x509.tbsCertificate;
  const issuer = { combined: "" };
  parsedCert.issuer.forEach(([iss]) => {
    const key2 = issuerSubjectIDKey[iss.type];
    if (key2) {
      issuer[key2] = iss.value.toString();
    }
  });
  issuer.combined = issuerSubjectToString(issuer);
  const subject = { combined: "" };
  parsedCert.subject.forEach(([iss]) => {
    const key2 = issuerSubjectIDKey[iss.type];
    if (key2) {
      subject[key2] = iss.value.toString();
    }
  });
  subject.combined = issuerSubjectToString(subject);
  let basicConstraintsCA = false;
  if (parsedCert.extensions) {
    for (const ext of parsedCert.extensions) {
      if (ext.extnID === id_ce_basicConstraints) {
        const basicConstraints = AsnParser.parse(ext.extnValue, BasicConstraints);
        basicConstraintsCA = basicConstraints.cA;
      }
    }
  }
  return {
    issuer,
    subject,
    version: parsedCert.version,
    basicConstraintsCA,
    notBefore: parsedCert.validity.notBefore.getTime(),
    notAfter: parsedCert.validity.notAfter.getTime(),
    parsedCertificate: x509
  };
}
function issuerSubjectToString(input) {
  const parts = [];
  if (input.C) {
    parts.push(input.C);
  }
  if (input.O) {
    parts.push(input.O);
  }
  if (input.OU) {
    parts.push(input.OU);
  }
  if (input.CN) {
    parts.push(input.CN);
  }
  return parts.join(" : ");
}

// node_modules/@simplewebauthn/server/esm/helpers/isCertRevoked.js
var import_reflect_metadata = __toESM(require_Reflect(), 1);

// node_modules/@peculiar/x509/build/x509.es.js
var import_pvtsutils = __toESM(require_build());

// node_modules/@peculiar/asn1-cms/build/es2015/issuer_and_serial_number.js
var IssuerAndSerialNumber = class {
  issuer = new Name();
  serialNumber = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: Name })
], IssuerAndSerialNumber.prototype, "issuer", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], IssuerAndSerialNumber.prototype, "serialNumber", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/signer_identifier.js
var SignerIdentifier = class SignerIdentifier2 {
  subjectKeyIdentifier;
  issuerAndSerialNumber;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: SubjectKeyIdentifier,
    context: 0,
    implicit: true
  })
], SignerIdentifier.prototype, "subjectKeyIdentifier", void 0);
__decorate([
  AsnProp({ type: IssuerAndSerialNumber })
], SignerIdentifier.prototype, "issuerAndSerialNumber", void 0);
SignerIdentifier = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], SignerIdentifier);

// node_modules/@peculiar/asn1-cms/build/es2015/types.js
var CMSVersion;
(function(CMSVersion2) {
  CMSVersion2[CMSVersion2["v0"] = 0] = "v0";
  CMSVersion2[CMSVersion2["v1"] = 1] = "v1";
  CMSVersion2[CMSVersion2["v2"] = 2] = "v2";
  CMSVersion2[CMSVersion2["v3"] = 3] = "v3";
  CMSVersion2[CMSVersion2["v4"] = 4] = "v4";
  CMSVersion2[CMSVersion2["v5"] = 5] = "v5";
})(CMSVersion || (CMSVersion = {}));
var DigestAlgorithmIdentifier = class DigestAlgorithmIdentifier2 extends AlgorithmIdentifier {
};
DigestAlgorithmIdentifier = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], DigestAlgorithmIdentifier);
var SignatureAlgorithmIdentifier = class SignatureAlgorithmIdentifier2 extends AlgorithmIdentifier {
};
SignatureAlgorithmIdentifier = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], SignatureAlgorithmIdentifier);
var KeyEncryptionAlgorithmIdentifier = class KeyEncryptionAlgorithmIdentifier2 extends AlgorithmIdentifier {
};
KeyEncryptionAlgorithmIdentifier = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], KeyEncryptionAlgorithmIdentifier);
var ContentEncryptionAlgorithmIdentifier = class ContentEncryptionAlgorithmIdentifier2 extends AlgorithmIdentifier {
};
ContentEncryptionAlgorithmIdentifier = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], ContentEncryptionAlgorithmIdentifier);
var MessageAuthenticationCodeAlgorithm = class MessageAuthenticationCodeAlgorithm2 extends AlgorithmIdentifier {
};
MessageAuthenticationCodeAlgorithm = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], MessageAuthenticationCodeAlgorithm);
var KeyDerivationAlgorithmIdentifier = class KeyDerivationAlgorithmIdentifier2 extends AlgorithmIdentifier {
};
KeyDerivationAlgorithmIdentifier = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], KeyDerivationAlgorithmIdentifier);

// node_modules/@peculiar/asn1-cms/build/es2015/attribute.js
var Attribute2 = class {
  attrType = "";
  attrValues = [];
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], Attribute2.prototype, "attrType", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    repeated: "set"
  })
], Attribute2.prototype, "attrValues", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/signer_info.js
var SignerInfos_1;
var SignerInfo = class {
  version = CMSVersion.v0;
  sid = new SignerIdentifier();
  digestAlgorithm = new DigestAlgorithmIdentifier();
  signedAttrs;
  signedAttrsRaw;
  signatureAlgorithm = new SignatureAlgorithmIdentifier();
  signature = new OctetString2();
  unsignedAttrs;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], SignerInfo.prototype, "version", void 0);
__decorate([
  AsnProp({ type: SignerIdentifier })
], SignerInfo.prototype, "sid", void 0);
__decorate([
  AsnProp({ type: DigestAlgorithmIdentifier })
], SignerInfo.prototype, "digestAlgorithm", void 0);
__decorate([
  AsnProp({
    type: Attribute2,
    repeated: "set",
    context: 0,
    implicit: true,
    optional: true,
    raw: true
  })
], SignerInfo.prototype, "signedAttrs", void 0);
__decorate([
  AsnProp({ type: SignatureAlgorithmIdentifier })
], SignerInfo.prototype, "signatureAlgorithm", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], SignerInfo.prototype, "signature", void 0);
__decorate([
  AsnProp({
    type: Attribute2,
    repeated: "set",
    context: 1,
    implicit: true,
    optional: true
  })
], SignerInfo.prototype, "unsignedAttrs", void 0);
var SignerInfos = SignerInfos_1 = class SignerInfos2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, SignerInfos_1.prototype);
  }
};
SignerInfos = SignerInfos_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Set,
    itemType: SignerInfo
  })
], SignerInfos);

// node_modules/@peculiar/asn1-cms/build/es2015/attributes/counter_signature.js
var CounterSignature = class CounterSignature2 extends SignerInfo {
};
CounterSignature = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], CounterSignature);

// node_modules/@peculiar/asn1-cms/build/es2015/attributes/signing_time.js
var SigningTime = class SigningTime2 extends Time {
};
SigningTime = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], SigningTime);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/aa_clear_attrs.js
var ACClearAttrs = class {
  acIssuer = new GeneralName();
  acSerial = 0;
  attrs = [];
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: GeneralName })
], ACClearAttrs.prototype, "acIssuer", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], ACClearAttrs.prototype, "acSerial", void 0);
__decorate([
  AsnProp({
    type: Attribute,
    repeated: "sequence"
  })
], ACClearAttrs.prototype, "attrs", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/attr_spec.js
var AttrSpec_1;
var AttrSpec = AttrSpec_1 = class AttrSpec2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, AttrSpec_1.prototype);
  }
};
AttrSpec = AttrSpec_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: AsnPropTypes.ObjectIdentifier
  })
], AttrSpec);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/aa_controls.js
var AAControls = class {
  pathLenConstraint;
  permittedAttrs;
  excludedAttrs;
  permitUnSpecified = true;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    optional: true
  })
], AAControls.prototype, "pathLenConstraint", void 0);
__decorate([
  AsnProp({
    type: AttrSpec,
    implicit: true,
    context: 0,
    optional: true
  })
], AAControls.prototype, "permittedAttrs", void 0);
__decorate([
  AsnProp({
    type: AttrSpec,
    implicit: true,
    context: 1,
    optional: true
  })
], AAControls.prototype, "excludedAttrs", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Boolean,
    defaultValue: true
  })
], AAControls.prototype, "permitUnSpecified", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/issuer_serial.js
var IssuerSerial = class {
  issuer = new GeneralNames();
  serial = new ArrayBuffer(0);
  issuerUID = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: GeneralNames })
], IssuerSerial.prototype, "issuer", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], IssuerSerial.prototype, "serial", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.BitString,
    optional: true
  })
], IssuerSerial.prototype, "issuerUID", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/object_digest_info.js
var DigestedObjectType;
(function(DigestedObjectType2) {
  DigestedObjectType2[DigestedObjectType2["publicKey"] = 0] = "publicKey";
  DigestedObjectType2[DigestedObjectType2["publicKeyCert"] = 1] = "publicKeyCert";
  DigestedObjectType2[DigestedObjectType2["otherObjectTypes"] = 2] = "otherObjectTypes";
})(DigestedObjectType || (DigestedObjectType = {}));
var ObjectDigestInfo = class {
  digestedObjectType = DigestedObjectType.publicKey;
  otherObjectTypeID;
  digestAlgorithm = new AlgorithmIdentifier();
  objectDigest = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Enumerated })
], ObjectDigestInfo.prototype, "digestedObjectType", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.ObjectIdentifier,
    optional: true
  })
], ObjectDigestInfo.prototype, "otherObjectTypeID", void 0);
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], ObjectDigestInfo.prototype, "digestAlgorithm", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.BitString })
], ObjectDigestInfo.prototype, "objectDigest", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/v2_form.js
var V2Form = class {
  issuerName;
  baseCertificateID;
  objectDigestInfo;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: GeneralNames,
    optional: true
  })
], V2Form.prototype, "issuerName", void 0);
__decorate([
  AsnProp({
    type: IssuerSerial,
    context: 0,
    implicit: true,
    optional: true
  })
], V2Form.prototype, "baseCertificateID", void 0);
__decorate([
  AsnProp({
    type: ObjectDigestInfo,
    context: 1,
    implicit: true,
    optional: true
  })
], V2Form.prototype, "objectDigestInfo", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/attr_cert_issuer.js
var AttCertIssuer = class AttCertIssuer2 {
  v1Form;
  v2Form;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: GeneralName,
    repeated: "sequence"
  })
], AttCertIssuer.prototype, "v1Form", void 0);
__decorate([
  AsnProp({
    type: V2Form,
    context: 0,
    implicit: true
  })
], AttCertIssuer.prototype, "v2Form", void 0);
AttCertIssuer = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], AttCertIssuer);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/attr_cert_validity_period.js
var AttCertValidityPeriod = class {
  notBeforeTime = /* @__PURE__ */ new Date();
  notAfterTime = /* @__PURE__ */ new Date();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.GeneralizedTime })
], AttCertValidityPeriod.prototype, "notBeforeTime", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.GeneralizedTime })
], AttCertValidityPeriod.prototype, "notAfterTime", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/holder.js
var Holder = class {
  baseCertificateID;
  entityName;
  objectDigestInfo;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: IssuerSerial,
    implicit: true,
    context: 0,
    optional: true
  })
], Holder.prototype, "baseCertificateID", void 0);
__decorate([
  AsnProp({
    type: GeneralNames,
    implicit: true,
    context: 1,
    optional: true
  })
], Holder.prototype, "entityName", void 0);
__decorate([
  AsnProp({
    type: ObjectDigestInfo,
    implicit: true,
    context: 2,
    optional: true
  })
], Holder.prototype, "objectDigestInfo", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/attribute_certificate_info.js
var AttCertVersion;
(function(AttCertVersion2) {
  AttCertVersion2[AttCertVersion2["v2"] = 1] = "v2";
})(AttCertVersion || (AttCertVersion = {}));
var AttributeCertificateInfo = class {
  version = AttCertVersion.v2;
  holder = new Holder();
  issuer = new AttCertIssuer();
  signature = new AlgorithmIdentifier();
  serialNumber = new ArrayBuffer(0);
  attrCertValidityPeriod = new AttCertValidityPeriod();
  attributes = [];
  issuerUniqueID;
  extensions;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], AttributeCertificateInfo.prototype, "version", void 0);
__decorate([
  AsnProp({ type: Holder })
], AttributeCertificateInfo.prototype, "holder", void 0);
__decorate([
  AsnProp({ type: AttCertIssuer })
], AttributeCertificateInfo.prototype, "issuer", void 0);
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], AttributeCertificateInfo.prototype, "signature", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], AttributeCertificateInfo.prototype, "serialNumber", void 0);
__decorate([
  AsnProp({ type: AttCertValidityPeriod })
], AttributeCertificateInfo.prototype, "attrCertValidityPeriod", void 0);
__decorate([
  AsnProp({
    type: Attribute,
    repeated: "sequence"
  })
], AttributeCertificateInfo.prototype, "attributes", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.BitString,
    optional: true
  })
], AttributeCertificateInfo.prototype, "issuerUniqueID", void 0);
__decorate([
  AsnProp({
    type: Extensions,
    optional: true
  })
], AttributeCertificateInfo.prototype, "extensions", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/attribute_certificate.js
var AttributeCertificate = class {
  acinfo = new AttributeCertificateInfo();
  signatureAlgorithm = new AlgorithmIdentifier();
  signatureValue = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AttributeCertificateInfo })
], AttributeCertificate.prototype, "acinfo", void 0);
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], AttributeCertificate.prototype, "signatureAlgorithm", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.BitString })
], AttributeCertificate.prototype, "signatureValue", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/class_list.js
var ClassListFlags;
(function(ClassListFlags2) {
  ClassListFlags2[ClassListFlags2["unmarked"] = 1] = "unmarked";
  ClassListFlags2[ClassListFlags2["unclassified"] = 2] = "unclassified";
  ClassListFlags2[ClassListFlags2["restricted"] = 4] = "restricted";
  ClassListFlags2[ClassListFlags2["confidential"] = 8] = "confidential";
  ClassListFlags2[ClassListFlags2["secret"] = 16] = "secret";
  ClassListFlags2[ClassListFlags2["topSecret"] = 32] = "topSecret";
})(ClassListFlags || (ClassListFlags = {}));
var ClassList = class extends BitString2 {
};

// node_modules/@peculiar/asn1-x509-attr/build/es2015/security_category.js
var SecurityCategory = class {
  type = "";
  value = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.ObjectIdentifier,
    implicit: true,
    context: 0
  })
], SecurityCategory.prototype, "type", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    implicit: true,
    context: 1
  })
], SecurityCategory.prototype, "value", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/clearance.js
var Clearance = class {
  policyId = "";
  classList = new ClassList(ClassListFlags.unclassified);
  securityCategories;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], Clearance.prototype, "policyId", void 0);
__decorate([
  AsnProp({
    type: ClassList,
    defaultValue: new ClassList(ClassListFlags.unclassified)
  })
], Clearance.prototype, "classList", void 0);
__decorate([
  AsnProp({
    type: SecurityCategory,
    repeated: "set"
  })
], Clearance.prototype, "securityCategories", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/ietf_attr_syntax.js
var IetfAttrSyntaxValueChoices = class {
  cotets;
  oid;
  string;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: OctetString2 })
], IetfAttrSyntaxValueChoices.prototype, "cotets", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], IetfAttrSyntaxValueChoices.prototype, "oid", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Utf8String })
], IetfAttrSyntaxValueChoices.prototype, "string", void 0);
var IetfAttrSyntax = class {
  policyAuthority;
  values = [];
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: GeneralNames,
    implicit: true,
    context: 0,
    optional: true
  })
], IetfAttrSyntax.prototype, "policyAuthority", void 0);
__decorate([
  AsnProp({
    type: IetfAttrSyntaxValueChoices,
    repeated: "sequence"
  })
], IetfAttrSyntax.prototype, "values", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/object_identifiers.js
var id_pe_ac_auditIdentity = `${id_pe}.4`;
var id_pe_aaControls = `${id_pe}.6`;
var id_pe_ac_proxying = `${id_pe}.10`;
var id_ce_targetInformation = `${id_ce}.55`;
var id_aca = `${id_pkix}.10`;
var id_aca_authenticationInfo = `${id_aca}.1`;
var id_aca_accessIdentity = `${id_aca}.2`;
var id_aca_chargingIdentity = `${id_aca}.3`;
var id_aca_group = `${id_aca}.4`;
var id_aca_encAttrs = `${id_aca}.6`;
var id_at = "2.5.4";
var id_at_role = `${id_at}.72`;

// node_modules/@peculiar/asn1-x509-attr/build/es2015/target.js
var Targets_1;
var TargetCert = class {
  targetCertificate = new IssuerSerial();
  targetName;
  certDigestInfo;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: IssuerSerial })
], TargetCert.prototype, "targetCertificate", void 0);
__decorate([
  AsnProp({
    type: GeneralName,
    optional: true
  })
], TargetCert.prototype, "targetName", void 0);
__decorate([
  AsnProp({
    type: ObjectDigestInfo,
    optional: true
  })
], TargetCert.prototype, "certDigestInfo", void 0);
var Target = class Target2 {
  targetName;
  targetGroup;
  targetCert;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: GeneralName,
    context: 0,
    implicit: true
  })
], Target.prototype, "targetName", void 0);
__decorate([
  AsnProp({
    type: GeneralName,
    context: 1,
    implicit: true
  })
], Target.prototype, "targetGroup", void 0);
__decorate([
  AsnProp({
    type: TargetCert,
    context: 2,
    implicit: true
  })
], Target.prototype, "targetCert", void 0);
Target = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], Target);
var Targets = Targets_1 = class Targets2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, Targets_1.prototype);
  }
};
Targets = Targets_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: Target
  })
], Targets);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/proxy_info.js
var ProxyInfo_1;
var ProxyInfo = ProxyInfo_1 = class ProxyInfo2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, ProxyInfo_1.prototype);
  }
};
ProxyInfo = ProxyInfo_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: Targets
  })
], ProxyInfo);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/role_syntax.js
var RoleSyntax = class {
  roleAuthority;
  roleName;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: GeneralNames,
    implicit: true,
    context: 0,
    optional: true
  })
], RoleSyntax.prototype, "roleAuthority", void 0);
__decorate([
  AsnProp({
    type: GeneralName,
    implicit: true,
    context: 1
  })
], RoleSyntax.prototype, "roleName", void 0);

// node_modules/@peculiar/asn1-x509-attr/build/es2015/svce_auth_info.js
var SvceAuthInfo = class {
  service = new GeneralName();
  ident = new GeneralName();
  authInfo;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: GeneralName })
], SvceAuthInfo.prototype, "service", void 0);
__decorate([
  AsnProp({ type: GeneralName })
], SvceAuthInfo.prototype, "ident", void 0);
__decorate([
  AsnProp({
    type: OctetString2,
    optional: true
  })
], SvceAuthInfo.prototype, "authInfo", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/certificate_choices.js
var CertificateSet_1;
var OtherCertificateFormat = class {
  otherCertFormat = "";
  otherCert = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], OtherCertificateFormat.prototype, "otherCertFormat", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Any })
], OtherCertificateFormat.prototype, "otherCert", void 0);
var CertificateChoices = class CertificateChoices2 {
  certificate;
  v2AttrCert;
  other;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: Certificate })
], CertificateChoices.prototype, "certificate", void 0);
__decorate([
  AsnProp({
    type: AttributeCertificate,
    context: 2,
    implicit: true
  })
], CertificateChoices.prototype, "v2AttrCert", void 0);
__decorate([
  AsnProp({
    type: OtherCertificateFormat,
    context: 3,
    implicit: true
  })
], CertificateChoices.prototype, "other", void 0);
CertificateChoices = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], CertificateChoices);
var CertificateSet = CertificateSet_1 = class CertificateSet2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, CertificateSet_1.prototype);
  }
};
CertificateSet = CertificateSet_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Set,
    itemType: CertificateChoices
  })
], CertificateSet);

// node_modules/@peculiar/asn1-cms/build/es2015/content_info.js
var ContentInfo = class {
  contentType = "";
  content = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], ContentInfo.prototype, "contentType", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    context: 0
  })
], ContentInfo.prototype, "content", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/encapsulated_content_info.js
var EncapsulatedContent = class EncapsulatedContent2 {
  single;
  any;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: OctetString2 })
], EncapsulatedContent.prototype, "single", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Any })
], EncapsulatedContent.prototype, "any", void 0);
EncapsulatedContent = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], EncapsulatedContent);
var EncapsulatedContentInfo = class {
  eContentType = "";
  eContent;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], EncapsulatedContentInfo.prototype, "eContentType", void 0);
__decorate([
  AsnProp({
    type: EncapsulatedContent,
    context: 0,
    optional: true
  })
], EncapsulatedContentInfo.prototype, "eContent", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/encrypted_content_info.js
var EncryptedContent = class EncryptedContent2 {
  value;
  constructedValue;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: OctetString2,
    context: 0,
    implicit: true,
    optional: true
  })
], EncryptedContent.prototype, "value", void 0);
__decorate([
  AsnProp({
    type: OctetString2,
    converter: AsnConstructedOctetStringConverter,
    context: 0,
    implicit: true,
    optional: true,
    repeated: "sequence"
  })
], EncryptedContent.prototype, "constructedValue", void 0);
EncryptedContent = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], EncryptedContent);
var EncryptedContentInfo = class {
  contentType = "";
  contentEncryptionAlgorithm = new ContentEncryptionAlgorithmIdentifier();
  encryptedContent;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], EncryptedContentInfo.prototype, "contentType", void 0);
__decorate([
  AsnProp({ type: ContentEncryptionAlgorithmIdentifier })
], EncryptedContentInfo.prototype, "contentEncryptionAlgorithm", void 0);
__decorate([
  AsnProp({
    type: EncryptedContent,
    optional: true
  })
], EncryptedContentInfo.prototype, "encryptedContent", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/other_key_attribute.js
var OtherKeyAttribute = class {
  keyAttrId = "";
  keyAttr;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], OtherKeyAttribute.prototype, "keyAttrId", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    optional: true
  })
], OtherKeyAttribute.prototype, "keyAttr", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/key_agree_recipient_info.js
var RecipientEncryptedKeys_1;
var RecipientKeyIdentifier = class {
  subjectKeyIdentifier = new SubjectKeyIdentifier();
  date;
  other;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: SubjectKeyIdentifier })
], RecipientKeyIdentifier.prototype, "subjectKeyIdentifier", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.GeneralizedTime,
    optional: true
  })
], RecipientKeyIdentifier.prototype, "date", void 0);
__decorate([
  AsnProp({
    type: OtherKeyAttribute,
    optional: true
  })
], RecipientKeyIdentifier.prototype, "other", void 0);
var KeyAgreeRecipientIdentifier = class KeyAgreeRecipientIdentifier2 {
  rKeyId;
  issuerAndSerialNumber;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: RecipientKeyIdentifier,
    context: 0,
    implicit: true,
    optional: true
  })
], KeyAgreeRecipientIdentifier.prototype, "rKeyId", void 0);
__decorate([
  AsnProp({
    type: IssuerAndSerialNumber,
    optional: true
  })
], KeyAgreeRecipientIdentifier.prototype, "issuerAndSerialNumber", void 0);
KeyAgreeRecipientIdentifier = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], KeyAgreeRecipientIdentifier);
var RecipientEncryptedKey = class {
  rid = new KeyAgreeRecipientIdentifier();
  encryptedKey = new OctetString2();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: KeyAgreeRecipientIdentifier })
], RecipientEncryptedKey.prototype, "rid", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], RecipientEncryptedKey.prototype, "encryptedKey", void 0);
var RecipientEncryptedKeys = RecipientEncryptedKeys_1 = class RecipientEncryptedKeys2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, RecipientEncryptedKeys_1.prototype);
  }
};
RecipientEncryptedKeys = RecipientEncryptedKeys_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: RecipientEncryptedKey
  })
], RecipientEncryptedKeys);
var OriginatorPublicKey = class {
  algorithm = new AlgorithmIdentifier();
  publicKey = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], OriginatorPublicKey.prototype, "algorithm", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.BitString })
], OriginatorPublicKey.prototype, "publicKey", void 0);
var OriginatorIdentifierOrKey = class OriginatorIdentifierOrKey2 {
  subjectKeyIdentifier;
  originatorKey;
  issuerAndSerialNumber;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: SubjectKeyIdentifier,
    context: 0,
    implicit: true,
    optional: true
  })
], OriginatorIdentifierOrKey.prototype, "subjectKeyIdentifier", void 0);
__decorate([
  AsnProp({
    type: OriginatorPublicKey,
    context: 1,
    implicit: true,
    optional: true
  })
], OriginatorIdentifierOrKey.prototype, "originatorKey", void 0);
__decorate([
  AsnProp({
    type: IssuerAndSerialNumber,
    optional: true
  })
], OriginatorIdentifierOrKey.prototype, "issuerAndSerialNumber", void 0);
OriginatorIdentifierOrKey = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], OriginatorIdentifierOrKey);
var KeyAgreeRecipientInfo = class {
  version = CMSVersion.v3;
  originator = new OriginatorIdentifierOrKey();
  ukm;
  keyEncryptionAlgorithm = new KeyEncryptionAlgorithmIdentifier();
  recipientEncryptedKeys = new RecipientEncryptedKeys();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], KeyAgreeRecipientInfo.prototype, "version", void 0);
__decorate([
  AsnProp({
    type: OriginatorIdentifierOrKey,
    context: 0
  })
], KeyAgreeRecipientInfo.prototype, "originator", void 0);
__decorate([
  AsnProp({
    type: OctetString2,
    context: 1,
    optional: true
  })
], KeyAgreeRecipientInfo.prototype, "ukm", void 0);
__decorate([
  AsnProp({ type: KeyEncryptionAlgorithmIdentifier })
], KeyAgreeRecipientInfo.prototype, "keyEncryptionAlgorithm", void 0);
__decorate([
  AsnProp({ type: RecipientEncryptedKeys })
], KeyAgreeRecipientInfo.prototype, "recipientEncryptedKeys", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/key_trans_recipient_info.js
var RecipientIdentifier = class RecipientIdentifier2 {
  subjectKeyIdentifier;
  issuerAndSerialNumber;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: SubjectKeyIdentifier,
    context: 0,
    implicit: true
  })
], RecipientIdentifier.prototype, "subjectKeyIdentifier", void 0);
__decorate([
  AsnProp({ type: IssuerAndSerialNumber })
], RecipientIdentifier.prototype, "issuerAndSerialNumber", void 0);
RecipientIdentifier = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], RecipientIdentifier);
var KeyTransRecipientInfo = class {
  version = CMSVersion.v0;
  rid = new RecipientIdentifier();
  keyEncryptionAlgorithm = new KeyEncryptionAlgorithmIdentifier();
  encryptedKey = new OctetString2();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], KeyTransRecipientInfo.prototype, "version", void 0);
__decorate([
  AsnProp({ type: RecipientIdentifier })
], KeyTransRecipientInfo.prototype, "rid", void 0);
__decorate([
  AsnProp({ type: KeyEncryptionAlgorithmIdentifier })
], KeyTransRecipientInfo.prototype, "keyEncryptionAlgorithm", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], KeyTransRecipientInfo.prototype, "encryptedKey", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/kek_recipient_info.js
var KEKIdentifier = class {
  keyIdentifier = new OctetString2();
  date;
  other;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: OctetString2 })
], KEKIdentifier.prototype, "keyIdentifier", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.GeneralizedTime,
    optional: true
  })
], KEKIdentifier.prototype, "date", void 0);
__decorate([
  AsnProp({
    type: OtherKeyAttribute,
    optional: true
  })
], KEKIdentifier.prototype, "other", void 0);
var KEKRecipientInfo = class {
  version = CMSVersion.v4;
  kekid = new KEKIdentifier();
  keyEncryptionAlgorithm = new KeyEncryptionAlgorithmIdentifier();
  encryptedKey = new OctetString2();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], KEKRecipientInfo.prototype, "version", void 0);
__decorate([
  AsnProp({ type: KEKIdentifier })
], KEKRecipientInfo.prototype, "kekid", void 0);
__decorate([
  AsnProp({ type: KeyEncryptionAlgorithmIdentifier })
], KEKRecipientInfo.prototype, "keyEncryptionAlgorithm", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], KEKRecipientInfo.prototype, "encryptedKey", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/password_recipient_info.js
var PasswordRecipientInfo = class {
  version = CMSVersion.v0;
  keyDerivationAlgorithm;
  keyEncryptionAlgorithm = new KeyEncryptionAlgorithmIdentifier();
  encryptedKey = new OctetString2();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], PasswordRecipientInfo.prototype, "version", void 0);
__decorate([
  AsnProp({
    type: KeyDerivationAlgorithmIdentifier,
    context: 0,
    optional: true
  })
], PasswordRecipientInfo.prototype, "keyDerivationAlgorithm", void 0);
__decorate([
  AsnProp({ type: KeyEncryptionAlgorithmIdentifier })
], PasswordRecipientInfo.prototype, "keyEncryptionAlgorithm", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], PasswordRecipientInfo.prototype, "encryptedKey", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/recipient_info.js
var OtherRecipientInfo = class {
  oriType = "";
  oriValue = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], OtherRecipientInfo.prototype, "oriType", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Any })
], OtherRecipientInfo.prototype, "oriValue", void 0);
var RecipientInfo = class RecipientInfo2 {
  ktri;
  kari;
  kekri;
  pwri;
  ori;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: KeyTransRecipientInfo,
    optional: true
  })
], RecipientInfo.prototype, "ktri", void 0);
__decorate([
  AsnProp({
    type: KeyAgreeRecipientInfo,
    context: 1,
    implicit: true,
    optional: true
  })
], RecipientInfo.prototype, "kari", void 0);
__decorate([
  AsnProp({
    type: KEKRecipientInfo,
    context: 2,
    implicit: true,
    optional: true
  })
], RecipientInfo.prototype, "kekri", void 0);
__decorate([
  AsnProp({
    type: PasswordRecipientInfo,
    context: 3,
    implicit: true,
    optional: true
  })
], RecipientInfo.prototype, "pwri", void 0);
__decorate([
  AsnProp({
    type: OtherRecipientInfo,
    context: 4,
    implicit: true,
    optional: true
  })
], RecipientInfo.prototype, "ori", void 0);
RecipientInfo = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], RecipientInfo);

// node_modules/@peculiar/asn1-cms/build/es2015/recipient_infos.js
var RecipientInfos_1;
var RecipientInfos = RecipientInfos_1 = class RecipientInfos2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, RecipientInfos_1.prototype);
  }
};
RecipientInfos = RecipientInfos_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Set,
    itemType: RecipientInfo
  })
], RecipientInfos);

// node_modules/@peculiar/asn1-cms/build/es2015/revocation_info_choice.js
var RevocationInfoChoices_1;
var id_ri = `${id_pkix}.16`;
var id_ri_ocsp_response = `${id_ri}.2`;
var id_ri_scvp = `${id_ri}.4`;
var OtherRevocationInfoFormat = class {
  otherRevInfoFormat = "";
  otherRevInfo = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], OtherRevocationInfoFormat.prototype, "otherRevInfoFormat", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Any })
], OtherRevocationInfoFormat.prototype, "otherRevInfo", void 0);
var RevocationInfoChoice = class RevocationInfoChoice2 {
  other = new OtherRevocationInfoFormat();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: OtherRevocationInfoFormat,
    context: 1,
    implicit: true
  })
], RevocationInfoChoice.prototype, "other", void 0);
RevocationInfoChoice = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], RevocationInfoChoice);
var RevocationInfoChoices = RevocationInfoChoices_1 = class RevocationInfoChoices2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, RevocationInfoChoices_1.prototype);
  }
};
RevocationInfoChoices = RevocationInfoChoices_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Set,
    itemType: RevocationInfoChoice
  })
], RevocationInfoChoices);

// node_modules/@peculiar/asn1-cms/build/es2015/originator_info.js
var OriginatorInfo = class {
  certs;
  crls;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: CertificateSet,
    context: 0,
    implicit: true,
    optional: true
  })
], OriginatorInfo.prototype, "certs", void 0);
__decorate([
  AsnProp({
    type: RevocationInfoChoices,
    context: 1,
    implicit: true,
    optional: true
  })
], OriginatorInfo.prototype, "crls", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/enveloped_data.js
var UnprotectedAttributes_1;
var UnprotectedAttributes = UnprotectedAttributes_1 = class UnprotectedAttributes2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, UnprotectedAttributes_1.prototype);
  }
};
UnprotectedAttributes = UnprotectedAttributes_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Set,
    itemType: Attribute2
  })
], UnprotectedAttributes);
var EnvelopedData = class {
  version = CMSVersion.v0;
  originatorInfo;
  recipientInfos = new RecipientInfos();
  encryptedContentInfo = new EncryptedContentInfo();
  unprotectedAttrs;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], EnvelopedData.prototype, "version", void 0);
__decorate([
  AsnProp({
    type: OriginatorInfo,
    context: 0,
    implicit: true,
    optional: true
  })
], EnvelopedData.prototype, "originatorInfo", void 0);
__decorate([
  AsnProp({ type: RecipientInfos })
], EnvelopedData.prototype, "recipientInfos", void 0);
__decorate([
  AsnProp({ type: EncryptedContentInfo })
], EnvelopedData.prototype, "encryptedContentInfo", void 0);
__decorate([
  AsnProp({
    type: UnprotectedAttributes,
    context: 1,
    implicit: true,
    optional: true
  })
], EnvelopedData.prototype, "unprotectedAttrs", void 0);

// node_modules/@peculiar/asn1-cms/build/es2015/object_identifiers.js
var id_data = "1.2.840.113549.1.7.1";
var id_signedData = "1.2.840.113549.1.7.2";

// node_modules/@peculiar/asn1-cms/build/es2015/signed_data.js
var DigestAlgorithmIdentifiers_1;
var DigestAlgorithmIdentifiers = DigestAlgorithmIdentifiers_1 = class DigestAlgorithmIdentifiers2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, DigestAlgorithmIdentifiers_1.prototype);
  }
};
DigestAlgorithmIdentifiers = DigestAlgorithmIdentifiers_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Set,
    itemType: DigestAlgorithmIdentifier
  })
], DigestAlgorithmIdentifiers);
var SignedData = class {
  version = CMSVersion.v0;
  digestAlgorithms = new DigestAlgorithmIdentifiers();
  encapContentInfo = new EncapsulatedContentInfo();
  certificates;
  crls;
  signerInfos = new SignerInfos();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], SignedData.prototype, "version", void 0);
__decorate([
  AsnProp({ type: DigestAlgorithmIdentifiers })
], SignedData.prototype, "digestAlgorithms", void 0);
__decorate([
  AsnProp({ type: EncapsulatedContentInfo })
], SignedData.prototype, "encapContentInfo", void 0);
__decorate([
  AsnProp({
    type: CertificateSet,
    context: 0,
    implicit: true,
    optional: true
  })
], SignedData.prototype, "certificates", void 0);
__decorate([
  AsnProp({
    type: RevocationInfoChoices,
    context: 1,
    implicit: true,
    optional: true
  })
], SignedData.prototype, "crls", void 0);
__decorate([
  AsnProp({ type: SignerInfos })
], SignedData.prototype, "signerInfos", void 0);

// node_modules/@peculiar/asn1-ecc/build/es2015/object_identifiers.js
var id_ecPublicKey = "1.2.840.10045.2.1";
var id_ecdsaWithSHA1 = "1.2.840.10045.4.1";
var id_ecdsaWithSHA224 = "1.2.840.10045.4.3.1";
var id_ecdsaWithSHA256 = "1.2.840.10045.4.3.2";
var id_ecdsaWithSHA384 = "1.2.840.10045.4.3.3";
var id_ecdsaWithSHA512 = "1.2.840.10045.4.3.4";
var id_secp256r1 = "1.2.840.10045.3.1.7";
var id_secp384r1 = "1.3.132.0.34";
var id_secp521r1 = "1.3.132.0.35";

// node_modules/@peculiar/asn1-ecc/build/es2015/algorithms.js
function create(algorithm) {
  return new AlgorithmIdentifier({ algorithm });
}
var ecdsaWithSHA1 = create(id_ecdsaWithSHA1);
var ecdsaWithSHA224 = create(id_ecdsaWithSHA224);
var ecdsaWithSHA256 = create(id_ecdsaWithSHA256);
var ecdsaWithSHA384 = create(id_ecdsaWithSHA384);
var ecdsaWithSHA512 = create(id_ecdsaWithSHA512);

// node_modules/@peculiar/asn1-ecc/build/es2015/rfc3279.js
var FieldID = class FieldID2 {
  fieldType;
  parameters;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], FieldID.prototype, "fieldType", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Any })
], FieldID.prototype, "parameters", void 0);
FieldID = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], FieldID);
var ECPoint = class extends OctetString2 {
};
var Curve = class Curve2 {
  a;
  b;
  seed;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.OctetString })
], Curve.prototype, "a", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.OctetString })
], Curve.prototype, "b", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.BitString,
    optional: true
  })
], Curve.prototype, "seed", void 0);
Curve = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], Curve);
var ECPVer;
(function(ECPVer2) {
  ECPVer2[ECPVer2["ecpVer1"] = 1] = "ecpVer1";
})(ECPVer || (ECPVer = {}));
var SpecifiedECDomain = class SpecifiedECDomain2 {
  version = ECPVer.ecpVer1;
  fieldID;
  curve;
  base;
  order;
  cofactor;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], SpecifiedECDomain.prototype, "version", void 0);
__decorate([
  AsnProp({ type: FieldID })
], SpecifiedECDomain.prototype, "fieldID", void 0);
__decorate([
  AsnProp({ type: Curve })
], SpecifiedECDomain.prototype, "curve", void 0);
__decorate([
  AsnProp({ type: ECPoint })
], SpecifiedECDomain.prototype, "base", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], SpecifiedECDomain.prototype, "order", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    optional: true
  })
], SpecifiedECDomain.prototype, "cofactor", void 0);
SpecifiedECDomain = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], SpecifiedECDomain);

// node_modules/@peculiar/asn1-ecc/build/es2015/ec_parameters.js
var ECParameters = class ECParameters2 {
  namedCurve;
  implicitCurve;
  specifiedCurve;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], ECParameters.prototype, "namedCurve", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Null })
], ECParameters.prototype, "implicitCurve", void 0);
__decorate([
  AsnProp({ type: SpecifiedECDomain })
], ECParameters.prototype, "specifiedCurve", void 0);
ECParameters = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], ECParameters);

// node_modules/@peculiar/asn1-ecc/build/es2015/ec_private_key.js
var ECPrivateKey = class {
  version = 1;
  privateKey = new OctetString2();
  parameters;
  publicKey;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], ECPrivateKey.prototype, "version", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], ECPrivateKey.prototype, "privateKey", void 0);
__decorate([
  AsnProp({
    type: ECParameters,
    context: 0,
    optional: true
  })
], ECPrivateKey.prototype, "parameters", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.BitString,
    context: 1,
    optional: true
  })
], ECPrivateKey.prototype, "publicKey", void 0);

// node_modules/@peculiar/asn1-ecc/build/es2015/ec_signature_value.js
var ECDSASigValue = class {
  r = new ArrayBuffer(0);
  s = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], ECDSASigValue.prototype, "r", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], ECDSASigValue.prototype, "s", void 0);

// node_modules/@peculiar/asn1-rsa/build/es2015/object_identifiers.js
var id_pkcs_1 = "1.2.840.113549.1.1";
var id_rsaEncryption = `${id_pkcs_1}.1`;
var id_RSAES_OAEP = `${id_pkcs_1}.7`;
var id_pSpecified = `${id_pkcs_1}.9`;
var id_RSASSA_PSS = `${id_pkcs_1}.10`;
var id_md2WithRSAEncryption = `${id_pkcs_1}.2`;
var id_md5WithRSAEncryption = `${id_pkcs_1}.4`;
var id_sha1WithRSAEncryption = `${id_pkcs_1}.5`;
var id_sha224WithRSAEncryption = `${id_pkcs_1}.14`;
var id_sha256WithRSAEncryption = `${id_pkcs_1}.11`;
var id_sha384WithRSAEncryption = `${id_pkcs_1}.12`;
var id_sha512WithRSAEncryption = `${id_pkcs_1}.13`;
var id_sha512_224WithRSAEncryption = `${id_pkcs_1}.15`;
var id_sha512_256WithRSAEncryption = `${id_pkcs_1}.16`;
var id_sha1 = "1.3.14.3.2.26";
var id_sha224 = "2.16.840.1.101.3.4.2.4";
var id_sha256 = "2.16.840.1.101.3.4.2.1";
var id_sha384 = "2.16.840.1.101.3.4.2.2";
var id_sha512 = "2.16.840.1.101.3.4.2.3";
var id_sha512_224 = "2.16.840.1.101.3.4.2.5";
var id_sha512_256 = "2.16.840.1.101.3.4.2.6";
var id_md2 = "1.2.840.113549.2.2";
var id_md5 = "1.2.840.113549.2.5";
var id_mgf1 = `${id_pkcs_1}.8`;

// node_modules/@peculiar/asn1-rsa/build/es2015/algorithms.js
function create2(algorithm) {
  return new AlgorithmIdentifier({
    algorithm,
    parameters: null
  });
}
var md2 = create2(id_md2);
var md4 = create2(id_md5);
var sha1 = create2(id_sha1);
var sha224 = create2(id_sha224);
var sha256 = create2(id_sha256);
var sha384 = create2(id_sha384);
var sha512 = create2(id_sha512);
var sha512_224 = create2(id_sha512_224);
var sha512_256 = create2(id_sha512_256);
var mgf1SHA1 = new AlgorithmIdentifier({
  algorithm: id_mgf1,
  parameters: AsnConvert.serialize(sha1)
});
var pSpecifiedEmpty = new AlgorithmIdentifier({
  algorithm: id_pSpecified,
  parameters: AsnConvert.serialize(AsnOctetStringConverter.toASN(new Uint8Array([218, 57, 163, 238, 94, 107, 75, 13, 50, 85, 191, 239, 149, 96, 24, 144, 175, 216, 7, 9]).buffer))
});
var rsaEncryption = create2(id_rsaEncryption);
var md2WithRSAEncryption = create2(id_md2WithRSAEncryption);
var md5WithRSAEncryption = create2(id_md5WithRSAEncryption);
var sha1WithRSAEncryption = create2(id_sha1WithRSAEncryption);
var sha224WithRSAEncryption = create2(id_sha512_224WithRSAEncryption);
var sha256WithRSAEncryption = create2(id_sha512_256WithRSAEncryption);
var sha384WithRSAEncryption = create2(id_sha384WithRSAEncryption);
var sha512WithRSAEncryption = create2(id_sha512WithRSAEncryption);
var sha512_224WithRSAEncryption = create2(id_sha512_224WithRSAEncryption);
var sha512_256WithRSAEncryption = create2(id_sha512_256WithRSAEncryption);

// node_modules/@peculiar/asn1-rsa/build/es2015/parameters/rsaes_oaep.js
var RsaEsOaepParams = class {
  hashAlgorithm = new AlgorithmIdentifier(sha1);
  maskGenAlgorithm = new AlgorithmIdentifier({
    algorithm: id_mgf1,
    parameters: AsnConvert.serialize(sha1)
  });
  pSourceAlgorithm = new AlgorithmIdentifier(pSpecifiedEmpty);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AlgorithmIdentifier,
    context: 0,
    defaultValue: sha1
  })
], RsaEsOaepParams.prototype, "hashAlgorithm", void 0);
__decorate([
  AsnProp({
    type: AlgorithmIdentifier,
    context: 1,
    defaultValue: mgf1SHA1
  })
], RsaEsOaepParams.prototype, "maskGenAlgorithm", void 0);
__decorate([
  AsnProp({
    type: AlgorithmIdentifier,
    context: 2,
    defaultValue: pSpecifiedEmpty
  })
], RsaEsOaepParams.prototype, "pSourceAlgorithm", void 0);
var RSAES_OAEP = new AlgorithmIdentifier({
  algorithm: id_RSAES_OAEP,
  parameters: AsnConvert.serialize(new RsaEsOaepParams())
});

// node_modules/@peculiar/asn1-rsa/build/es2015/parameters/rsassa_pss.js
var RsaSaPssParams = class {
  hashAlgorithm = new AlgorithmIdentifier(sha1);
  maskGenAlgorithm = new AlgorithmIdentifier({
    algorithm: id_mgf1,
    parameters: AsnConvert.serialize(sha1)
  });
  saltLength = 20;
  trailerField = 1;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AlgorithmIdentifier,
    context: 0,
    defaultValue: sha1
  })
], RsaSaPssParams.prototype, "hashAlgorithm", void 0);
__decorate([
  AsnProp({
    type: AlgorithmIdentifier,
    context: 1,
    defaultValue: mgf1SHA1
  })
], RsaSaPssParams.prototype, "maskGenAlgorithm", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    context: 2,
    defaultValue: 20
  })
], RsaSaPssParams.prototype, "saltLength", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    context: 3,
    defaultValue: 1
  })
], RsaSaPssParams.prototype, "trailerField", void 0);
var RSASSA_PSS = new AlgorithmIdentifier({
  algorithm: id_RSASSA_PSS,
  parameters: AsnConvert.serialize(new RsaSaPssParams())
});

// node_modules/@peculiar/asn1-rsa/build/es2015/parameters/rsassa_pkcs1_v1_5.js
var DigestInfo = class {
  digestAlgorithm = new AlgorithmIdentifier();
  digest = new OctetString2();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], DigestInfo.prototype, "digestAlgorithm", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], DigestInfo.prototype, "digest", void 0);

// node_modules/@peculiar/asn1-rsa/build/es2015/other_prime_info.js
var OtherPrimeInfos_1;
var OtherPrimeInfo = class {
  prime = new ArrayBuffer(0);
  exponent = new ArrayBuffer(0);
  coefficient = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], OtherPrimeInfo.prototype, "prime", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], OtherPrimeInfo.prototype, "exponent", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], OtherPrimeInfo.prototype, "coefficient", void 0);
var OtherPrimeInfos = OtherPrimeInfos_1 = class OtherPrimeInfos2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, OtherPrimeInfos_1.prototype);
  }
};
OtherPrimeInfos = OtherPrimeInfos_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: OtherPrimeInfo
  })
], OtherPrimeInfos);

// node_modules/@peculiar/asn1-rsa/build/es2015/rsa_private_key.js
var RSAPrivateKey = class {
  version = 0;
  modulus = new ArrayBuffer(0);
  publicExponent = new ArrayBuffer(0);
  privateExponent = new ArrayBuffer(0);
  prime1 = new ArrayBuffer(0);
  prime2 = new ArrayBuffer(0);
  exponent1 = new ArrayBuffer(0);
  exponent2 = new ArrayBuffer(0);
  coefficient = new ArrayBuffer(0);
  otherPrimeInfos;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], RSAPrivateKey.prototype, "version", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], RSAPrivateKey.prototype, "modulus", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], RSAPrivateKey.prototype, "publicExponent", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], RSAPrivateKey.prototype, "privateExponent", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], RSAPrivateKey.prototype, "prime1", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], RSAPrivateKey.prototype, "prime2", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], RSAPrivateKey.prototype, "exponent1", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], RSAPrivateKey.prototype, "exponent2", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], RSAPrivateKey.prototype, "coefficient", void 0);
__decorate([
  AsnProp({
    type: OtherPrimeInfos,
    optional: true
  })
], RSAPrivateKey.prototype, "otherPrimeInfos", void 0);

// node_modules/@peculiar/asn1-rsa/build/es2015/rsa_public_key.js
var RSAPublicKey = class {
  modulus = new ArrayBuffer(0);
  publicExponent = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], RSAPublicKey.prototype, "modulus", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    converter: AsnIntegerArrayBufferConverter
  })
], RSAPublicKey.prototype, "publicExponent", void 0);

// node_modules/tsyringe/dist/esm5/types/lifecycle.js
var Lifecycle;
(function(Lifecycle2) {
  Lifecycle2[Lifecycle2["Transient"] = 0] = "Transient";
  Lifecycle2[Lifecycle2["Singleton"] = 1] = "Singleton";
  Lifecycle2[Lifecycle2["ResolutionScoped"] = 2] = "ResolutionScoped";
  Lifecycle2[Lifecycle2["ContainerScoped"] = 3] = "ContainerScoped";
})(Lifecycle || (Lifecycle = {}));
var lifecycle_default = Lifecycle;

// node_modules/tsyringe/node_modules/tslib/modules/index.js
var import_tslib87 = __toESM(require_tslib(), 1);
var {
  __extends,
  __assign,
  __rest,
  __decorate: __decorate2,
  __param,
  __metadata,
  __awaiter,
  __generator,
  __exportStar,
  __createBinding,
  __values,
  __read,
  __spread,
  __spreadArrays,
  __await,
  __asyncGenerator,
  __asyncDelegator,
  __asyncValues,
  __makeTemplateObject,
  __importStar,
  __importDefault,
  __classPrivateFieldGet: __classPrivateFieldGet2,
  __classPrivateFieldSet: __classPrivateFieldSet2
} = import_tslib87.default;

// node_modules/tsyringe/dist/esm5/reflection-helpers.js
var INJECTION_TOKEN_METADATA_KEY = "injectionTokens";
function getParamInfo(target) {
  var params = Reflect.getMetadata("design:paramtypes", target) || [];
  var injectionTokens = Reflect.getOwnMetadata(INJECTION_TOKEN_METADATA_KEY, target) || {};
  Object.keys(injectionTokens).forEach(function(key2) {
    params[+key2] = injectionTokens[key2];
  });
  return params;
}

// node_modules/tsyringe/dist/esm5/providers/class-provider.js
function isClassProvider(provider) {
  return !!provider.useClass;
}

// node_modules/tsyringe/dist/esm5/providers/factory-provider.js
function isFactoryProvider(provider) {
  return !!provider.useFactory;
}

// node_modules/tsyringe/dist/esm5/lazy-helpers.js
var DelayedConstructor = (function() {
  function DelayedConstructor2(wrap2) {
    this.wrap = wrap2;
    this.reflectMethods = [
      "get",
      "getPrototypeOf",
      "setPrototypeOf",
      "getOwnPropertyDescriptor",
      "defineProperty",
      "has",
      "set",
      "deleteProperty",
      "apply",
      "construct",
      "ownKeys"
    ];
  }
  DelayedConstructor2.prototype.createProxy = function(createObject) {
    var _this = this;
    var target = {};
    var init = false;
    var value;
    var delayedObject = function() {
      if (!init) {
        value = createObject(_this.wrap());
        init = true;
      }
      return value;
    };
    return new Proxy(target, this.createHandler(delayedObject));
  };
  DelayedConstructor2.prototype.createHandler = function(delayedObject) {
    var handler = {};
    var install = function(name) {
      handler[name] = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        args[0] = delayedObject();
        var method = Reflect[name];
        return method.apply(void 0, __spread(args));
      };
    };
    this.reflectMethods.forEach(install);
    return handler;
  };
  return DelayedConstructor2;
})();

// node_modules/tsyringe/dist/esm5/providers/injection-token.js
function isNormalToken(token) {
  return typeof token === "string" || typeof token === "symbol";
}
function isTokenDescriptor(descriptor) {
  return typeof descriptor === "object" && "token" in descriptor && "multiple" in descriptor;
}
function isTransformDescriptor(descriptor) {
  return typeof descriptor === "object" && "token" in descriptor && "transform" in descriptor;
}
function isConstructorToken(token) {
  return typeof token === "function" || token instanceof DelayedConstructor;
}

// node_modules/tsyringe/dist/esm5/providers/token-provider.js
function isTokenProvider(provider) {
  return !!provider.useToken;
}

// node_modules/tsyringe/dist/esm5/providers/value-provider.js
function isValueProvider(provider) {
  return provider.useValue != void 0;
}

// node_modules/tsyringe/dist/esm5/providers/provider.js
function isProvider(provider) {
  return isClassProvider(provider) || isValueProvider(provider) || isTokenProvider(provider) || isFactoryProvider(provider);
}

// node_modules/tsyringe/dist/esm5/registry-base.js
var RegistryBase = (function() {
  function RegistryBase2() {
    this._registryMap = /* @__PURE__ */ new Map();
  }
  RegistryBase2.prototype.entries = function() {
    return this._registryMap.entries();
  };
  RegistryBase2.prototype.getAll = function(key2) {
    this.ensure(key2);
    return this._registryMap.get(key2);
  };
  RegistryBase2.prototype.get = function(key2) {
    this.ensure(key2);
    var value = this._registryMap.get(key2);
    return value[value.length - 1] || null;
  };
  RegistryBase2.prototype.set = function(key2, value) {
    this.ensure(key2);
    this._registryMap.get(key2).push(value);
  };
  RegistryBase2.prototype.setAll = function(key2, value) {
    this._registryMap.set(key2, value);
  };
  RegistryBase2.prototype.has = function(key2) {
    this.ensure(key2);
    return this._registryMap.get(key2).length > 0;
  };
  RegistryBase2.prototype.clear = function() {
    this._registryMap.clear();
  };
  RegistryBase2.prototype.ensure = function(key2) {
    if (!this._registryMap.has(key2)) {
      this._registryMap.set(key2, []);
    }
  };
  return RegistryBase2;
})();
var registry_base_default = RegistryBase;

// node_modules/tsyringe/dist/esm5/registry.js
var Registry = (function(_super) {
  __extends(Registry2, _super);
  function Registry2() {
    return _super !== null && _super.apply(this, arguments) || this;
  }
  return Registry2;
})(registry_base_default);
var registry_default = Registry;

// node_modules/tsyringe/dist/esm5/resolution-context.js
var ResolutionContext = /* @__PURE__ */ (function() {
  function ResolutionContext2() {
    this.scopedResolutions = /* @__PURE__ */ new Map();
  }
  return ResolutionContext2;
})();
var resolution_context_default = ResolutionContext;

// node_modules/tsyringe/dist/esm5/error-helpers.js
function formatDependency(params, idx) {
  if (params === null) {
    return "at position #" + idx;
  }
  var argName = params.split(",")[idx].trim();
  return '"' + argName + '" at position #' + idx;
}
function composeErrorMessage(msg, e, indent) {
  if (indent === void 0) {
    indent = "    ";
  }
  return __spread([msg], e.message.split("\n").map(function(l) {
    return indent + l;
  })).join("\n");
}
function formatErrorCtor(ctor, paramIdx, error) {
  var _a3 = __read(ctor.toString().match(/constructor\(([\w, ]+)\)/) || [], 2), _b = _a3[1], params = _b === void 0 ? null : _b;
  var dep = formatDependency(params, paramIdx);
  return composeErrorMessage("Cannot inject the dependency " + dep + ' of "' + ctor.name + '" constructor. Reason:', error);
}

// node_modules/tsyringe/dist/esm5/types/disposable.js
function isDisposable(value) {
  if (typeof value.dispose !== "function")
    return false;
  var disposeFun = value.dispose;
  if (disposeFun.length > 0) {
    return false;
  }
  return true;
}

// node_modules/tsyringe/dist/esm5/interceptors.js
var PreResolutionInterceptors = (function(_super) {
  __extends(PreResolutionInterceptors2, _super);
  function PreResolutionInterceptors2() {
    return _super !== null && _super.apply(this, arguments) || this;
  }
  return PreResolutionInterceptors2;
})(registry_base_default);
var PostResolutionInterceptors = (function(_super) {
  __extends(PostResolutionInterceptors2, _super);
  function PostResolutionInterceptors2() {
    return _super !== null && _super.apply(this, arguments) || this;
  }
  return PostResolutionInterceptors2;
})(registry_base_default);
var Interceptors = /* @__PURE__ */ (function() {
  function Interceptors2() {
    this.preResolution = new PreResolutionInterceptors();
    this.postResolution = new PostResolutionInterceptors();
  }
  return Interceptors2;
})();
var interceptors_default = Interceptors;

// node_modules/tsyringe/dist/esm5/dependency-container.js
var typeInfo = /* @__PURE__ */ new Map();
var InternalDependencyContainer = (function() {
  function InternalDependencyContainer2(parent) {
    this.parent = parent;
    this._registry = new registry_default();
    this.interceptors = new interceptors_default();
    this.disposed = false;
    this.disposables = /* @__PURE__ */ new Set();
  }
  InternalDependencyContainer2.prototype.register = function(token, providerOrConstructor, options) {
    if (options === void 0) {
      options = { lifecycle: lifecycle_default.Transient };
    }
    this.ensureNotDisposed();
    var provider;
    if (!isProvider(providerOrConstructor)) {
      provider = { useClass: providerOrConstructor };
    } else {
      provider = providerOrConstructor;
    }
    if (isTokenProvider(provider)) {
      var path = [token];
      var tokenProvider = provider;
      while (tokenProvider != null) {
        var currentToken = tokenProvider.useToken;
        if (path.includes(currentToken)) {
          throw new Error("Token registration cycle detected! " + __spread(path, [currentToken]).join(" -> "));
        }
        path.push(currentToken);
        var registration = this._registry.get(currentToken);
        if (registration && isTokenProvider(registration.provider)) {
          tokenProvider = registration.provider;
        } else {
          tokenProvider = null;
        }
      }
    }
    if (options.lifecycle === lifecycle_default.Singleton || options.lifecycle == lifecycle_default.ContainerScoped || options.lifecycle == lifecycle_default.ResolutionScoped) {
      if (isValueProvider(provider) || isFactoryProvider(provider)) {
        throw new Error('Cannot use lifecycle "' + lifecycle_default[options.lifecycle] + '" with ValueProviders or FactoryProviders');
      }
    }
    this._registry.set(token, { provider, options });
    return this;
  };
  InternalDependencyContainer2.prototype.registerType = function(from, to) {
    this.ensureNotDisposed();
    if (isNormalToken(to)) {
      return this.register(from, {
        useToken: to
      });
    }
    return this.register(from, {
      useClass: to
    });
  };
  InternalDependencyContainer2.prototype.registerInstance = function(token, instance2) {
    this.ensureNotDisposed();
    return this.register(token, {
      useValue: instance2
    });
  };
  InternalDependencyContainer2.prototype.registerSingleton = function(from, to) {
    this.ensureNotDisposed();
    if (isNormalToken(from)) {
      if (isNormalToken(to)) {
        return this.register(from, {
          useToken: to
        }, { lifecycle: lifecycle_default.Singleton });
      } else if (to) {
        return this.register(from, {
          useClass: to
        }, { lifecycle: lifecycle_default.Singleton });
      }
      throw new Error('Cannot register a type name as a singleton without a "to" token');
    }
    var useClass = from;
    if (to && !isNormalToken(to)) {
      useClass = to;
    }
    return this.register(from, {
      useClass
    }, { lifecycle: lifecycle_default.Singleton });
  };
  InternalDependencyContainer2.prototype.resolve = function(token, context3, isOptional) {
    if (context3 === void 0) {
      context3 = new resolution_context_default();
    }
    if (isOptional === void 0) {
      isOptional = false;
    }
    this.ensureNotDisposed();
    var registration = this.getRegistration(token);
    if (!registration && isNormalToken(token)) {
      if (isOptional) {
        return void 0;
      }
      throw new Error('Attempted to resolve unregistered dependency token: "' + token.toString() + '"');
    }
    this.executePreResolutionInterceptor(token, "Single");
    if (registration) {
      var result = this.resolveRegistration(registration, context3);
      this.executePostResolutionInterceptor(token, result, "Single");
      return result;
    }
    if (isConstructorToken(token)) {
      var result = this.construct(token, context3);
      this.executePostResolutionInterceptor(token, result, "Single");
      return result;
    }
    throw new Error("Attempted to construct an undefined constructor. Could mean a circular dependency problem. Try using `delay` function.");
  };
  InternalDependencyContainer2.prototype.executePreResolutionInterceptor = function(token, resolutionType) {
    var e_1, _a3;
    if (this.interceptors.preResolution.has(token)) {
      var remainingInterceptors = [];
      try {
        for (var _b = __values(this.interceptors.preResolution.getAll(token)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var interceptor = _c.value;
          if (interceptor.options.frequency != "Once") {
            remainingInterceptors.push(interceptor);
          }
          interceptor.callback(token, resolutionType);
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a3 = _b.return)) _a3.call(_b);
        } finally {
          if (e_1) throw e_1.error;
        }
      }
      this.interceptors.preResolution.setAll(token, remainingInterceptors);
    }
  };
  InternalDependencyContainer2.prototype.executePostResolutionInterceptor = function(token, result, resolutionType) {
    var e_2, _a3;
    if (this.interceptors.postResolution.has(token)) {
      var remainingInterceptors = [];
      try {
        for (var _b = __values(this.interceptors.postResolution.getAll(token)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var interceptor = _c.value;
          if (interceptor.options.frequency != "Once") {
            remainingInterceptors.push(interceptor);
          }
          interceptor.callback(token, result, resolutionType);
        }
      } catch (e_2_1) {
        e_2 = { error: e_2_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a3 = _b.return)) _a3.call(_b);
        } finally {
          if (e_2) throw e_2.error;
        }
      }
      this.interceptors.postResolution.setAll(token, remainingInterceptors);
    }
  };
  InternalDependencyContainer2.prototype.resolveRegistration = function(registration, context3) {
    this.ensureNotDisposed();
    if (registration.options.lifecycle === lifecycle_default.ResolutionScoped && context3.scopedResolutions.has(registration)) {
      return context3.scopedResolutions.get(registration);
    }
    var isSingleton = registration.options.lifecycle === lifecycle_default.Singleton;
    var isContainerScoped = registration.options.lifecycle === lifecycle_default.ContainerScoped;
    var returnInstance = isSingleton || isContainerScoped;
    var resolved;
    if (isValueProvider(registration.provider)) {
      resolved = registration.provider.useValue;
    } else if (isTokenProvider(registration.provider)) {
      resolved = returnInstance ? registration.instance || (registration.instance = this.resolve(registration.provider.useToken, context3)) : this.resolve(registration.provider.useToken, context3);
    } else if (isClassProvider(registration.provider)) {
      resolved = returnInstance ? registration.instance || (registration.instance = this.construct(registration.provider.useClass, context3)) : this.construct(registration.provider.useClass, context3);
    } else if (isFactoryProvider(registration.provider)) {
      resolved = registration.provider.useFactory(this);
    } else {
      resolved = this.construct(registration.provider, context3);
    }
    if (registration.options.lifecycle === lifecycle_default.ResolutionScoped) {
      context3.scopedResolutions.set(registration, resolved);
    }
    return resolved;
  };
  InternalDependencyContainer2.prototype.resolveAll = function(token, context3, isOptional) {
    var _this = this;
    if (context3 === void 0) {
      context3 = new resolution_context_default();
    }
    if (isOptional === void 0) {
      isOptional = false;
    }
    this.ensureNotDisposed();
    var registrations = this.getAllRegistrations(token);
    if (!registrations && isNormalToken(token)) {
      if (isOptional) {
        return [];
      }
      throw new Error('Attempted to resolve unregistered dependency token: "' + token.toString() + '"');
    }
    this.executePreResolutionInterceptor(token, "All");
    if (registrations) {
      var result_1 = registrations.map(function(item) {
        return _this.resolveRegistration(item, context3);
      });
      this.executePostResolutionInterceptor(token, result_1, "All");
      return result_1;
    }
    var result = [this.construct(token, context3)];
    this.executePostResolutionInterceptor(token, result, "All");
    return result;
  };
  InternalDependencyContainer2.prototype.isRegistered = function(token, recursive) {
    if (recursive === void 0) {
      recursive = false;
    }
    this.ensureNotDisposed();
    return this._registry.has(token) || recursive && (this.parent || false) && this.parent.isRegistered(token, true);
  };
  InternalDependencyContainer2.prototype.reset = function() {
    this.ensureNotDisposed();
    this._registry.clear();
    this.interceptors.preResolution.clear();
    this.interceptors.postResolution.clear();
  };
  InternalDependencyContainer2.prototype.clearInstances = function() {
    var e_3, _a3;
    this.ensureNotDisposed();
    try {
      for (var _b = __values(this._registry.entries()), _c = _b.next(); !_c.done; _c = _b.next()) {
        var _d = __read(_c.value, 2), token = _d[0], registrations = _d[1];
        this._registry.setAll(token, registrations.filter(function(registration) {
          return !isValueProvider(registration.provider);
        }).map(function(registration) {
          registration.instance = void 0;
          return registration;
        }));
      }
    } catch (e_3_1) {
      e_3 = { error: e_3_1 };
    } finally {
      try {
        if (_c && !_c.done && (_a3 = _b.return)) _a3.call(_b);
      } finally {
        if (e_3) throw e_3.error;
      }
    }
  };
  InternalDependencyContainer2.prototype.createChildContainer = function() {
    var e_4, _a3;
    this.ensureNotDisposed();
    var childContainer = new InternalDependencyContainer2(this);
    try {
      for (var _b = __values(this._registry.entries()), _c = _b.next(); !_c.done; _c = _b.next()) {
        var _d = __read(_c.value, 2), token = _d[0], registrations = _d[1];
        if (registrations.some(function(_a4) {
          var options = _a4.options;
          return options.lifecycle === lifecycle_default.ContainerScoped;
        })) {
          childContainer._registry.setAll(token, registrations.map(function(registration) {
            if (registration.options.lifecycle === lifecycle_default.ContainerScoped) {
              return {
                provider: registration.provider,
                options: registration.options
              };
            }
            return registration;
          }));
        }
      }
    } catch (e_4_1) {
      e_4 = { error: e_4_1 };
    } finally {
      try {
        if (_c && !_c.done && (_a3 = _b.return)) _a3.call(_b);
      } finally {
        if (e_4) throw e_4.error;
      }
    }
    return childContainer;
  };
  InternalDependencyContainer2.prototype.beforeResolution = function(token, callback, options) {
    if (options === void 0) {
      options = { frequency: "Always" };
    }
    this.interceptors.preResolution.set(token, {
      callback,
      options
    });
  };
  InternalDependencyContainer2.prototype.afterResolution = function(token, callback, options) {
    if (options === void 0) {
      options = { frequency: "Always" };
    }
    this.interceptors.postResolution.set(token, {
      callback,
      options
    });
  };
  InternalDependencyContainer2.prototype.dispose = function() {
    return __awaiter(this, void 0, void 0, function() {
      var promises;
      return __generator(this, function(_a3) {
        switch (_a3.label) {
          case 0:
            this.disposed = true;
            promises = [];
            this.disposables.forEach(function(disposable) {
              var maybePromise = disposable.dispose();
              if (maybePromise) {
                promises.push(maybePromise);
              }
            });
            return [4, Promise.all(promises)];
          case 1:
            _a3.sent();
            return [2];
        }
      });
    });
  };
  InternalDependencyContainer2.prototype.getRegistration = function(token) {
    if (this.isRegistered(token)) {
      return this._registry.get(token);
    }
    if (this.parent) {
      return this.parent.getRegistration(token);
    }
    return null;
  };
  InternalDependencyContainer2.prototype.getAllRegistrations = function(token) {
    if (this.isRegistered(token)) {
      return this._registry.getAll(token);
    }
    if (this.parent) {
      return this.parent.getAllRegistrations(token);
    }
    return null;
  };
  InternalDependencyContainer2.prototype.construct = function(ctor, context3) {
    var _this = this;
    if (ctor instanceof DelayedConstructor) {
      return ctor.createProxy(function(target) {
        return _this.resolve(target, context3);
      });
    }
    var instance2 = (function() {
      var paramInfo = typeInfo.get(ctor);
      if (!paramInfo || paramInfo.length === 0) {
        if (ctor.length === 0) {
          return new ctor();
        } else {
          throw new Error('TypeInfo not known for "' + ctor.name + '"');
        }
      }
      var params = paramInfo.map(_this.resolveParams(context3, ctor));
      return new (ctor.bind.apply(ctor, __spread([void 0], params)))();
    })();
    if (isDisposable(instance2)) {
      this.disposables.add(instance2);
    }
    return instance2;
  };
  InternalDependencyContainer2.prototype.resolveParams = function(context3, ctor) {
    var _this = this;
    return function(param, idx) {
      var _a3, _b, _c;
      try {
        if (isTokenDescriptor(param)) {
          if (isTransformDescriptor(param)) {
            return param.multiple ? (_a3 = _this.resolve(param.transform)).transform.apply(_a3, __spread([_this.resolveAll(param.token, new resolution_context_default(), param.isOptional)], param.transformArgs)) : (_b = _this.resolve(param.transform)).transform.apply(_b, __spread([_this.resolve(param.token, context3, param.isOptional)], param.transformArgs));
          } else {
            return param.multiple ? _this.resolveAll(param.token, new resolution_context_default(), param.isOptional) : _this.resolve(param.token, context3, param.isOptional);
          }
        } else if (isTransformDescriptor(param)) {
          return (_c = _this.resolve(param.transform, context3)).transform.apply(_c, __spread([_this.resolve(param.token, context3)], param.transformArgs));
        }
        return _this.resolve(param, context3);
      } catch (e) {
        throw new Error(formatErrorCtor(ctor, idx, e));
      }
    };
  };
  InternalDependencyContainer2.prototype.ensureNotDisposed = function() {
    if (this.disposed) {
      throw new Error("This container has been disposed, you cannot interact with a disposed container");
    }
  };
  return InternalDependencyContainer2;
})();
var instance = new InternalDependencyContainer();

// node_modules/tsyringe/dist/esm5/decorators/injectable.js
function injectable(options) {
  return function(target) {
    typeInfo.set(target, getParamInfo(target));
    if (options && options.token) {
      if (!Array.isArray(options.token)) {
        instance.register(options.token, target);
      } else {
        options.token.forEach(function(token) {
          instance.register(token, target);
        });
      }
    }
  };
}
var injectable_default = injectable;

// node_modules/tsyringe/dist/esm5/index.js
if (typeof Reflect === "undefined" || !Reflect.getMetadata) {
  throw new Error(`tsyringe requires a reflect polyfill. Please add 'import "reflect-metadata"' to the top of your entry point.`);
}

// node_modules/@peculiar/asn1-pfx/build/es2015/attribute.js
var PKCS12AttrSet_1;
var PKCS12Attribute = class {
  attrId = "";
  attrValues = [];
  constructor(params = {}) {
    Object.assign(params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], PKCS12Attribute.prototype, "attrId", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    repeated: "set"
  })
], PKCS12Attribute.prototype, "attrValues", void 0);
var PKCS12AttrSet = PKCS12AttrSet_1 = class PKCS12AttrSet2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, PKCS12AttrSet_1.prototype);
  }
};
PKCS12AttrSet = PKCS12AttrSet_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: PKCS12Attribute
  })
], PKCS12AttrSet);

// node_modules/@peculiar/asn1-pfx/build/es2015/authenticated_safe.js
var AuthenticatedSafe_1;
var AuthenticatedSafe = AuthenticatedSafe_1 = class AuthenticatedSafe2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, AuthenticatedSafe_1.prototype);
  }
};
AuthenticatedSafe = AuthenticatedSafe_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: ContentInfo
  })
], AuthenticatedSafe);

// node_modules/@peculiar/asn1-pfx/build/es2015/object_identifiers.js
var id_rsadsi = "1.2.840.113549";
var id_pkcs = `${id_rsadsi}.1`;
var id_pkcs_12 = `${id_pkcs}.12`;
var id_pkcs_12PbeIds = `${id_pkcs_12}.1`;
var id_pbeWithSHAAnd128BitRC4 = `${id_pkcs_12PbeIds}.1`;
var id_pbeWithSHAAnd40BitRC4 = `${id_pkcs_12PbeIds}.2`;
var id_pbeWithSHAAnd3_KeyTripleDES_CBC = `${id_pkcs_12PbeIds}.3`;
var id_pbeWithSHAAnd2_KeyTripleDES_CBC = `${id_pkcs_12PbeIds}.4`;
var id_pbeWithSHAAnd128BitRC2_CBC = `${id_pkcs_12PbeIds}.5`;
var id_pbewithSHAAnd40BitRC2_CBC = `${id_pkcs_12PbeIds}.6`;
var id_bagtypes = `${id_pkcs_12}.10.1`;

// node_modules/@peculiar/asn1-pfx/build/es2015/bags/types.js
var id_keyBag = `${id_bagtypes}.1`;
var id_pkcs8ShroudedKeyBag = `${id_bagtypes}.2`;
var id_certBag = `${id_bagtypes}.3`;
var id_CRLBag = `${id_bagtypes}.4`;
var id_SecretBag = `${id_bagtypes}.5`;
var id_SafeContents = `${id_bagtypes}.6`;
var id_pkcs_9 = "1.2.840.113549.1.9";

// node_modules/@peculiar/asn1-pfx/build/es2015/bags/cert_bag.js
var CertBag = class {
  certId = "";
  certValue = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], CertBag.prototype, "certId", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    context: 0
  })
], CertBag.prototype, "certValue", void 0);
var id_certTypes = `${id_pkcs_9}.22`;
var id_x509Certificate = `${id_certTypes}.1`;
var id_sdsiCertificate = `${id_certTypes}.2`;

// node_modules/@peculiar/asn1-pfx/build/es2015/bags/crl_bag.js
var CRLBag = class {
  crlId = "";
  crltValue = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], CRLBag.prototype, "crlId", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    context: 0
  })
], CRLBag.prototype, "crltValue", void 0);
var id_crlTypes = `${id_pkcs_9}.23`;
var id_x509CRL = `${id_crlTypes}.1`;

// node_modules/@peculiar/asn1-pkcs8/build/es2015/encrypted_private_key_info.js
var EncryptedData = class extends OctetString2 {
};
var EncryptedPrivateKeyInfo = class {
  encryptionAlgorithm = new AlgorithmIdentifier();
  encryptedData = new EncryptedData();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], EncryptedPrivateKeyInfo.prototype, "encryptionAlgorithm", void 0);
__decorate([
  AsnProp({ type: EncryptedData })
], EncryptedPrivateKeyInfo.prototype, "encryptedData", void 0);

// node_modules/@peculiar/asn1-pkcs8/build/es2015/private_key_info.js
var Attributes_1;
var Version2;
(function(Version5) {
  Version5[Version5["v1"] = 0] = "v1";
})(Version2 || (Version2 = {}));
var PrivateKey = class extends OctetString2 {
};
var Attributes = Attributes_1 = class Attributes2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, Attributes_1.prototype);
  }
};
Attributes = Attributes_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: Attribute
  })
], Attributes);
var PrivateKeyInfo = class {
  version = Version2.v1;
  privateKeyAlgorithm = new AlgorithmIdentifier();
  privateKey = new PrivateKey();
  attributes;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], PrivateKeyInfo.prototype, "version", void 0);
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], PrivateKeyInfo.prototype, "privateKeyAlgorithm", void 0);
__decorate([
  AsnProp({ type: PrivateKey })
], PrivateKeyInfo.prototype, "privateKey", void 0);
__decorate([
  AsnProp({
    type: Attributes,
    implicit: true,
    context: 0,
    optional: true
  })
], PrivateKeyInfo.prototype, "attributes", void 0);

// node_modules/@peculiar/asn1-pfx/build/es2015/bags/key_bag.js
var KeyBag = class KeyBag2 extends PrivateKeyInfo {
};
KeyBag = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], KeyBag);

// node_modules/@peculiar/asn1-pfx/build/es2015/bags/pkcs8_shrouded_key_bag.js
var PKCS8ShroudedKeyBag = class PKCS8ShroudedKeyBag2 extends EncryptedPrivateKeyInfo {
};
PKCS8ShroudedKeyBag = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], PKCS8ShroudedKeyBag);

// node_modules/@peculiar/asn1-pfx/build/es2015/bags/secret_bag.js
var SecretBag = class {
  secretTypeId = "";
  secretValue = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], SecretBag.prototype, "secretTypeId", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    context: 0
  })
], SecretBag.prototype, "secretValue", void 0);

// node_modules/@peculiar/asn1-pfx/build/es2015/mac_data.js
var MacData = class {
  mac = new DigestInfo();
  macSalt = new OctetString2();
  iterations = 1;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: DigestInfo })
], MacData.prototype, "mac", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], MacData.prototype, "macSalt", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Integer,
    defaultValue: 1
  })
], MacData.prototype, "iterations", void 0);

// node_modules/@peculiar/asn1-pfx/build/es2015/pfx.js
var PFX = class {
  version = 3;
  authSafe = new ContentInfo();
  macData = new MacData();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], PFX.prototype, "version", void 0);
__decorate([
  AsnProp({ type: ContentInfo })
], PFX.prototype, "authSafe", void 0);
__decorate([
  AsnProp({
    type: MacData,
    optional: true
  })
], PFX.prototype, "macData", void 0);

// node_modules/@peculiar/asn1-pfx/build/es2015/safe_bag.js
var SafeContents_1;
var SafeBag = class {
  bagId = "";
  bagValue = new ArrayBuffer(0);
  bagAttributes;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], SafeBag.prototype, "bagId", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.Any,
    context: 0
  })
], SafeBag.prototype, "bagValue", void 0);
__decorate([
  AsnProp({
    type: PKCS12Attribute,
    repeated: "set",
    optional: true
  })
], SafeBag.prototype, "bagAttributes", void 0);
var SafeContents = SafeContents_1 = class SafeContents2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, SafeContents_1.prototype);
  }
};
SafeContents = SafeContents_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: SafeBag
  })
], SafeContents);

// node_modules/@peculiar/asn1-pkcs9/build/es2015/index.js
var ExtensionRequest_1;
var ExtendedCertificateAttributes_1;
var SMIMECapabilities_1;
var id_pkcs9 = "1.2.840.113549.1.9";
var id_pkcs9_mo = `${id_pkcs9}.0`;
var id_pkcs9_oc = `${id_pkcs9}.24`;
var id_pkcs9_at = `${id_pkcs9}.25`;
var id_pkcs9_sx = `${id_pkcs9}.26`;
var id_pkcs9_mr = `${id_pkcs9}.27`;
var id_pkcs9_oc_pkcsEntity = `${id_pkcs9_oc}.1`;
var id_pkcs9_oc_naturalPerson = `${id_pkcs9_oc}.2`;
var id_pkcs9_at_emailAddress = `${id_pkcs9}.1`;
var id_pkcs9_at_unstructuredName = `${id_pkcs9}.2`;
var id_pkcs9_at_contentType = `${id_pkcs9}.3`;
var id_pkcs9_at_messageDigest = `${id_pkcs9}.4`;
var id_pkcs9_at_signingTime = `${id_pkcs9}.5`;
var id_pkcs9_at_counterSignature = `${id_pkcs9}.6`;
var id_pkcs9_at_challengePassword = `${id_pkcs9}.7`;
var id_pkcs9_at_unstructuredAddress = `${id_pkcs9}.8`;
var id_pkcs9_at_extendedCertificateAttributes = `${id_pkcs9}.9`;
var id_pkcs9_at_signingDescription = `${id_pkcs9}.13`;
var id_pkcs9_at_extensionRequest = `${id_pkcs9}.14`;
var id_pkcs9_at_smimeCapabilities = `${id_pkcs9}.15`;
var id_pkcs9_at_friendlyName = `${id_pkcs9}.20`;
var id_pkcs9_at_localKeyId = `${id_pkcs9}.21`;
var id_pkcs9_at_pkcs15Token = `${id_pkcs9_at}.1`;
var id_pkcs9_at_encryptedPrivateKeyInfo = `${id_pkcs9_at}.2`;
var id_pkcs9_at_randomNonce = `${id_pkcs9_at}.3`;
var id_pkcs9_at_sequenceNumber = `${id_pkcs9_at}.4`;
var id_pkcs9_at_pkcs7PDU = `${id_pkcs9_at}.5`;
var id_ietf_at = "1.3.6.1.5.5.7.9";
var id_pkcs9_at_dateOfBirth = `${id_ietf_at}.1`;
var id_pkcs9_at_placeOfBirth = `${id_ietf_at}.2`;
var id_pkcs9_at_gender = `${id_ietf_at}.3`;
var id_pkcs9_at_countryOfCitizenship = `${id_ietf_at}.4`;
var id_pkcs9_at_countryOfResidence = `${id_ietf_at}.5`;
var id_pkcs9_sx_pkcs9String = `${id_pkcs9_sx}.1`;
var id_pkcs9_sx_signingTime = `${id_pkcs9_sx}.2`;
var id_pkcs9_mr_caseIgnoreMatch = `${id_pkcs9_mr}.1`;
var id_pkcs9_mr_signingTimeMatch = `${id_pkcs9_mr}.2`;
var id_smime = `${id_pkcs9}.16`;
var id_certTypes2 = `${id_pkcs9}.22`;
var crlTypes = `${id_pkcs9}.23`;
var id_at_pseudonym = `${id_at}.65`;
var PKCS9String = class PKCS9String2 extends DirectoryString {
  ia5String;
  constructor(params = {}) {
    super(params);
  }
  toString() {
    const o = {};
    o.toString();
    return this.ia5String || super.toString();
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.IA5String })
], PKCS9String.prototype, "ia5String", void 0);
PKCS9String = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], PKCS9String);
var Pkcs7PDU = class Pkcs7PDU2 extends ContentInfo {
};
Pkcs7PDU = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], Pkcs7PDU);
var UserPKCS12 = class UserPKCS122 extends PFX {
};
UserPKCS12 = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], UserPKCS12);
var EncryptedPrivateKeyInfo2 = class EncryptedPrivateKeyInfo3 extends EncryptedPrivateKeyInfo {
};
EncryptedPrivateKeyInfo2 = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], EncryptedPrivateKeyInfo2);
var EmailAddress = class EmailAddress2 {
  value;
  constructor(value = "") {
    this.value = value;
  }
  toString() {
    return this.value;
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.IA5String })
], EmailAddress.prototype, "value", void 0);
EmailAddress = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], EmailAddress);
var UnstructuredName = class UnstructuredName2 extends PKCS9String {
};
UnstructuredName = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], UnstructuredName);
var UnstructuredAddress = class UnstructuredAddress2 extends DirectoryString {
};
UnstructuredAddress = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], UnstructuredAddress);
var DateOfBirth = class DateOfBirth2 {
  value;
  constructor(value = /* @__PURE__ */ new Date()) {
    this.value = value;
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.GeneralizedTime })
], DateOfBirth.prototype, "value", void 0);
DateOfBirth = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], DateOfBirth);
var PlaceOfBirth = class PlaceOfBirth2 extends DirectoryString {
};
PlaceOfBirth = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], PlaceOfBirth);
var Gender = class Gender2 {
  value;
  constructor(value = "M") {
    this.value = value;
  }
  toString() {
    return this.value;
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.PrintableString })
], Gender.prototype, "value", void 0);
Gender = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], Gender);
var CountryOfCitizenship = class CountryOfCitizenship2 {
  value;
  constructor(value = "") {
    this.value = value;
  }
  toString() {
    return this.value;
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.PrintableString })
], CountryOfCitizenship.prototype, "value", void 0);
CountryOfCitizenship = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], CountryOfCitizenship);
var CountryOfResidence = class CountryOfResidence2 extends CountryOfCitizenship {
};
CountryOfResidence = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], CountryOfResidence);
var Pseudonym = class Pseudonym2 extends DirectoryString {
};
Pseudonym = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], Pseudonym);
var ContentType = class ContentType2 {
  value;
  constructor(value = "") {
    this.value = value;
  }
  toString() {
    return this.value;
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.ObjectIdentifier })
], ContentType.prototype, "value", void 0);
ContentType = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], ContentType);
var SigningTime3 = class SigningTime4 extends Time {
};
SigningTime3 = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], SigningTime3);
var SequenceNumber = class SequenceNumber2 {
  value;
  constructor(value = 0) {
    this.value = value;
  }
  toString() {
    return this.value.toString();
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], SequenceNumber.prototype, "value", void 0);
SequenceNumber = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], SequenceNumber);
var CounterSignature3 = class CounterSignature4 extends SignerInfo {
};
CounterSignature3 = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], CounterSignature3);
var ChallengePassword = class ChallengePassword2 extends DirectoryString {
};
ChallengePassword = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], ChallengePassword);
var ExtensionRequest = ExtensionRequest_1 = class ExtensionRequest2 extends Extensions {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, ExtensionRequest_1.prototype);
  }
};
ExtensionRequest = ExtensionRequest_1 = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], ExtensionRequest);
var ExtendedCertificateAttributes = ExtendedCertificateAttributes_1 = class ExtendedCertificateAttributes2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, ExtendedCertificateAttributes_1.prototype);
  }
};
ExtendedCertificateAttributes = ExtendedCertificateAttributes_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Set,
    itemType: Attribute2
  })
], ExtendedCertificateAttributes);
var FriendlyName = class FriendlyName2 {
  value;
  constructor(value = "") {
    this.value = value;
  }
  toString() {
    return this.value;
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.BmpString })
], FriendlyName.prototype, "value", void 0);
FriendlyName = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], FriendlyName);
var SMIMECapability = class SMIMECapability2 extends AlgorithmIdentifier {
};
SMIMECapability = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], SMIMECapability);
var SMIMECapabilities = SMIMECapabilities_1 = class SMIMECapabilities2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, SMIMECapabilities_1.prototype);
  }
};
SMIMECapabilities = SMIMECapabilities_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: SMIMECapability
  })
], SMIMECapabilities);

// node_modules/@peculiar/asn1-x509-post-quantum/build/es2015/composite_signatures.js
var CompositeParams_1;
var CompositeSignatureValue_1;
var CompositeParams = CompositeParams_1 = class CompositeParams2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, CompositeParams_1.prototype);
  }
};
CompositeParams = CompositeParams_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: AlgorithmIdentifier
  })
], CompositeParams);
var CompositeSignatureValue = CompositeSignatureValue_1 = class CompositeSignatureValue2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, CompositeSignatureValue_1.prototype);
  }
};
CompositeSignatureValue = CompositeSignatureValue_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: AsnPropTypes.BitString
  })
], CompositeSignatureValue);

// node_modules/@peculiar/asn1-asym-key/build/es2015/index.js
var AsymmetricKeyPackage_1;
var Version3;
(function(Version5) {
  Version5[Version5["v1"] = 0] = "v1";
  Version5[Version5["v2"] = 1] = "v2";
})(Version3 || (Version3 = {}));
var PrivateKeyAlgorithmIdentifier = class PrivateKeyAlgorithmIdentifier2 extends AlgorithmIdentifier {
};
PrivateKeyAlgorithmIdentifier = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], PrivateKeyAlgorithmIdentifier);
var OneAsymmetricKey = class OneAsymmetricKey2 {
  version = Version3.v1;
  privateKeyAlgorithm = new AlgorithmIdentifier();
  privateKey = new ArrayBuffer(0);
  attributes;
  publicKey;
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], OneAsymmetricKey.prototype, "version", void 0);
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], OneAsymmetricKey.prototype, "privateKeyAlgorithm", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.OctetString })
], OneAsymmetricKey.prototype, "privateKey", void 0);
__decorate([
  AsnProp({
    type: Attributes,
    context: 0,
    implicit: true,
    optional: true
  })
], OneAsymmetricKey.prototype, "attributes", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.BitString,
    context: 1,
    implicit: true,
    optional: true
  })
], OneAsymmetricKey.prototype, "publicKey", void 0);
OneAsymmetricKey = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], OneAsymmetricKey);
var PrivateKeyInfo2 = class PrivateKeyInfo3 extends OneAsymmetricKey {
};
PrivateKeyInfo2 = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], PrivateKeyInfo2);
var AsymmetricKeyPackage = AsymmetricKeyPackage_1 = class AsymmetricKeyPackage2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, AsymmetricKeyPackage_1.prototype);
  }
};
AsymmetricKeyPackage = AsymmetricKeyPackage_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: OneAsymmetricKey
  })
], AsymmetricKeyPackage);

// node_modules/@peculiar/asn1-x509-post-quantum/build/es2015/composite_keys.js
var CompositePublicKey_1;
var CompositePrivateKey_1;
var CompositeAlgorithmIdentifier = class CompositeAlgorithmIdentifier2 extends AlgorithmIdentifier {
};
CompositeAlgorithmIdentifier = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], CompositeAlgorithmIdentifier);
var CompositePublicKey = CompositePublicKey_1 = class CompositePublicKey2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, CompositePublicKey_1.prototype);
  }
};
CompositePublicKey = CompositePublicKey_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: SubjectPublicKeyInfo
  })
], CompositePublicKey);
var CompositePrivateKey = CompositePrivateKey_1 = class CompositePrivateKey2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, CompositePrivateKey_1.prototype);
  }
};
CompositePrivateKey = CompositePrivateKey_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: OneAsymmetricKey
  })
], CompositePrivateKey);

// node_modules/@peculiar/asn1-x509-post-quantum/build/es2015/object_identifiers.js
var id_sigAlgs = "2.16.840.1.101.3.4.3";
var id_ml_dsa_44 = `${id_sigAlgs}.17`;
var id_ml_dsa_65 = `${id_sigAlgs}.18`;
var id_ml_dsa_87 = `${id_sigAlgs}.19`;
var id_slh_dsa_sha2_128s = `${id_sigAlgs}.20`;
var id_slh_dsa_sha2_128f = `${id_sigAlgs}.21`;
var id_slh_dsa_sha2_192s = `${id_sigAlgs}.22`;
var id_slh_dsa_sha2_192f = `${id_sigAlgs}.23`;
var id_slh_dsa_sha2_256s = `${id_sigAlgs}.24`;
var id_slh_dsa_sha2_256f = `${id_sigAlgs}.25`;
var id_slh_dsa_shake_128s = `${id_sigAlgs}.26`;
var id_slh_dsa_shake_128f = `${id_sigAlgs}.27`;
var id_slh_dsa_shake_192s = `${id_sigAlgs}.28`;
var id_slh_dsa_shake_192f = `${id_sigAlgs}.29`;
var id_slh_dsa_shake_256s = `${id_sigAlgs}.30`;
var id_slh_dsa_shake_256f = `${id_sigAlgs}.31`;

// node_modules/@peculiar/asn1-csr/build/es2015/attributes.js
var Attributes_12;
var Attributes3 = Attributes_12 = class Attributes4 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, Attributes_12.prototype);
  }
};
Attributes3 = Attributes_12 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: Attribute
  })
], Attributes3);

// node_modules/@peculiar/asn1-csr/build/es2015/certification_request_info.js
var CertificationRequestInfo = class {
  version = 0;
  subject = new Name();
  subjectPKInfo = new SubjectPublicKeyInfo();
  attributes = new Attributes3();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], CertificationRequestInfo.prototype, "version", void 0);
__decorate([
  AsnProp({ type: Name })
], CertificationRequestInfo.prototype, "subject", void 0);
__decorate([
  AsnProp({ type: SubjectPublicKeyInfo })
], CertificationRequestInfo.prototype, "subjectPKInfo", void 0);
__decorate([
  AsnProp({
    type: Attributes3,
    implicit: true,
    context: 0,
    optional: true
  })
], CertificationRequestInfo.prototype, "attributes", void 0);

// node_modules/@peculiar/asn1-csr/build/es2015/certification_request.js
var CertificationRequest = class {
  certificationRequestInfo = new CertificationRequestInfo();
  certificationRequestInfoRaw;
  signatureAlgorithm = new AlgorithmIdentifier();
  signature = new ArrayBuffer(0);
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: CertificationRequestInfo,
    raw: true
  })
], CertificationRequest.prototype, "certificationRequestInfo", void 0);
__decorate([
  AsnProp({ type: AlgorithmIdentifier })
], CertificationRequest.prototype, "signatureAlgorithm", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.BitString })
], CertificationRequest.prototype, "signature", void 0);

// node_modules/@peculiar/x509/build/x509.es.js
var diAlgorithm = "crypto.algorithm";
var AlgorithmProvider = class {
  getAlgorithms() {
    return instance.resolveAll(diAlgorithm);
  }
  toAsnAlgorithm(alg) {
    const algCopy = { ...alg };
    if (algCopy.hash && typeof algCopy.hash === "string") {
      algCopy.hash = { name: algCopy.hash };
    }
    for (const algorithm of this.getAlgorithms()) {
      const res = algorithm.toAsnAlgorithm(algCopy);
      if (res) {
        return res;
      }
    }
    if (/^[0-9.]+$/.test(alg.name)) {
      const res = new AlgorithmIdentifier({ algorithm: alg.name });
      if ("parameters" in alg) {
        const unknown = alg;
        res.parameters = unknown.parameters;
      }
      return res;
    }
    throw new Error("Cannot convert WebCrypto algorithm to ASN.1 algorithm");
  }
  toWebAlgorithm(alg) {
    for (const algorithm of this.getAlgorithms()) {
      const res = algorithm.toWebAlgorithm(alg);
      if (res) {
        return res;
      }
    }
    const unknown = {
      name: alg.algorithm,
      parameters: alg.parameters
    };
    return unknown;
  }
};
var diAlgorithmProvider = "crypto.algorithmProvider";
instance.registerSingleton(diAlgorithmProvider, AlgorithmProvider);
var EcAlgorithm_1;
var idVersionOne = "1.3.36.3.3.2.8.1.1";
var idBrainpoolP160r1 = `${idVersionOne}.1`;
var idBrainpoolP160t1 = `${idVersionOne}.2`;
var idBrainpoolP192r1 = `${idVersionOne}.3`;
var idBrainpoolP192t1 = `${idVersionOne}.4`;
var idBrainpoolP224r1 = `${idVersionOne}.5`;
var idBrainpoolP224t1 = `${idVersionOne}.6`;
var idBrainpoolP256r1 = `${idVersionOne}.7`;
var idBrainpoolP256t1 = `${idVersionOne}.8`;
var idBrainpoolP320r1 = `${idVersionOne}.9`;
var idBrainpoolP320t1 = `${idVersionOne}.10`;
var idBrainpoolP384r1 = `${idVersionOne}.11`;
var idBrainpoolP384t1 = `${idVersionOne}.12`;
var idBrainpoolP512r1 = `${idVersionOne}.13`;
var idBrainpoolP512t1 = `${idVersionOne}.14`;
var brainpoolP160r1 = "brainpoolP160r1";
var brainpoolP160t1 = "brainpoolP160t1";
var brainpoolP192r1 = "brainpoolP192r1";
var brainpoolP192t1 = "brainpoolP192t1";
var brainpoolP224r1 = "brainpoolP224r1";
var brainpoolP224t1 = "brainpoolP224t1";
var brainpoolP256r1 = "brainpoolP256r1";
var brainpoolP256t1 = "brainpoolP256t1";
var brainpoolP320r1 = "brainpoolP320r1";
var brainpoolP320t1 = "brainpoolP320t1";
var brainpoolP384r1 = "brainpoolP384r1";
var brainpoolP384t1 = "brainpoolP384t1";
var brainpoolP512r1 = "brainpoolP512r1";
var brainpoolP512t1 = "brainpoolP512t1";
var ECDSA = "ECDSA";
var EcAlgorithm = EcAlgorithm_1 = class EcAlgorithm2 {
  toAsnAlgorithm(alg) {
    switch (alg.name.toLowerCase()) {
      case ECDSA.toLowerCase():
        if ("hash" in alg) {
          const hash = typeof alg.hash === "string" ? alg.hash : alg.hash.name;
          switch (hash.toLowerCase()) {
            case "sha-1":
              return ecdsaWithSHA1;
            case "sha-256":
              return ecdsaWithSHA256;
            case "sha-384":
              return ecdsaWithSHA384;
            case "sha-512":
              return ecdsaWithSHA512;
          }
        } else if ("namedCurve" in alg) {
          let parameters = "";
          switch (alg.namedCurve) {
            case "P-256":
              parameters = id_secp256r1;
              break;
            case "K-256":
              parameters = EcAlgorithm_1.SECP256K1;
              break;
            case "P-384":
              parameters = id_secp384r1;
              break;
            case "P-521":
              parameters = id_secp521r1;
              break;
            case brainpoolP160r1:
              parameters = idBrainpoolP160r1;
              break;
            case brainpoolP160t1:
              parameters = idBrainpoolP160t1;
              break;
            case brainpoolP192r1:
              parameters = idBrainpoolP192r1;
              break;
            case brainpoolP192t1:
              parameters = idBrainpoolP192t1;
              break;
            case brainpoolP224r1:
              parameters = idBrainpoolP224r1;
              break;
            case brainpoolP224t1:
              parameters = idBrainpoolP224t1;
              break;
            case brainpoolP256r1:
              parameters = idBrainpoolP256r1;
              break;
            case brainpoolP256t1:
              parameters = idBrainpoolP256t1;
              break;
            case brainpoolP320r1:
              parameters = idBrainpoolP320r1;
              break;
            case brainpoolP320t1:
              parameters = idBrainpoolP320t1;
              break;
            case brainpoolP384r1:
              parameters = idBrainpoolP384r1;
              break;
            case brainpoolP384t1:
              parameters = idBrainpoolP384t1;
              break;
            case brainpoolP512r1:
              parameters = idBrainpoolP512r1;
              break;
            case brainpoolP512t1:
              parameters = idBrainpoolP512t1;
              break;
          }
          if (parameters) {
            return new AlgorithmIdentifier({
              algorithm: id_ecPublicKey,
              parameters: AsnConvert.serialize(new ECParameters({ namedCurve: parameters }))
            });
          }
        }
    }
    return null;
  }
  toWebAlgorithm(alg) {
    switch (alg.algorithm) {
      case id_ecdsaWithSHA1:
        return {
          name: ECDSA,
          hash: { name: "SHA-1" }
        };
      case id_ecdsaWithSHA256:
        return {
          name: ECDSA,
          hash: { name: "SHA-256" }
        };
      case id_ecdsaWithSHA384:
        return {
          name: ECDSA,
          hash: { name: "SHA-384" }
        };
      case id_ecdsaWithSHA512:
        return {
          name: ECDSA,
          hash: { name: "SHA-512" }
        };
      case id_ecPublicKey: {
        if (!alg.parameters) {
          throw new TypeError("Cannot get required parameters from EC algorithm");
        }
        const parameters = AsnConvert.parse(alg.parameters, ECParameters);
        switch (parameters.namedCurve) {
          case id_secp256r1:
            return {
              name: ECDSA,
              namedCurve: "P-256"
            };
          case EcAlgorithm_1.SECP256K1:
            return {
              name: ECDSA,
              namedCurve: "K-256"
            };
          case id_secp384r1:
            return {
              name: ECDSA,
              namedCurve: "P-384"
            };
          case id_secp521r1:
            return {
              name: ECDSA,
              namedCurve: "P-521"
            };
          case idBrainpoolP160r1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP160r1
            };
          case idBrainpoolP160t1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP160t1
            };
          case idBrainpoolP192r1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP192r1
            };
          case idBrainpoolP192t1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP192t1
            };
          case idBrainpoolP224r1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP224r1
            };
          case idBrainpoolP224t1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP224t1
            };
          case idBrainpoolP256r1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP256r1
            };
          case idBrainpoolP256t1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP256t1
            };
          case idBrainpoolP320r1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP320r1
            };
          case idBrainpoolP320t1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP320t1
            };
          case idBrainpoolP384r1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP384r1
            };
          case idBrainpoolP384t1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP384t1
            };
          case idBrainpoolP512r1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP512r1
            };
          case idBrainpoolP512t1:
            return {
              name: ECDSA,
              namedCurve: brainpoolP512t1
            };
        }
      }
    }
    return null;
  }
};
EcAlgorithm.SECP256K1 = "1.3.132.0.10";
EcAlgorithm = EcAlgorithm_1 = __decorate([
  injectable_default()
], EcAlgorithm);
instance.registerSingleton(diAlgorithm, EcAlgorithm);
var NAME2 = /* @__PURE__ */ Symbol("name");
var VALUE = /* @__PURE__ */ Symbol("value");
var TextObject = class {
  constructor(name, items = {}, value = "") {
    this[NAME2] = name;
    this[VALUE] = value;
    for (const key2 in items) {
      this[key2] = items[key2];
    }
  }
};
TextObject.NAME = NAME2;
TextObject.VALUE = VALUE;
var DefaultAlgorithmSerializer = class {
  static toTextObject(alg) {
    const obj = new TextObject("Algorithm Identifier", {}, OidSerializer.toString(alg.algorithm));
    if (alg.parameters) {
      switch (alg.algorithm) {
        case id_ecPublicKey: {
          const ecAlg = new EcAlgorithm().toWebAlgorithm(alg);
          if (ecAlg && "namedCurve" in ecAlg) {
            obj["Named Curve"] = ecAlg.namedCurve;
          } else {
            obj["Parameters"] = alg.parameters;
          }
          break;
        }
        default:
          obj["Parameters"] = alg.parameters;
      }
    }
    return obj;
  }
};
var OidSerializer = class {
  static toString(oid) {
    const name = this.items[oid];
    if (name) {
      return name;
    }
    return oid;
  }
};
OidSerializer.items = {
  [id_sha1]: "sha1",
  [id_sha224]: "sha224",
  [id_sha256]: "sha256",
  [id_sha384]: "sha384",
  [id_sha512]: "sha512",
  [id_rsaEncryption]: "rsaEncryption",
  [id_sha1WithRSAEncryption]: "sha1WithRSAEncryption",
  [id_sha224WithRSAEncryption]: "sha224WithRSAEncryption",
  [id_sha256WithRSAEncryption]: "sha256WithRSAEncryption",
  [id_sha384WithRSAEncryption]: "sha384WithRSAEncryption",
  [id_sha512WithRSAEncryption]: "sha512WithRSAEncryption",
  [id_ecPublicKey]: "ecPublicKey",
  [id_ecdsaWithSHA1]: "ecdsaWithSHA1",
  [id_ecdsaWithSHA224]: "ecdsaWithSHA224",
  [id_ecdsaWithSHA256]: "ecdsaWithSHA256",
  [id_ecdsaWithSHA384]: "ecdsaWithSHA384",
  [id_ecdsaWithSHA512]: "ecdsaWithSHA512",
  [id_kp_serverAuth]: "TLS WWW server authentication",
  [id_kp_clientAuth]: "TLS WWW client authentication",
  [id_kp_codeSigning]: "Code Signing",
  [id_kp_emailProtection]: "E-mail Protection",
  [id_kp_timeStamping]: "Time Stamping",
  [id_kp_OCSPSigning]: "OCSP Signing",
  [id_signedData]: "Signed Data"
};
var TextConverter = class {
  static serialize(obj) {
    return this.serializeObj(obj).join("\n");
  }
  static pad(deep = 0) {
    return "".padStart(2 * deep, " ");
  }
  static serializeObj(obj, deep = 0) {
    const res = [];
    let pad2 = this.pad(deep++);
    let value = "";
    const objValue = obj[TextObject.VALUE];
    if (objValue) {
      value = ` ${objValue}`;
    }
    res.push(`${pad2}${obj[TextObject.NAME]}:${value}`);
    pad2 = this.pad(deep);
    for (const key2 in obj) {
      if (typeof key2 === "symbol") {
        continue;
      }
      const value2 = obj[key2];
      const keyValue = key2 ? `${key2}: ` : "";
      if (typeof value2 === "string" || typeof value2 === "number" || typeof value2 === "boolean") {
        res.push(`${pad2}${keyValue}${value2}`);
      } else if (value2 instanceof Date) {
        res.push(`${pad2}${keyValue}${value2.toUTCString()}`);
      } else if (Array.isArray(value2)) {
        for (const obj2 of value2) {
          obj2[TextObject.NAME] = key2;
          res.push(...this.serializeObj(obj2, deep));
        }
      } else if (value2 instanceof TextObject) {
        value2[TextObject.NAME] = key2;
        res.push(...this.serializeObj(value2, deep));
      } else if (import_pvtsutils.BufferSourceConverter.isBufferSource(value2)) {
        if (key2) {
          res.push(`${pad2}${keyValue}`);
          res.push(...this.serializeBufferSource(value2, deep + 1));
        } else {
          res.push(...this.serializeBufferSource(value2, deep));
        }
      } else if ("toTextObject" in value2) {
        const obj2 = value2.toTextObject();
        obj2[TextObject.NAME] = key2;
        res.push(...this.serializeObj(obj2, deep));
      } else {
        throw new TypeError("Cannot serialize data in text format. Unsupported type.");
      }
    }
    return res;
  }
  static serializeBufferSource(buffer, deep = 0) {
    const pad2 = this.pad(deep);
    const view = import_pvtsutils.BufferSourceConverter.toUint8Array(buffer);
    const res = [];
    for (let i = 0; i < view.length; ) {
      const row = [];
      for (let j = 0; j < 16 && i < view.length; j++) {
        if (j === 8) {
          row.push("");
        }
        const hex2 = view[i++].toString(16).padStart(2, "0");
        row.push(hex2);
      }
      res.push(`${pad2}${row.join(" ")}`);
    }
    return res;
  }
  static serializeAlgorithm(alg) {
    return this.algorithmSerializer.toTextObject(alg);
  }
};
TextConverter.oidSerializer = OidSerializer;
TextConverter.algorithmSerializer = DefaultAlgorithmSerializer;
var _AsnData_rawData;
var _AsnData_options;
var AsnData = class _AsnData {
  get parseOptions() {
    return __classPrivateFieldGet(this, _AsnData_options, "f");
  }
  get rawData() {
    if (!__classPrivateFieldGet(this, _AsnData_rawData, "f")) {
      __classPrivateFieldSet(this, _AsnData_rawData, AsnConvert.serialize(this.asn), "f");
    }
    return __classPrivateFieldGet(this, _AsnData_rawData, "f");
  }
  constructor(...args) {
    _AsnData_rawData.set(this, void 0);
    _AsnData_options.set(this, void 0);
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      __classPrivateFieldSet(this, _AsnData_options, args[2], "f");
      this.asn = AsnConvert.parse(args[0], args[1], args[2]);
      __classPrivateFieldSet(this, _AsnData_rawData, import_pvtsutils.BufferSourceConverter.toArrayBuffer(args[0]), "f");
      this.onInit(this.asn);
    } else {
      __classPrivateFieldSet(this, _AsnData_options, args[1], "f");
      this.asn = args[0];
      this.onInit(this.asn);
    }
  }
  equal(data) {
    if (data instanceof _AsnData) {
      return (0, import_pvtsutils.isEqual)(data.rawData, this.rawData);
    }
    return false;
  }
  toString(format4 = "text") {
    switch (format4) {
      case "asn":
        return AsnConvert.toString(this.rawData, __classPrivateFieldGet(this, _AsnData_options, "f"));
      case "text":
        return TextConverter.serialize(this.toTextObject());
      case "hex":
        return import_pvtsutils.Convert.ToHex(this.rawData);
      case "base64":
        return import_pvtsutils.Convert.ToBase64(this.rawData);
      case "base64url":
        return import_pvtsutils.Convert.ToBase64Url(this.rawData);
      default:
        throw TypeError("Argument 'format' is unsupported value");
    }
  }
  getTextName() {
    const constructor = this.constructor;
    return constructor.NAME;
  }
  toTextObject() {
    const obj = this.toTextObjectEmpty();
    obj[""] = this.rawData;
    return obj;
  }
  toTextObjectEmpty(value) {
    return new TextObject(this.getTextName(), {}, value);
  }
};
_AsnData_rawData = /* @__PURE__ */ new WeakMap(), _AsnData_options = /* @__PURE__ */ new WeakMap();
AsnData.NAME = "ASN";
var Extension2 = class _Extension extends AsnData {
  constructor(...args) {
    let raw;
    let options;
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      raw = import_pvtsutils.BufferSourceConverter.toArrayBuffer(args[0]);
      options = args[1];
    } else {
      raw = AsnConvert.serialize(new Extension({
        extnID: args[0],
        critical: args[1],
        extnValue: new OctetString2(import_pvtsutils.BufferSourceConverter.toArrayBuffer(args[2]))
      }));
    }
    super(raw, Extension, options);
  }
  onInit(asn) {
    this.type = asn.extnID;
    this.critical = asn.critical;
    this.value = asn.extnValue.buffer;
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    obj[""] = this.value;
    return obj;
  }
  toTextObjectWithoutValue() {
    const obj = this.toTextObjectEmpty(this.critical ? "critical" : void 0);
    if (obj[TextObject.NAME] === _Extension.NAME) {
      obj[TextObject.NAME] = OidSerializer.toString(this.type);
    }
    return obj;
  }
};
var _a2;
var CryptoProvider = class _CryptoProvider {
  static isCryptoKeyPair(data) {
    return data && data.privateKey && data.publicKey;
  }
  static isCryptoKey(data) {
    return data && data.usages && data.type && data.algorithm && data.extractable !== void 0;
  }
  constructor() {
    this.items = /* @__PURE__ */ new Map();
    this[_a2] = "CryptoProvider";
    if (typeof self !== "undefined" && typeof crypto !== "undefined") {
      this.set(_CryptoProvider.DEFAULT, crypto);
    } else if (typeof global !== "undefined" && global.crypto && global.crypto.subtle) {
      this.set(_CryptoProvider.DEFAULT, global.crypto);
    }
  }
  clear() {
    this.items.clear();
  }
  delete(key2) {
    return this.items.delete(key2);
  }
  forEach(callbackfn, thisArg) {
    return this.items.forEach(callbackfn, thisArg);
  }
  has(key2) {
    return this.items.has(key2);
  }
  get size() {
    return this.items.size;
  }
  entries() {
    return this.items.entries();
  }
  keys() {
    return this.items.keys();
  }
  values() {
    return this.items.values();
  }
  [Symbol.iterator]() {
    return this.items[Symbol.iterator]();
  }
  get(key2 = _CryptoProvider.DEFAULT) {
    const crypto2 = this.items.get(key2.toLowerCase());
    if (!crypto2) {
      throw new Error(`Cannot get Crypto by name '${key2}'`);
    }
    return crypto2;
  }
  set(key2, value) {
    if (typeof key2 === "string") {
      if (!value) {
        throw new TypeError("Argument 'value' is required");
      }
      this.items.set(key2.toLowerCase(), value);
    } else {
      this.items.set(_CryptoProvider.DEFAULT, key2);
    }
    return this;
  }
};
_a2 = Symbol.toStringTag;
CryptoProvider.DEFAULT = "default";
var cryptoProvider = new CryptoProvider();
var OID_REGEX = /^[0-2](?:\.[1-9][0-9]*)+$/;
function isOID(id) {
  return new RegExp(OID_REGEX).test(id);
}
var NameIdentifier = class {
  constructor(names2 = {}) {
    this.items = {};
    for (const id in names2) {
      this.register(id, names2[id]);
    }
  }
  get(idOrName) {
    return this.items[idOrName] || null;
  }
  findId(idOrName) {
    if (!isOID(idOrName)) {
      return this.get(idOrName);
    }
    return idOrName;
  }
  register(id, name) {
    this.items[id] = name;
    this.items[name] = id;
  }
};
var names = new NameIdentifier();
names.register("CN", "2.5.4.3");
names.register("L", "2.5.4.7");
names.register("ST", "2.5.4.8");
names.register("O", "2.5.4.10");
names.register("OU", "2.5.4.11");
names.register("C", "2.5.4.6");
names.register("DC", "0.9.2342.19200300.100.1.25");
names.register("E", "1.2.840.113549.1.9.1");
names.register("G", "2.5.4.42");
names.register("I", "2.5.4.43");
names.register("SN", "2.5.4.4");
names.register("T", "2.5.4.12");
function replaceUnknownCharacter(text, char) {
  return `\\${import_pvtsutils.Convert.ToHex(import_pvtsutils.Convert.FromUtf8String(char)).toUpperCase()}`;
}
function escape2(data) {
  return data.replace(/([,+"\\<>;])/g, "\\$1").replace(/^([ #])/, "\\$1").replace(/([ ]$)/, "\\$1").replace(/([\r\n\t])/, replaceUnknownCharacter);
}
var Name3 = class _Name {
  static isASCII(text) {
    for (let i = 0; i < text.length; i++) {
      const code = text.charCodeAt(i);
      if (code > 255) {
        return false;
      }
    }
    return true;
  }
  static isPrintableString(text) {
    return /^[A-Za-z0-9 '()+,-./:=?]*$/g.test(text);
  }
  constructor(data, extraNames = {}) {
    this.extraNames = new NameIdentifier();
    this.asn = new Name();
    for (const key2 in extraNames) {
      if (Object.prototype.hasOwnProperty.call(extraNames, key2)) {
        const value = extraNames[key2];
        this.extraNames.register(key2, value);
      }
    }
    if (typeof data === "string") {
      this.asn = this.fromString(data);
    } else if (data instanceof Name) {
      this.asn = data;
    } else if (import_pvtsutils.BufferSourceConverter.isBufferSource(data)) {
      this.asn = AsnConvert.parse(data, Name);
    } else {
      this.asn = this.fromJSON(data);
    }
  }
  getField(idOrName) {
    const id = this.extraNames.findId(idOrName) || names.findId(idOrName);
    const res = [];
    for (const name of this.asn) {
      for (const rdn of name) {
        if (rdn.type === id) {
          res.push(rdn.value.toString());
        }
      }
    }
    return res;
  }
  getName(idOrName) {
    return this.extraNames.get(idOrName) || names.get(idOrName);
  }
  toString() {
    return this.asn.map((rdn) => rdn.map((o) => {
      const type = this.getName(o.type) || o.type;
      const value = o.value.anyValue ? `#${import_pvtsutils.Convert.ToHex(o.value.anyValue)}` : escape2(o.value.toString());
      return `${type}=${value}`;
    }).join("+")).join(", ");
  }
  toJSON() {
    var _a3;
    const json2 = [];
    for (const rdn of this.asn) {
      const jsonItem = {};
      for (const attr of rdn) {
        const type = this.getName(attr.type) || attr.type;
        (_a3 = jsonItem[type]) !== null && _a3 !== void 0 ? _a3 : jsonItem[type] = [];
        jsonItem[type].push(attr.value.anyValue ? `#${import_pvtsutils.Convert.ToHex(attr.value.anyValue)}` : attr.value.toString());
      }
      json2.push(jsonItem);
    }
    return json2;
  }
  fromString(data) {
    const asn = new Name();
    const regex = /(\d\.[\d.]*\d|[A-Za-z]+)=((?:"")|(?:".*?[^\\]")|(?:[^,+"\\](?=[,+]|$))|(?:[^,+].*?(?:[^\\][,+]))|(?:))([,+])?/g;
    let matches = null;
    let level = ",";
    while (matches = regex.exec(`${data},`)) {
      let [, type, value] = matches;
      const lastChar = value[value.length - 1];
      if (lastChar === "," || lastChar === "+") {
        value = value.slice(0, value.length - 1);
        matches[3] = lastChar;
      }
      const next = matches[3];
      type = this.getTypeOid(type);
      const attr = this.createAttribute(type, value);
      if (level === "+") {
        asn[asn.length - 1].push(attr);
      } else {
        asn.push(new RelativeDistinguishedName([attr]));
      }
      level = next;
    }
    return asn;
  }
  fromJSON(data) {
    const asn = new Name();
    for (const item of data) {
      const asnRdn = new RelativeDistinguishedName();
      for (const type in item) {
        const typeId = this.getTypeOid(type);
        const values = item[type];
        for (const value of values) {
          const asnAttr = this.createAttribute(typeId, value);
          asnRdn.push(asnAttr);
        }
      }
      asn.push(asnRdn);
    }
    return asn;
  }
  getTypeOid(type) {
    if (!/[\d.]+/.test(type)) {
      type = this.getName(type) || "";
    }
    if (!type) {
      throw new Error(`Cannot get OID for name type '${type}'`);
    }
    return type;
  }
  createAttribute(type, value) {
    const attr = new AttributeTypeAndValue({ type });
    if (typeof value === "object") {
      for (const key2 in value) {
        switch (key2) {
          case "ia5String":
            attr.value.ia5String = value[key2];
            break;
          case "utf8String":
            attr.value.utf8String = value[key2];
            break;
          case "universalString":
            attr.value.universalString = value[key2];
            break;
          case "bmpString":
            attr.value.bmpString = value[key2];
            break;
          case "printableString":
            attr.value.printableString = value[key2];
            break;
        }
      }
    } else if (value[0] === "#") {
      attr.value.anyValue = import_pvtsutils.Convert.FromHex(value.slice(1));
    } else {
      const processedValue = this.processStringValue(value);
      if (type === this.getName("E") || type === this.getName("DC")) {
        attr.value.ia5String = processedValue;
      } else {
        if (_Name.isPrintableString(processedValue)) {
          attr.value.printableString = processedValue;
        } else {
          attr.value.utf8String = processedValue;
        }
      }
    }
    return attr;
  }
  processStringValue(value) {
    const quotedMatches = /"(.*?[^\\])?"/.exec(value);
    if (quotedMatches) {
      value = quotedMatches[1];
    }
    return value.replace(/\\0a/gi, "\n").replace(/\\0d/gi, "\r").replace(/\\0g/gi, "	").replace(/\\(.)/g, "$1");
  }
  toArrayBuffer() {
    return AsnConvert.serialize(this.asn);
  }
  async getThumbprint(arg1, arg2) {
    let crypto2;
    let algorithm = "SHA-1";
    if (arg1) {
      if (typeof arg1 === "object" && "subtle" in arg1) {
        crypto2 = arg1;
      } else {
        algorithm = arg1;
        crypto2 = arg2;
      }
    }
    crypto2 !== null && crypto2 !== void 0 ? crypto2 : crypto2 = cryptoProvider.get();
    return await crypto2.subtle.digest(algorithm, this.toArrayBuffer());
  }
};
var ERR_GN_CONSTRUCTOR = "Cannot initialize GeneralName from ASN.1 data.";
var ERR_GN_STRING_FORMAT = `${ERR_GN_CONSTRUCTOR} Unsupported string format in use.`;
var ERR_GUID = `${ERR_GN_CONSTRUCTOR} Value doesn't match to GUID regular expression.`;
var GUID_REGEX = /^([0-9a-f]{8})-?([0-9a-f]{4})-?([0-9a-f]{4})-?([0-9a-f]{4})-?([0-9a-f]{12})$/i;
var id_GUID = "1.3.6.1.4.1.311.25.1";
var id_UPN = "1.3.6.1.4.1.311.20.2.3";
var DNS = "dns";
var DN = "dn";
var EMAIL = "email";
var IP = "ip";
var URL2 = "url";
var GUID = "guid";
var UPN = "upn";
var REGISTERED_ID = "id";
var GeneralName3 = class extends AsnData {
  constructor(...args) {
    let name;
    if (args.length === 2) {
      switch (args[0]) {
        case DN: {
          const derName = new Name3(args[1]).toArrayBuffer();
          const asnName = AsnConvert.parse(derName, Name);
          name = new GeneralName({ directoryName: asnName });
          break;
        }
        case DNS:
          name = new GeneralName({ dNSName: args[1] });
          break;
        case EMAIL:
          name = new GeneralName({ rfc822Name: args[1] });
          break;
        case GUID: {
          const matches = new RegExp(GUID_REGEX, "i").exec(args[1]);
          if (!matches) {
            throw new Error("Cannot parse GUID value. Value doesn't match to regular expression");
          }
          const hex2 = matches.slice(1).map((o, i) => {
            if (i < 3) {
              return import_pvtsutils.Convert.ToHex(new Uint8Array(import_pvtsutils.Convert.FromHex(o)).reverse());
            }
            return o;
          }).join("");
          name = new GeneralName({
            otherName: new OtherName({
              typeId: id_GUID,
              value: AsnConvert.serialize(new OctetString2(import_pvtsutils.Convert.FromHex(hex2)))
            })
          });
          break;
        }
        case IP:
          name = new GeneralName({ iPAddress: args[1] });
          break;
        case REGISTERED_ID:
          name = new GeneralName({ registeredID: args[1] });
          break;
        case UPN: {
          name = new GeneralName({
            otherName: new OtherName({
              typeId: id_UPN,
              value: AsnConvert.serialize(AsnUtf8StringConverter.toASN(args[1]))
            })
          });
          break;
        }
        case URL2:
          name = new GeneralName({ uniformResourceIdentifier: args[1] });
          break;
        default:
          throw new Error("Cannot create GeneralName. Unsupported type of the name");
      }
    } else if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      name = AsnConvert.parse(args[0], GeneralName);
    } else {
      name = args[0];
    }
    super(name);
  }
  onInit(asn) {
    if (asn.dNSName != void 0) {
      this.type = DNS;
      this.value = asn.dNSName;
    } else if (asn.rfc822Name != void 0) {
      this.type = EMAIL;
      this.value = asn.rfc822Name;
    } else if (asn.iPAddress != void 0) {
      this.type = IP;
      this.value = asn.iPAddress;
    } else if (asn.uniformResourceIdentifier != void 0) {
      this.type = URL2;
      this.value = asn.uniformResourceIdentifier;
    } else if (asn.registeredID != void 0) {
      this.type = REGISTERED_ID;
      this.value = asn.registeredID;
    } else if (asn.directoryName != void 0) {
      this.type = DN;
      this.value = new Name3(asn.directoryName).toString();
    } else if (asn.otherName != void 0) {
      if (asn.otherName.typeId === id_GUID) {
        this.type = GUID;
        const guid = AsnConvert.parse(asn.otherName.value, OctetString2);
        const matches = new RegExp(GUID_REGEX, "i").exec(import_pvtsutils.Convert.ToHex(guid));
        if (!matches) {
          throw new Error(ERR_GUID);
        }
        this.value = matches.slice(1).map((o, i) => {
          if (i < 3) {
            return import_pvtsutils.Convert.ToHex(new Uint8Array(import_pvtsutils.Convert.FromHex(o)).reverse());
          }
          return o;
        }).join("-");
      } else if (asn.otherName.typeId === id_UPN) {
        this.type = UPN;
        this.value = AsnConvert.parse(asn.otherName.value, DirectoryString).toString();
      } else {
        throw new Error(ERR_GN_STRING_FORMAT);
      }
    } else {
      throw new Error(ERR_GN_STRING_FORMAT);
    }
  }
  toJSON() {
    return {
      type: this.type,
      value: this.value
    };
  }
  toTextObject() {
    let type;
    switch (this.type) {
      case DN:
      case DNS:
      case GUID:
      case IP:
      case REGISTERED_ID:
      case UPN:
      case URL2:
        type = this.type.toUpperCase();
        break;
      case EMAIL:
        type = "Email";
        break;
      default:
        throw new Error("Unsupported GeneralName type");
    }
    let value = this.value;
    if (this.type === REGISTERED_ID) {
      value = OidSerializer.toString(value);
    }
    return new TextObject(type, void 0, value);
  }
};
var GeneralNames3 = class extends AsnData {
  constructor(params) {
    let names2;
    if (params instanceof GeneralNames) {
      names2 = params;
    } else if (Array.isArray(params)) {
      const items = [];
      for (const name of params) {
        if (name instanceof GeneralName) {
          items.push(name);
        } else {
          const asnName = AsnConvert.parse(new GeneralName3(name.type, name.value).rawData, GeneralName);
          items.push(asnName);
        }
      }
      names2 = new GeneralNames(items);
    } else if (import_pvtsutils.BufferSourceConverter.isBufferSource(params)) {
      names2 = AsnConvert.parse(params, GeneralNames);
    } else {
      throw new Error("Cannot initialize GeneralNames. Incorrect incoming arguments");
    }
    super(names2);
  }
  onInit(asn) {
    const items = [];
    for (const asnName of asn) {
      let name = null;
      try {
        name = new GeneralName3(asnName);
      } catch {
        continue;
      }
      items.push(name);
    }
    this.items = items;
  }
  toJSON() {
    return this.items.map((o) => o.toJSON());
  }
  toTextObject() {
    const res = super.toTextObjectEmpty();
    for (const name of this.items) {
      const nameObj = name.toTextObject();
      let field = res[nameObj[TextObject.NAME]];
      if (!Array.isArray(field)) {
        field = [];
        res[nameObj[TextObject.NAME]] = field;
      }
      field.push(nameObj);
    }
    return res;
  }
};
GeneralNames3.NAME = "GeneralNames";
var rPaddingTag = "-{5}";
var rEolChars = "\\n";
var rNameTag = `[^${rEolChars}]+`;
var rBeginTag = `${rPaddingTag}BEGIN (${rNameTag}(?=${rPaddingTag}))${rPaddingTag}`;
var rEndTag = `${rPaddingTag}END \\1${rPaddingTag}`;
var rEolGroup = "\\n";
var rHeaderKey = `[^:${rEolChars}]+`;
var rHeaderValue = `(?:[^${rEolChars}]+${rEolGroup}(?: +[^${rEolChars}]+${rEolGroup})*)`;
var rBase64Chars = "[a-zA-Z0-9=+/]+";
var rBase64 = `(?:${rBase64Chars}${rEolGroup})+`;
var rPem = `${rBeginTag}${rEolGroup}(?:((?:${rHeaderKey}: ${rHeaderValue})+))?${rEolGroup}?(${rBase64})${rEndTag}`;
var rEolPattern = new RegExp(`[${rEolChars}]+`, "g");
var PemConverter = class {
  static isPem(data) {
    return typeof data === "string" && new RegExp(rPem, "g").test(data.replace(/\r/g, ""));
  }
  static decodeWithHeaders(pem2) {
    pem2 = pem2.replace(/\r/g, "");
    const pattern = new RegExp(rPem, "g");
    const res = [];
    let matches = null;
    while (matches = pattern.exec(pem2)) {
      const base644 = matches[3].replace(rEolPattern, "");
      const pemStruct = {
        type: matches[1],
        headers: [],
        rawData: import_pvtsutils.Convert.FromBase64(base644)
      };
      const headersString = matches[2];
      if (headersString) {
        const headers2 = headersString.split(new RegExp(rEolGroup, "g"));
        let lastHeader = null;
        for (const header of headers2) {
          const [key2, value] = header.split(/:(.*)/);
          if (value === void 0) {
            if (!lastHeader) {
              throw new Error("Cannot parse PEM string. Incorrect header value");
            }
            lastHeader.value += key2.trim();
          } else {
            if (lastHeader) {
              pemStruct.headers.push(lastHeader);
            }
            lastHeader = {
              key: key2,
              value: value.trim()
            };
          }
        }
        if (lastHeader) {
          pemStruct.headers.push(lastHeader);
        }
      }
      res.push(pemStruct);
    }
    return res;
  }
  static decode(pem2) {
    const blocks = this.decodeWithHeaders(pem2);
    return blocks.map((o) => o.rawData);
  }
  static decodeFirst(pem2) {
    const items = this.decode(pem2);
    if (!items.length) {
      throw new RangeError("PEM string doesn't contain any objects");
    }
    return items[0];
  }
  static encode(rawData, tag) {
    if (Array.isArray(rawData)) {
      const raws = new Array();
      if (tag) {
        rawData.forEach((element) => {
          if (!import_pvtsutils.BufferSourceConverter.isBufferSource(element)) {
            throw new TypeError("Cannot encode array of BufferSource in PEM format. Not all items of the array are BufferSource");
          }
          raws.push(this.encodeStruct({
            type: tag,
            rawData: import_pvtsutils.BufferSourceConverter.toArrayBuffer(element)
          }));
        });
      } else {
        rawData.forEach((element) => {
          if (!("type" in element)) {
            throw new TypeError("Cannot encode array of PemStruct in PEM format. Not all items of the array are PemStrut");
          }
          raws.push(this.encodeStruct(element));
        });
      }
      return raws.join("\n");
    } else {
      if (!tag) {
        throw new Error("Required argument 'tag' is missed");
      }
      return this.encodeStruct({
        type: tag,
        rawData: import_pvtsutils.BufferSourceConverter.toArrayBuffer(rawData)
      });
    }
  }
  static encodeStruct(pem2) {
    var _a3;
    const upperCaseType = pem2.type.toLocaleUpperCase();
    const res = [];
    res.push(`-----BEGIN ${upperCaseType}-----`);
    if ((_a3 = pem2.headers) === null || _a3 === void 0 ? void 0 : _a3.length) {
      for (const header of pem2.headers) {
        res.push(`${header.key}: ${header.value}`);
      }
      res.push("");
    }
    const base644 = import_pvtsutils.Convert.ToBase64(pem2.rawData);
    for (let i = 0; i < base644.length; i += 64) {
      res.push(base644.substring(i, i + 64));
    }
    res.push(`-----END ${upperCaseType}-----`);
    return res.join("\n");
  }
};
PemConverter.CertificateTag = "CERTIFICATE";
PemConverter.CrlTag = "CRL";
PemConverter.CertificateRequestTag = "CERTIFICATE REQUEST";
PemConverter.PublicKeyTag = "PUBLIC KEY";
PemConverter.PrivateKeyTag = "PRIVATE KEY";
var PemData = class _PemData extends AsnData {
  static isAsnEncoded(data) {
    return import_pvtsutils.BufferSourceConverter.isBufferSource(data) || typeof data === "string";
  }
  static toArrayBuffer(raw) {
    if (typeof raw === "string") {
      if (PemConverter.isPem(raw)) {
        return PemConverter.decode(raw)[0];
      } else if (import_pvtsutils.Convert.isHex(raw)) {
        return import_pvtsutils.Convert.FromHex(raw);
      } else if (import_pvtsutils.Convert.isBase64(raw)) {
        return import_pvtsutils.Convert.FromBase64(raw);
      } else if (import_pvtsutils.Convert.isBase64Url(raw)) {
        return import_pvtsutils.Convert.FromBase64Url(raw);
      } else {
        throw new TypeError("Unsupported format of 'raw' argument. Must be one of DER, PEM, HEX, Base64, or Base4Url");
      }
    } else {
      const buffer = import_pvtsutils.BufferSourceConverter.toUint8Array(raw);
      if (buffer.length > 0 && buffer[0] === 48) {
        return import_pvtsutils.BufferSourceConverter.toArrayBuffer(raw);
      }
      const stringRaw = import_pvtsutils.Convert.ToBinary(raw);
      if (PemConverter.isPem(stringRaw)) {
        return PemConverter.decode(stringRaw)[0];
      } else if (import_pvtsutils.Convert.isHex(stringRaw)) {
        return import_pvtsutils.Convert.FromHex(stringRaw);
      } else if (import_pvtsutils.Convert.isBase64(stringRaw)) {
        return import_pvtsutils.Convert.FromBase64(stringRaw);
      } else if (import_pvtsutils.Convert.isBase64Url(stringRaw)) {
        return import_pvtsutils.Convert.FromBase64Url(stringRaw);
      }
      throw new TypeError("Unsupported format of 'raw' argument. Must be one of DER, PEM, HEX, Base64, or Base4Url");
    }
  }
  constructor(...args) {
    if (_PemData.isAsnEncoded(args[0])) {
      super(_PemData.toArrayBuffer(args[0]), args[1], args[2]);
    } else {
      super(args[0], args[1]);
    }
  }
  toString(format4 = "pem") {
    switch (format4) {
      case "pem":
        return PemConverter.encode(this.rawData, this.tag);
      default:
        return super.toString(format4);
    }
  }
};
var PublicKey = class _PublicKey extends PemData {
  static async create(data, crypto2 = cryptoProvider.get()) {
    if (data instanceof _PublicKey) {
      return data;
    } else if (CryptoProvider.isCryptoKey(data)) {
      if (data.type !== "public") {
        throw new TypeError("Public key is required");
      }
      const spki = await crypto2.subtle.exportKey("spki", data);
      return new _PublicKey(spki);
    } else if (data.publicKey) {
      return data.publicKey;
    } else if (import_pvtsutils.BufferSourceConverter.isBufferSource(data)) {
      return new _PublicKey(data);
    } else {
      throw new TypeError("Unsupported PublicKeyType");
    }
  }
  constructor(param, options) {
    if (PemData.isAsnEncoded(param)) {
      super(param, SubjectPublicKeyInfo, options);
    } else {
      super(param, options);
    }
    this.tag = PemConverter.PublicKeyTag;
  }
  async export(arg1, arg2, arg3) {
    let crypto2;
    let keyUsages = ["verify"];
    let algorithm = {
      hash: "SHA-256",
      ...this.algorithm
    };
    if (arg2) {
      algorithm = arg1;
      keyUsages = arg2;
      crypto2 = arg3;
    } else {
      crypto2 = arg1;
    }
    crypto2 !== null && crypto2 !== void 0 ? crypto2 : crypto2 = cryptoProvider.get();
    let raw = this.rawData;
    const asnSpki = AsnConvert.parse(this.rawData, SubjectPublicKeyInfo, this.parseOptions);
    if (asnSpki.algorithm.algorithm === id_RSASSA_PSS) {
      raw = convertSpkiToRsaPkcs1(asnSpki, raw);
    }
    return crypto2.subtle.importKey("spki", raw, algorithm, true, keyUsages);
  }
  onInit(asn) {
    const algProv = instance.resolve(diAlgorithmProvider);
    const algorithm = this.algorithm = algProv.toWebAlgorithm(asn.algorithm);
    switch (asn.algorithm.algorithm) {
      case id_rsaEncryption: {
        const rsaPublicKey = AsnConvert.parse(asn.subjectPublicKey, RSAPublicKey, this.parseOptions);
        const modulus = import_pvtsutils.BufferSourceConverter.toUint8Array(rsaPublicKey.modulus);
        algorithm.publicExponent = import_pvtsutils.BufferSourceConverter.toUint8Array(rsaPublicKey.publicExponent);
        algorithm.modulusLength = (!modulus[0] ? modulus.slice(1) : modulus).byteLength << 3;
        break;
      }
    }
  }
  async getThumbprint(arg1, arg2) {
    let crypto2;
    let algorithm = "SHA-1";
    if (arg1) {
      if (typeof arg1 === "object" && "subtle" in arg1) {
        crypto2 = arg1;
      } else {
        algorithm = arg1;
        crypto2 = arg2;
      }
    }
    crypto2 !== null && crypto2 !== void 0 ? crypto2 : crypto2 = cryptoProvider.get();
    return await crypto2.subtle.digest(algorithm, this.rawData);
  }
  async getKeyIdentifier(arg1, arg2) {
    let crypto2;
    let algorithm = "SHA-1";
    if (arg1) {
      if (typeof arg1 === "object" && "subtle" in arg1) {
        crypto2 = arg1;
      } else {
        algorithm = arg1;
        crypto2 = arg2;
      }
    }
    crypto2 !== null && crypto2 !== void 0 ? crypto2 : crypto2 = cryptoProvider.get();
    const asn = AsnConvert.parse(this.rawData, SubjectPublicKeyInfo, this.parseOptions);
    return await crypto2.subtle.digest(algorithm, asn.subjectPublicKey);
  }
  toTextObject() {
    const obj = this.toTextObjectEmpty();
    const asn = AsnConvert.parse(this.rawData, SubjectPublicKeyInfo, this.parseOptions);
    obj["Algorithm"] = TextConverter.serializeAlgorithm(asn.algorithm);
    switch (asn.algorithm.algorithm) {
      case id_ecPublicKey:
        obj["EC Point"] = asn.subjectPublicKey;
        break;
      case id_rsaEncryption:
      default:
        obj["Raw Data"] = asn.subjectPublicKey;
    }
    return obj;
  }
};
function convertSpkiToRsaPkcs1(asnSpki, raw) {
  asnSpki.algorithm = new AlgorithmIdentifier({
    algorithm: id_rsaEncryption,
    parameters: null
  });
  raw = AsnConvert.serialize(asnSpki);
  return raw;
}
var AuthorityKeyIdentifierExtension = class _AuthorityKeyIdentifierExtension extends Extension2 {
  static async create(param, critical = false, crypto2 = cryptoProvider.get()) {
    if ("name" in param && "serialNumber" in param) {
      return new _AuthorityKeyIdentifierExtension(param, critical);
    }
    const key2 = await PublicKey.create(param, crypto2);
    const id = await key2.getKeyIdentifier(crypto2);
    return new _AuthorityKeyIdentifierExtension(import_pvtsutils.Convert.ToHex(id), critical);
  }
  constructor(...args) {
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
    } else if (typeof args[0] === "string") {
      const value = new AuthorityKeyIdentifier({
        keyIdentifier: new KeyIdentifier(import_pvtsutils.Convert.FromHex(args[0]))
      });
      super(id_ce_authorityKeyIdentifier, args[1], AsnConvert.serialize(value));
    } else {
      const certId = args[0];
      const certIdName = certId.name instanceof GeneralNames3 ? AsnConvert.parse(certId.name.rawData, GeneralNames) : certId.name;
      const value = new AuthorityKeyIdentifier({
        authorityCertIssuer: certIdName,
        authorityCertSerialNumber: import_pvtsutils.Convert.FromHex(certId.serialNumber)
      });
      super(id_ce_authorityKeyIdentifier, args[1], AsnConvert.serialize(value));
    }
  }
  onInit(asn) {
    super.onInit(asn);
    const aki = AsnConvert.parse(asn.extnValue, AuthorityKeyIdentifier, this.parseOptions);
    if (aki.keyIdentifier) {
      this.keyId = import_pvtsutils.Convert.ToHex(aki.keyIdentifier);
    }
    if (aki.authorityCertIssuer || aki.authorityCertSerialNumber) {
      this.certId = {
        name: aki.authorityCertIssuer || [],
        serialNumber: aki.authorityCertSerialNumber ? import_pvtsutils.Convert.ToHex(aki.authorityCertSerialNumber) : ""
      };
    }
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    const asn = AsnConvert.parse(this.value, AuthorityKeyIdentifier, this.parseOptions);
    if (asn.authorityCertIssuer) {
      obj["Authority Issuer"] = new GeneralNames3(asn.authorityCertIssuer).toTextObject();
    }
    if (asn.authorityCertSerialNumber) {
      obj["Authority Serial Number"] = asn.authorityCertSerialNumber;
    }
    if (asn.keyIdentifier) {
      obj[""] = asn.keyIdentifier;
    }
    return obj;
  }
};
AuthorityKeyIdentifierExtension.NAME = "Authority Key Identifier";
var BasicConstraintsExtension = class extends Extension2 {
  constructor(...args) {
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
      const value = AsnConvert.parse(this.value, BasicConstraints, this.parseOptions);
      this.ca = value.cA;
      this.pathLength = value.pathLenConstraint;
    } else {
      const value = new BasicConstraints({
        cA: args[0],
        pathLenConstraint: args[1]
      });
      super(id_ce_basicConstraints, args[2], AsnConvert.serialize(value));
      this.ca = args[0];
      this.pathLength = args[1];
    }
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    if (this.ca) {
      obj["CA"] = this.ca;
    }
    if (this.pathLength !== void 0) {
      obj["Path Length"] = this.pathLength;
    }
    return obj;
  }
};
BasicConstraintsExtension.NAME = "Basic Constraints";
var ExtendedKeyUsage3;
(function(ExtendedKeyUsage4) {
  ExtendedKeyUsage4["serverAuth"] = "1.3.6.1.5.5.7.3.1";
  ExtendedKeyUsage4["clientAuth"] = "1.3.6.1.5.5.7.3.2";
  ExtendedKeyUsage4["codeSigning"] = "1.3.6.1.5.5.7.3.3";
  ExtendedKeyUsage4["emailProtection"] = "1.3.6.1.5.5.7.3.4";
  ExtendedKeyUsage4["timeStamping"] = "1.3.6.1.5.5.7.3.8";
  ExtendedKeyUsage4["ocspSigning"] = "1.3.6.1.5.5.7.3.9";
})(ExtendedKeyUsage3 || (ExtendedKeyUsage3 = {}));
var ExtendedKeyUsageExtension = class extends Extension2 {
  constructor(...args) {
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
      const value = AsnConvert.parse(this.value, ExtendedKeyUsage, this.parseOptions);
      this.usages = value.map((o) => o);
    } else {
      const value = new ExtendedKeyUsage(args[0]);
      super(id_ce_extKeyUsage, args[1], AsnConvert.serialize(value));
      this.usages = args[0];
    }
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    obj[""] = this.usages.map((o) => OidSerializer.toString(o)).join(", ");
    return obj;
  }
};
ExtendedKeyUsageExtension.NAME = "Extended Key Usages";
var KeyUsageFlags2;
(function(KeyUsageFlags3) {
  KeyUsageFlags3[KeyUsageFlags3["digitalSignature"] = 1] = "digitalSignature";
  KeyUsageFlags3[KeyUsageFlags3["nonRepudiation"] = 2] = "nonRepudiation";
  KeyUsageFlags3[KeyUsageFlags3["keyEncipherment"] = 4] = "keyEncipherment";
  KeyUsageFlags3[KeyUsageFlags3["dataEncipherment"] = 8] = "dataEncipherment";
  KeyUsageFlags3[KeyUsageFlags3["keyAgreement"] = 16] = "keyAgreement";
  KeyUsageFlags3[KeyUsageFlags3["keyCertSign"] = 32] = "keyCertSign";
  KeyUsageFlags3[KeyUsageFlags3["cRLSign"] = 64] = "cRLSign";
  KeyUsageFlags3[KeyUsageFlags3["encipherOnly"] = 128] = "encipherOnly";
  KeyUsageFlags3[KeyUsageFlags3["decipherOnly"] = 256] = "decipherOnly";
})(KeyUsageFlags2 || (KeyUsageFlags2 = {}));
var KeyUsagesExtension = class extends Extension2 {
  constructor(...args) {
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
      const value = AsnConvert.parse(this.value, KeyUsage, this.parseOptions);
      this.usages = value.toNumber();
    } else {
      const value = new KeyUsage(args[0]);
      super(id_ce_keyUsage, args[1], AsnConvert.serialize(value));
      this.usages = args[0];
    }
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    const asn = AsnConvert.parse(this.value, KeyUsage, this.parseOptions);
    obj[""] = asn.toJSON().join(", ");
    return obj;
  }
};
KeyUsagesExtension.NAME = "Key Usages";
var SubjectKeyIdentifierExtension = class _SubjectKeyIdentifierExtension extends Extension2 {
  static async create(publicKey, critical = false, crypto2 = cryptoProvider.get()) {
    const key2 = await PublicKey.create(publicKey, crypto2);
    const id = await key2.getKeyIdentifier(crypto2);
    return new _SubjectKeyIdentifierExtension(import_pvtsutils.Convert.ToHex(id), critical);
  }
  constructor(...args) {
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
      const value = AsnConvert.parse(this.value, SubjectKeyIdentifier, this.parseOptions);
      this.keyId = import_pvtsutils.Convert.ToHex(value);
    } else {
      const identifier = typeof args[0] === "string" ? import_pvtsutils.Convert.FromHex(args[0]) : args[0];
      const value = new SubjectKeyIdentifier(identifier);
      super(id_ce_subjectKeyIdentifier, args[1], AsnConvert.serialize(value));
      this.keyId = import_pvtsutils.Convert.ToHex(identifier);
    }
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    const asn = AsnConvert.parse(this.value, SubjectKeyIdentifier, this.parseOptions);
    obj[""] = asn;
    return obj;
  }
};
SubjectKeyIdentifierExtension.NAME = "Subject Key Identifier";
var SubjectAlternativeNameExtension = class extends Extension2 {
  constructor(...args) {
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
    } else {
      super(id_ce_subjectAltName, args[1], new GeneralNames3(args[0] || []).rawData);
    }
  }
  onInit(asn) {
    super.onInit(asn);
    const value = AsnConvert.parse(asn.extnValue, SubjectAlternativeName, this.parseOptions);
    this.names = new GeneralNames3(value);
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    const namesObj = this.names.toTextObject();
    for (const key2 in namesObj) {
      obj[key2] = namesObj[key2];
    }
    return obj;
  }
};
SubjectAlternativeNameExtension.NAME = "Subject Alternative Name";
var ExtensionFactory = class {
  static register(id, type) {
    this.items.set(id, type);
  }
  static create(data, options) {
    const extension = new Extension2(data, options);
    const Type = this.items.get(extension.type);
    if (Type) {
      return new Type(data, options);
    }
    return extension;
  }
};
ExtensionFactory.items = /* @__PURE__ */ new Map();
var CertificatePolicyExtension = class extends Extension2 {
  constructor(...args) {
    var _a3;
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
      const asnPolicies = AsnConvert.parse(this.value, CertificatePolicies, this.parseOptions);
      this.policies = asnPolicies.map((o) => o.policyIdentifier);
    } else {
      const policies = args[0];
      const critical = (_a3 = args[1]) !== null && _a3 !== void 0 ? _a3 : false;
      const value = new CertificatePolicies(policies.map((o) => new PolicyInformation({ policyIdentifier: o })));
      super(id_ce_certificatePolicies, critical, AsnConvert.serialize(value));
      this.policies = policies;
    }
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    obj["Policy"] = this.policies.map((o) => new TextObject("", {}, OidSerializer.toString(o)));
    return obj;
  }
};
CertificatePolicyExtension.NAME = "Certificate Policies";
ExtensionFactory.register(id_ce_certificatePolicies, CertificatePolicyExtension);
var CRLDistributionPointsExtension = class extends Extension2 {
  constructor(...args) {
    var _a3;
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
    } else if (Array.isArray(args[0]) && typeof args[0][0] === "string") {
      const urls = args[0];
      const dps = urls.map((url) => {
        return new DistributionPoint({
          distributionPoint: new DistributionPointName({
            fullName: [new GeneralName({ uniformResourceIdentifier: url })]
          })
        });
      });
      const value = new CRLDistributionPoints(dps);
      super(id_ce_cRLDistributionPoints, args[1], AsnConvert.serialize(value));
    } else {
      const value = new CRLDistributionPoints(args[0]);
      super(id_ce_cRLDistributionPoints, args[1], AsnConvert.serialize(value));
    }
    (_a3 = this.distributionPoints) !== null && _a3 !== void 0 ? _a3 : this.distributionPoints = [];
  }
  onInit(asn) {
    super.onInit(asn);
    const crlExt = AsnConvert.parse(asn.extnValue, CRLDistributionPoints, this.parseOptions);
    this.distributionPoints = crlExt;
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    obj["Distribution Point"] = this.distributionPoints.map((dp) => {
      var _a3;
      const dpObj = new TextObject("");
      if ((_a3 = dp.distributionPoint) === null || _a3 === void 0 ? void 0 : _a3.fullName) {
        dpObj[""] = dp.distributionPoint.fullName.map((name) => new GeneralName3(name).toString()).join(", ");
      }
      if (dp.reasons) {
        dpObj["Reasons"] = dp.reasons.toString();
      }
      if (dp.cRLIssuer) {
        dpObj["CRL Issuer"] = dp.cRLIssuer.map((issuer) => issuer.toString()).join(", ");
      }
      return dpObj;
    });
    return obj;
  }
};
CRLDistributionPointsExtension.NAME = "CRL Distribution Points";
var AuthorityInfoAccessExtension = class extends Extension2 {
  constructor(...args) {
    var _a3, _b, _c, _d;
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
    } else if (args[0] instanceof AuthorityInfoAccessSyntax) {
      const value = new AuthorityInfoAccessSyntax(args[0]);
      super(id_pe_authorityInfoAccess, args[1], AsnConvert.serialize(value));
    } else {
      const params = args[0];
      const value = new AuthorityInfoAccessSyntax();
      addAccessDescriptions(value, params, id_ad_ocsp, "ocsp");
      addAccessDescriptions(value, params, id_ad_caIssuers, "caIssuers");
      addAccessDescriptions(value, params, id_ad_timeStamping, "timeStamping");
      addAccessDescriptions(value, params, id_ad_caRepository, "caRepository");
      super(id_pe_authorityInfoAccess, args[1], AsnConvert.serialize(value));
    }
    (_a3 = this.ocsp) !== null && _a3 !== void 0 ? _a3 : this.ocsp = [];
    (_b = this.caIssuers) !== null && _b !== void 0 ? _b : this.caIssuers = [];
    (_c = this.timeStamping) !== null && _c !== void 0 ? _c : this.timeStamping = [];
    (_d = this.caRepository) !== null && _d !== void 0 ? _d : this.caRepository = [];
  }
  onInit(asn) {
    super.onInit(asn);
    this.ocsp = [];
    this.caIssuers = [];
    this.timeStamping = [];
    this.caRepository = [];
    const aia = AsnConvert.parse(asn.extnValue, AuthorityInfoAccessSyntax, this.parseOptions);
    aia.forEach((accessDescription) => {
      switch (accessDescription.accessMethod) {
        case id_ad_ocsp:
          this.ocsp.push(new GeneralName3(accessDescription.accessLocation));
          break;
        case id_ad_caIssuers:
          this.caIssuers.push(new GeneralName3(accessDescription.accessLocation));
          break;
        case id_ad_timeStamping:
          this.timeStamping.push(new GeneralName3(accessDescription.accessLocation));
          break;
        case id_ad_caRepository:
          this.caRepository.push(new GeneralName3(accessDescription.accessLocation));
          break;
      }
    });
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    if (this.ocsp.length) {
      addUrlsToObject(obj, "OCSP", this.ocsp);
    }
    if (this.caIssuers.length) {
      addUrlsToObject(obj, "CA Issuers", this.caIssuers);
    }
    if (this.timeStamping.length) {
      addUrlsToObject(obj, "Time Stamping", this.timeStamping);
    }
    if (this.caRepository.length) {
      addUrlsToObject(obj, "CA Repository", this.caRepository);
    }
    return obj;
  }
};
AuthorityInfoAccessExtension.NAME = "Authority Info Access";
function addUrlsToObject(obj, key2, urls) {
  if (urls.length === 1) {
    obj[key2] = urls[0].toTextObject();
  } else {
    const names2 = new TextObject("");
    urls.forEach((name, index) => {
      const nameObj = name.toTextObject();
      const indexedKey = `${nameObj[TextObject.NAME]} ${index + 1}`;
      let field = names2[indexedKey];
      if (!Array.isArray(field)) {
        field = [];
        names2[indexedKey] = field;
      }
      field.push(nameObj);
    });
    obj[key2] = names2;
  }
}
function addAccessDescriptions(value, params, method, key2) {
  const items = params[key2];
  if (items) {
    const array = Array.isArray(items) ? items : [items];
    array.forEach((url) => {
      if (typeof url === "string") {
        url = new GeneralName3("url", url);
      }
      value.push(new AccessDescription({
        accessMethod: method,
        accessLocation: AsnConvert.parse(url.rawData, GeneralName)
      }));
    });
  }
}
var IssuerAlternativeNameExtension = class extends Extension2 {
  constructor(...args) {
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
    } else {
      super(id_ce_issuerAltName, args[1], new GeneralNames3(args[0] || []).rawData);
    }
  }
  onInit(asn) {
    super.onInit(asn);
    const value = AsnConvert.parse(asn.extnValue, GeneralNames, this.parseOptions);
    this.names = new GeneralNames3(value);
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    const namesObj = this.names.toTextObject();
    for (const key2 in namesObj) {
      obj[key2] = namesObj[key2];
    }
    return obj;
  }
};
IssuerAlternativeNameExtension.NAME = "Issuer Alternative Name";
var Attribute3 = class _Attribute extends AsnData {
  constructor(...args) {
    let raw;
    let options;
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      raw = import_pvtsutils.BufferSourceConverter.toArrayBuffer(args[0]);
      options = args[1];
    } else {
      const type = args[0];
      const values = Array.isArray(args[1]) ? args[1].map((o) => import_pvtsutils.BufferSourceConverter.toArrayBuffer(o)) : [];
      raw = AsnConvert.serialize(new Attribute({
        type,
        values
      }));
    }
    super(raw, Attribute, options);
  }
  onInit(asn) {
    this.type = asn.type;
    this.values = asn.values;
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    obj["Value"] = this.values.map((o) => new TextObject("", { "": o }));
    return obj;
  }
  toTextObjectWithoutValue() {
    const obj = this.toTextObjectEmpty();
    if (obj[TextObject.NAME] === _Attribute.NAME) {
      obj[TextObject.NAME] = OidSerializer.toString(this.type);
    }
    return obj;
  }
};
Attribute3.NAME = "Attribute";
var ChallengePasswordAttribute = class extends Attribute3 {
  constructor(...args) {
    var _a3;
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
    } else {
      const value = new ChallengePassword({ printableString: args[0] });
      super(id_pkcs9_at_challengePassword, [AsnConvert.serialize(value)]);
    }
    (_a3 = this.password) !== null && _a3 !== void 0 ? _a3 : this.password = "";
  }
  onInit(asn) {
    super.onInit(asn);
    if (this.values[0]) {
      const value = AsnConvert.parse(this.values[0], ChallengePassword, this.parseOptions);
      this.password = value.toString();
    }
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    obj[TextObject.VALUE] = this.password;
    return obj;
  }
};
ChallengePasswordAttribute.NAME = "Challenge Password";
var ExtensionsAttribute = class extends Attribute3 {
  constructor(...args) {
    var _a3;
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      super(args[0], args[1]);
    } else {
      const extensions = args[0];
      const value = new Extensions();
      for (const extension of extensions) {
        value.push(AsnConvert.parse(extension.rawData, Extension));
      }
      super(id_pkcs9_at_extensionRequest, [AsnConvert.serialize(value)]);
    }
    (_a3 = this.items) !== null && _a3 !== void 0 ? _a3 : this.items = [];
  }
  onInit(asn) {
    super.onInit(asn);
    if (this.values[0]) {
      const value = AsnConvert.parse(this.values[0], Extensions, this.parseOptions);
      this.items = value.map((o) => ExtensionFactory.create(AsnConvert.serialize(o), this.parseOptions));
    }
  }
  toTextObject() {
    const obj = this.toTextObjectWithoutValue();
    const extensions = this.items.map((o) => o.toTextObject());
    for (const extension of extensions) {
      obj[extension[TextObject.NAME]] = extension;
    }
    return obj;
  }
};
ExtensionsAttribute.NAME = "Extensions";
var AttributeFactory = class {
  static register(id, type) {
    this.items.set(id, type);
  }
  static create(data, options) {
    const attribute = new Attribute3(data, options);
    const Type = this.items.get(attribute.type);
    if (Type) {
      return new Type(data, options);
    }
    return attribute;
  }
};
AttributeFactory.items = /* @__PURE__ */ new Map();
var diAsnSignatureFormatter = "crypto.signatureFormatter";
var AsnDefaultSignatureFormatter = class {
  toAsnSignature(algorithm, signature) {
    return import_pvtsutils.BufferSourceConverter.toArrayBuffer(signature);
  }
  toWebSignature(algorithm, signature) {
    return import_pvtsutils.BufferSourceConverter.toArrayBuffer(signature);
  }
};
var RsaAlgorithm_1;
var RsaAlgorithm = RsaAlgorithm_1 = class RsaAlgorithm2 {
  static createPssParams(hash, saltLength) {
    const hashAlgorithm = RsaAlgorithm_1.getHashAlgorithm(hash);
    if (!hashAlgorithm) {
      return null;
    }
    return new RsaSaPssParams({
      hashAlgorithm,
      maskGenAlgorithm: new AlgorithmIdentifier({
        algorithm: id_mgf1,
        parameters: AsnConvert.serialize(hashAlgorithm)
      }),
      saltLength
    });
  }
  static getHashAlgorithm(alg) {
    const algProv = instance.resolve(diAlgorithmProvider);
    if (typeof alg === "string") {
      return algProv.toAsnAlgorithm({ name: alg });
    }
    if (typeof alg === "object" && alg && "name" in alg) {
      return algProv.toAsnAlgorithm(alg);
    }
    return null;
  }
  toAsnAlgorithm(alg) {
    switch (alg.name.toLowerCase()) {
      case "rsassa-pkcs1-v1_5":
        if ("hash" in alg) {
          let hash;
          if (typeof alg.hash === "string") {
            hash = alg.hash;
          } else if (alg.hash && typeof alg.hash === "object" && "name" in alg.hash && typeof alg.hash.name === "string") {
            hash = alg.hash.name.toUpperCase();
          } else {
            throw new Error("Cannot get hash algorithm name");
          }
          switch (hash.toLowerCase()) {
            case "sha-1":
              return new AlgorithmIdentifier({
                algorithm: id_sha1WithRSAEncryption,
                parameters: null
              });
            case "sha-256":
              return new AlgorithmIdentifier({
                algorithm: id_sha256WithRSAEncryption,
                parameters: null
              });
            case "sha-384":
              return new AlgorithmIdentifier({
                algorithm: id_sha384WithRSAEncryption,
                parameters: null
              });
            case "sha-512":
              return new AlgorithmIdentifier({
                algorithm: id_sha512WithRSAEncryption,
                parameters: null
              });
          }
        } else {
          return new AlgorithmIdentifier({
            algorithm: id_rsaEncryption,
            parameters: null
          });
        }
        break;
      case "rsa-pss":
        if ("hash" in alg) {
          if (!("saltLength" in alg && typeof alg.saltLength === "number")) {
            throw new Error("Cannot get 'saltLength' from 'alg' argument");
          }
          const pssParams = RsaAlgorithm_1.createPssParams(alg.hash, alg.saltLength);
          if (!pssParams) {
            throw new Error("Cannot create PSS parameters");
          }
          return new AlgorithmIdentifier({
            algorithm: id_RSASSA_PSS,
            parameters: AsnConvert.serialize(pssParams)
          });
        } else {
          return new AlgorithmIdentifier({
            algorithm: id_RSASSA_PSS,
            parameters: null
          });
        }
    }
    return null;
  }
  toWebAlgorithm(alg) {
    switch (alg.algorithm) {
      case id_rsaEncryption:
        return { name: "RSASSA-PKCS1-v1_5" };
      case id_sha1WithRSAEncryption:
        return {
          name: "RSASSA-PKCS1-v1_5",
          hash: { name: "SHA-1" }
        };
      case id_sha256WithRSAEncryption:
        return {
          name: "RSASSA-PKCS1-v1_5",
          hash: { name: "SHA-256" }
        };
      case id_sha384WithRSAEncryption:
        return {
          name: "RSASSA-PKCS1-v1_5",
          hash: { name: "SHA-384" }
        };
      case id_sha512WithRSAEncryption:
        return {
          name: "RSASSA-PKCS1-v1_5",
          hash: { name: "SHA-512" }
        };
      case id_RSASSA_PSS:
        if (alg.parameters) {
          const pssParams = AsnConvert.parse(alg.parameters, RsaSaPssParams);
          const algProv = instance.resolve(diAlgorithmProvider);
          const hashAlg = algProv.toWebAlgorithm(pssParams.hashAlgorithm);
          return {
            name: "RSA-PSS",
            hash: hashAlg,
            saltLength: pssParams.saltLength
          };
        } else {
          return { name: "RSA-PSS" };
        }
    }
    return null;
  }
};
RsaAlgorithm = RsaAlgorithm_1 = __decorate([
  injectable_default()
], RsaAlgorithm);
instance.registerSingleton(diAlgorithm, RsaAlgorithm);
var ShaAlgorithm = class ShaAlgorithm2 {
  toAsnAlgorithm(alg) {
    switch (alg.name.toLowerCase()) {
      case "sha-1":
        return new AlgorithmIdentifier({ algorithm: id_sha1 });
      case "sha-256":
        return new AlgorithmIdentifier({ algorithm: id_sha256 });
      case "sha-384":
        return new AlgorithmIdentifier({ algorithm: id_sha384 });
      case "sha-512":
        return new AlgorithmIdentifier({ algorithm: id_sha512 });
    }
    return null;
  }
  toWebAlgorithm(alg) {
    switch (alg.algorithm) {
      case id_sha1:
        return { name: "SHA-1" };
      case id_sha256:
        return { name: "SHA-256" };
      case id_sha384:
        return { name: "SHA-384" };
      case id_sha512:
        return { name: "SHA-512" };
    }
    return null;
  }
};
ShaAlgorithm = __decorate([
  injectable_default()
], ShaAlgorithm);
instance.registerSingleton(diAlgorithm, ShaAlgorithm);
var AsnEcSignatureFormatter = class _AsnEcSignatureFormatter {
  addPadding(pointSize, data) {
    const bytes = import_pvtsutils.BufferSourceConverter.toUint8Array(data);
    const res = new Uint8Array(pointSize);
    res.set(bytes, pointSize - bytes.length);
    return res.buffer;
  }
  removePadding(data, positive = false) {
    let bytes = import_pvtsutils.BufferSourceConverter.toUint8Array(data);
    for (let i = 0; i < bytes.length; i++) {
      if (!bytes[i]) {
        continue;
      }
      bytes = bytes.slice(i);
      break;
    }
    if (positive && bytes[0] > 127) {
      const result = new Uint8Array(bytes.length + 1);
      result.set(bytes, 1);
      return result.buffer;
    }
    return bytes.buffer;
  }
  toAsnSignature(algorithm, signature) {
    if (algorithm.name === "ECDSA") {
      const namedCurve = algorithm.namedCurve;
      const pointSize = _AsnEcSignatureFormatter.namedCurveSize.get(namedCurve) || _AsnEcSignatureFormatter.defaultNamedCurveSize;
      const ecSignature = new ECDSASigValue();
      const uint8Signature = import_pvtsutils.BufferSourceConverter.toUint8Array(signature);
      ecSignature.r = this.removePadding(uint8Signature.slice(0, pointSize), true);
      ecSignature.s = this.removePadding(uint8Signature.slice(pointSize, pointSize + pointSize), true);
      return AsnConvert.serialize(ecSignature);
    }
    return null;
  }
  toWebSignature(algorithm, signature) {
    if (algorithm.name === "ECDSA") {
      const ecSigValue = AsnConvert.parse(signature, ECDSASigValue);
      const namedCurve = algorithm.namedCurve;
      const pointSize = _AsnEcSignatureFormatter.namedCurveSize.get(namedCurve) || _AsnEcSignatureFormatter.defaultNamedCurveSize;
      const r = this.addPadding(pointSize, this.removePadding(ecSigValue.r));
      const s = this.addPadding(pointSize, this.removePadding(ecSigValue.s));
      return (0, import_pvtsutils.combine)(r, s);
    }
    return null;
  }
};
AsnEcSignatureFormatter.namedCurveSize = /* @__PURE__ */ new Map();
AsnEcSignatureFormatter.defaultNamedCurveSize = 32;
var idX25519 = "1.3.101.110";
var idX448 = "1.3.101.111";
var idEd25519 = "1.3.101.112";
var idEd448 = "1.3.101.113";
var EdAlgorithm = class EdAlgorithm2 {
  toAsnAlgorithm(alg) {
    let algorithm = null;
    switch (alg.name.toLowerCase()) {
      case "ed25519":
        algorithm = idEd25519;
        break;
      case "x25519":
        algorithm = idX25519;
        break;
      case "eddsa":
        switch (alg.namedCurve.toLowerCase()) {
          case "ed25519":
            algorithm = idEd25519;
            break;
          case "ed448":
            algorithm = idEd448;
            break;
        }
        break;
      case "ecdh-es":
        switch (alg.namedCurve.toLowerCase()) {
          case "x25519":
            algorithm = idX25519;
            break;
          case "x448":
            algorithm = idX448;
            break;
        }
    }
    if (algorithm) {
      return new AlgorithmIdentifier({ algorithm });
    }
    return null;
  }
  toWebAlgorithm(alg) {
    switch (alg.algorithm) {
      case idEd25519:
        return { name: "Ed25519" };
      case idEd448:
        return {
          name: "EdDSA",
          namedCurve: "Ed448"
        };
      case idX25519:
        return { name: "X25519" };
      case idX448:
        return {
          name: "ECDH-ES",
          namedCurve: "X448"
        };
    }
    return null;
  }
};
EdAlgorithm = __decorate([
  injectable_default()
], EdAlgorithm);
instance.registerSingleton(diAlgorithm, EdAlgorithm);
var MlDsaAlgorithm = class MlDsaAlgorithm2 {
  toAsnAlgorithm(alg) {
    let algorithm = null;
    switch (alg.name.toLowerCase()) {
      case "ml-dsa-44":
        algorithm = id_ml_dsa_44;
        break;
      case "ml-dsa-65":
        algorithm = id_ml_dsa_65;
        break;
      case "ml-dsa-87":
        algorithm = id_ml_dsa_87;
        break;
    }
    if (algorithm) {
      return new AlgorithmIdentifier({ algorithm });
    }
    return null;
  }
  toWebAlgorithm(alg) {
    switch (alg.algorithm) {
      case id_ml_dsa_44:
        return { name: "ML-DSA-44" };
      case id_ml_dsa_65:
        return { name: "ML-DSA-65" };
      case id_ml_dsa_87:
        return { name: "ML-DSA-87" };
    }
    return null;
  }
};
MlDsaAlgorithm = __decorate([
  injectable_default()
], MlDsaAlgorithm);
instance.registerSingleton(diAlgorithm, MlDsaAlgorithm);
var SlhDsaAlgorithm = class SlhDsaAlgorithm2 {
  toAsnAlgorithm(alg) {
    let algorithm = null;
    switch (alg.name.toLowerCase()) {
      case "slh-dsa-sha2-128s":
        algorithm = id_slh_dsa_sha2_128s;
        break;
      case "slh-dsa-sha2-128f":
        algorithm = id_slh_dsa_sha2_128f;
        break;
      case "slh-dsa-sha2-192s":
        algorithm = id_slh_dsa_sha2_192s;
        break;
      case "slh-dsa-sha2-192f":
        algorithm = id_slh_dsa_sha2_192f;
        break;
      case "slh-dsa-sha2-256s":
        algorithm = id_slh_dsa_sha2_256s;
        break;
      case "slh-dsa-sha2-256f":
        algorithm = id_slh_dsa_sha2_256f;
        break;
      case "slh-dsa-shake-128s":
        algorithm = id_slh_dsa_shake_128s;
        break;
      case "slh-dsa-shake-128f":
        algorithm = id_slh_dsa_shake_128f;
        break;
      case "slh-dsa-shake-192s":
        algorithm = id_slh_dsa_shake_192s;
        break;
      case "slh-dsa-shake-192f":
        algorithm = id_slh_dsa_shake_192f;
        break;
      case "slh-dsa-shake-256s":
        algorithm = id_slh_dsa_shake_256s;
        break;
      case "slh-dsa-shake-256f":
        algorithm = id_slh_dsa_shake_256f;
        break;
    }
    if (algorithm) {
      return new AlgorithmIdentifier({ algorithm });
    }
    return null;
  }
  toWebAlgorithm(alg) {
    switch (alg.algorithm) {
      case id_slh_dsa_sha2_128s:
        return { name: "SLH-DSA-SHA2-128s" };
      case id_slh_dsa_sha2_128f:
        return { name: "SLH-DSA-SHA2-128f" };
      case id_slh_dsa_sha2_192s:
        return { name: "SLH-DSA-SHA2-192s" };
      case id_slh_dsa_sha2_192f:
        return { name: "SLH-DSA-SHA2-192f" };
      case id_slh_dsa_sha2_256s:
        return { name: "SLH-DSA-SHA2-256s" };
      case id_slh_dsa_sha2_256f:
        return { name: "SLH-DSA-SHA2-256f" };
      case id_slh_dsa_shake_128s:
        return { name: "SLH-DSA-SHAKE-128s" };
      case id_slh_dsa_shake_128f:
        return { name: "SLH-DSA-SHAKE-128f" };
      case id_slh_dsa_shake_192s:
        return { name: "SLH-DSA-SHAKE-192s" };
      case id_slh_dsa_shake_192f:
        return { name: "SLH-DSA-SHAKE-192f" };
      case id_slh_dsa_shake_256s:
        return { name: "SLH-DSA-SHAKE-256s" };
      case id_slh_dsa_shake_256f:
        return { name: "SLH-DSA-SHAKE-256f" };
    }
    return null;
  }
};
SlhDsaAlgorithm = __decorate([
  injectable_default()
], SlhDsaAlgorithm);
instance.registerSingleton(diAlgorithm, SlhDsaAlgorithm);
var _Pkcs10CertificateRequest_tbs;
var _Pkcs10CertificateRequest_subjectName;
var _Pkcs10CertificateRequest_subject;
var _Pkcs10CertificateRequest_signatureAlgorithm;
var _Pkcs10CertificateRequest_signature;
var _Pkcs10CertificateRequest_publicKey;
var _Pkcs10CertificateRequest_attributes;
var _Pkcs10CertificateRequest_extensions;
var Pkcs10CertificateRequest = class extends PemData {
  get subjectName() {
    if (!__classPrivateFieldGet(this, _Pkcs10CertificateRequest_subjectName, "f")) {
      __classPrivateFieldSet(this, _Pkcs10CertificateRequest_subjectName, new Name3(this.asn.certificationRequestInfo.subject), "f");
    }
    return __classPrivateFieldGet(this, _Pkcs10CertificateRequest_subjectName, "f");
  }
  get subject() {
    if (!__classPrivateFieldGet(this, _Pkcs10CertificateRequest_subject, "f")) {
      __classPrivateFieldSet(this, _Pkcs10CertificateRequest_subject, this.subjectName.toString(), "f");
    }
    return __classPrivateFieldGet(this, _Pkcs10CertificateRequest_subject, "f");
  }
  get signatureAlgorithm() {
    if (!__classPrivateFieldGet(this, _Pkcs10CertificateRequest_signatureAlgorithm, "f")) {
      const algProv = instance.resolve(diAlgorithmProvider);
      __classPrivateFieldSet(this, _Pkcs10CertificateRequest_signatureAlgorithm, algProv.toWebAlgorithm(this.asn.signatureAlgorithm), "f");
    }
    return __classPrivateFieldGet(this, _Pkcs10CertificateRequest_signatureAlgorithm, "f");
  }
  get signature() {
    if (!__classPrivateFieldGet(this, _Pkcs10CertificateRequest_signature, "f")) {
      __classPrivateFieldSet(this, _Pkcs10CertificateRequest_signature, this.asn.signature, "f");
    }
    return __classPrivateFieldGet(this, _Pkcs10CertificateRequest_signature, "f");
  }
  get publicKey() {
    if (!__classPrivateFieldGet(this, _Pkcs10CertificateRequest_publicKey, "f")) {
      __classPrivateFieldSet(this, _Pkcs10CertificateRequest_publicKey, new PublicKey(this.asn.certificationRequestInfo.subjectPKInfo, this.parseOptions), "f");
    }
    return __classPrivateFieldGet(this, _Pkcs10CertificateRequest_publicKey, "f");
  }
  get attributes() {
    if (!__classPrivateFieldGet(this, _Pkcs10CertificateRequest_attributes, "f")) {
      __classPrivateFieldSet(this, _Pkcs10CertificateRequest_attributes, this.asn.certificationRequestInfo.attributes.map((o) => AttributeFactory.create(AsnConvert.serialize(o), this.parseOptions)), "f");
    }
    return __classPrivateFieldGet(this, _Pkcs10CertificateRequest_attributes, "f");
  }
  get extensions() {
    if (!__classPrivateFieldGet(this, _Pkcs10CertificateRequest_extensions, "f")) {
      __classPrivateFieldSet(this, _Pkcs10CertificateRequest_extensions, [], "f");
      const extensions = this.getAttribute(id_pkcs9_at_extensionRequest);
      if (extensions instanceof ExtensionsAttribute) {
        __classPrivateFieldSet(this, _Pkcs10CertificateRequest_extensions, extensions.items, "f");
      }
    }
    return __classPrivateFieldGet(this, _Pkcs10CertificateRequest_extensions, "f");
  }
  get tbs() {
    if (!__classPrivateFieldGet(this, _Pkcs10CertificateRequest_tbs, "f")) {
      __classPrivateFieldSet(this, _Pkcs10CertificateRequest_tbs, this.asn.certificationRequestInfoRaw || AsnConvert.serialize(this.asn.certificationRequestInfo), "f");
    }
    return __classPrivateFieldGet(this, _Pkcs10CertificateRequest_tbs, "f");
  }
  constructor(param, options) {
    const args = PemData.isAsnEncoded(param) ? [param, CertificationRequest, options] : [param, options];
    super(args[0], args[1], args[2]);
    _Pkcs10CertificateRequest_tbs.set(this, void 0);
    _Pkcs10CertificateRequest_subjectName.set(this, void 0);
    _Pkcs10CertificateRequest_subject.set(this, void 0);
    _Pkcs10CertificateRequest_signatureAlgorithm.set(this, void 0);
    _Pkcs10CertificateRequest_signature.set(this, void 0);
    _Pkcs10CertificateRequest_publicKey.set(this, void 0);
    _Pkcs10CertificateRequest_attributes.set(this, void 0);
    _Pkcs10CertificateRequest_extensions.set(this, void 0);
    this.tag = PemConverter.CertificateRequestTag;
  }
  onInit(_asn) {
  }
  getAttribute(type) {
    for (const attr of this.attributes) {
      if (attr.type === type) {
        return attr;
      }
    }
    return null;
  }
  getAttributes(type) {
    return this.attributes.filter((o) => o.type === type);
  }
  getExtension(type) {
    for (const ext of this.extensions) {
      if (ext.type === type) {
        return ext;
      }
    }
    return null;
  }
  getExtensions(type) {
    return this.extensions.filter((o) => o.type === type);
  }
  async verify(crypto2 = cryptoProvider.get()) {
    const algorithm = {
      ...this.publicKey.algorithm,
      ...this.signatureAlgorithm
    };
    const publicKey = await this.publicKey.export(algorithm, ["verify"], crypto2);
    const signatureFormatters = instance.resolveAll(diAsnSignatureFormatter).reverse();
    let signature = null;
    for (const signatureFormatter of signatureFormatters) {
      signature = signatureFormatter.toWebSignature(algorithm, this.signature);
      if (signature) {
        break;
      }
    }
    if (!signature) {
      throw Error("Cannot convert WebCrypto signature value to ASN.1 format");
    }
    const ok = await crypto2.subtle.verify(this.signatureAlgorithm, publicKey, signature, this.tbs);
    return ok;
  }
  toTextObject() {
    const obj = this.toTextObjectEmpty();
    const req = AsnConvert.parse(this.rawData, CertificationRequest, this.parseOptions);
    const tbs = req.certificationRequestInfo;
    const data = new TextObject("", {
      Version: `${Version[tbs.version]} (${tbs.version})`,
      Subject: this.subject,
      "Subject Public Key Info": this.publicKey
    });
    if (this.attributes.length) {
      const attrs = new TextObject("");
      for (const ext of this.attributes) {
        const attrObj = ext.toTextObject();
        attrs[attrObj[TextObject.NAME]] = attrObj;
      }
      data["Attributes"] = attrs;
    }
    obj["Data"] = data;
    obj["Signature"] = new TextObject("", {
      Algorithm: TextConverter.serializeAlgorithm(req.signatureAlgorithm),
      "": req.signature
    });
    return obj;
  }
};
_Pkcs10CertificateRequest_tbs = /* @__PURE__ */ new WeakMap(), _Pkcs10CertificateRequest_subjectName = /* @__PURE__ */ new WeakMap(), _Pkcs10CertificateRequest_subject = /* @__PURE__ */ new WeakMap(), _Pkcs10CertificateRequest_signatureAlgorithm = /* @__PURE__ */ new WeakMap(), _Pkcs10CertificateRequest_signature = /* @__PURE__ */ new WeakMap(), _Pkcs10CertificateRequest_publicKey = /* @__PURE__ */ new WeakMap(), _Pkcs10CertificateRequest_attributes = /* @__PURE__ */ new WeakMap(), _Pkcs10CertificateRequest_extensions = /* @__PURE__ */ new WeakMap();
Pkcs10CertificateRequest.NAME = "PKCS#10 Certificate Request";
function toPositiveIntegerOctets(input) {
  let firstNonZero = 0;
  while (firstNonZero < input.length - 1 && input[firstNonZero] === 0) {
    firstNonZero++;
  }
  let serialNumber = input.slice(firstNonZero);
  if (!serialNumber.length) {
    serialNumber = new Uint8Array([0]);
  }
  if (serialNumber[0] > 127) {
    const newSerialNumber = new Uint8Array(serialNumber.length + 1);
    newSerialNumber[0] = 0;
    newSerialNumber.set(serialNumber, 1);
    serialNumber = newSerialNumber;
  }
  return serialNumber.buffer;
}
function normalizeCertificateSerialNumber(input) {
  return toPositiveIntegerOctets(import_pvtsutils.BufferSourceConverter.toUint8Array(import_pvtsutils.Convert.FromHex(input || "")));
}
function getCertificateSerialNumber(raw) {
  let serialNumber = import_pvtsutils.BufferSourceConverter.toUint8Array(raw);
  if (serialNumber.length > 1 && serialNumber[0] === 0 && serialNumber[1] > 127) {
    serialNumber = serialNumber.slice(1);
  }
  return import_pvtsutils.Convert.ToHex(serialNumber);
}
var _X509Certificate_tbs;
var _X509Certificate_serialNumber;
var _X509Certificate_subjectName;
var _X509Certificate_subject;
var _X509Certificate_issuerName;
var _X509Certificate_issuer;
var _X509Certificate_notBefore;
var _X509Certificate_notAfter;
var _X509Certificate_signatureAlgorithm;
var _X509Certificate_signature;
var _X509Certificate_extensions;
var _X509Certificate_publicKey;
var X509Certificate = class extends PemData {
  get publicKey() {
    if (!__classPrivateFieldGet(this, _X509Certificate_publicKey, "f")) {
      __classPrivateFieldSet(this, _X509Certificate_publicKey, new PublicKey(this.asn.tbsCertificate.subjectPublicKeyInfo, this.parseOptions), "f");
    }
    return __classPrivateFieldGet(this, _X509Certificate_publicKey, "f");
  }
  get serialNumber() {
    if (!__classPrivateFieldGet(this, _X509Certificate_serialNumber, "f")) {
      __classPrivateFieldSet(this, _X509Certificate_serialNumber, getCertificateSerialNumber(this.asn.tbsCertificate.serialNumber), "f");
    }
    return __classPrivateFieldGet(this, _X509Certificate_serialNumber, "f");
  }
  get subjectName() {
    if (!__classPrivateFieldGet(this, _X509Certificate_subjectName, "f")) {
      __classPrivateFieldSet(this, _X509Certificate_subjectName, new Name3(this.asn.tbsCertificate.subject), "f");
    }
    return __classPrivateFieldGet(this, _X509Certificate_subjectName, "f");
  }
  get subject() {
    if (!__classPrivateFieldGet(this, _X509Certificate_subject, "f")) {
      __classPrivateFieldSet(this, _X509Certificate_subject, this.subjectName.toString(), "f");
    }
    return __classPrivateFieldGet(this, _X509Certificate_subject, "f");
  }
  get issuerName() {
    if (!__classPrivateFieldGet(this, _X509Certificate_issuerName, "f")) {
      __classPrivateFieldSet(this, _X509Certificate_issuerName, new Name3(this.asn.tbsCertificate.issuer), "f");
    }
    return __classPrivateFieldGet(this, _X509Certificate_issuerName, "f");
  }
  get issuer() {
    if (!__classPrivateFieldGet(this, _X509Certificate_issuer, "f")) {
      __classPrivateFieldSet(this, _X509Certificate_issuer, this.issuerName.toString(), "f");
    }
    return __classPrivateFieldGet(this, _X509Certificate_issuer, "f");
  }
  get notBefore() {
    if (!__classPrivateFieldGet(this, _X509Certificate_notBefore, "f")) {
      const notBefore = this.asn.tbsCertificate.validity.notBefore.utcTime || this.asn.tbsCertificate.validity.notBefore.generalTime;
      if (!notBefore) {
        throw new Error("Cannot get 'notBefore' value");
      }
      __classPrivateFieldSet(this, _X509Certificate_notBefore, notBefore, "f");
    }
    return __classPrivateFieldGet(this, _X509Certificate_notBefore, "f");
  }
  get notAfter() {
    if (!__classPrivateFieldGet(this, _X509Certificate_notAfter, "f")) {
      const notAfter = this.asn.tbsCertificate.validity.notAfter.utcTime || this.asn.tbsCertificate.validity.notAfter.generalTime;
      if (!notAfter) {
        throw new Error("Cannot get 'notAfter' value");
      }
      __classPrivateFieldSet(this, _X509Certificate_notAfter, notAfter, "f");
    }
    return __classPrivateFieldGet(this, _X509Certificate_notAfter, "f");
  }
  get signatureAlgorithm() {
    if (!__classPrivateFieldGet(this, _X509Certificate_signatureAlgorithm, "f")) {
      const algProv = instance.resolve(diAlgorithmProvider);
      __classPrivateFieldSet(this, _X509Certificate_signatureAlgorithm, algProv.toWebAlgorithm(this.asn.signatureAlgorithm), "f");
    }
    return __classPrivateFieldGet(this, _X509Certificate_signatureAlgorithm, "f");
  }
  get signature() {
    if (!__classPrivateFieldGet(this, _X509Certificate_signature, "f")) {
      __classPrivateFieldSet(this, _X509Certificate_signature, this.asn.signatureValue, "f");
    }
    return __classPrivateFieldGet(this, _X509Certificate_signature, "f");
  }
  get extensions() {
    if (!__classPrivateFieldGet(this, _X509Certificate_extensions, "f")) {
      __classPrivateFieldSet(this, _X509Certificate_extensions, [], "f");
      if (this.asn.tbsCertificate.extensions) {
        __classPrivateFieldSet(this, _X509Certificate_extensions, this.asn.tbsCertificate.extensions.map((o) => ExtensionFactory.create(AsnConvert.serialize(o), this.parseOptions)), "f");
      }
    }
    return __classPrivateFieldGet(this, _X509Certificate_extensions, "f");
  }
  get tbs() {
    if (!__classPrivateFieldGet(this, _X509Certificate_tbs, "f")) {
      __classPrivateFieldSet(this, _X509Certificate_tbs, this.asn.tbsCertificateRaw || AsnConvert.serialize(this.asn.tbsCertificate), "f");
    }
    return __classPrivateFieldGet(this, _X509Certificate_tbs, "f");
  }
  constructor(param, options) {
    const args = PemData.isAsnEncoded(param) ? [param, Certificate, options] : [param, options];
    super(args[0], args[1], args[2]);
    _X509Certificate_tbs.set(this, void 0);
    _X509Certificate_serialNumber.set(this, void 0);
    _X509Certificate_subjectName.set(this, void 0);
    _X509Certificate_subject.set(this, void 0);
    _X509Certificate_issuerName.set(this, void 0);
    _X509Certificate_issuer.set(this, void 0);
    _X509Certificate_notBefore.set(this, void 0);
    _X509Certificate_notAfter.set(this, void 0);
    _X509Certificate_signatureAlgorithm.set(this, void 0);
    _X509Certificate_signature.set(this, void 0);
    _X509Certificate_extensions.set(this, void 0);
    _X509Certificate_publicKey.set(this, void 0);
    this.tag = PemConverter.CertificateTag;
  }
  onInit(_asn) {
  }
  getExtension(type) {
    for (const ext of this.extensions) {
      if (typeof type === "string") {
        if (ext.type === type) {
          return ext;
        }
      } else {
        if (ext instanceof type) {
          return ext;
        }
      }
    }
    return null;
  }
  getExtensions(type) {
    return this.extensions.filter((o) => {
      if (typeof type === "string") {
        return o.type === type;
      } else {
        return o instanceof type;
      }
    });
  }
  async verify(params = {}, crypto2 = cryptoProvider.get()) {
    let keyAlgorithm;
    let publicKey;
    const paramsKey = params.publicKey;
    try {
      if (!paramsKey) {
        keyAlgorithm = {
          ...this.publicKey.algorithm,
          ...this.signatureAlgorithm
        };
        publicKey = await this.publicKey.export(keyAlgorithm, ["verify"], crypto2);
      } else if ("publicKey" in paramsKey) {
        keyAlgorithm = {
          ...paramsKey.publicKey.algorithm,
          ...this.signatureAlgorithm
        };
        publicKey = await paramsKey.publicKey.export(keyAlgorithm, ["verify"], crypto2);
      } else if (paramsKey instanceof PublicKey) {
        keyAlgorithm = {
          ...paramsKey.algorithm,
          ...this.signatureAlgorithm
        };
        publicKey = await paramsKey.export(keyAlgorithm, ["verify"], crypto2);
      } else if (import_pvtsutils.BufferSourceConverter.isBufferSource(paramsKey)) {
        const key2 = new PublicKey(paramsKey);
        keyAlgorithm = {
          ...key2.algorithm,
          ...this.signatureAlgorithm
        };
        publicKey = await key2.export(keyAlgorithm, ["verify"], crypto2);
      } else {
        keyAlgorithm = {
          ...paramsKey.algorithm,
          ...this.signatureAlgorithm
        };
        publicKey = paramsKey;
      }
    } catch {
      return false;
    }
    const signatureFormatters = instance.resolveAll(diAsnSignatureFormatter).reverse();
    let signature = null;
    for (const signatureFormatter of signatureFormatters) {
      signature = signatureFormatter.toWebSignature(keyAlgorithm, this.signature);
      if (signature) {
        break;
      }
    }
    if (!signature) {
      throw Error("Cannot convert ASN.1 signature value to WebCrypto format");
    }
    const ok = await crypto2.subtle.verify(this.signatureAlgorithm, publicKey, signature, this.tbs);
    if (params.signatureOnly) {
      return ok;
    } else {
      const date = params.date || /* @__PURE__ */ new Date();
      const time = date.getTime();
      return ok && this.notBefore.getTime() < time && time < this.notAfter.getTime();
    }
  }
  async getThumbprint(arg1, arg2) {
    let crypto2;
    let algorithm = "SHA-1";
    if (arg1) {
      if (typeof arg1 === "object" && "subtle" in arg1) {
        crypto2 = arg1;
      } else {
        algorithm = arg1;
        crypto2 = arg2;
      }
    }
    crypto2 !== null && crypto2 !== void 0 ? crypto2 : crypto2 = cryptoProvider.get();
    return await crypto2.subtle.digest(algorithm, this.rawData);
  }
  async isSelfSigned(crypto2 = cryptoProvider.get()) {
    return this.subject === this.issuer && await this.verify({ signatureOnly: true }, crypto2);
  }
  toTextObject() {
    const obj = this.toTextObjectEmpty();
    const cert = AsnConvert.parse(this.rawData, Certificate, this.parseOptions);
    const tbs = cert.tbsCertificate;
    const data = new TextObject("", {
      Version: `${Version[tbs.version]} (${tbs.version})`,
      "Serial Number": tbs.serialNumber,
      "Signature Algorithm": TextConverter.serializeAlgorithm(tbs.signature),
      Issuer: this.issuer,
      Validity: new TextObject("", {
        "Not Before": tbs.validity.notBefore.getTime(),
        "Not After": tbs.validity.notAfter.getTime()
      }),
      Subject: this.subject,
      "Subject Public Key Info": this.publicKey
    });
    if (tbs.issuerUniqueID) {
      data["Issuer Unique ID"] = tbs.issuerUniqueID;
    }
    if (tbs.subjectUniqueID) {
      data["Subject Unique ID"] = tbs.subjectUniqueID;
    }
    if (this.extensions.length) {
      const extensions = new TextObject("");
      for (const ext of this.extensions) {
        const extObj = ext.toTextObject();
        extensions[extObj[TextObject.NAME]] = extObj;
      }
      data["Extensions"] = extensions;
    }
    obj["Data"] = data;
    obj["Signature"] = new TextObject("", {
      Algorithm: TextConverter.serializeAlgorithm(cert.signatureAlgorithm),
      "": cert.signatureValue
    });
    return obj;
  }
};
_X509Certificate_tbs = /* @__PURE__ */ new WeakMap(), _X509Certificate_serialNumber = /* @__PURE__ */ new WeakMap(), _X509Certificate_subjectName = /* @__PURE__ */ new WeakMap(), _X509Certificate_subject = /* @__PURE__ */ new WeakMap(), _X509Certificate_issuerName = /* @__PURE__ */ new WeakMap(), _X509Certificate_issuer = /* @__PURE__ */ new WeakMap(), _X509Certificate_notBefore = /* @__PURE__ */ new WeakMap(), _X509Certificate_notAfter = /* @__PURE__ */ new WeakMap(), _X509Certificate_signatureAlgorithm = /* @__PURE__ */ new WeakMap(), _X509Certificate_signature = /* @__PURE__ */ new WeakMap(), _X509Certificate_extensions = /* @__PURE__ */ new WeakMap(), _X509Certificate_publicKey = /* @__PURE__ */ new WeakMap();
X509Certificate.NAME = "Certificate";
var _X509Certificates_options;
var X509Certificates = class extends Array {
  constructor(param, options) {
    super();
    _X509Certificates_options.set(this, void 0);
    if (PemData.isAsnEncoded(param)) {
      this.import(param, options);
    } else if (param instanceof X509Certificate) {
      this.push(param);
    } else if (Array.isArray(param)) {
      for (const item of param) {
        this.push(item);
      }
    }
  }
  export(format4) {
    const signedData = new SignedData();
    signedData.version = 1;
    signedData.encapContentInfo.eContentType = id_data;
    signedData.encapContentInfo.eContent = new EncapsulatedContent({
      single: new OctetString2()
    });
    signedData.certificates = new CertificateSet(this.map((o) => new CertificateChoices({
      certificate: AsnConvert.parse(o.rawData, Certificate, __classPrivateFieldGet(this, _X509Certificates_options, "f"))
    })));
    const cms = new ContentInfo({
      contentType: id_signedData,
      content: AsnConvert.serialize(signedData)
    });
    const raw = AsnConvert.serialize(cms);
    if (format4 === "raw") {
      return raw;
    }
    return this.toString(format4);
  }
  import(data, options) {
    const raw = PemData.toArrayBuffer(data);
    const cms = AsnConvert.parse(raw, ContentInfo, options);
    if (cms.contentType !== id_signedData) {
      throw new TypeError("Cannot parse CMS package. Incoming data is not a SignedData object.");
    }
    const signedData = AsnConvert.parse(cms.content, SignedData, options);
    const certificates = [];
    for (const item of signedData.certificates || []) {
      if (item.certificate) {
        certificates.push(new X509Certificate(item.certificate, options));
      }
    }
    this.clear();
    for (const certificate of certificates) {
      this.push(certificate);
    }
    __classPrivateFieldSet(this, _X509Certificates_options, options, "f");
  }
  clear() {
    while (this.pop()) {
    }
  }
  toString(format4 = "pem") {
    const raw = this.export("raw");
    switch (format4) {
      case "pem":
        return PemConverter.encode(raw, "CMS");
      case "pem-chain":
        return this.map((o) => o.toString("pem")).join("\n");
      case "asn":
        return AsnConvert.toString(raw, __classPrivateFieldGet(this, _X509Certificates_options, "f"));
      case "hex":
        return import_pvtsutils.Convert.ToHex(raw);
      case "base64":
        return import_pvtsutils.Convert.ToBase64(raw);
      case "base64url":
        return import_pvtsutils.Convert.ToBase64Url(raw);
      case "text":
        return TextConverter.serialize(this.toTextObject());
      default:
        throw TypeError("Argument 'format' is unsupported value");
    }
  }
  toTextObject() {
    const contentInfo = AsnConvert.parse(this.export("raw"), ContentInfo, __classPrivateFieldGet(this, _X509Certificates_options, "f"));
    const signedData = AsnConvert.parse(contentInfo.content, SignedData, __classPrivateFieldGet(this, _X509Certificates_options, "f"));
    const obj = new TextObject("X509Certificates", {
      "Content Type": OidSerializer.toString(contentInfo.contentType),
      Content: new TextObject("", {
        Version: `${CMSVersion[signedData.version]} (${signedData.version})`,
        Certificates: new TextObject("", { Certificate: this.map((o) => o.toTextObject()) })
      })
    });
    return obj;
  }
};
_X509Certificates_options = /* @__PURE__ */ new WeakMap();
var X509ChainBuilder = class {
  constructor(params = {}) {
    this.certificates = [];
    if (params.certificates) {
      this.certificates = params.certificates;
    }
  }
  async build(cert, crypto2 = cryptoProvider.get()) {
    const chain = new X509Certificates(cert);
    let current = cert;
    while (current = await this.findIssuer(current, crypto2)) {
      const thumbprint = await current.getThumbprint(crypto2);
      for (const item of chain) {
        const thumbprint2 = await item.getThumbprint(crypto2);
        if ((0, import_pvtsutils.isEqual)(thumbprint, thumbprint2)) {
          throw new Error("Cannot build a certificate chain. Circular dependency.");
        }
      }
      chain.push(current);
    }
    return chain;
  }
  async findIssuer(cert, crypto2 = cryptoProvider.get()) {
    if (!await cert.isSelfSigned(crypto2)) {
      const akiExt = cert.getExtension(id_ce_authorityKeyIdentifier);
      for (const item of this.certificates) {
        if (item.subject !== cert.issuer) {
          continue;
        }
        if (akiExt) {
          if (akiExt.keyId) {
            const skiExt = item.getExtension(id_ce_subjectKeyIdentifier);
            if (skiExt && skiExt.keyId !== akiExt.keyId) {
              continue;
            }
          } else if (akiExt.certId) {
            const sanExt = item.getExtension(id_ce_subjectAltName);
            if (sanExt && !(akiExt.certId.serialNumber === item.serialNumber && (0, import_pvtsutils.isEqual)(AsnConvert.serialize(akiExt.certId.name), AsnConvert.serialize(sanExt)))) {
              continue;
            }
          }
        }
        try {
          const algorithm = {
            ...item.publicKey.algorithm,
            ...cert.signatureAlgorithm
          };
          const publicKey = await item.publicKey.export(algorithm, ["verify"], crypto2);
          const ok = await cert.verify({
            publicKey,
            signatureOnly: true
          }, crypto2);
          if (!ok) {
            continue;
          }
        } catch {
          continue;
        }
        return item;
      }
    }
    return null;
  }
};
var _X509CrlEntry_serialNumber;
var _X509CrlEntry_revocationDate;
var _X509CrlEntry_reason;
var _X509CrlEntry_invalidity;
var _X509CrlEntry_extensions;
var X509CrlReason;
(function(X509CrlReason2) {
  X509CrlReason2[X509CrlReason2["unspecified"] = 0] = "unspecified";
  X509CrlReason2[X509CrlReason2["keyCompromise"] = 1] = "keyCompromise";
  X509CrlReason2[X509CrlReason2["cACompromise"] = 2] = "cACompromise";
  X509CrlReason2[X509CrlReason2["affiliationChanged"] = 3] = "affiliationChanged";
  X509CrlReason2[X509CrlReason2["superseded"] = 4] = "superseded";
  X509CrlReason2[X509CrlReason2["cessationOfOperation"] = 5] = "cessationOfOperation";
  X509CrlReason2[X509CrlReason2["certificateHold"] = 6] = "certificateHold";
  X509CrlReason2[X509CrlReason2["removeFromCRL"] = 8] = "removeFromCRL";
  X509CrlReason2[X509CrlReason2["privilegeWithdrawn"] = 9] = "privilegeWithdrawn";
  X509CrlReason2[X509CrlReason2["aACompromise"] = 10] = "aACompromise";
})(X509CrlReason || (X509CrlReason = {}));
var X509CrlEntry = class extends AsnData {
  get serialNumber() {
    if (!__classPrivateFieldGet(this, _X509CrlEntry_serialNumber, "f")) {
      __classPrivateFieldSet(this, _X509CrlEntry_serialNumber, getCertificateSerialNumber(this.asn.userCertificate), "f");
    }
    return __classPrivateFieldGet(this, _X509CrlEntry_serialNumber, "f");
  }
  get revocationDate() {
    if (!__classPrivateFieldGet(this, _X509CrlEntry_revocationDate, "f")) {
      __classPrivateFieldSet(this, _X509CrlEntry_revocationDate, this.asn.revocationDate.getTime(), "f");
    }
    return __classPrivateFieldGet(this, _X509CrlEntry_revocationDate, "f");
  }
  get reason() {
    if (__classPrivateFieldGet(this, _X509CrlEntry_reason, "f") === void 0) {
      void this.extensions;
    }
    return __classPrivateFieldGet(this, _X509CrlEntry_reason, "f");
  }
  get invalidity() {
    if (__classPrivateFieldGet(this, _X509CrlEntry_invalidity, "f") === void 0) {
      void this.extensions;
    }
    return __classPrivateFieldGet(this, _X509CrlEntry_invalidity, "f");
  }
  get extensions() {
    if (!__classPrivateFieldGet(this, _X509CrlEntry_extensions, "f")) {
      __classPrivateFieldSet(this, _X509CrlEntry_extensions, [], "f");
      if (this.asn.crlEntryExtensions) {
        __classPrivateFieldSet(this, _X509CrlEntry_extensions, this.asn.crlEntryExtensions.map((o) => {
          const extension = ExtensionFactory.create(AsnConvert.serialize(o), this.parseOptions);
          switch (extension.type) {
            case id_ce_cRLReasons:
              if (__classPrivateFieldGet(this, _X509CrlEntry_reason, "f") === void 0) {
                __classPrivateFieldSet(this, _X509CrlEntry_reason, AsnConvert.parse(extension.value, CRLReason, this.parseOptions).reason, "f");
              }
              break;
            case id_ce_invalidityDate:
              if (__classPrivateFieldGet(this, _X509CrlEntry_invalidity, "f") === void 0) {
                __classPrivateFieldSet(this, _X509CrlEntry_invalidity, AsnConvert.parse(extension.value, InvalidityDate, this.parseOptions).value, "f");
              }
              break;
          }
          return extension;
        }), "f");
      }
    }
    return __classPrivateFieldGet(this, _X509CrlEntry_extensions, "f");
  }
  constructor(...args) {
    let raw;
    let options;
    if (import_pvtsutils.BufferSourceConverter.isBufferSource(args[0])) {
      raw = import_pvtsutils.BufferSourceConverter.toArrayBuffer(args[0]);
      options = args[1];
    } else if (typeof args[0] === "string") {
      raw = AsnConvert.serialize(new RevokedCertificate({
        userCertificate: normalizeCertificateSerialNumber(args[0]),
        revocationDate: new Time(args[1]),
        crlEntryExtensions: args[2]
      }));
    } else if (args[0] instanceof RevokedCertificate) {
      raw = args[0];
      options = args[1];
    }
    if (!raw) {
      throw new TypeError("Cannot create X509CrlEntry instance. Wrong constructor arguments.");
    }
    const superArgs = raw instanceof RevokedCertificate ? [raw, options] : [raw, RevokedCertificate, options];
    super(superArgs[0], superArgs[1], superArgs[2]);
    _X509CrlEntry_serialNumber.set(this, void 0);
    _X509CrlEntry_revocationDate.set(this, void 0);
    _X509CrlEntry_reason.set(this, void 0);
    _X509CrlEntry_invalidity.set(this, void 0);
    _X509CrlEntry_extensions.set(this, void 0);
  }
  onInit(_asn) {
  }
};
_X509CrlEntry_serialNumber = /* @__PURE__ */ new WeakMap(), _X509CrlEntry_revocationDate = /* @__PURE__ */ new WeakMap(), _X509CrlEntry_reason = /* @__PURE__ */ new WeakMap(), _X509CrlEntry_invalidity = /* @__PURE__ */ new WeakMap(), _X509CrlEntry_extensions = /* @__PURE__ */ new WeakMap();
var _X509Crl_tbs;
var _X509Crl_signatureAlgorithm;
var _X509Crl_issuerName;
var _X509Crl_thisUpdate;
var _X509Crl_nextUpdate;
var _X509Crl_entries;
var _X509Crl_extensions;
var X509Crl = class extends PemData {
  get version() {
    return this.asn.tbsCertList.version;
  }
  get signatureAlgorithm() {
    if (!__classPrivateFieldGet(this, _X509Crl_signatureAlgorithm, "f")) {
      const algProv = instance.resolve(diAlgorithmProvider);
      __classPrivateFieldSet(this, _X509Crl_signatureAlgorithm, algProv.toWebAlgorithm(this.asn.signatureAlgorithm), "f");
    }
    return __classPrivateFieldGet(this, _X509Crl_signatureAlgorithm, "f");
  }
  get signature() {
    return this.asn.signature;
  }
  get issuer() {
    return this.issuerName.toString();
  }
  get issuerName() {
    if (!__classPrivateFieldGet(this, _X509Crl_issuerName, "f")) {
      __classPrivateFieldSet(this, _X509Crl_issuerName, new Name3(this.asn.tbsCertList.issuer), "f");
    }
    return __classPrivateFieldGet(this, _X509Crl_issuerName, "f");
  }
  get thisUpdate() {
    if (!__classPrivateFieldGet(this, _X509Crl_thisUpdate, "f")) {
      const thisUpdate = this.asn.tbsCertList.thisUpdate.getTime();
      if (!thisUpdate) {
        throw new Error("Cannot get 'thisUpdate' value");
      }
      __classPrivateFieldSet(this, _X509Crl_thisUpdate, thisUpdate, "f");
    }
    return __classPrivateFieldGet(this, _X509Crl_thisUpdate, "f");
  }
  get nextUpdate() {
    var _a3;
    if (__classPrivateFieldGet(this, _X509Crl_nextUpdate, "f") === void 0) {
      __classPrivateFieldSet(this, _X509Crl_nextUpdate, ((_a3 = this.asn.tbsCertList.nextUpdate) === null || _a3 === void 0 ? void 0 : _a3.getTime()) || void 0, "f");
    }
    return __classPrivateFieldGet(this, _X509Crl_nextUpdate, "f");
  }
  get entries() {
    var _a3;
    if (!__classPrivateFieldGet(this, _X509Crl_entries, "f")) {
      __classPrivateFieldSet(this, _X509Crl_entries, ((_a3 = this.asn.tbsCertList.revokedCertificates) === null || _a3 === void 0 ? void 0 : _a3.map((o) => new X509CrlEntry(o, this.parseOptions))) || [], "f");
    }
    return __classPrivateFieldGet(this, _X509Crl_entries, "f");
  }
  get extensions() {
    if (!__classPrivateFieldGet(this, _X509Crl_extensions, "f")) {
      __classPrivateFieldSet(this, _X509Crl_extensions, [], "f");
      if (this.asn.tbsCertList.crlExtensions) {
        __classPrivateFieldSet(this, _X509Crl_extensions, this.asn.tbsCertList.crlExtensions.map((o) => ExtensionFactory.create(AsnConvert.serialize(o), this.parseOptions)), "f");
      }
    }
    return __classPrivateFieldGet(this, _X509Crl_extensions, "f");
  }
  get tbs() {
    if (!__classPrivateFieldGet(this, _X509Crl_tbs, "f")) {
      __classPrivateFieldSet(this, _X509Crl_tbs, this.asn.tbsCertListRaw || AsnConvert.serialize(this.asn.tbsCertList), "f");
    }
    return __classPrivateFieldGet(this, _X509Crl_tbs, "f");
  }
  get tbsCertListSignatureAlgorithm() {
    return this.asn.tbsCertList.signature;
  }
  get certListSignatureAlgorithm() {
    return this.asn.signatureAlgorithm;
  }
  constructor(param, options) {
    const args = PemData.isAsnEncoded(param) ? [param, CertificateList, options] : [param, options];
    super(args[0], args[1], args[2]);
    this.tag = PemConverter.CrlTag;
    _X509Crl_tbs.set(this, void 0);
    _X509Crl_signatureAlgorithm.set(this, void 0);
    _X509Crl_issuerName.set(this, void 0);
    _X509Crl_thisUpdate.set(this, void 0);
    _X509Crl_nextUpdate.set(this, void 0);
    _X509Crl_entries.set(this, void 0);
    _X509Crl_extensions.set(this, void 0);
  }
  onInit(_asn) {
  }
  getExtension(type) {
    for (const ext of this.extensions) {
      if (typeof type === "string") {
        if (ext.type === type) {
          return ext;
        }
      } else {
        if (ext instanceof type) {
          return ext;
        }
      }
    }
    return null;
  }
  getExtensions(type) {
    return this.extensions.filter((o) => {
      if (typeof type === "string") {
        return o.type === type;
      } else {
        return o instanceof type;
      }
    });
  }
  async verify(params, crypto2 = cryptoProvider.get()) {
    if (!this.certListSignatureAlgorithm.isEqual(this.tbsCertListSignatureAlgorithm)) {
      throw new Error("algorithm identifier in the sequence tbsCertList and CertificateList mismatch");
    }
    let keyAlgorithm;
    let publicKey;
    const paramsKey = params.publicKey;
    try {
      if (paramsKey instanceof X509Certificate) {
        keyAlgorithm = {
          ...paramsKey.publicKey.algorithm,
          ...paramsKey.signatureAlgorithm
        };
        publicKey = await paramsKey.publicKey.export(keyAlgorithm, ["verify"]);
      } else if (paramsKey instanceof PublicKey) {
        keyAlgorithm = {
          ...paramsKey.algorithm,
          ...this.signatureAlgorithm
        };
        publicKey = await paramsKey.export(keyAlgorithm, ["verify"]);
      } else {
        keyAlgorithm = {
          ...paramsKey.algorithm,
          ...this.signatureAlgorithm
        };
        publicKey = paramsKey;
      }
    } catch {
      return false;
    }
    const signatureFormatters = instance.resolveAll(diAsnSignatureFormatter).reverse();
    let signature = null;
    for (const signatureFormatter of signatureFormatters) {
      signature = signatureFormatter.toWebSignature(keyAlgorithm, this.signature);
      if (signature) {
        break;
      }
    }
    if (!signature) {
      throw Error("Cannot convert ASN.1 signature value to WebCrypto format");
    }
    return await crypto2.subtle.verify(this.signatureAlgorithm, publicKey, signature, this.tbs);
  }
  async getThumbprint(arg1, arg2) {
    let crypto2;
    let algorithm = "SHA-1";
    if (arg1) {
      if (typeof arg1 === "object" && "subtle" in arg1) {
        crypto2 = arg1;
      } else {
        algorithm = arg1;
        crypto2 = arg2;
      }
    }
    crypto2 !== null && crypto2 !== void 0 ? crypto2 : crypto2 = cryptoProvider.get();
    return await crypto2.subtle.digest(algorithm, this.rawData);
  }
  findRevoked(certOrSerialNumber) {
    const serialNumber = typeof certOrSerialNumber === "string" ? certOrSerialNumber : certOrSerialNumber.serialNumber;
    const serialBuffer = normalizeCertificateSerialNumber(serialNumber);
    for (const revoked of this.asn.tbsCertList.revokedCertificates || []) {
      if (import_pvtsutils.BufferSourceConverter.isEqual(revoked.userCertificate, serialBuffer)) {
        return new X509CrlEntry(AsnConvert.serialize(revoked), this.parseOptions);
      }
    }
    return null;
  }
};
_X509Crl_tbs = /* @__PURE__ */ new WeakMap(), _X509Crl_signatureAlgorithm = /* @__PURE__ */ new WeakMap(), _X509Crl_issuerName = /* @__PURE__ */ new WeakMap(), _X509Crl_thisUpdate = /* @__PURE__ */ new WeakMap(), _X509Crl_nextUpdate = /* @__PURE__ */ new WeakMap(), _X509Crl_entries = /* @__PURE__ */ new WeakMap(), _X509Crl_extensions = /* @__PURE__ */ new WeakMap();
ExtensionFactory.register(id_ce_basicConstraints, BasicConstraintsExtension);
ExtensionFactory.register(id_ce_extKeyUsage, ExtendedKeyUsageExtension);
ExtensionFactory.register(id_ce_keyUsage, KeyUsagesExtension);
ExtensionFactory.register(id_ce_subjectKeyIdentifier, SubjectKeyIdentifierExtension);
ExtensionFactory.register(id_ce_authorityKeyIdentifier, AuthorityKeyIdentifierExtension);
ExtensionFactory.register(id_ce_subjectAltName, SubjectAlternativeNameExtension);
ExtensionFactory.register(id_ce_cRLDistributionPoints, CRLDistributionPointsExtension);
ExtensionFactory.register(id_pe_authorityInfoAccess, AuthorityInfoAccessExtension);
ExtensionFactory.register(id_ce_issuerAltName, IssuerAlternativeNameExtension);
AttributeFactory.register(id_pkcs9_at_challengePassword, ChallengePasswordAttribute);
AttributeFactory.register(id_pkcs9_at_extensionRequest, ExtensionsAttribute);
instance.registerSingleton(diAsnSignatureFormatter, AsnDefaultSignatureFormatter);
instance.registerSingleton(diAsnSignatureFormatter, AsnEcSignatureFormatter);
AsnEcSignatureFormatter.namedCurveSize.set("P-256", 32);
AsnEcSignatureFormatter.namedCurveSize.set("K-256", 32);
AsnEcSignatureFormatter.namedCurveSize.set("P-384", 48);
AsnEcSignatureFormatter.namedCurveSize.set("P-521", 66);

// node_modules/@simplewebauthn/server/esm/helpers/fetch.js
function fetch2(url) {
  return _fetchInternals.stubThis(url);
}
var _fetchInternals = {
  stubThis: (url) => globalThis.fetch(url)
};

// node_modules/@simplewebauthn/server/esm/helpers/isCertRevoked.js
var cacheRevokedCerts = {};
async function isCertRevoked(certificate, issuer) {
  if (!issuer) {
    return false;
  }
  const { extensions } = certificate;
  if (!extensions) {
    return false;
  }
  const { keyIdentifier: issuerKeyIdentifier, fromExtension: issuerKeyIdentifierFromExtension } = await getIssuerKeyIdentifier(issuer);
  const certificateExtAuthorityKeyID = certificate.extensions.find((ext) => ext instanceof AuthorityKeyIdentifierExtension);
  if (issuerKeyIdentifierFromExtension && certificateExtAuthorityKeyID?.keyId && certificateExtAuthorityKeyID.keyId !== issuerKeyIdentifier) {
    throw new Error(`Certificate's AuthorityKeyIdentifier did not match issuer's SubjectKeyIdentifier "${issuerKeyIdentifier}"`);
  }
  const extCRLDistributionPoints = extensions.find((ext) => ext instanceof CRLDistributionPointsExtension);
  const crlURLs = [];
  extCRLDistributionPoints?.distributionPoints?.forEach((dPoint) => {
    dPoint.distributionPoint?.fullName?.forEach((fullName) => {
      if (fullName.uniformResourceIdentifier) {
        crlURLs.push(fullName.uniformResourceIdentifier);
      }
    });
  });
  if (!(crlURLs.length > 0)) {
    return false;
  }
  for (const crlURL of crlURLs) {
    const cacheKey = `${issuerKeyIdentifier}|${crlURL}`;
    const cached = cacheRevokedCerts[cacheKey];
    if (cached) {
      const now = /* @__PURE__ */ new Date();
      if (!cached.nextUpdate || cached.nextUpdate > now) {
        return cached.revokedCerts.indexOf(certificate.serialNumber) >= 0;
      }
    }
    let crlBytes;
    try {
      const respCRL = await fetch2(crlURL);
      crlBytes = await respCRL.arrayBuffer();
    } catch (_err) {
      continue;
    }
    let certCRL;
    try {
      certCRL = new X509Crl(crlBytes);
    } catch (_err) {
      continue;
    }
    const certCRLVerified = await certCRL.verify({ publicKey: issuer.publicKey });
    if (!certCRLVerified) {
      throw new Error(`CRL from ${crlURL} failed signature verification against issuer "${issuer.subject}"`);
    }
    const crlAKI = certCRL.getExtension(AuthorityKeyIdentifierExtension);
    if (issuerKeyIdentifierFromExtension && crlAKI?.keyId && crlAKI.keyId !== issuerKeyIdentifier) {
      throw new Error(`CRL from ${crlURL} contained an AuthorityKeyIdentifier that did not match issuer's SubjectKeyIdentifier "${issuerKeyIdentifier}"`);
    }
    if (certCRL.nextUpdate) {
      cacheRevokedCerts[cacheKey] = {
        revokedCerts: certCRL.entries.map((entry) => entry.serialNumber),
        nextUpdate: certCRL.nextUpdate
      };
    }
    const revoked = certCRL.findRevoked(certificate);
    if (revoked) {
      return true;
    }
  }
  return false;
}
async function getIssuerKeyIdentifier(issuer) {
  const issuerSKI = issuer.extensions?.find((ext) => ext instanceof SubjectKeyIdentifierExtension);
  if (issuerSKI?.keyId) {
    return { keyIdentifier: issuerSKI.keyId, fromExtension: true };
  }
  const computed = await SubjectKeyIdentifierExtension.create(issuer.publicKey);
  return { keyIdentifier: computed.keyId, fromExtension: false };
}

// node_modules/@simplewebauthn/server/esm/helpers/decodeAuthenticatorExtensions.js
function decodeAuthenticatorExtensions(extensionData) {
  let toCBOR;
  try {
    toCBOR = isoCBOR_exports.decodeFirst(extensionData);
  } catch (err) {
    const _err = err;
    throw new Error(`Error decoding authenticator extensions: ${_err.message}`);
  }
  return convertMapToObjectDeep(toCBOR);
}
function convertMapToObjectDeep(input) {
  const mapped = {};
  for (const [key2, value] of input) {
    if (value instanceof Map) {
      mapped[key2] = convertMapToObjectDeep(value);
    } else {
      mapped[key2] = value;
    }
  }
  return mapped;
}

// node_modules/@simplewebauthn/server/esm/helpers/parseAuthenticatorData.js
function parseAuthenticatorData(authData) {
  if (authData.byteLength < 37) {
    throw new Error(`Authenticator data was ${authData.byteLength} bytes, expected at least 37 bytes`);
  }
  let pointer = 0;
  const dataView = isoUint8Array_exports.toDataView(authData);
  const rpIdHash = authData.slice(pointer, pointer += 32);
  const flagsBuf = authData.slice(pointer, pointer += 1);
  const flagsInt = flagsBuf[0];
  const flags = {
    up: !!(flagsInt & 1 << 0),
    // User Presence
    uv: !!(flagsInt & 1 << 2),
    // User Verified
    be: !!(flagsInt & 1 << 3),
    // Backup Eligibility
    bs: !!(flagsInt & 1 << 4),
    // Backup State
    at: !!(flagsInt & 1 << 6),
    // Attested Credential Data Present
    ed: !!(flagsInt & 1 << 7),
    // Extension Data Present
    flagsInt
  };
  const counterBuf = authData.slice(pointer, pointer + 4);
  const counter = dataView.getUint32(pointer, false);
  pointer += 4;
  let aaguid = void 0;
  let credentialID = void 0;
  let credentialPublicKey = void 0;
  if (flags.at) {
    aaguid = authData.slice(pointer, pointer += 16);
    const credIDLen = dataView.getUint16(pointer);
    pointer += 2;
    credentialID = authData.slice(pointer, pointer += credIDLen);
    const badEdDSACBOR = isoUint8Array_exports.fromHex("a301634f4b500327206745643235353139");
    const bytesAtCurrentPosition = authData.slice(pointer, pointer + badEdDSACBOR.byteLength);
    let foundBadCBOR = false;
    if (isoUint8Array_exports.areEqual(badEdDSACBOR, bytesAtCurrentPosition)) {
      foundBadCBOR = true;
      authData[pointer] = 164;
    }
    const firstDecoded = isoCBOR_exports.decodeFirst(authData.slice(pointer));
    const firstEncoded = Uint8Array.from(
      /**
       * Casting to `Map` via `as unknown` here because TS doesn't make it possible to define Maps
       * with discrete keys and properties with known types per pair, and CBOR libs typically parse
       * CBOR Major Type 5 to `Map` because you can have numbers for keys. A `COSEPublicKey` can be
       * generalized as "a Map with numbers for keys and either numbers or bytes for values" though.
       * If this presumption falls apart then other parts of verification later on will fail so we
       * should be safe doing this here.
       */
      isoCBOR_exports.encode(firstDecoded)
    );
    if (foundBadCBOR) {
      authData[pointer] = 163;
    }
    credentialPublicKey = firstEncoded;
    pointer += firstEncoded.byteLength;
  }
  let extensionsData = void 0;
  let extensionsDataBuffer = void 0;
  if (flags.ed) {
    const firstDecoded = isoCBOR_exports.decodeFirst(authData.slice(pointer));
    extensionsDataBuffer = Uint8Array.from(isoCBOR_exports.encode(firstDecoded));
    extensionsData = decodeAuthenticatorExtensions(extensionsDataBuffer);
    pointer += extensionsDataBuffer.byteLength;
  }
  if (authData.byteLength > pointer) {
    throw new Error("Leftover bytes detected while parsing authenticator data");
  }
  return _parseAuthenticatorDataInternals.stubThis({
    rpIdHash,
    flagsBuf,
    flags,
    counter,
    counterBuf,
    aaguid,
    credentialID,
    credentialPublicKey,
    extensionsData,
    extensionsDataBuffer
  });
}
var _parseAuthenticatorDataInternals = {
  stubThis: (value) => value
};

// node_modules/@simplewebauthn/server/esm/helpers/toHash.js
function toHash(data, algorithm = -7) {
  if (typeof data === "string") {
    data = isoUint8Array_exports.fromUTF8String(data);
  }
  const digest3 = isoCrypto_exports.digest(data, algorithm);
  return digest3;
}

// node_modules/@simplewebauthn/server/esm/helpers/validateCertificatePath.js
var import_reflect_metadata2 = __toESM(require_Reflect(), 1);

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/mapCoseAlgToWebCryptoKeyAlgName.js
function mapCoseAlgToWebCryptoKeyAlgName(alg) {
  if ([COSEALG.EdDSA].indexOf(alg) >= 0) {
    return "Ed25519";
  } else if ([COSEALG.ES256, COSEALG.ES384, COSEALG.ES512, COSEALG.ES256K].indexOf(alg) >= 0) {
    return "ECDSA";
  } else if ([COSEALG.RS256, COSEALG.RS384, COSEALG.RS512, COSEALG.RS1].indexOf(alg) >= 0) {
    return "RSASSA-PKCS1-v1_5";
  } else if ([COSEALG.PS256, COSEALG.PS384, COSEALG.PS512].indexOf(alg) >= 0) {
    return "RSA-PSS";
  } else if ([COSEALG.ML_DSA_44].indexOf(alg) >= 0) {
    return "ML-DSA-44";
  } else if ([COSEALG.ML_DSA_65].indexOf(alg) >= 0) {
    return "ML-DSA-65";
  } else if ([COSEALG.ML_DSA_87].indexOf(alg) >= 0) {
    return "ML-DSA-87";
  }
  throw new Error(`Could not map COSE alg value of ${alg} to a WebCrypto key alg name`);
}

// node_modules/@simplewebauthn/server/esm/errors/index.js
var SimpleWebAuthnError = class extends Error {
  constructor({ message, code, cause }) {
    super(message, { cause });
    Object.defineProperty(this, "code", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    this.name = "SimpleWebAuthnError";
    this.code = code;
  }
};
var PQCNotSupportedError = class extends SimpleWebAuthnError {
  constructor(alg) {
    const webCryptoAlg = mapCoseAlgToWebCryptoKeyAlgName(alg);
    const message = `This runtime's WebCrypto.subtle does not support use of ${webCryptoAlg}`;
    super({ message, code: "RUNTIME_NO_PQC_SUPPORT" });
  }
};

// node_modules/@simplewebauthn/server/esm/helpers/validateCertificatePath.js
async function validateCertificatePath(x5cCertsPEM, trustAnchorsPEM = []) {
  if (trustAnchorsPEM.length === 0) {
    return true;
  }
  const trustAnchorsParsed = trustAnchorsPEM.map((certPEM) => {
    try {
      return new X509Certificate(certPEM);
    } catch (err) {
      throw new SimpleWebAuthnError({
        message: `Could not parse trust anchor certificate:
${certPEM}`,
        code: "CERTIFICATE_PATH_VERIFICATION_FAILED",
        cause: err
      });
    }
  });
  const validTrustAnchors = [];
  for (let i = 0; i < trustAnchorsParsed.length; i++) {
    const cert = trustAnchorsParsed[i];
    try {
      assertCertIsWithinValidTimeWindow(cert);
    } catch (_err) {
      continue;
    }
    validTrustAnchors.push(cert);
  }
  if (validTrustAnchors.length === 0) {
    throw new SimpleWebAuthnError({
      message: "No specified trust anchor was valid for verifying x5c",
      code: "CERTIFICATE_PATH_VERIFICATION_FAILED"
    });
  }
  const x5cCertsParsed = x5cCertsPEM.map((certPEM) => new X509Certificate(certPEM));
  const x5cLeafCert = x5cCertsParsed[0];
  let x5cIntermediates = [];
  if (x5cCertsParsed.length > 1) {
    x5cIntermediates = x5cCertsParsed.slice(1);
  }
  let invalidCertificateChain = true;
  let validatedChain = void 0;
  for (const anchor of validTrustAnchors) {
    try {
      const x5cWithTrustAnchor = x5cCertsParsed.concat([anchor]);
      const numUniqueCerts = new Set(x5cWithTrustAnchor.map((cert) => cert.toString("pem"))).size;
      if (numUniqueCerts !== x5cWithTrustAnchor.length) {
        throw new SimpleWebAuthnError({
          message: "Invalid certificate path: found duplicate certificates",
          code: "CERTIFICATE_PATH_VERIFICATION_FAILED"
        });
      }
      const chainBuilder = new X509ChainBuilder({ certificates: [...x5cIntermediates, anchor] });
      const chain = await chainBuilder.build(x5cLeafCert);
      const lastCert = chain[chain.length - 1];
      const lastCertEqualsAnchor = lastCert.equal(anchor);
      let certBeforeLastSignedByAnchor = false;
      if (!lastCertEqualsAnchor && chain.length > 1) {
        const certBeforeLast = chain[chain.length - 2];
        certBeforeLastSignedByAnchor = await certBeforeLast.verify({
          publicKey: anchor.publicKey,
          signatureOnly: true
        });
      }
      const chainReachesAnchor = lastCertEqualsAnchor || certBeforeLastSignedByAnchor;
      if (!chainReachesAnchor) {
        continue;
      }
      if (certBeforeLastSignedByAnchor) {
        chain[chain.length - 1] = anchor;
      }
      invalidCertificateChain = false;
      validatedChain = chain;
      break;
    } catch (err) {
      throw new SimpleWebAuthnError({
        message: "Unexpected error while validating certificate path",
        code: "CERTIFICATE_PATH_VERIFICATION_FAILED",
        cause: err
      });
    }
  }
  if (validatedChain) {
    for (let i = 0; i < validatedChain.length; i++) {
      const cert = validatedChain[i];
      try {
        assertCertIsWithinValidTimeWindow(cert);
      } catch (_err) {
        throw new SimpleWebAuthnError({
          message: `Found certificate out of validity period:
${cert.toString()}`,
          code: "CERTIFICATE_PATH_VERIFICATION_FAILED"
        });
      }
      let issuerCert = void 0;
      if (i < validatedChain.length - 1) {
        issuerCert = validatedChain[i + 1];
      } else {
        if (await cert.isSelfSigned()) {
          issuerCert = cert;
        }
      }
      try {
        await assertCertNotRevoked(cert, issuerCert);
      } catch (err) {
        throw new SimpleWebAuthnError({
          message: `The following certificate failed revocation status check
${cert.toString()}`,
          code: "CERTIFICATE_PATH_VERIFICATION_FAILED",
          cause: err
        });
      }
    }
  } else {
    invalidCertificateChain = true;
  }
  if (invalidCertificateChain) {
    throw new SimpleWebAuthnError({
      message: "x5c could not be chained to any specified trust anchor",
      code: "CERTIFICATE_PATH_VERIFICATION_FAILED"
    });
  }
  return true;
}
async function assertCertNotRevoked(certificate, issuerCert) {
  const subjectCertRevoked = await isCertRevoked(certificate, issuerCert);
  if (subjectCertRevoked) {
    throw new Error("Found revoked certificate in certificate path");
  }
}
function assertCertIsWithinValidTimeWindow(certificate) {
  const { notBefore: certNotBefore, notAfter: certNotAfter } = certificate;
  const now = new Date(Date.now());
  if (certNotBefore > now || certNotAfter < now) {
    throw new Error("Certificate is not yet valid or expired");
  }
}

// node_modules/@simplewebauthn/server/esm/helpers/mapX509SignatureAlgToCOSEAlg.js
function mapX509SignatureAlgToCOSEAlg(signatureAlgorithm) {
  let alg;
  if (signatureAlgorithm === id_ecdsaWithSHA256) {
    alg = COSEALG.ES256;
  } else if (signatureAlgorithm === id_ecdsaWithSHA384) {
    alg = COSEALG.ES384;
  } else if (signatureAlgorithm === id_ecdsaWithSHA512) {
    alg = COSEALG.ES512;
  } else if (signatureAlgorithm === id_sha256WithRSAEncryption) {
    alg = COSEALG.RS256;
  } else if (signatureAlgorithm === id_sha384WithRSAEncryption) {
    alg = COSEALG.RS384;
  } else if (signatureAlgorithm === id_sha512WithRSAEncryption) {
    alg = COSEALG.RS512;
  } else if (signatureAlgorithm === id_sha1WithRSAEncryption) {
    alg = COSEALG.RS1;
  } else if (signatureAlgorithm === id_ml_dsa_44) {
    alg = COSEALG.ML_DSA_44;
  } else if (signatureAlgorithm === id_ml_dsa_65) {
    alg = COSEALG.ML_DSA_65;
  } else if (signatureAlgorithm === id_ml_dsa_87) {
    alg = COSEALG.ML_DSA_87;
  } else {
    throw new Error(`Unable to map X.509 signature algorithm ${signatureAlgorithm} to a COSE algorithm`);
  }
  return alg;
}

// node_modules/@simplewebauthn/server/esm/helpers/convertX509PublicKeyToCOSE.js
function convertX509PublicKeyToCOSE(x509Certificate) {
  let cosePublicKey = /* @__PURE__ */ new Map();
  const x509 = AsnParser.parse(x509Certificate, Certificate);
  const { tbsCertificate } = x509;
  const { subjectPublicKeyInfo } = tbsCertificate;
  const publicKeyAlgorithmID = subjectPublicKeyInfo.algorithm.algorithm;
  if (publicKeyAlgorithmID === id_ecPublicKey) {
    if (!subjectPublicKeyInfo.algorithm.parameters) {
      throw new Error("Certificate public key was missing parameters (EC2)");
    }
    const ecParameters = AsnParser.parse(new Uint8Array(subjectPublicKeyInfo.algorithm.parameters), ECParameters);
    let alg;
    let crv;
    const { namedCurve } = ecParameters;
    if (namedCurve === id_secp256r1) {
      alg = COSEALG.ES256;
      crv = COSECRV.P256;
    } else if (namedCurve === id_secp384r1) {
      alg = COSEALG.ES384;
      crv = COSECRV.P384;
    } else {
      throw new Error(`Certificate public key contained unexpected namedCurve ${namedCurve} (EC2)`);
    }
    const subjectPublicKey = new Uint8Array(subjectPublicKeyInfo.subjectPublicKey);
    let x;
    let y;
    if (subjectPublicKey[0] === 4) {
      let pointer = 1;
      const halfLength = (subjectPublicKey.length - 1) / 2;
      x = subjectPublicKey.slice(pointer, pointer += halfLength);
      y = subjectPublicKey.slice(pointer);
    } else {
      throw new Error('TODO: Figure out how to handle public keys in "compressed form"');
    }
    const coseEC2PubKey = /* @__PURE__ */ new Map();
    coseEC2PubKey.set(COSEKEYS.kty, COSEKTY.EC2);
    coseEC2PubKey.set(COSEKEYS.alg, alg);
    coseEC2PubKey.set(COSEKEYS.crv, crv);
    coseEC2PubKey.set(COSEKEYS.x, x);
    coseEC2PubKey.set(COSEKEYS.y, y);
    cosePublicKey = coseEC2PubKey;
  } else if (publicKeyAlgorithmID === id_rsaEncryption) {
    const rsaPublicKey = AsnParser.parse(subjectPublicKeyInfo.subjectPublicKey, RSAPublicKey);
    const coseRSAPubKey = /* @__PURE__ */ new Map();
    coseRSAPubKey.set(COSEKEYS.kty, COSEKTY.RSA);
    coseRSAPubKey.set(COSEKEYS.alg, COSEALG.RS256);
    coseRSAPubKey.set(COSEKEYS.n, new Uint8Array(rsaPublicKey.modulus));
    coseRSAPubKey.set(COSEKEYS.e, new Uint8Array(rsaPublicKey.publicExponent));
    cosePublicKey = coseRSAPubKey;
  } else if ([id_ml_dsa_44, id_ml_dsa_65, id_ml_dsa_87].indexOf(publicKeyAlgorithmID) >= 0) {
    const coseAKPPubKey = /* @__PURE__ */ new Map();
    coseAKPPubKey.set(COSEKEYS.kty, COSEKTY.AKP);
    coseAKPPubKey.set(COSEKEYS.alg, mapX509SignatureAlgToCOSEAlg(publicKeyAlgorithmID));
    coseAKPPubKey.set(COSEKEYS.pub, new Uint8Array(subjectPublicKeyInfo.subjectPublicKey));
    cosePublicKey = coseAKPPubKey;
  } else {
    throw new Error(`Certificate public key contained unexpected algorithm ID ${publicKeyAlgorithmID}`);
  }
  return cosePublicKey;
}

// node_modules/@simplewebauthn/server/esm/helpers/verifySignature.js
function verifySignature(opts) {
  const { signature, data, credentialPublicKey, x509Certificate, hashAlgorithm } = opts;
  if (!x509Certificate && !credentialPublicKey) {
    throw new Error('Must declare either "leafCert" or "credentialPublicKey"');
  }
  if (x509Certificate && credentialPublicKey) {
    throw new Error('Must not declare both "leafCert" and "credentialPublicKey"');
  }
  let cosePublicKey = /* @__PURE__ */ new Map();
  if (credentialPublicKey) {
    cosePublicKey = decodeCredentialPublicKey(credentialPublicKey);
  } else if (x509Certificate) {
    cosePublicKey = convertX509PublicKeyToCOSE(x509Certificate);
  }
  return _verifySignatureInternals.stubThis(isoCrypto_exports.verify({
    cosePublicKey,
    signature,
    data,
    shaHashOverride: hashAlgorithm
  }));
}
var _verifySignatureInternals = {
  stubThis: (value) => value
};

// node_modules/@simplewebauthn/server/esm/metadata/parseJWT.js
function parseJWT(jwt) {
  const parts = jwt.split(".");
  return [
    JSON.parse(isoBase64URL_exports.toUTF8String(parts[0])),
    JSON.parse(isoBase64URL_exports.toUTF8String(parts[1])),
    parts[2]
  ];
}

// node_modules/@simplewebauthn/server/esm/helpers/mapJWSAlgToCOSEAlg.js
function mapJWSAlgToCOSEAlg(alg) {
  let algCOSE;
  if (alg === "ES256") {
    algCOSE = COSEALG.ES256;
  } else if (alg === "ES384") {
    algCOSE = COSEALG.ES384;
  } else if (alg === "ES512") {
    algCOSE = COSEALG.ES512;
  } else if (alg === "RS256") {
    algCOSE = COSEALG.RS256;
  } else if (alg === "RS384") {
    algCOSE = COSEALG.RS384;
  } else if (alg === "RS512") {
    algCOSE = COSEALG.RS512;
  } else {
    throw new Error(`Unable to map JWS algorithm "${alg}" to a COSE algorithm`);
  }
  return algCOSE;
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/importJWKKey.js
async function importJWKKey(opts) {
  const WebCrypto = await getWebCrypto();
  const { keyData, algorithm } = opts;
  return WebCrypto.subtle.importKey("jwk", keyData, algorithm, false, ["verify"]);
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/verifyEC2.js
async function verifyEC2(opts) {
  const { cosePublicKey, signature, data, shaHashOverride } = opts;
  const WebCrypto = await getWebCrypto();
  const alg = cosePublicKey.get(COSEKEYS.alg);
  const crv = cosePublicKey.get(COSEKEYS.crv);
  const x = cosePublicKey.get(COSEKEYS.x);
  const y = cosePublicKey.get(COSEKEYS.y);
  if (!alg) {
    throw new Error("Public key was missing alg (EC2)");
  }
  if (!crv) {
    throw new Error("Public key was missing crv (EC2)");
  }
  if (!x) {
    throw new Error("Public key was missing x (EC2)");
  }
  if (!y) {
    throw new Error("Public key was missing y (EC2)");
  }
  let _crv;
  if (crv === COSECRV.P256) {
    _crv = "P-256";
  } else if (crv === COSECRV.P384) {
    _crv = "P-384";
  } else if (crv === COSECRV.P521) {
    _crv = "P-521";
  } else {
    throw new Error(`Unexpected COSE crv value of ${crv} (EC2)`);
  }
  const keyData = {
    kty: "EC",
    crv: _crv,
    x: isoBase64URL_exports.fromBuffer(x),
    y: isoBase64URL_exports.fromBuffer(y),
    ext: false
  };
  const keyAlgorithm = {
    /**
     * Note to future self: you can't use `mapCoseAlgToWebCryptoKeyAlgName()` here because some
     * leaf certs from actual devices specified an RSA SHA value for `alg` (e.g. `-257`) which
     * would then map here to `'RSASSA-PKCS1-v1_5'`. We always want `'ECDSA'` here so we'll
     * hard-code this.
     */
    name: "ECDSA",
    namedCurve: _crv
  };
  const key2 = await importJWKKey({ keyData, algorithm: keyAlgorithm });
  let subtleAlg = mapCoseAlgToWebCryptoHashAlgName(alg);
  if (shaHashOverride) {
    subtleAlg = mapCoseAlgToWebCryptoHashAlgName(shaHashOverride);
  }
  const verifyAlgorithm = {
    name: "ECDSA",
    hash: { name: subtleAlg }
  };
  return WebCrypto.subtle.verify(verifyAlgorithm, key2, signature, data);
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/verifyRSA.js
async function verifyRSA(opts) {
  const { cosePublicKey, signature, data, shaHashOverride } = opts;
  const WebCrypto = await getWebCrypto();
  const alg = cosePublicKey.get(COSEKEYS.alg);
  const n = cosePublicKey.get(COSEKEYS.n);
  const e = cosePublicKey.get(COSEKEYS.e);
  if (!alg) {
    throw new Error("Public key was missing alg (RSA)");
  }
  if (!isCOSEAlg(alg)) {
    throw new Error(`Public key had invalid alg ${alg} (RSA)`);
  }
  if (!n) {
    throw new Error("Public key was missing n (RSA)");
  }
  if (!e) {
    throw new Error("Public key was missing e (RSA)");
  }
  const keyData = {
    kty: "RSA",
    alg: "",
    n: isoBase64URL_exports.fromBuffer(n),
    e: isoBase64URL_exports.fromBuffer(e),
    ext: false
  };
  const keyAlgorithm = {
    name: mapCoseAlgToWebCryptoKeyAlgName(alg),
    hash: { name: mapCoseAlgToWebCryptoHashAlgName(alg) }
  };
  const verifyAlgorithm = {
    name: mapCoseAlgToWebCryptoKeyAlgName(alg)
  };
  if (shaHashOverride) {
    keyAlgorithm.hash.name = mapCoseAlgToWebCryptoHashAlgName(shaHashOverride);
  }
  if (keyAlgorithm.name === "RSASSA-PKCS1-v1_5") {
    if (keyAlgorithm.hash.name === "SHA-256") {
      keyData.alg = "RS256";
    } else if (keyAlgorithm.hash.name === "SHA-384") {
      keyData.alg = "RS384";
    } else if (keyAlgorithm.hash.name === "SHA-512") {
      keyData.alg = "RS512";
    } else if (keyAlgorithm.hash.name === "SHA-1") {
      keyData.alg = "RS1";
    }
  } else if (keyAlgorithm.name === "RSA-PSS") {
    let saltLength = 0;
    if (keyAlgorithm.hash.name === "SHA-256") {
      keyData.alg = "PS256";
      saltLength = 32;
    } else if (keyAlgorithm.hash.name === "SHA-384") {
      keyData.alg = "PS384";
      saltLength = 48;
    } else if (keyAlgorithm.hash.name === "SHA-512") {
      keyData.alg = "PS512";
      saltLength = 64;
    }
    verifyAlgorithm.saltLength = saltLength;
  } else {
    throw new Error(`Unexpected RSA key algorithm ${alg} (${keyAlgorithm.name})`);
  }
  const key2 = await importJWKKey({ keyData, algorithm: keyAlgorithm });
  return WebCrypto.subtle.verify(verifyAlgorithm, key2, signature, data);
}

// node_modules/@simplewebauthn/server/esm/metadata/verifyJWT.js
function verifyJWT(jwt, leafCert) {
  const [header, payload, signature] = jwt.split(".");
  const certCOSE = convertX509PublicKeyToCOSE(leafCert);
  const data = isoUint8Array_exports.fromUTF8String(`${header}.${payload}`);
  const signatureBytes = isoBase64URL_exports.toBuffer(signature);
  const headerJSON = JSON.parse(isoBase64URL_exports.toUTF8String(header));
  const jwtHeaderHashAlgCOSE = mapJWSAlgToCOSEAlg(headerJSON.alg);
  if (isCOSEPublicKeyEC2(certCOSE)) {
    return verifyEC2({
      data,
      signature: signatureBytes,
      cosePublicKey: certCOSE,
      shaHashOverride: jwtHeaderHashAlgCOSE
    });
  } else if (isCOSEPublicKeyRSA(certCOSE)) {
    return verifyRSA({
      data,
      signature: signatureBytes,
      cosePublicKey: certCOSE,
      shaHashOverride: jwtHeaderHashAlgCOSE
    });
  }
  const kty = certCOSE.get(COSEKEYS.kty);
  throw new Error(`JWT verification with public key of kty ${kty} is not supported by this method`);
}

// node_modules/@simplewebauthn/server/esm/helpers/convertPEMToBytes.js
function convertPEMToBytes(pem2) {
  const certBase64 = pem2.replace("-----BEGIN CERTIFICATE-----", "").replace("-----END CERTIFICATE-----", "").replace(/[\n ]/g, "");
  return isoBase64URL_exports.toBuffer(certBase64, "base64");
}

// node_modules/@simplewebauthn/server/esm/metadata/verifyMDSBlob.js
async function verifyMDSBlob(blob) {
  const parsedJWT = parseJWT(blob);
  const header = parsedJWT[0];
  const payload = parsedJWT[1];
  const headerCertsPEM = header.x5c.map(convertCertBufferToPEM);
  try {
    const rootCerts = SettingsService.getRootCertificates({
      identifier: "mds"
    });
    await validateCertificatePath(headerCertsPEM, rootCerts);
  } catch (error) {
    const _error = error;
    throw new Error("BLOB certificate path could not be validated", { cause: _error });
  }
  const leafCert = headerCertsPEM[0];
  const verified = await verifyJWT(blob, convertPEMToBytes(leafCert));
  if (!verified) {
    throw new Error("BLOB signature could not be verified");
  }
  const statements = [];
  for (const entry of payload.entries) {
    if (entry.aaguid && entry.metadataStatement) {
      statements.push(entry.metadataStatement);
    }
  }
  const [year, month, day] = payload.nextUpdate.split("-");
  const parsedNextUpdate = new Date(
    parseInt(year, 10),
    // Months need to be zero-indexed
    parseInt(month, 10) - 1,
    parseInt(day, 10)
  );
  return {
    statements,
    parsedNextUpdate,
    payload
  };
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/verifyAKP.js
async function verifyAKP(opts) {
  const { cosePublicKey, signature, data } = opts;
  const WebCrypto = await getWebCrypto();
  const alg = cosePublicKey.get(COSEKEYS.alg);
  const pub = cosePublicKey.get(COSEKEYS.pub);
  if (!alg) {
    throw new Error("Public key was missing alg (AKP)");
  }
  if (!isCOSEAlg(alg)) {
    throw new Error(`Public key had invalid alg ${alg} (AKP)`);
  }
  if (!pub) {
    throw new Error("Public key was missing pub (AKP)");
  }
  const webCryptoAlg = mapCoseAlgToWebCryptoKeyAlgName(alg);
  const keyData = {
    kty: "AKP",
    alg: webCryptoAlg,
    pub: isoBase64URL_exports.fromBuffer(pub),
    ext: false
  };
  let key2;
  try {
    key2 = await importJWKKey({ keyData, algorithm: webCryptoAlg });
  } catch (err) {
    const _err = err;
    if (_err.name === "NotSupportedError") {
      throw new PQCNotSupportedError(alg);
    } else {
      throw err;
    }
  }
  return WebCrypto.subtle.verify(webCryptoAlg, key2, signature, data);
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/verifyOKP.js
async function verifyOKP(opts) {
  const { cosePublicKey, signature, data } = opts;
  const WebCrypto = await getWebCrypto();
  const alg = cosePublicKey.get(COSEKEYS.alg);
  const crv = cosePublicKey.get(COSEKEYS.crv);
  const x = cosePublicKey.get(COSEKEYS.x);
  if (!alg) {
    throw new Error("Public key was missing alg (OKP)");
  }
  if (!isCOSEAlg(alg)) {
    throw new Error(`Public key had invalid alg ${alg} (OKP)`);
  }
  if (!crv) {
    throw new Error("Public key was missing crv (OKP)");
  }
  if (!x) {
    throw new Error("Public key was missing x (OKP)");
  }
  let _crv;
  if (crv === COSECRV.ED25519) {
    _crv = "Ed25519";
  } else {
    throw new Error(`Unexpected COSE crv value of ${crv} (OKP)`);
  }
  const keyData = {
    kty: "OKP",
    crv: _crv,
    alg: "EdDSA",
    x: isoBase64URL_exports.fromBuffer(x),
    ext: false
  };
  const keyAlgorithm = {
    name: _crv,
    namedCurve: _crv
  };
  const key2 = await importJWKKey({ keyData, algorithm: keyAlgorithm });
  const verifyAlgorithm = {
    name: _crv
  };
  return WebCrypto.subtle.verify(verifyAlgorithm, key2, signature, data);
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/unwrapEC2Signature.js
function unwrapEC2Signature(signature, crv) {
  const parsedSignature = AsnParser.parse(signature, ECDSASigValue);
  const rBytes = new Uint8Array(parsedSignature.r);
  const sBytes = new Uint8Array(parsedSignature.s);
  const componentLength = getSignatureComponentLength(crv);
  const rNormalizedBytes = toNormalizedBytes(rBytes, componentLength);
  const sNormalizedBytes = toNormalizedBytes(sBytes, componentLength);
  const finalSignature = isoUint8Array_exports.concat([
    rNormalizedBytes,
    sNormalizedBytes
  ]);
  return finalSignature;
}
function getSignatureComponentLength(crv) {
  switch (crv) {
    case COSECRV.P256:
      return 32;
    case COSECRV.P384:
      return 48;
    case COSECRV.P521:
      return 66;
    default:
      throw new Error(`Unexpected COSE crv value of ${crv} (EC2)`);
  }
}
function toNormalizedBytes(bytes, componentLength) {
  let normalizedBytes;
  if (bytes.length < componentLength) {
    normalizedBytes = new Uint8Array(componentLength);
    normalizedBytes.set(bytes, componentLength - bytes.length);
  } else if (bytes.length === componentLength) {
    normalizedBytes = bytes;
  } else if (bytes.length === componentLength + 1 && bytes[0] === 0 && (bytes[1] & 128) === 128) {
    normalizedBytes = bytes.subarray(1);
  } else {
    throw new Error(`Invalid signature component length ${bytes.length}, expected ${componentLength}`);
  }
  return normalizedBytes;
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/verify.js
function verify(opts) {
  const { cosePublicKey, signature, data, shaHashOverride } = opts;
  if (isCOSEPublicKeyEC2(cosePublicKey)) {
    const crv = cosePublicKey.get(COSEKEYS.crv);
    if (!isCOSECrv(crv)) {
      throw new Error(`unknown COSE curve ${crv}`);
    }
    const unwrappedSignature = unwrapEC2Signature(signature, crv);
    return verifyEC2({
      cosePublicKey,
      signature: unwrappedSignature,
      data,
      shaHashOverride
    });
  } else if (isCOSEPublicKeyRSA(cosePublicKey)) {
    return verifyRSA({ cosePublicKey, signature, data, shaHashOverride });
  } else if (isCOSEPublicKeyOKP(cosePublicKey)) {
    return verifyOKP({ cosePublicKey, signature, data });
  } else if (isCOSEPublicKeyAKP(cosePublicKey)) {
    return verifyAKP({ cosePublicKey, signature, data });
  }
  const kty = cosePublicKey.get(COSEKEYS.kty);
  throw new Error(`Signature verification with public key of kty ${kty} is not supported by this method`);
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoUint8Array.js
var isoUint8Array_exports = {};
__export(isoUint8Array_exports, {
  areEqual: () => areEqual,
  concat: () => concat3,
  fromASCIIString: () => fromASCIIString,
  fromHex: () => fromHex,
  fromUTF8String: () => fromUTF8String2,
  toDataView: () => toDataView,
  toHex: () => toHex,
  toUTF8String: () => toUTF8String2
});
function areEqual(array1, array2) {
  if (array1.length != array2.length) {
    return false;
  }
  return array1.every((val, i) => val === array2[i]);
}
function toHex(array) {
  const hexParts = Array.from(array, (i) => i.toString(16).padStart(2, "0"));
  return hexParts.join("");
}
function fromHex(hex2) {
  if (!hex2) {
    return Uint8Array.from([]);
  }
  const isValid = hex2.length !== 0 && hex2.length % 2 === 0 && !/[^a-fA-F0-9]/u.test(hex2);
  if (!isValid) {
    throw new Error("Invalid hex string");
  }
  const byteStrings = hex2.match(/.{1,2}/g) ?? [];
  return Uint8Array.from(byteStrings.map((byte) => parseInt(byte, 16)));
}
function concat3(arrays) {
  let pointer = 0;
  const totalLength = arrays.reduce((prev, curr) => prev + curr.length, 0);
  const toReturn = new Uint8Array(totalLength);
  arrays.forEach((arr) => {
    toReturn.set(arr, pointer);
    pointer += arr.length;
  });
  return toReturn;
}
function toUTF8String2(array) {
  const decoder = new globalThis.TextDecoder("utf-8");
  return decoder.decode(array);
}
function fromUTF8String2(utf8String) {
  const encoder2 = new globalThis.TextEncoder();
  return encoder2.encode(utf8String);
}
function fromASCIIString(value) {
  return Uint8Array.from(value.split("").map((x) => x.charCodeAt(0)));
}
function toDataView(array) {
  return new DataView(array.buffer, array.byteOffset, array.length);
}

// node_modules/@simplewebauthn/server/esm/helpers/convertCertBufferToPEM.js
function convertCertBufferToPEM(certBuffer) {
  let b64cert;
  if (typeof certBuffer === "string") {
    if (isoBase64URL_exports.isBase64URL(certBuffer)) {
      b64cert = isoBase64URL_exports.toBase64(certBuffer);
    } else if (isoBase64URL_exports.isBase64(certBuffer)) {
      b64cert = certBuffer;
    } else {
      throw new Error("Certificate is not a valid base64 or base64url string");
    }
  } else {
    b64cert = isoBase64URL_exports.fromBuffer(certBuffer, "base64");
  }
  let PEMKey = "";
  for (let i = 0; i < Math.ceil(b64cert.length / 64); i += 1) {
    const start = 64 * i;
    PEMKey += `${b64cert.substr(start, 64)}
`;
  }
  PEMKey = `-----BEGIN CERTIFICATE-----
${PEMKey}-----END CERTIFICATE-----
`;
  return PEMKey;
}

// node_modules/@simplewebauthn/server/esm/helpers/iso/isoCrypto/runtimeSupportsWebCryptoKeyAlg.js
function runtimeSupportsWebCryptoKeyAlg(alg) {
  const globalSubtleCrypto = globalThis.SubtleCrypto;
  if (typeof globalSubtleCrypto.supports !== "function") {
    return false;
  }
  try {
    return globalSubtleCrypto.supports("verify", alg);
  } catch (_err) {
    return false;
  }
}

// node_modules/@simplewebauthn/server/esm/services/defaultRootCerts/android-safetynet.js
var GlobalSign_Root_CA = `-----BEGIN CERTIFICATE-----
MIIDdTCCAl2gAwIBAgILBAAAAAABFUtaw5QwDQYJKoZIhvcNAQEFBQAwVzELMAkG
A1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2ExEDAOBgNVBAsTB1Jv
b3QgQ0ExGzAZBgNVBAMTEkdsb2JhbFNpZ24gUm9vdCBDQTAeFw05ODA5MDExMjAw
MDBaFw0yODAxMjgxMjAwMDBaMFcxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9i
YWxTaWduIG52LXNhMRAwDgYDVQQLEwdSb290IENBMRswGQYDVQQDExJHbG9iYWxT
aWduIFJvb3QgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDaDuaZ
jc6j40+Kfvvxi4Mla+pIH/EqsLmVEQS98GPR4mdmzxzdzxtIK+6NiY6arymAZavp
xy0Sy6scTHAHoT0KMM0VjU/43dSMUBUc71DuxC73/OlS8pF94G3VNTCOXkNz8kHp
1Wrjsok6Vjk4bwY8iGlbKk3Fp1S4bInMm/k8yuX9ifUSPJJ4ltbcdG6TRGHRjcdG
snUOhugZitVtbNV4FpWi6cgKOOvyJBNPc1STE4U6G7weNLWLBYy5d4ux2x8gkasJ
U26Qzns3dLlwR5EiUWMWea6xrkEmCMgZK9FGqkjWZCrXgzT/LCrBbBlDSgeF59N8
9iFo7+ryUp9/k5DPAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIBBjAPBgNVHRMBAf8E
BTADAQH/MB0GA1UdDgQWBBRge2YaRQ2XyolQL30EzTSo//z9SzANBgkqhkiG9w0B
AQUFAAOCAQEA1nPnfE920I2/7LqivjTFKDK1fPxsnCwrvQmeU79rXqoRSLblCKOz
yj1hTdNGCbM+w6DjY1Ub8rrvrTnhQ7k4o+YviiY776BQVvnGCv04zcQLcFGUl5gE
38NflNUVyRRBnMRddWQVDf9VMOyGj/8N7yy5Y0b2qvzfvGn9LhJIZJrglfCm7ymP
AbEVtQwdpf5pLGkkeB6zpxxxYu7KyJesF12KwvhHhm4qxFYxldBniYUr+WymXUad
DKqC5JlR3XC321Y9YeRq4VzW9v493kHMB65jUr9TU/Qr6cf9tveCX4XSQRjbgbME
HMUfpIBvFSDJ3gyICh3WZlXi/EjJKSZp4A==
-----END CERTIFICATE-----
`;

// node_modules/@simplewebauthn/server/esm/services/defaultRootCerts/android-key.js
var Google_Hardware_Attestation_Root_1 = `-----BEGIN CERTIFICATE-----
MIIFYDCCA0igAwIBAgIJAOj6GWMU0voYMA0GCSqGSIb3DQEBCwUAMBsxGTAXBgNV
BAUTEGY5MjAwOWU4NTNiNmIwNDUwHhcNMTYwNTI2MTYyODUyWhcNMjYwNTI0MTYy
ODUyWjAbMRkwFwYDVQQFExBmOTIwMDllODUzYjZiMDQ1MIICIjANBgkqhkiG9w0B
AQEFAAOCAg8AMIICCgKCAgEAr7bHgiuxpwHsK7Qui8xUFmOr75gvMsd/dTEDDJdS
Sxtf6An7xyqpRR90PL2abxM1dEqlXnf2tqw1Ne4Xwl5jlRfdnJLmN0pTy/4lj4/7
tv0Sk3iiKkypnEUtR6WfMgH0QZfKHM1+di+y9TFRtv6y//0rb+T+W8a9nsNL/ggj
nar86461qO0rOs2cXjp3kOG1FEJ5MVmFmBGtnrKpa73XpXyTqRxB/M0n1n/W9nGq
C4FSYa04T6N5RIZGBN2z2MT5IKGbFlbC8UrW0DxW7AYImQQcHtGl/m00QLVWutHQ
oVJYnFPlXTcHYvASLu+RhhsbDmxMgJJ0mcDpvsC4PjvB+TxywElgS70vE0XmLD+O
JtvsBslHZvPBKCOdT0MS+tgSOIfga+z1Z1g7+DVagf7quvmag8jfPioyKvxnK/Eg
sTUVi2ghzq8wm27ud/mIM7AY2qEORR8Go3TVB4HzWQgpZrt3i5MIlCaY504LzSRi
igHCzAPlHws+W0rB5N+er5/2pJKnfBSDiCiFAVtCLOZ7gLiMm0jhO2B6tUXHI/+M
RPjy02i59lINMRRev56GKtcd9qO/0kUJWdZTdA2XoS82ixPvZtXQpUpuL12ab+9E
aDK8Z4RHJYYfCT3Q5vNAXaiWQ+8PTWm2QgBR/bkwSWc+NpUFgNPN9PvQi8WEg5Um
AGMCAwEAAaOBpjCBozAdBgNVHQ4EFgQUNmHhAHyIBQlRi0RsR/8aTMnqTxIwHwYD
VR0jBBgwFoAUNmHhAHyIBQlRi0RsR/8aTMnqTxIwDwYDVR0TAQH/BAUwAwEB/zAO
BgNVHQ8BAf8EBAMCAYYwQAYDVR0fBDkwNzA1oDOgMYYvaHR0cHM6Ly9hbmRyb2lk
Lmdvb2dsZWFwaXMuY29tL2F0dGVzdGF0aW9uL2NybC8wDQYJKoZIhvcNAQELBQAD
ggIBACDIw41L3KlXG0aMiS//cqrG+EShHUGo8HNsw30W1kJtjn6UBwRM6jnmiwfB
Pb8VA91chb2vssAtX2zbTvqBJ9+LBPGCdw/E53Rbf86qhxKaiAHOjpvAy5Y3m00m
qC0w/Zwvju1twb4vhLaJ5NkUJYsUS7rmJKHHBnETLi8GFqiEsqTWpG/6ibYCv7rY
DBJDcR9W62BW9jfIoBQcxUCUJouMPH25lLNcDc1ssqvC2v7iUgI9LeoM1sNovqPm
QUiG9rHli1vXxzCyaMTjwftkJLkf6724DFhuKug2jITV0QkXvaJWF4nUaHOTNA4u
JU9WDvZLI1j83A+/xnAJUucIv/zGJ1AMH2boHqF8CY16LpsYgBt6tKxxWH00XcyD
CdW2KlBCeqbQPcsFmWyWugxdcekhYsAWyoSf818NUsZdBWBaR/OukXrNLfkQ79Iy
ZohZbvabO/X+MVT3rriAoKc8oE2Uws6DF+60PV7/WIPjNvXySdqspImSN78mflxD
qwLqRBYkA3I75qppLGG9rp7UCdRjxMl8ZDBld+7yvHVgt1cVzJx9xnyGCC23Uaic
MDSXYrB4I4WHXPGjxhZuCuPBLTdOLU8YRvMYdEvYebWHMpvwGCF6bAx3JBpIeOQ1
wDB5y0USicV3YgYGmi+NZfhA4URSh77Yd6uuJOJENRaNVTzk
-----END CERTIFICATE-----
`;
var Google_Hardware_Attestation_Root_2 = `-----BEGIN CERTIFICATE-----
MIIFHDCCAwSgAwIBAgIJANUP8luj8tazMA0GCSqGSIb3DQEBCwUAMBsxGTAXBgNV
BAUTEGY5MjAwOWU4NTNiNmIwNDUwHhcNMTkxMTIyMjAzNzU4WhcNMzQxMTE4MjAz
NzU4WjAbMRkwFwYDVQQFExBmOTIwMDllODUzYjZiMDQ1MIICIjANBgkqhkiG9w0B
AQEFAAOCAg8AMIICCgKCAgEAr7bHgiuxpwHsK7Qui8xUFmOr75gvMsd/dTEDDJdS
Sxtf6An7xyqpRR90PL2abxM1dEqlXnf2tqw1Ne4Xwl5jlRfdnJLmN0pTy/4lj4/7
tv0Sk3iiKkypnEUtR6WfMgH0QZfKHM1+di+y9TFRtv6y//0rb+T+W8a9nsNL/ggj
nar86461qO0rOs2cXjp3kOG1FEJ5MVmFmBGtnrKpa73XpXyTqRxB/M0n1n/W9nGq
C4FSYa04T6N5RIZGBN2z2MT5IKGbFlbC8UrW0DxW7AYImQQcHtGl/m00QLVWutHQ
oVJYnFPlXTcHYvASLu+RhhsbDmxMgJJ0mcDpvsC4PjvB+TxywElgS70vE0XmLD+O
JtvsBslHZvPBKCOdT0MS+tgSOIfga+z1Z1g7+DVagf7quvmag8jfPioyKvxnK/Eg
sTUVi2ghzq8wm27ud/mIM7AY2qEORR8Go3TVB4HzWQgpZrt3i5MIlCaY504LzSRi
igHCzAPlHws+W0rB5N+er5/2pJKnfBSDiCiFAVtCLOZ7gLiMm0jhO2B6tUXHI/+M
RPjy02i59lINMRRev56GKtcd9qO/0kUJWdZTdA2XoS82ixPvZtXQpUpuL12ab+9E
aDK8Z4RHJYYfCT3Q5vNAXaiWQ+8PTWm2QgBR/bkwSWc+NpUFgNPN9PvQi8WEg5Um
AGMCAwEAAaNjMGEwHQYDVR0OBBYEFDZh4QB8iAUJUYtEbEf/GkzJ6k8SMB8GA1Ud
IwQYMBaAFDZh4QB8iAUJUYtEbEf/GkzJ6k8SMA8GA1UdEwEB/wQFMAMBAf8wDgYD
VR0PAQH/BAQDAgIEMA0GCSqGSIb3DQEBCwUAA4ICAQBOMaBc8oumXb2voc7XCWnu
XKhBBK3e2KMGz39t7lA3XXRe2ZLLAkLM5y3J7tURkf5a1SutfdOyXAmeE6SRo83U
h6WszodmMkxK5GM4JGrnt4pBisu5igXEydaW7qq2CdC6DOGjG+mEkN8/TA6p3cno
L/sPyz6evdjLlSeJ8rFBH6xWyIZCbrcpYEJzXaUOEaxxXxgYz5/cTiVKN2M1G2ok
QBUIYSY6bjEL4aUN5cfo7ogP3UvliEo3Eo0YgwuzR2v0KR6C1cZqZJSTnghIC/vA
D32KdNQ+c3N+vl2OTsUVMC1GiWkngNx1OO1+kXW+YTnnTUOtOIswUP/Vqd5SYgAI
mMAfY8U9/iIgkQj6T2W6FsScy94IN9fFhE1UtzmLoBIuUFsVXJMTz+Jucth+IqoW
Fua9v1R93/k98p41pjtFX+H8DslVgfP097vju4KDlqN64xV1grw3ZLl4CiOe/A91
oeLm2UHOq6wn3esB4r2EIQKb6jTVGu5sYCcdWpXr0AUVqcABPdgL+H7qJguBw09o
jm6xNIrw2OocrDKsudk/okr/AwqEyPKw9WnMlQgLIKw1rODG2NvU9oR3GVGdMkUB
ZutL8VuFkERQGt6vQ2OCw0sV47VMkuYbacK/xyZFiRcrPJPb41zgbQj9XAEyLKCH
ex0SdDrx+tWUDqG8At2JHA==
-----END CERTIFICATE-----
`;
var Google_Hardware_Attestation_Root_3 = `
-----BEGIN CERTIFICATE-----
MIIFHDCCAwSgAwIBAgIJAMNrfES5rhgxMA0GCSqGSIb3DQEBCwUAMBsxGTAXBgNV
BAUTEGY5MjAwOWU4NTNiNmIwNDUwHhcNMjExMTE3MjMxMDQyWhcNMzYxMTEzMjMx
MDQyWjAbMRkwFwYDVQQFExBmOTIwMDllODUzYjZiMDQ1MIICIjANBgkqhkiG9w0B
AQEFAAOCAg8AMIICCgKCAgEAr7bHgiuxpwHsK7Qui8xUFmOr75gvMsd/dTEDDJdS
Sxtf6An7xyqpRR90PL2abxM1dEqlXnf2tqw1Ne4Xwl5jlRfdnJLmN0pTy/4lj4/7
tv0Sk3iiKkypnEUtR6WfMgH0QZfKHM1+di+y9TFRtv6y//0rb+T+W8a9nsNL/ggj
nar86461qO0rOs2cXjp3kOG1FEJ5MVmFmBGtnrKpa73XpXyTqRxB/M0n1n/W9nGq
C4FSYa04T6N5RIZGBN2z2MT5IKGbFlbC8UrW0DxW7AYImQQcHtGl/m00QLVWutHQ
oVJYnFPlXTcHYvASLu+RhhsbDmxMgJJ0mcDpvsC4PjvB+TxywElgS70vE0XmLD+O
JtvsBslHZvPBKCOdT0MS+tgSOIfga+z1Z1g7+DVagf7quvmag8jfPioyKvxnK/Eg
sTUVi2ghzq8wm27ud/mIM7AY2qEORR8Go3TVB4HzWQgpZrt3i5MIlCaY504LzSRi
igHCzAPlHws+W0rB5N+er5/2pJKnfBSDiCiFAVtCLOZ7gLiMm0jhO2B6tUXHI/+M
RPjy02i59lINMRRev56GKtcd9qO/0kUJWdZTdA2XoS82ixPvZtXQpUpuL12ab+9E
aDK8Z4RHJYYfCT3Q5vNAXaiWQ+8PTWm2QgBR/bkwSWc+NpUFgNPN9PvQi8WEg5Um
AGMCAwEAAaNjMGEwHQYDVR0OBBYEFDZh4QB8iAUJUYtEbEf/GkzJ6k8SMB8GA1Ud
IwQYMBaAFDZh4QB8iAUJUYtEbEf/GkzJ6k8SMA8GA1UdEwEB/wQFMAMBAf8wDgYD
VR0PAQH/BAQDAgIEMA0GCSqGSIb3DQEBCwUAA4ICAQBTNNZe5cuf8oiq+jV0itTG
zWVhSTjOBEk2FQvh11J3o3lna0o7rd8RFHnN00q4hi6TapFhh4qaw/iG6Xg+xOan
63niLWIC5GOPFgPeYXM9+nBb3zZzC8ABypYuCusWCmt6Tn3+Pjbz3MTVhRGXuT/T
QH4KGFY4PhvzAyXwdjTOCXID+aHud4RLcSySr0Fq/L+R8TWalvM1wJJPhyRjqRCJ
erGtfBagiALzvhnmY7U1qFcS0NCnKjoO7oFedKdWlZz0YAfu3aGCJd4KHT0MsGiL
Zez9WP81xYSrKMNEsDK+zK5fVzw6jA7cxmpXcARTnmAuGUeI7VVDhDzKeVOctf3a
0qQLwC+d0+xrETZ4r2fRGNw2YEs2W8Qj6oDcfPvq9JySe7pJ6wcHnl5EZ0lwc4xH
7Y4Dx9RA1JlfooLMw3tOdJZH0enxPXaydfAD3YifeZpFaUzicHeLzVJLt9dvGB0b
HQLE4+EqKFgOZv2EoP686DQqbVS1u+9k0p2xbMA105TBIk7npraa8VM0fnrRKi7w
lZKwdH+aNAyhbXRW9xsnODJ+g8eF452zvbiKKngEKirK5LGieoXBX7tZ9D1GNBH2
Ob3bKOwwIWdEFle/YF/h6zWgdeoaNGDqVBrLr2+0DtWoiB1aDEjLWl9FmyIUyUm7
mD/vFDkzF+wm7cyWpQpCVQ==
-----END CERTIFICATE-----
`;
var Google_Hardware_Attestation_Root_4 = `
-----BEGIN CERTIFICATE-----
MIIFHDCCAwSgAwIBAgIJAPHBcqaZ6vUdMA0GCSqGSIb3DQEBCwUAMBsxGTAXBgNV
BAUTEGY5MjAwOWU4NTNiNmIwNDUwHhcNMjIwMzIwMTgwNzQ4WhcNNDIwMzE1MTgw
NzQ4WjAbMRkwFwYDVQQFExBmOTIwMDllODUzYjZiMDQ1MIICIjANBgkqhkiG9w0B
AQEFAAOCAg8AMIICCgKCAgEAr7bHgiuxpwHsK7Qui8xUFmOr75gvMsd/dTEDDJdS
Sxtf6An7xyqpRR90PL2abxM1dEqlXnf2tqw1Ne4Xwl5jlRfdnJLmN0pTy/4lj4/7
tv0Sk3iiKkypnEUtR6WfMgH0QZfKHM1+di+y9TFRtv6y//0rb+T+W8a9nsNL/ggj
nar86461qO0rOs2cXjp3kOG1FEJ5MVmFmBGtnrKpa73XpXyTqRxB/M0n1n/W9nGq
C4FSYa04T6N5RIZGBN2z2MT5IKGbFlbC8UrW0DxW7AYImQQcHtGl/m00QLVWutHQ
oVJYnFPlXTcHYvASLu+RhhsbDmxMgJJ0mcDpvsC4PjvB+TxywElgS70vE0XmLD+O
JtvsBslHZvPBKCOdT0MS+tgSOIfga+z1Z1g7+DVagf7quvmag8jfPioyKvxnK/Eg
sTUVi2ghzq8wm27ud/mIM7AY2qEORR8Go3TVB4HzWQgpZrt3i5MIlCaY504LzSRi
igHCzAPlHws+W0rB5N+er5/2pJKnfBSDiCiFAVtCLOZ7gLiMm0jhO2B6tUXHI/+M
RPjy02i59lINMRRev56GKtcd9qO/0kUJWdZTdA2XoS82ixPvZtXQpUpuL12ab+9E
aDK8Z4RHJYYfCT3Q5vNAXaiWQ+8PTWm2QgBR/bkwSWc+NpUFgNPN9PvQi8WEg5Um
AGMCAwEAAaNjMGEwHQYDVR0OBBYEFDZh4QB8iAUJUYtEbEf/GkzJ6k8SMB8GA1Ud
IwQYMBaAFDZh4QB8iAUJUYtEbEf/GkzJ6k8SMA8GA1UdEwEB/wQFMAMBAf8wDgYD
VR0PAQH/BAQDAgIEMA0GCSqGSIb3DQEBCwUAA4ICAQB8cMqTllHc8U+qCrOlg3H7
174lmaCsbo/bJ0C17JEgMLb4kvrqsXZs01U3mB/qABg/1t5Pd5AORHARs1hhqGIC
W/nKMav574f9rZN4PC2ZlufGXb7sIdJpGiO9ctRhiLuYuly10JccUZGEHpHSYM2G
tkgYbZba6lsCPYAAP83cyDV+1aOkTf1RCp/lM0PKvmxYN10RYsK631jrleGdcdkx
oSK//mSQbgcWnmAEZrzHoF1/0gso1HZgIn0YLzVhLSA/iXCX4QT2h3J5z3znluKG
1nv8NQdxei2DIIhASWfu804CA96cQKTTlaae2fweqXjdN1/v2nqOhngNyz1361mF
mr4XmaKH/ItTwOe72NI9ZcwS1lVaCvsIkTDCEXdm9rCNPAY10iTunIHFXRh+7KPz
lHGewCq/8TOohBRn0/NNfh7uRslOSZ/xKbN9tMBtw37Z8d2vvnXq/YWdsm1+JLVw
n6yYD/yacNJBlwpddla8eaVMjsF6nBnIgQOf9zKSe06nSTqvgwUHosgOECZJZ1Eu
zbH4yswbt02tKtKEFhx+v+OTge/06V+jGsqTWLsfrOCNLuA8H++z+pUENmpqnnHo
vaI47gC+TNpkgYGkkBT6B/m/U01BuOBBTzhIlMEZq9qkDWuM2cA5kW5V3FJUcfHn
w1IdYIg2Wxg7yHcQZemFQg==
-----END CERTIFICATE-----
`;

// node_modules/@simplewebauthn/server/esm/services/defaultRootCerts/apple.js
var Apple_WebAuthn_Root_CA = `-----BEGIN CERTIFICATE-----
MIICEjCCAZmgAwIBAgIQaB0BbHo84wIlpQGUKEdXcTAKBggqhkjOPQQDAzBLMR8w
HQYDVQQDDBZBcHBsZSBXZWJBdXRobiBSb290IENBMRMwEQYDVQQKDApBcHBsZSBJ
bmMuMRMwEQYDVQQIDApDYWxpZm9ybmlhMB4XDTIwMDMxODE4MjEzMloXDTQ1MDMx
NTAwMDAwMFowSzEfMB0GA1UEAwwWQXBwbGUgV2ViQXV0aG4gUm9vdCBDQTETMBEG
A1UECgwKQXBwbGUgSW5jLjETMBEGA1UECAwKQ2FsaWZvcm5pYTB2MBAGByqGSM49
AgEGBSuBBAAiA2IABCJCQ2pTVhzjl4Wo6IhHtMSAzO2cv+H9DQKev3//fG59G11k
xu9eI0/7o6V5uShBpe1u6l6mS19S1FEh6yGljnZAJ+2GNP1mi/YK2kSXIuTHjxA/
pcoRf7XkOtO4o1qlcaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUJtdk
2cV4wlpn0afeaxLQG2PxxtcwDgYDVR0PAQH/BAQDAgEGMAoGCCqGSM49BAMDA2cA
MGQCMFrZ+9DsJ1PW9hfNdBywZDsWDbWFp28it1d/5w2RPkRX3Bbn/UbDTNLx7Jr3
jAGGiQIwHFj+dJZYUJR786osByBelJYsVZd2GbHQu209b5RCmGQ21gpSAk9QZW4B
1bWeT0vT
-----END CERTIFICATE-----
`;

// node_modules/@simplewebauthn/server/esm/services/defaultRootCerts/mds.js
var GlobalSign_Root_CA_R3 = `-----BEGIN CERTIFICATE-----
MIIDXzCCAkegAwIBAgILBAAAAAABIVhTCKIwDQYJKoZIhvcNAQELBQAwTDEgMB4G
A1UECxMXR2xvYmFsU2lnbiBSb290IENBIC0gUjMxEzARBgNVBAoTCkdsb2JhbFNp
Z24xEzARBgNVBAMTCkdsb2JhbFNpZ24wHhcNMDkwMzE4MTAwMDAwWhcNMjkwMzE4
MTAwMDAwWjBMMSAwHgYDVQQLExdHbG9iYWxTaWduIFJvb3QgQ0EgLSBSMzETMBEG
A1UEChMKR2xvYmFsU2lnbjETMBEGA1UEAxMKR2xvYmFsU2lnbjCCASIwDQYJKoZI
hvcNAQEBBQADggEPADCCAQoCggEBAMwldpB5BngiFvXAg7aEyiie/QV2EcWtiHL8
RgJDx7KKnQRfJMsuS+FggkbhUqsMgUdwbN1k0ev1LKMPgj0MK66X17YUhhB5uzsT
gHeMCOFJ0mpiLx9e+pZo34knlTifBtc+ycsmWQ1z3rDI6SYOgxXG71uL0gRgykmm
KPZpO/bLyCiR5Z2KYVc3rHQU3HTgOu5yLy6c+9C7v/U9AOEGM+iCK65TpjoWc4zd
QQ4gOsC0p6Hpsk+QLjJg6VfLuQSSaGjlOCZgdbKfd/+RFO+uIEn8rUAVSNECMWEZ
XriX7613t2Saer9fwRPvm2L7DWzgVGkWqQPabumDk3F2xmmFghcCAwEAAaNCMEAw
DgYDVR0PAQH/BAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFI/wS3+o
LkUkrk1Q+mOai97i3Ru8MA0GCSqGSIb3DQEBCwUAA4IBAQBLQNvAUKr+yAzv95ZU
RUm7lgAJQayzE4aGKAczymvmdLm6AC2upArT9fHxD4q/c2dKg8dEe3jgr25sbwMp
jjM5RcOO5LlXbKr8EpbsU8Yt5CRsuZRj+9xTaGdWPoO4zzUhw8lo/s7awlOqzJCK
6fBdRoyV3XpYKBovHd7NADdBj+1EbddTKJd+82cEHhXXipa0095MJ6RMG3NzdvQX
mcIfeg7jLQitChws/zyrVQ4PkX4268NXSb7hLi18YIvDQVETI53O9zJrlAGomecs
Mx86OyXShkDOOyyGeMlhLxS67ttVb9+E7gUJTb0o2HLO02JQZR7rkpeDMdmztcpH
WD9f
-----END CERTIFICATE-----
 `;
var GlobalSign_Root_R46 = `-----BEGIN CERTIFICATE-----
MIIFWjCCA0KgAwIBAgISEdK7udcjGJ5AXwqdLdDfJWfRMA0GCSqGSIb3DQEBDAUA
MEYxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNhMRwwGgYD
VQQDExNHbG9iYWxTaWduIFJvb3QgUjQ2MB4XDTE5MDMyMDAwMDAwMFoXDTQ2MDMy
MDAwMDAwMFowRjELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYt
c2ExHDAaBgNVBAMTE0dsb2JhbFNpZ24gUm9vdCBSNDYwggIiMA0GCSqGSIb3DQEB
AQUAA4ICDwAwggIKAoICAQCsrHQy6LNl5brtQyYdpokNRbopiLKkHWPd08EsCVeJ
OaFV6Wc0dwxu5FUdUiXSE2te4R2pt32JMl8Nnp8semNgQB+msLZ4j5lUlghYruQG
vGIFAha/r6gjA7aUD7xubMLL1aa7DOn2wQL7Id5m3RerdELv8HQvJfTqa1VbkNud
316HCkD7rRlr+/fKYIje2sGP1q7Vf9Q8g+7XFkyDRTNrJ9CG0Bwta/OrffGFqfUo
0q3v84RLHIf8E6M6cqJaESvWJ3En7YEtbWaBkoe0G1h6zD8K+kZPTXhc+CtI4wSE
y132tGqzZfxCnlEmIyDLPRT5ge1lFgBPGmSXZgjPjHvjK8Cd+RTyG/FWaha/LIWF
zXg4mutCagI0GIMXTpRW+LaCtfOW3T3zvn8gdz57GSNrLNRyc0NXfeD412lPFzYE
+cCQYDdF3uYM2HSNrpyibXRdQr4G9dlkbgIQrImwTDsHTUB+JMWKmIJ5jqSngiCN
I/onccnfxkF0oE32kRbcRoxfKWMxWXEM2G/CtjJ9++ZdU6Z+Ffy7dXxd7Pj2Fxzs
x2sZy/N78CsHpdlseVR2bJ0cpm4O6XkMqCNqo98bMDGfsVR7/mrLZqrcZdCinkqa
ByFrgY/bxFn63iLABJzjqls2k+g9vXqhnQt2sQvHnf3PmKgGwvgqo6GDoLclcqUC
4wIDAQABo0IwQDAOBgNVHQ8BAf8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAdBgNV
HQ4EFgQUA1yrc4GHqMywptWU4jaWSf8FmSwwDQYJKoZIhvcNAQEMBQADggIBAHx4
7PYCLLtbfpIrXTncvtgdokIzTfnvpCo7RGkerNlFo048p9gkUbJUHJNOxO97k4Vg
JuoJSOD1u8fpaNK7ajFxzHmuEajwmf3lH7wvqMxX63bEIaZHU1VNaL8FpO7XJqti
2kM3S+LGteWygxk6x9PbTZ4IevPuzz5i+6zoYMzRx6Fcg0XERczzF2sUyQQCPtIk
pnnpHs6i58FZFZ8d4kuaPp92CC1r2LpXFNqD6v6MVenQTqnMdzGxRBF6XLE+0xRF
FRhiJBPSy03OXIPBNvIQtQ6IbbjhVp+J3pZmOUdkLG5NrmJ7v2B0GbhWrJKsFjLt
rWhV/pi60zTe9Mlhww6G9kuEYO4Ne7UyWHmRVSyBQ7N0H3qqJZ4d16GLuc1CLgSk
ZoNNiTW2bKg2SnkheCLQQrzRQDGQob4Ez8pn7fXwgNNgyYMqIgXQBztSvwyeqiv5
u+YfjyW6hY0XHgL+XVAEV8/+LbzvXMAaq7afJMbfc2hIkCwU9D9SGuTSyxTDYWnP
4vkYxboznxSjBF25cfe1lNj2M8FawTSLfJvdkzrnE6JwYZ+vj+vYxXX4M2bUdGc6
N3ec592kD3ZDZopD8p/7DEJ4Y9HiD2971KE9dJeFt0g5QdYg/NA6s/rob8SKunE3
vouXsXgxT7PntgMTzlSdriVZzH81Xwj3QEUxeCp6
-----END CERTIFICATE-----
`;

// node_modules/@simplewebauthn/server/esm/services/settingsService.js
var BaseSettingsService = class {
  constructor() {
    Object.defineProperty(this, "pemCertificates", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_runtimeSupportsPQC", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    this.pemCertificates = /* @__PURE__ */ new Map();
  }
  setRootCertificates(opts) {
    const { identifier, certificates } = opts;
    const newCertificates = [];
    for (const cert of certificates) {
      if (cert instanceof Uint8Array) {
        newCertificates.push(convertCertBufferToPEM(cert));
      } else {
        newCertificates.push(cert);
      }
    }
    this.pemCertificates.set(identifier, newCertificates);
  }
  getRootCertificates(opts) {
    const { identifier } = opts;
    return this.pemCertificates.get(identifier) ?? [];
  }
  runtimeSupportsPQC() {
    this._runtimeSupportsPQC ??= runtimeSupportsWebCryptoKeyAlg("ML-DSA-44");
    return this._runtimeSupportsPQC;
  }
};
var SettingsService = new BaseSettingsService();
SettingsService.setRootCertificates({
  identifier: "android-key",
  certificates: [
    Google_Hardware_Attestation_Root_1,
    Google_Hardware_Attestation_Root_2,
    Google_Hardware_Attestation_Root_3,
    Google_Hardware_Attestation_Root_4
  ]
});
SettingsService.setRootCertificates({
  identifier: "android-safetynet",
  certificates: [GlobalSign_Root_CA]
});
SettingsService.setRootCertificates({
  identifier: "apple",
  certificates: [Apple_WebAuthn_Root_CA]
});
SettingsService.setRootCertificates({
  identifier: "mds",
  certificates: [
    GlobalSign_Root_CA_R3,
    GlobalSign_Root_R46
  ]
});

// node_modules/@simplewebauthn/server/esm/registration/generateRegistrationOptions.js
var defaultAuthenticatorSelection = {
  residentKey: "preferred",
  userVerification: "preferred"
};
function getDefaultSupportedAlgorithmIDs() {
  if (SettingsService.runtimeSupportsPQC()) {
    return [COSEALG.ML_DSA_44, COSEALG.EdDSA, COSEALG.ES256, COSEALG.RS256];
  }
  return [COSEALG.EdDSA, COSEALG.ES256, COSEALG.RS256];
}
async function generateRegistrationOptions(options) {
  const { rpName, rpID, userName, userID, challenge = await generateChallenge(), userDisplayName = "", timeout = 6e4, attestationType = "none", excludeCredentials = [], authenticatorSelection = defaultAuthenticatorSelection, extensions, supportedAlgorithmIDs = getDefaultSupportedAlgorithmIDs(), preferredAuthenticatorType } = options;
  const pubKeyCredParams = supportedAlgorithmIDs.map((id) => ({
    alg: id,
    type: "public-key"
  }));
  if (authenticatorSelection.residentKey === void 0) {
    if (authenticatorSelection.requireResidentKey) {
      authenticatorSelection.residentKey = "required";
    } else {
    }
  } else {
    authenticatorSelection.requireResidentKey = authenticatorSelection.residentKey === "required";
  }
  let _challenge = challenge;
  if (typeof _challenge === "string") {
    _challenge = isoUint8Array_exports.fromUTF8String(_challenge);
  }
  if (typeof userID === "string") {
    throw new Error(`String values for \`userID\` are no longer supported. See https://simplewebauthn.dev/docs/advanced/server/custom-user-ids`);
  }
  let _userID = userID;
  if (!_userID) {
    _userID = await generateUserID();
  }
  const hints = [];
  if (preferredAuthenticatorType) {
    if (preferredAuthenticatorType === "securityKey") {
      hints.push("security-key");
      authenticatorSelection.authenticatorAttachment = "cross-platform";
    } else if (preferredAuthenticatorType === "localDevice") {
      hints.push("client-device");
      authenticatorSelection.authenticatorAttachment = "platform";
    } else if (preferredAuthenticatorType === "remoteDevice") {
      hints.push("hybrid");
      authenticatorSelection.authenticatorAttachment = "cross-platform";
    }
  }
  return {
    challenge: isoBase64URL_exports.fromBuffer(_challenge),
    rp: {
      name: rpName,
      id: rpID
    },
    user: {
      id: isoBase64URL_exports.fromBuffer(_userID),
      name: userName,
      displayName: userDisplayName
    },
    pubKeyCredParams,
    timeout,
    attestation: attestationType,
    excludeCredentials: excludeCredentials.map((cred) => {
      if (!isoBase64URL_exports.isBase64URL(cred.id)) {
        throw new Error(`excludeCredential id "${cred.id}" is not a valid base64url string`);
      }
      return {
        ...cred,
        id: isoBase64URL_exports.trimPadding(cred.id),
        type: "public-key"
      };
    }),
    authenticatorSelection,
    extensions: {
      ...extensions,
      credProps: true
    },
    hints
  };
}

// node_modules/@simplewebauthn/server/esm/helpers/parseBackupFlags.js
function parseBackupFlags({ be, bs }) {
  const credentialBackedUp = bs;
  let credentialDeviceType = "singleDevice";
  if (be) {
    credentialDeviceType = "multiDevice";
  }
  if (credentialDeviceType === "singleDevice" && credentialBackedUp) {
    throw new InvalidBackupFlags("Single-device credential indicated that it was backed up, which should be impossible.");
  }
  return { credentialDeviceType, credentialBackedUp };
}
var InvalidBackupFlags = class extends Error {
  constructor(message) {
    super(message);
    this.name = "InvalidBackupFlags";
  }
};

// node_modules/@simplewebauthn/server/esm/helpers/matchExpectedRPID.js
async function matchExpectedRPID(rpIDHash, expectedRPIDs) {
  try {
    const matchedRPID = await Promise.any(expectedRPIDs.map((expected) => {
      return new Promise((resolve, reject) => {
        toHash(isoUint8Array_exports.fromASCIIString(expected)).then((expectedRPIDHash) => {
          if (isoUint8Array_exports.areEqual(rpIDHash, expectedRPIDHash)) {
            resolve(expected);
          } else {
            reject();
          }
        });
      });
    }));
    return matchedRPID;
  } catch (err) {
    const _err = err;
    if (_err.name === "AggregateError") {
      throw new UnexpectedRPIDHash();
    }
    throw err;
  }
}
var UnexpectedRPIDHash = class extends Error {
  constructor() {
    const message = "Unexpected RP ID hash";
    super(message);
    this.name = "UnexpectedRPIDHash";
  }
};

// node_modules/@simplewebauthn/server/esm/registration/verifications/verifyAttestationFIDOU2F.js
async function verifyAttestationFIDOU2F(options) {
  const { attStmt, clientDataHash, rpIdHash, credentialID, credentialPublicKey, aaguid, rootCertificates } = options;
  const reservedByte = Uint8Array.from([0]);
  const publicKey = convertCOSEtoPKCS(credentialPublicKey);
  const signatureBase = isoUint8Array_exports.concat([
    reservedByte,
    rpIdHash,
    clientDataHash,
    credentialID,
    publicKey
  ]);
  const sig = attStmt.get("sig");
  const x5c = attStmt.get("x5c");
  if (!x5c) {
    throw new Error("No attestation certificate provided in attestation statement (FIDOU2F)");
  }
  if (!sig) {
    throw new Error("No attestation signature provided in attestation statement (FIDOU2F)");
  }
  const aaguidToHex = Number.parseInt(isoUint8Array_exports.toHex(aaguid), 16);
  if (aaguidToHex !== 0) {
    throw new Error(`AAGUID "${aaguidToHex}" was not expected value`);
  }
  try {
    await validateCertificatePath(x5c.map(convertCertBufferToPEM), rootCertificates);
  } catch (err) {
    const _err = err;
    throw new Error(`${_err.message} (FIDOU2F)`);
  }
  return verifySignature({
    signature: sig,
    data: signatureBase,
    x509Certificate: x5c[0],
    hashAlgorithm: COSEALG.ES256
  });
}

// node_modules/@simplewebauthn/server/esm/helpers/validateExtFIDOGenCEAAGUID.js
var id_fido_gen_ce_aaguid = "1.3.6.1.4.1.45724.1.1.4";
function validateExtFIDOGenCEAAGUID(certExtensions, aaguid) {
  if (!certExtensions) {
    return true;
  }
  const extFIDOGenCEAAGUID = certExtensions.find((ext) => ext.extnID === id_fido_gen_ce_aaguid);
  if (!extFIDOGenCEAAGUID) {
    return true;
  }
  const parsedExtFIDOGenCEAAGUID = AsnParser.parse(extFIDOGenCEAAGUID.extnValue, OctetString2);
  const extValue = new Uint8Array(parsedExtFIDOGenCEAAGUID.buffer);
  const aaguidAndExtAreEqual = isoUint8Array_exports.areEqual(aaguid, extValue);
  if (!aaguidAndExtAreEqual) {
    const _debugExtHex = isoUint8Array_exports.toHex(extValue);
    const _debugAAGUIDHex = isoUint8Array_exports.toHex(aaguid);
    throw new Error(`Certificate extension id-fido-gen-ce-aaguid (${id_fido_gen_ce_aaguid}) value of "${_debugExtHex}" was present but not equal to attestation statement AAGUID value of "${_debugAAGUIDHex}"`);
  }
  return true;
}

// node_modules/@simplewebauthn/server/esm/helpers/logging.js
var DefaultNoopLogger = {
  debug() {
  },
  info() {
  },
  warn() {
  },
  error() {
  }
};
function buildLoggerAllMethods(logger) {
  const toReturn = { ...DefaultNoopLogger };
  if (logger.debug) {
    toReturn.debug = logger.debug;
  }
  if (logger.info) {
    toReturn.info = logger.info;
  }
  if (logger.warn) {
    toReturn.warn = logger.warn;
  }
  if (logger.error) {
    toReturn.error = logger.error;
  }
  return toReturn;
}

// node_modules/@simplewebauthn/server/esm/services/metadataService.js
var NonRefreshingMDS = {
  url: "",
  no: 0,
  nextUpdate: /* @__PURE__ */ new Date(0)
};
var defaultURLMDS = "https://mds.fidoalliance.org/";
var SERVICE_STATE;
(function(SERVICE_STATE2) {
  SERVICE_STATE2[SERVICE_STATE2["DISABLED"] = 0] = "DISABLED";
  SERVICE_STATE2[SERVICE_STATE2["REFRESHING"] = 1] = "REFRESHING";
  SERVICE_STATE2[SERVICE_STATE2["READY"] = 2] = "READY";
})(SERVICE_STATE || (SERVICE_STATE = {}));
var BaseMetadataService = class {
  constructor() {
    Object.defineProperty(this, "mdsCache", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: {}
    });
    Object.defineProperty(this, "statementCache", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: {}
    });
    Object.defineProperty(this, "state", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: SERVICE_STATE.DISABLED
    });
    Object.defineProperty(this, "verificationMode", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: "strict"
    });
    Object.defineProperty(this, "logger", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: DefaultNoopLogger
    });
  }
  async initialize(opts = {}) {
    this.statementCache = {};
    const { mdsServers = [defaultURLMDS], statements, verificationMode, logger = DefaultNoopLogger } = opts;
    this.logger = buildLoggerAllMethods(logger);
    this.setState(SERVICE_STATE.REFRESHING);
    if (statements?.length) {
      let statementsAdded = 0;
      statements.forEach((statement) => {
        if (statement.aaguid) {
          this.statementCache[statement.aaguid] = {
            entry: {
              metadataStatement: statement,
              statusReports: [],
              timeOfLastStatusChange: "1970-01-01"
            },
            url: NonRefreshingMDS.url
          };
          statementsAdded += 1;
        }
      });
      this.logger.info(`Cached ${statementsAdded} local statements`);
    }
    if (mdsServers?.length) {
      const currentCacheCount = Object.keys(this.statementCache).length;
      let numServers = mdsServers.length;
      for (const url of mdsServers) {
        try {
          const cachedMDS = {
            url,
            no: 0,
            nextUpdate: /* @__PURE__ */ new Date(0)
          };
          const blob = await this.downloadBlob(cachedMDS);
          await this.verifyBlob(blob, cachedMDS);
        } catch (err) {
          this.logger.error(`Could not download BLOB from ${url}:`, err);
          numServers -= 1;
        }
      }
      const newCacheCount = Object.keys(this.statementCache).length;
      const cacheDiff = newCacheCount - currentCacheCount;
      this.logger.info(`Cached ${cacheDiff} statements from ${numServers} metadata server(s)`);
    }
    if (verificationMode) {
      this.verificationMode = verificationMode;
    }
    this.setState(SERVICE_STATE.READY);
  }
  async getStatement(aaguid) {
    if (this.state === SERVICE_STATE.DISABLED) {
      return;
    }
    if (!aaguid) {
      return;
    }
    if (aaguid instanceof Uint8Array) {
      aaguid = convertAAGUIDToString(aaguid);
    }
    await this.pauseUntilReady();
    const cachedStatement = this.statementCache[aaguid];
    if (!cachedStatement) {
      if (this.verificationMode === "strict") {
        throw new Error(`No metadata statement found for aaguid "${aaguid}"`);
      }
      return;
    }
    if (cachedStatement.url) {
      const mds = this.mdsCache[cachedStatement.url];
      const now = /* @__PURE__ */ new Date();
      if (now > mds.nextUpdate) {
        try {
          this.setState(SERVICE_STATE.REFRESHING);
          const blob = await this.downloadBlob(mds);
          await this.verifyBlob(blob, mds);
        } finally {
          this.setState(SERVICE_STATE.READY);
        }
      }
    }
    const { entry } = cachedStatement;
    for (const report of entry.statusReports) {
      const { status } = report;
      if (status === "USER_VERIFICATION_BYPASS" || status === "ATTESTATION_KEY_COMPROMISE" || status === "USER_KEY_REMOTE_COMPROMISE" || status === "USER_KEY_PHYSICAL_COMPROMISE") {
        throw new Error(`Detected compromised aaguid "${aaguid}"`);
      }
    }
    return entry.metadataStatement;
  }
  /**
   * Download and process the latest BLOB from MDS
   */
  async downloadBlob(cachedMDS) {
    const { url } = cachedMDS;
    const resp = await fetch2(url);
    const data = await resp.text();
    return data;
  }
  /**
   * Verify and process the MDS metadata blob
   */
  async verifyBlob(blob, cachedMDS) {
    const { url, no } = cachedMDS;
    const { payload, parsedNextUpdate } = await verifyMDSBlob(blob);
    if (payload.no <= no) {
      throw new Error(`Latest BLOB no. ${payload.no} is not greater than previous no. ${no}`);
    }
    for (const entry of payload.entries) {
      if (entry.aaguid) {
        this.statementCache[entry.aaguid] = { entry, url };
      }
    }
    if (url) {
      this.mdsCache[url] = {
        ...cachedMDS,
        // Store the payload `no` to make sure we're getting the next BLOB in the sequence
        no: payload.no,
        // Remember when we need to refresh this blob
        nextUpdate: parsedNextUpdate
      };
    } else {
      if (parsedNextUpdate < /* @__PURE__ */ new Date()) {
        this.logger.warn(`\u26A0\uFE0F This MDS blob (serial: ${payload.no}) contains stale data as of ${parsedNextUpdate.toISOString()}. Please consider re-initializing MetadataService with a newer MDS blob.`);
      }
    }
  }
  /**
   * A helper method to pause execution until the service is ready
   */
  pauseUntilReady() {
    if (this.state === SERVICE_STATE.READY) {
      return new Promise((resolve) => {
        resolve();
      });
    }
    const readyPromise = new Promise((resolve, reject) => {
      const totalTimeoutMS = 7e4;
      const intervalMS = 100;
      let iterations = totalTimeoutMS / intervalMS;
      const intervalID = globalThis.setInterval(() => {
        if (iterations < 1) {
          clearInterval(intervalID);
          reject(`State did not become ready in ${totalTimeoutMS / 1e3} seconds`);
        } else if (this.state === SERVICE_STATE.READY) {
          clearInterval(intervalID);
          resolve();
        }
        iterations -= 1;
      }, intervalMS);
    });
    return readyPromise;
  }
  /**
   * Report service status on change
   */
  setState(newState) {
    this.state = newState;
    if (newState === SERVICE_STATE.DISABLED) {
      this.logger.debug("MetadataService is DISABLED");
    } else if (newState === SERVICE_STATE.REFRESHING) {
      this.logger.debug("MetadataService is REFRESHING");
    } else if (newState === SERVICE_STATE.READY) {
      this.logger.debug("MetadataService is READY");
    }
  }
};
var MetadataService = new BaseMetadataService();

// node_modules/@simplewebauthn/server/esm/metadata/verifyAttestationWithMetadata.js
async function verifyAttestationWithMetadata({ statement, credentialPublicKey, x5c, attestationStatementAlg }) {
  const { authenticationAlgorithms, authenticatorGetInfo, attestationRootCertificates } = statement;
  const keypairCOSEAlgs = /* @__PURE__ */ new Set();
  authenticationAlgorithms.forEach((algSign) => {
    const algSignCOSEINFO = algSignToCOSEInfoMap[algSign];
    if (algSignCOSEINFO) {
      keypairCOSEAlgs.add(algSignCOSEINFO);
    }
  });
  const decodedPublicKey = decodeCredentialPublicKey(credentialPublicKey);
  const kty = decodedPublicKey.get(COSEKEYS.kty);
  const alg = decodedPublicKey.get(COSEKEYS.alg);
  if (!kty) {
    throw new Error("Credential public key was missing kty");
  }
  if (!alg) {
    throw new Error("Credential public key was missing alg");
  }
  if (!kty) {
    throw new Error("Credential public key was missing kty");
  }
  const publicKeyCOSEInfo = { kty, alg };
  if (isCOSEPublicKeyEC2(decodedPublicKey)) {
    const crv = decodedPublicKey.get(COSEKEYS.crv);
    publicKeyCOSEInfo.crv = crv;
  }
  let foundMatch = false;
  for (const keypairAlg of keypairCOSEAlgs) {
    if (keypairAlg.alg === publicKeyCOSEInfo.alg && keypairAlg.kty === publicKeyCOSEInfo.kty) {
      if ((keypairAlg.kty === COSEKTY.EC2 || keypairAlg.kty === COSEKTY.OKP) && keypairAlg.crv === publicKeyCOSEInfo.crv) {
        foundMatch = true;
      } else {
        foundMatch = true;
      }
    }
    if (foundMatch) {
      break;
    }
  }
  if (!foundMatch) {
    const debugMDSAlgs = authenticationAlgorithms.map((algSign) => `'${algSign}' (COSE info: ${stringifyCOSEInfo(algSignToCOSEInfoMap[algSign])})`);
    const strMDSAlgs = JSON.stringify(debugMDSAlgs, null, 2).replace(/"/g, "");
    const strPubKeyAlg = stringifyCOSEInfo(publicKeyCOSEInfo);
    throw new Error(`Public key parameters ${strPubKeyAlg} did not match any of the following metadata algorithms:
${strMDSAlgs}`);
  }
  if (attestationStatementAlg !== void 0 && authenticatorGetInfo?.algorithms !== void 0) {
    const getInfoAlgs = authenticatorGetInfo.algorithms.map((_alg) => _alg.alg);
    if (getInfoAlgs.indexOf(attestationStatementAlg) < 0) {
      throw new Error(`Attestation statement alg ${attestationStatementAlg} did not match one of ${getInfoAlgs}`);
    }
  }
  const authenticatorCerts = x5c.map(convertCertBufferToPEM);
  const statementRootCerts = attestationRootCertificates.map(convertCertBufferToPEM);
  let authenticatorIsSelfReferencing = false;
  if (authenticatorCerts.length === 1 && statementRootCerts.indexOf(authenticatorCerts[0]) >= 0) {
    authenticatorIsSelfReferencing = true;
  }
  if (!authenticatorIsSelfReferencing) {
    await validateCertificatePath(authenticatorCerts, statementRootCerts);
  }
  return true;
}
var algSignToCOSEInfoMap = {
  secp256r1_ecdsa_sha256_raw: { kty: 2, alg: -7, crv: 1 },
  secp256r1_ecdsa_sha256_der: { kty: 2, alg: -7, crv: 1 },
  rsassa_pss_sha256_raw: { kty: 3, alg: -37 },
  rsassa_pss_sha256_der: { kty: 3, alg: -37 },
  secp256k1_ecdsa_sha256_raw: { kty: 2, alg: -47, crv: 8 },
  secp256k1_ecdsa_sha256_der: { kty: 2, alg: -47, crv: 8 },
  rsassa_pss_sha384_raw: { kty: 3, alg: -38 },
  rsassa_pkcsv15_sha256_raw: { kty: 3, alg: -257 },
  rsassa_pkcsv15_sha384_raw: { kty: 3, alg: -258 },
  rsassa_pkcsv15_sha512_raw: { kty: 3, alg: -259 },
  rsassa_pkcsv15_sha1_raw: { kty: 3, alg: -65535 },
  secp384r1_ecdsa_sha384_raw: { kty: 2, alg: -35, crv: 2 },
  secp512r1_ecdsa_sha256_raw: { kty: 2, alg: -36, crv: 3 },
  ed25519_eddsa_sha512_raw: { kty: 1, alg: -8, crv: 6 }
};
function stringifyCOSEInfo(info) {
  const { kty, alg, crv } = info;
  let toReturn = "";
  if (kty !== COSEKTY.RSA) {
    toReturn = `{ kty: ${kty}, alg: ${alg}, crv: ${crv} }`;
  } else {
    toReturn = `{ kty: ${kty}, alg: ${alg} }`;
  }
  return toReturn;
}

// node_modules/@simplewebauthn/server/esm/registration/verifications/verifyAttestationPacked.js
async function verifyAttestationPacked(options) {
  const { attStmt, clientDataHash, authData, credentialPublicKey, aaguid, rootCertificates } = options;
  const sig = attStmt.get("sig");
  const x5c = attStmt.get("x5c");
  const alg = attStmt.get("alg");
  if (!sig) {
    throw new Error("No attestation signature provided in attestation statement (Packed)");
  }
  if (!alg) {
    throw new Error("Attestation statement did not contain alg (Packed)");
  }
  if (!isCOSEAlg(alg)) {
    throw new Error(`Attestation statement contained invalid alg ${alg} (Packed)`);
  }
  const signatureBase = isoUint8Array_exports.concat([authData, clientDataHash]);
  let verified = false;
  if (x5c) {
    const { subject, basicConstraintsCA, version, notBefore, notAfter, parsedCertificate } = getCertificateInfo(x5c[0]);
    const { OU, CN, O, C } = subject;
    if (OU !== "Authenticator Attestation") {
      throw new Error('Certificate OU was not "Authenticator Attestation" (Packed|Full)');
    }
    if (!CN) {
      throw new Error("Certificate CN was empty (Packed|Full)");
    }
    if (!O) {
      throw new Error("Certificate O was empty (Packed|Full)");
    }
    if (!C || C.length !== 2) {
      throw new Error("Certificate C was not two-character ISO 3166 code (Packed|Full)");
    }
    if (basicConstraintsCA) {
      throw new Error("Certificate basic constraints CA was not `false` (Packed|Full)");
    }
    if (version !== 2) {
      throw new Error("Certificate version was not `3` (ASN.1 value of 2) (Packed|Full)");
    }
    let now = /* @__PURE__ */ new Date();
    if (notBefore > now) {
      throw new Error(`Certificate not good before "${notBefore.toString()}" (Packed|Full)`);
    }
    now = /* @__PURE__ */ new Date();
    if (notAfter < now) {
      throw new Error(`Certificate not good after "${notAfter.toString()}" (Packed|Full)`);
    }
    try {
      await validateExtFIDOGenCEAAGUID(parsedCertificate.tbsCertificate.extensions, aaguid);
    } catch (err) {
      const _err = err;
      throw new Error(`${_err.message} (Packed|Full)`);
    }
    const statement = await MetadataService.getStatement(aaguid);
    if (statement) {
      if (statement.attestationTypes.indexOf("basic_full") < 0) {
        throw new Error("Metadata does not indicate support for full attestations (Packed|Full)");
      }
      try {
        await verifyAttestationWithMetadata({
          statement,
          credentialPublicKey,
          x5c,
          attestationStatementAlg: alg
        });
      } catch (err) {
        const _err = err;
        throw new Error(`${_err.message} (Packed|Full)`);
      }
    } else {
      try {
        await validateCertificatePath(x5c.map(convertCertBufferToPEM), rootCertificates);
      } catch (err) {
        const _err = err;
        throw new Error(`${_err.message} (Packed|Full)`, { cause: _err });
      }
    }
    verified = await verifySignature({
      signature: sig,
      data: signatureBase,
      x509Certificate: x5c[0],
      hashAlgorithm: alg
    });
  } else {
    verified = await verifySignature({
      signature: sig,
      data: signatureBase,
      credentialPublicKey,
      hashAlgorithm: alg
    });
  }
  return verified;
}

// node_modules/@simplewebauthn/server/esm/registration/verifications/verifyAttestationAndroidSafetyNet.js
async function verifyAttestationAndroidSafetyNet(options) {
  const { attStmt, clientDataHash, authData, aaguid, rootCertificates, verifyTimestampMS = true, credentialPublicKey, attestationSafetyNetEnforceCTSCheck } = options;
  const alg = attStmt.get("alg");
  const response2 = attStmt.get("response");
  const ver = attStmt.get("ver");
  if (!ver) {
    throw new Error("No ver value in attestation (SafetyNet)");
  }
  if (!response2) {
    throw new Error("No response was included in attStmt by authenticator (SafetyNet)");
  }
  const jwt = isoUint8Array_exports.toUTF8String(response2);
  const jwtParts = jwt.split(".");
  const HEADER = JSON.parse(isoBase64URL_exports.toUTF8String(jwtParts[0]));
  const PAYLOAD = JSON.parse(isoBase64URL_exports.toUTF8String(jwtParts[1]));
  const SIGNATURE = jwtParts[2];
  const { nonce, ctsProfileMatch, timestampMs } = PAYLOAD;
  if (verifyTimestampMS) {
    let now = Date.now();
    if (timestampMs > Date.now()) {
      throw new Error(`Payload timestamp "${timestampMs}" was later than "${now}" (SafetyNet)`);
    }
    const timestampPlusDelay = timestampMs + 60 * 1e3;
    now = Date.now();
    if (timestampPlusDelay < now) {
      throw new Error(`Payload timestamp "${timestampPlusDelay}" has expired (SafetyNet)`);
    }
  }
  const nonceBase = isoUint8Array_exports.concat([authData, clientDataHash]);
  const nonceBuffer = await toHash(nonceBase);
  const expectedNonce = isoBase64URL_exports.fromBuffer(nonceBuffer, "base64");
  if (nonce !== expectedNonce) {
    throw new Error("Could not verify payload nonce (SafetyNet)");
  }
  if (attestationSafetyNetEnforceCTSCheck && !ctsProfileMatch) {
    throw new Error("Could not verify device integrity (SafetyNet)");
  }
  const leafCertBuffer = isoBase64URL_exports.toBuffer(HEADER.x5c[0], "base64");
  const leafCertInfo = getCertificateInfo(leafCertBuffer);
  const { subject } = leafCertInfo;
  if (subject.CN !== "attest.android.com") {
    throw new Error('Certificate common name was not "attest.android.com" (SafetyNet)');
  }
  const statement = await MetadataService.getStatement(aaguid);
  if (statement) {
    try {
      await verifyAttestationWithMetadata({
        statement,
        credentialPublicKey,
        x5c: HEADER.x5c,
        attestationStatementAlg: alg
      });
    } catch (err) {
      const _err = err;
      throw new Error(`${_err.message} (SafetyNet)`);
    }
  } else {
    try {
      await validateCertificatePath(HEADER.x5c.map(convertCertBufferToPEM), rootCertificates);
    } catch (err) {
      const _err = err;
      throw new Error(`${_err.message} (SafetyNet)`);
    }
  }
  const signatureBaseBuffer = isoUint8Array_exports.fromUTF8String(`${jwtParts[0]}.${jwtParts[1]}`);
  const signatureBuffer = isoBase64URL_exports.toBuffer(SIGNATURE);
  const verified = await verifySignature({
    signature: signatureBuffer,
    data: signatureBaseBuffer,
    x509Certificate: leafCertBuffer,
    hashAlgorithm: alg
  });
  return verified;
}

// node_modules/@simplewebauthn/server/esm/registration/verifications/tpm/constants.js
var TPM_ST = {
  196: "TPM_ST_RSP_COMMAND",
  32768: "TPM_ST_NULL",
  32769: "TPM_ST_NO_SESSIONS",
  32770: "TPM_ST_SESSIONS",
  32788: "TPM_ST_ATTEST_NV",
  32789: "TPM_ST_ATTEST_COMMAND_AUDIT",
  32790: "TPM_ST_ATTEST_SESSION_AUDIT",
  32791: "TPM_ST_ATTEST_CERTIFY",
  32792: "TPM_ST_ATTEST_QUOTE",
  32793: "TPM_ST_ATTEST_TIME",
  32794: "TPM_ST_ATTEST_CREATION",
  32801: "TPM_ST_CREATION",
  32802: "TPM_ST_VERIFIED",
  32803: "TPM_ST_AUTH_SECRET",
  32804: "TPM_ST_HASHCHECK",
  32805: "TPM_ST_AUTH_SIGNED",
  32809: "TPM_ST_FU_MANIFEST"
};
var TPM_ALG = {
  0: "TPM_ALG_ERROR",
  1: "TPM_ALG_RSA",
  4: "TPM_ALG_SHA",
  // @ts-ignore 2300
  4: "TPM_ALG_SHA1",
  5: "TPM_ALG_HMAC",
  6: "TPM_ALG_AES",
  7: "TPM_ALG_MGF1",
  8: "TPM_ALG_KEYEDHASH",
  10: "TPM_ALG_XOR",
  11: "TPM_ALG_SHA256",
  12: "TPM_ALG_SHA384",
  13: "TPM_ALG_SHA512",
  16: "TPM_ALG_NULL",
  18: "TPM_ALG_SM3_256",
  19: "TPM_ALG_SM4",
  20: "TPM_ALG_RSASSA",
  21: "TPM_ALG_RSAES",
  22: "TPM_ALG_RSAPSS",
  23: "TPM_ALG_OAEP",
  24: "TPM_ALG_ECDSA",
  25: "TPM_ALG_ECDH",
  26: "TPM_ALG_ECDAA",
  27: "TPM_ALG_SM2",
  28: "TPM_ALG_ECSCHNORR",
  29: "TPM_ALG_ECMQV",
  32: "TPM_ALG_KDF1_SP800_56A",
  33: "TPM_ALG_KDF2",
  34: "TPM_ALG_KDF1_SP800_108",
  35: "TPM_ALG_ECC",
  37: "TPM_ALG_SYMCIPHER",
  38: "TPM_ALG_CAMELLIA",
  64: "TPM_ALG_CTR",
  65: "TPM_ALG_OFB",
  66: "TPM_ALG_CBC",
  67: "TPM_ALG_CFB",
  68: "TPM_ALG_ECB"
};
var TPM_ECC_CURVE = {
  0: "TPM_ECC_NONE",
  1: "TPM_ECC_NIST_P192",
  2: "TPM_ECC_NIST_P224",
  3: "TPM_ECC_NIST_P256",
  4: "TPM_ECC_NIST_P384",
  5: "TPM_ECC_NIST_P521",
  16: "TPM_ECC_BN_P256",
  17: "TPM_ECC_BN_P638",
  32: "TPM_ECC_SM2_P256"
};
var TPM_MANUFACTURERS = {
  "id:414D4400": { name: "AMD", id: "AMD" },
  "id:414E5400": { name: "Ant Group", id: "ANT" },
  "id:41544D4C": { name: "Atmel", id: "ATML" },
  "id:4252434D": { name: "Broadcom", id: "BRCM" },
  "id:4353434F": { name: "Cisco", id: "CSCO" },
  "id:464C5953": { name: "Flyslice Technologies", id: "FLYS" },
  "id:524F4343": { name: "Fuzhou Rockchip", id: "ROCC" },
  "id:474F4F47": { name: "Google", id: "GOOG" },
  "id:48504900": { name: "HPI", id: "HPI" },
  "id:48504500": { name: "HPE", id: "HPE" },
  "id:48495349": { name: "Huawei", id: "HISI" },
  "id:49424D00": { name: "IBM", id: "IBM" },
  // IBM is "id:49424d00" in the TPM spec. It's been normalized here
  "id:49465800": { name: "Infineon", id: "IFX" },
  "id:494E5443": { name: "Intel", id: "INTC" },
  "id:4C454E00": { name: "Lenovo", id: "LEN" },
  "id:4D534654": { name: "Microsoft", id: "MSFT" },
  "id:4E534D20": { name: "National Semiconductor", id: "NSM" },
  "id:4E545A00": { name: "Nationz", id: "NTZ" },
  "id:4E534700": { name: "NSING", id: "NSG" },
  "id:4E544300": { name: "Nuvoton Technology", id: "NTC" },
  "id:51434F4D": { name: "Qualcomm", id: "QCOM" },
  "id:534D534E": { name: "Samsung", id: "SMSN" },
  "id:53454345": { name: "SecEdge", id: "SECE" },
  "id:534E5300": { name: "Sinosun", id: "SNS" },
  "id:534D5343": { name: "SMSC", id: "SMSC" },
  "id:53544D20": { name: "STMicroelectronics", id: "STM" },
  "id:54584E00": { name: "Texas Instruments", id: "TXN" },
  "id:57454300": { name: "Winbond", id: "WEC" },
  "id:5345414C": { name: "Wisekey", id: "SEAL" },
  "id:FFFFF1D0": { name: "FIDO Alliance", id: "FIDO" }
  // FIDO Conformance
};
var TPM_ECC_CURVE_COSE_CRV_MAP = {
  TPM_ECC_NIST_P256: 1,
  // p256
  TPM_ECC_NIST_P384: 2,
  // p384
  TPM_ECC_NIST_P521: 3,
  // p521
  TPM_ECC_BN_P256: 1,
  // p256
  TPM_ECC_SM2_P256: 1
  // p256
};

// node_modules/@simplewebauthn/server/esm/registration/verifications/tpm/parseCertInfo.js
function parseCertInfo(certInfo) {
  let pointer = 0;
  const dataView = isoUint8Array_exports.toDataView(certInfo);
  const magic = dataView.getUint32(pointer);
  pointer += 4;
  const typeBuffer = dataView.getUint16(pointer);
  pointer += 2;
  const type = TPM_ST[typeBuffer];
  const qualifiedSignerLength = dataView.getUint16(pointer);
  pointer += 2;
  const qualifiedSigner = certInfo.slice(pointer, pointer += qualifiedSignerLength);
  const extraDataLength = dataView.getUint16(pointer);
  pointer += 2;
  const extraData = certInfo.slice(pointer, pointer += extraDataLength);
  const clock = certInfo.slice(pointer, pointer += 8);
  const resetCount = dataView.getUint32(pointer);
  pointer += 4;
  const restartCount = dataView.getUint32(pointer);
  pointer += 4;
  const safe = !!certInfo.slice(pointer, pointer += 1);
  const clockInfo = { clock, resetCount, restartCount, safe };
  const firmwareVersion = certInfo.slice(pointer, pointer += 8);
  const attestedNameLength = dataView.getUint16(pointer);
  pointer += 2;
  const attestedName = certInfo.slice(pointer, pointer += attestedNameLength);
  const attestedNameDataView = isoUint8Array_exports.toDataView(attestedName);
  const qualifiedNameLength = dataView.getUint16(pointer);
  pointer += 2;
  const qualifiedName = certInfo.slice(pointer, pointer += qualifiedNameLength);
  const attested = {
    nameAlg: TPM_ALG[attestedNameDataView.getUint16(0)],
    nameAlgBuffer: attestedName.slice(0, 2),
    name: attestedName,
    qualifiedName
  };
  return {
    magic,
    type,
    qualifiedSigner,
    extraData,
    clockInfo,
    firmwareVersion,
    attested
  };
}

// node_modules/@simplewebauthn/server/esm/registration/verifications/tpm/parsePubArea.js
function parsePubArea(pubArea) {
  let pointer = 0;
  const dataView = isoUint8Array_exports.toDataView(pubArea);
  const type = TPM_ALG[dataView.getUint16(pointer)];
  pointer += 2;
  const nameAlg = TPM_ALG[dataView.getUint16(pointer)];
  pointer += 2;
  const objectAttributesInt = dataView.getUint32(pointer);
  pointer += 4;
  const objectAttributes = {
    fixedTPM: !!(objectAttributesInt & 1),
    stClear: !!(objectAttributesInt & 2),
    fixedParent: !!(objectAttributesInt & 8),
    sensitiveDataOrigin: !!(objectAttributesInt & 16),
    userWithAuth: !!(objectAttributesInt & 32),
    adminWithPolicy: !!(objectAttributesInt & 64),
    noDA: !!(objectAttributesInt & 512),
    encryptedDuplication: !!(objectAttributesInt & 1024),
    restricted: !!(objectAttributesInt & 32768),
    decrypt: !!(objectAttributesInt & 65536),
    signOrEncrypt: !!(objectAttributesInt & 131072)
  };
  const authPolicyLength = dataView.getUint16(pointer);
  pointer += 2;
  const authPolicy = pubArea.slice(pointer, pointer += authPolicyLength);
  const parameters = {};
  let unique = Uint8Array.from([]);
  if (type === "TPM_ALG_RSA") {
    const symmetric = TPM_ALG[dataView.getUint16(pointer)];
    pointer += 2;
    const scheme = TPM_ALG[dataView.getUint16(pointer)];
    pointer += 2;
    const keyBits = dataView.getUint16(pointer);
    pointer += 2;
    const exponent = dataView.getUint32(pointer);
    pointer += 4;
    parameters.rsa = { symmetric, scheme, keyBits, exponent };
    const uniqueLength = dataView.getUint16(pointer);
    pointer += 2;
    unique = pubArea.slice(pointer, pointer += uniqueLength);
  } else if (type === "TPM_ALG_ECC") {
    const symmetric = TPM_ALG[dataView.getUint16(pointer)];
    pointer += 2;
    const scheme = TPM_ALG[dataView.getUint16(pointer)];
    pointer += 2;
    const curveID = TPM_ECC_CURVE[dataView.getUint16(pointer)];
    pointer += 2;
    const kdf = TPM_ALG[dataView.getUint16(pointer)];
    pointer += 2;
    parameters.ecc = { symmetric, scheme, curveID, kdf };
    const uniqueXLength = dataView.getUint16(pointer);
    pointer += 2;
    const uniqueX = pubArea.slice(pointer, pointer += uniqueXLength);
    const uniqueYLength = dataView.getUint16(pointer);
    pointer += 2;
    const uniqueY = pubArea.slice(pointer, pointer += uniqueYLength);
    unique = isoUint8Array_exports.concat([uniqueX, uniqueY]);
  } else {
    throw new Error(`Unexpected type "${type}" (TPM)`);
  }
  return {
    type,
    nameAlg,
    objectAttributes,
    authPolicy,
    parameters,
    unique
  };
}

// node_modules/@simplewebauthn/server/esm/registration/verifications/tpm/isValidTPMManufacturerID.js
function getTPMManufacturerInfo(id) {
  const _normalized = `id:${id.substring(3).toUpperCase()}`;
  return TPM_MANUFACTURERS[_normalized];
}

// node_modules/@simplewebauthn/server/esm/registration/verifications/tpm/verifyAttestationTPM.js
async function verifyAttestationTPM(options) {
  const { aaguid, attStmt, authData, credentialPublicKey, clientDataHash, rootCertificates } = options;
  const ver = attStmt.get("ver");
  const sig = attStmt.get("sig");
  const alg = attStmt.get("alg");
  const x5c = attStmt.get("x5c");
  const pubArea = attStmt.get("pubArea");
  const certInfo = attStmt.get("certInfo");
  if (ver !== "2.0") {
    throw new Error(`Unexpected ver "${ver}", expected "2.0" (TPM)`);
  }
  if (!sig) {
    throw new Error("No attestation signature provided in attestation statement (TPM)");
  }
  if (!alg) {
    throw new Error(`Attestation statement did not contain alg (TPM)`);
  }
  if (!isCOSEAlg(alg)) {
    throw new Error(`Attestation statement contained invalid alg ${alg} (TPM)`);
  }
  if (!x5c) {
    throw new Error("No attestation certificate provided in attestation statement (TPM)");
  }
  if (!pubArea) {
    throw new Error("Attestation statement did not contain pubArea (TPM)");
  }
  if (!certInfo) {
    throw new Error("Attestation statement did not contain certInfo (TPM)");
  }
  const parsedPubArea = parsePubArea(pubArea);
  const { unique, type: pubType, parameters } = parsedPubArea;
  const cosePublicKey = decodeCredentialPublicKey(credentialPublicKey);
  if (pubType === "TPM_ALG_RSA") {
    if (!isCOSEPublicKeyRSA(cosePublicKey)) {
      throw new Error(`Credential public key with kty ${cosePublicKey.get(COSEKEYS.kty)} did not match ${pubType}`);
    }
    const n = cosePublicKey.get(COSEKEYS.n);
    const e = cosePublicKey.get(COSEKEYS.e);
    if (!n) {
      throw new Error("COSE public key missing n (TPM|RSA)");
    }
    if (!e) {
      throw new Error("COSE public key missing e (TPM|RSA)");
    }
    if (!isoUint8Array_exports.areEqual(unique, n)) {
      throw new Error("PubArea unique is not same as credentialPublicKey (TPM|RSA)");
    }
    if (!parameters.rsa) {
      throw new Error(`Parsed pubArea type is RSA, but missing parameters.rsa (TPM|RSA)`);
    }
    const eBuffer = e;
    const pubAreaExponent = parameters.rsa.exponent || 65537;
    const eSum = eBuffer[0] + (eBuffer[1] << 8) + (eBuffer[2] << 16);
    if (pubAreaExponent !== eSum) {
      throw new Error(`Unexpected public key exp ${eSum}, expected ${pubAreaExponent} (TPM|RSA)`);
    }
  } else if (pubType === "TPM_ALG_ECC") {
    if (!isCOSEPublicKeyEC2(cosePublicKey)) {
      throw new Error(`Credential public key with kty ${cosePublicKey.get(COSEKEYS.kty)} did not match ${pubType}`);
    }
    const crv = cosePublicKey.get(COSEKEYS.crv);
    const x = cosePublicKey.get(COSEKEYS.x);
    const y = cosePublicKey.get(COSEKEYS.y);
    if (!crv) {
      throw new Error("COSE public key missing crv (TPM|ECC)");
    }
    if (!x) {
      throw new Error("COSE public key missing x (TPM|ECC)");
    }
    if (!y) {
      throw new Error("COSE public key missing y (TPM|ECC)");
    }
    if (!isoUint8Array_exports.areEqual(unique, isoUint8Array_exports.concat([x, y]))) {
      throw new Error("PubArea unique is not same as public key x and y (TPM|ECC)");
    }
    if (!parameters.ecc) {
      throw new Error(`Parsed pubArea type is ECC, but missing parameters.ecc (TPM|ECC)`);
    }
    const pubAreaCurveID = parameters.ecc.curveID;
    const pubAreaCurveIDMapToCOSECRV = TPM_ECC_CURVE_COSE_CRV_MAP[pubAreaCurveID];
    if (pubAreaCurveIDMapToCOSECRV !== crv) {
      throw new Error(`Public area key curve ID "${pubAreaCurveID}" mapped to "${pubAreaCurveIDMapToCOSECRV}" which did not match public key crv of "${crv}" (TPM|ECC)`);
    }
  } else {
    throw new Error(`Unsupported pubArea.type "${pubType}"`);
  }
  const parsedCertInfo = parseCertInfo(certInfo);
  const { magic, type: certType, attested, extraData } = parsedCertInfo;
  if (magic !== 4283712327) {
    throw new Error(`Unexpected magic value "${magic}", expected "0xff544347" (TPM)`);
  }
  if (certType !== "TPM_ST_ATTEST_CERTIFY") {
    throw new Error(`Unexpected type "${certType}", expected "TPM_ST_ATTEST_CERTIFY" (TPM)`);
  }
  const pubAreaHash = await toHash(pubArea, attestedNameAlgToCOSEAlg(attested.nameAlg));
  const attestedName = isoUint8Array_exports.concat([
    attested.nameAlgBuffer,
    pubAreaHash
  ]);
  if (!isoUint8Array_exports.areEqual(attested.name, attestedName)) {
    throw new Error(`Attested name comparison failed (TPM)`);
  }
  const attToBeSigned = isoUint8Array_exports.concat([authData, clientDataHash]);
  const attToBeSignedHash = await toHash(attToBeSigned, alg);
  if (!isoUint8Array_exports.areEqual(extraData, attToBeSignedHash)) {
    throw new Error("CertInfo extra data did not equal hashed attestation (TPM)");
  }
  if (x5c.length < 1) {
    throw new Error("No certificates present in x5c array (TPM)");
  }
  const leafCertInfo = getCertificateInfo(x5c[0]);
  const { basicConstraintsCA, version, subject, notAfter, notBefore } = leafCertInfo;
  if (basicConstraintsCA) {
    throw new Error("Certificate basic constraints CA was not `false` (TPM)");
  }
  if (version !== 2) {
    throw new Error("Certificate version was not `3` (ASN.1 value of 2) (TPM)");
  }
  if (subject.combined.length > 0) {
    throw new Error("Certificate subject was not empty (TPM)");
  }
  let now = /* @__PURE__ */ new Date();
  if (notBefore > now) {
    throw new Error(`Certificate not good before "${notBefore.toString()}" (TPM)`);
  }
  now = /* @__PURE__ */ new Date();
  if (notAfter < now) {
    throw new Error(`Certificate not good after "${notAfter.toString()}" (TPM)`);
  }
  const parsedCert = AsnParser.parse(x5c[0], Certificate);
  if (!parsedCert.tbsCertificate.extensions) {
    throw new Error("Certificate was missing extensions (TPM)");
  }
  let subjectAltNamePresent;
  let extKeyUsage;
  parsedCert.tbsCertificate.extensions.forEach((ext) => {
    if (ext.extnID === id_ce_subjectAltName) {
      subjectAltNamePresent = AsnParser.parse(ext.extnValue, SubjectAlternativeName);
    } else if (ext.extnID === id_ce_extKeyUsage) {
      extKeyUsage = AsnParser.parse(ext.extnValue, ExtendedKeyUsage);
    }
  });
  if (!subjectAltNamePresent) {
    throw new Error("Certificate did not contain subjectAltName extension (TPM)");
  }
  if (!subjectAltNamePresent[0].directoryName?.[0].length) {
    throw new Error("Certificate subjectAltName extension directoryName was empty (TPM)");
  }
  const { tcgAtTpmManufacturer, tcgAtTpmModel, tcgAtTpmVersion } = getTcgAtTpmValues(subjectAltNamePresent[0].directoryName);
  if (!tcgAtTpmManufacturer || !tcgAtTpmModel || !tcgAtTpmVersion) {
    throw new Error("Certificate contained incomplete subjectAltName data (TPM)");
  }
  if (!extKeyUsage) {
    throw new Error("Certificate did not contain ExtendedKeyUsage extension (TPM)");
  }
  if (!getTPMManufacturerInfo(tcgAtTpmManufacturer)) {
    throw new Error(`Could not match TPM manufacturer "${tcgAtTpmManufacturer}" (TPM)`);
  }
  if (extKeyUsage[0] !== "2.23.133.8.3") {
    throw new Error(`Unexpected extKeyUsage "${extKeyUsage[0]}", expected "2.23.133.8.3" (TPM)`);
  }
  try {
    await validateExtFIDOGenCEAAGUID(parsedCert.tbsCertificate.extensions, aaguid);
  } catch (err) {
    const _err = err;
    throw new Error(`${_err.message} (TPM)`);
  }
  const statement = await MetadataService.getStatement(aaguid);
  if (statement) {
    try {
      await verifyAttestationWithMetadata({
        statement,
        credentialPublicKey,
        x5c,
        attestationStatementAlg: alg
      });
    } catch (err) {
      const _err = err;
      throw new Error(`${_err.message} (TPM)`);
    }
  } else {
    try {
      await validateCertificatePath(x5c.map(convertCertBufferToPEM), rootCertificates);
    } catch (err) {
      const _err = err;
      throw new Error(`${_err.message} (TPM)`);
    }
  }
  return verifySignature({
    signature: sig,
    data: certInfo,
    x509Certificate: x5c[0],
    hashAlgorithm: alg
  });
}
function getTcgAtTpmValues(root) {
  const oidManufacturer = "2.23.133.2.1";
  const oidModel = "2.23.133.2.2";
  const oidVersion = "2.23.133.2.3";
  let tcgAtTpmManufacturer;
  let tcgAtTpmModel;
  let tcgAtTpmVersion;
  root.forEach((relName) => {
    relName.forEach((attr) => {
      if (attr.type === oidManufacturer) {
        tcgAtTpmManufacturer = attr.value.toString();
      } else if (attr.type === oidModel) {
        tcgAtTpmModel = attr.value.toString();
      } else if (attr.type === oidVersion) {
        tcgAtTpmVersion = attr.value.toString();
      }
    });
  });
  return {
    tcgAtTpmManufacturer,
    tcgAtTpmModel,
    tcgAtTpmVersion
  };
}
function attestedNameAlgToCOSEAlg(alg) {
  if (alg === "TPM_ALG_SHA256") {
    return COSEALG.ES256;
  } else if (alg === "TPM_ALG_SHA384") {
    return COSEALG.ES384;
  } else if (alg === "TPM_ALG_SHA512") {
    return COSEALG.ES512;
  }
  throw new Error(`Unexpected TPM attested name alg ${alg}`);
}

// node_modules/@peculiar/asn1-android/build/es2015/key_description.js
var IntegerSet_1;
var id_ce_keyDescription = "1.3.6.1.4.1.11129.2.1.17";
var VerifiedBootState;
(function(VerifiedBootState2) {
  VerifiedBootState2[VerifiedBootState2["verified"] = 0] = "verified";
  VerifiedBootState2[VerifiedBootState2["selfSigned"] = 1] = "selfSigned";
  VerifiedBootState2[VerifiedBootState2["unverified"] = 2] = "unverified";
  VerifiedBootState2[VerifiedBootState2["failed"] = 3] = "failed";
})(VerifiedBootState || (VerifiedBootState = {}));
var RootOfTrust = class {
  verifiedBootKey = new OctetString2();
  deviceLocked = false;
  verifiedBootState = VerifiedBootState.verified;
  verifiedBootHash;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: OctetString2 })
], RootOfTrust.prototype, "verifiedBootKey", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Boolean })
], RootOfTrust.prototype, "deviceLocked", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Enumerated })
], RootOfTrust.prototype, "verifiedBootState", void 0);
__decorate([
  AsnProp({
    type: OctetString2,
    optional: true
  })
], RootOfTrust.prototype, "verifiedBootHash", void 0);
var IntegerSet = IntegerSet_1 = class IntegerSet2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, IntegerSet_1.prototype);
  }
};
IntegerSet = IntegerSet_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Set,
    itemType: AsnPropTypes.Integer
  })
], IntegerSet);
var AuthorizationList = class {
  purpose;
  algorithm;
  keySize;
  digest;
  padding;
  ecCurve;
  rsaPublicExponent;
  mgfDigest;
  rollbackResistance;
  earlyBootOnly;
  activeDateTime;
  originationExpireDateTime;
  usageExpireDateTime;
  usageCountLimit;
  noAuthRequired;
  userAuthType;
  authTimeout;
  allowWhileOnBody;
  trustedUserPresenceRequired;
  trustedConfirmationRequired;
  unlockedDeviceRequired;
  allApplications;
  applicationId;
  creationDateTime;
  origin;
  rollbackResistant;
  rootOfTrust;
  osVersion;
  osPatchLevel;
  attestationApplicationId;
  attestationIdBrand;
  attestationIdDevice;
  attestationIdProduct;
  attestationIdSerial;
  attestationIdImei;
  attestationIdMeid;
  attestationIdManufacturer;
  attestationIdModel;
  vendorPatchLevel;
  bootPatchLevel;
  deviceUniqueAttestation;
  attestationIdSecondImei;
  moduleHash;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    context: 1,
    type: IntegerSet,
    optional: true
  })
], AuthorizationList.prototype, "purpose", void 0);
__decorate([
  AsnProp({
    context: 2,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "algorithm", void 0);
__decorate([
  AsnProp({
    context: 3,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "keySize", void 0);
__decorate([
  AsnProp({
    context: 5,
    type: IntegerSet,
    optional: true
  })
], AuthorizationList.prototype, "digest", void 0);
__decorate([
  AsnProp({
    context: 6,
    type: IntegerSet,
    optional: true
  })
], AuthorizationList.prototype, "padding", void 0);
__decorate([
  AsnProp({
    context: 10,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "ecCurve", void 0);
__decorate([
  AsnProp({
    context: 200,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "rsaPublicExponent", void 0);
__decorate([
  AsnProp({
    context: 203,
    type: IntegerSet,
    optional: true
  })
], AuthorizationList.prototype, "mgfDigest", void 0);
__decorate([
  AsnProp({
    context: 303,
    type: AsnPropTypes.Null,
    optional: true
  })
], AuthorizationList.prototype, "rollbackResistance", void 0);
__decorate([
  AsnProp({
    context: 305,
    type: AsnPropTypes.Null,
    optional: true
  })
], AuthorizationList.prototype, "earlyBootOnly", void 0);
__decorate([
  AsnProp({
    context: 400,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "activeDateTime", void 0);
__decorate([
  AsnProp({
    context: 401,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "originationExpireDateTime", void 0);
__decorate([
  AsnProp({
    context: 402,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "usageExpireDateTime", void 0);
__decorate([
  AsnProp({
    context: 405,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "usageCountLimit", void 0);
__decorate([
  AsnProp({
    context: 503,
    type: AsnPropTypes.Null,
    optional: true
  })
], AuthorizationList.prototype, "noAuthRequired", void 0);
__decorate([
  AsnProp({
    context: 504,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "userAuthType", void 0);
__decorate([
  AsnProp({
    context: 505,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "authTimeout", void 0);
__decorate([
  AsnProp({
    context: 506,
    type: AsnPropTypes.Null,
    optional: true
  })
], AuthorizationList.prototype, "allowWhileOnBody", void 0);
__decorate([
  AsnProp({
    context: 507,
    type: AsnPropTypes.Null,
    optional: true
  })
], AuthorizationList.prototype, "trustedUserPresenceRequired", void 0);
__decorate([
  AsnProp({
    context: 508,
    type: AsnPropTypes.Null,
    optional: true
  })
], AuthorizationList.prototype, "trustedConfirmationRequired", void 0);
__decorate([
  AsnProp({
    context: 509,
    type: AsnPropTypes.Null,
    optional: true
  })
], AuthorizationList.prototype, "unlockedDeviceRequired", void 0);
__decorate([
  AsnProp({
    context: 600,
    type: AsnPropTypes.Null,
    optional: true
  })
], AuthorizationList.prototype, "allApplications", void 0);
__decorate([
  AsnProp({
    context: 601,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "applicationId", void 0);
__decorate([
  AsnProp({
    context: 701,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "creationDateTime", void 0);
__decorate([
  AsnProp({
    context: 702,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "origin", void 0);
__decorate([
  AsnProp({
    context: 703,
    type: AsnPropTypes.Null,
    optional: true
  })
], AuthorizationList.prototype, "rollbackResistant", void 0);
__decorate([
  AsnProp({
    context: 704,
    type: RootOfTrust,
    optional: true
  })
], AuthorizationList.prototype, "rootOfTrust", void 0);
__decorate([
  AsnProp({
    context: 705,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "osVersion", void 0);
__decorate([
  AsnProp({
    context: 706,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "osPatchLevel", void 0);
__decorate([
  AsnProp({
    context: 709,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "attestationApplicationId", void 0);
__decorate([
  AsnProp({
    context: 710,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "attestationIdBrand", void 0);
__decorate([
  AsnProp({
    context: 711,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "attestationIdDevice", void 0);
__decorate([
  AsnProp({
    context: 712,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "attestationIdProduct", void 0);
__decorate([
  AsnProp({
    context: 713,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "attestationIdSerial", void 0);
__decorate([
  AsnProp({
    context: 714,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "attestationIdImei", void 0);
__decorate([
  AsnProp({
    context: 715,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "attestationIdMeid", void 0);
__decorate([
  AsnProp({
    context: 716,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "attestationIdManufacturer", void 0);
__decorate([
  AsnProp({
    context: 717,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "attestationIdModel", void 0);
__decorate([
  AsnProp({
    context: 718,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "vendorPatchLevel", void 0);
__decorate([
  AsnProp({
    context: 719,
    type: AsnPropTypes.Integer,
    optional: true
  })
], AuthorizationList.prototype, "bootPatchLevel", void 0);
__decorate([
  AsnProp({
    context: 720,
    type: AsnPropTypes.Null,
    optional: true
  })
], AuthorizationList.prototype, "deviceUniqueAttestation", void 0);
__decorate([
  AsnProp({
    context: 723,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "attestationIdSecondImei", void 0);
__decorate([
  AsnProp({
    context: 724,
    type: OctetString2,
    optional: true
  })
], AuthorizationList.prototype, "moduleHash", void 0);
var SecurityLevel;
(function(SecurityLevel2) {
  SecurityLevel2[SecurityLevel2["software"] = 0] = "software";
  SecurityLevel2[SecurityLevel2["trustedEnvironment"] = 1] = "trustedEnvironment";
  SecurityLevel2[SecurityLevel2["strongBox"] = 2] = "strongBox";
})(SecurityLevel || (SecurityLevel = {}));
var Version4;
(function(Version5) {
  Version5[Version5["KM2"] = 1] = "KM2";
  Version5[Version5["KM3"] = 2] = "KM3";
  Version5[Version5["KM4"] = 3] = "KM4";
  Version5[Version5["KM4_1"] = 4] = "KM4_1";
  Version5[Version5["keyMint1"] = 100] = "keyMint1";
  Version5[Version5["keyMint2"] = 200] = "keyMint2";
  Version5[Version5["keyMint3"] = 300] = "keyMint3";
  Version5[Version5["keyMint4"] = 400] = "keyMint4";
})(Version4 || (Version4 = {}));
var KeyDescription = class {
  attestationVersion = Version4.KM4;
  attestationSecurityLevel = SecurityLevel.software;
  keymasterVersion = 0;
  keymasterSecurityLevel = SecurityLevel.software;
  attestationChallenge = new OctetString2();
  uniqueId = new OctetString2();
  softwareEnforced = new AuthorizationList();
  teeEnforced = new AuthorizationList();
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], KeyDescription.prototype, "attestationVersion", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Enumerated })
], KeyDescription.prototype, "attestationSecurityLevel", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], KeyDescription.prototype, "keymasterVersion", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Enumerated })
], KeyDescription.prototype, "keymasterSecurityLevel", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], KeyDescription.prototype, "attestationChallenge", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], KeyDescription.prototype, "uniqueId", void 0);
__decorate([
  AsnProp({ type: AuthorizationList })
], KeyDescription.prototype, "softwareEnforced", void 0);
__decorate([
  AsnProp({ type: AuthorizationList })
], KeyDescription.prototype, "teeEnforced", void 0);
var KeyMintKeyDescription = class _KeyMintKeyDescription {
  attestationVersion = Version4.keyMint4;
  attestationSecurityLevel = SecurityLevel.software;
  keyMintVersion = 0;
  keyMintSecurityLevel = SecurityLevel.software;
  attestationChallenge = new OctetString2();
  uniqueId = new OctetString2();
  softwareEnforced = new AuthorizationList();
  hardwareEnforced = new AuthorizationList();
  constructor(params = {}) {
    Object.assign(this, params);
  }
  toLegacyKeyDescription() {
    return new KeyDescription({
      attestationVersion: this.attestationVersion,
      attestationSecurityLevel: this.attestationSecurityLevel,
      keymasterVersion: this.keyMintVersion,
      keymasterSecurityLevel: this.keyMintSecurityLevel,
      attestationChallenge: this.attestationChallenge,
      uniqueId: this.uniqueId,
      softwareEnforced: this.softwareEnforced,
      teeEnforced: this.hardwareEnforced
    });
  }
  static fromLegacyKeyDescription(keyDesc) {
    return new _KeyMintKeyDescription({
      attestationVersion: keyDesc.attestationVersion,
      attestationSecurityLevel: keyDesc.attestationSecurityLevel,
      keyMintVersion: keyDesc.keymasterVersion,
      keyMintSecurityLevel: keyDesc.keymasterSecurityLevel,
      attestationChallenge: keyDesc.attestationChallenge,
      uniqueId: keyDesc.uniqueId,
      softwareEnforced: keyDesc.softwareEnforced,
      hardwareEnforced: keyDesc.teeEnforced
    });
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], KeyMintKeyDescription.prototype, "attestationVersion", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Enumerated })
], KeyMintKeyDescription.prototype, "attestationSecurityLevel", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], KeyMintKeyDescription.prototype, "keyMintVersion", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Enumerated })
], KeyMintKeyDescription.prototype, "keyMintSecurityLevel", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], KeyMintKeyDescription.prototype, "attestationChallenge", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], KeyMintKeyDescription.prototype, "uniqueId", void 0);
__decorate([
  AsnProp({ type: AuthorizationList })
], KeyMintKeyDescription.prototype, "softwareEnforced", void 0);
__decorate([
  AsnProp({ type: AuthorizationList })
], KeyMintKeyDescription.prototype, "hardwareEnforced", void 0);

// node_modules/@peculiar/asn1-android/build/es2015/nonstandard.js
var NonStandardAuthorizationList_1;
var NonStandardAuthorization = class NonStandardAuthorization2 extends AuthorizationList {
};
NonStandardAuthorization = __decorate([
  AsnType({ type: AsnTypeTypes.Choice })
], NonStandardAuthorization);
var NonStandardAuthorizationList = NonStandardAuthorizationList_1 = class NonStandardAuthorizationList2 extends AsnArray {
  constructor(items) {
    super(items);
    Object.setPrototypeOf(this, NonStandardAuthorizationList_1.prototype);
  }
  findProperty(key2) {
    const prop = this.find((o) => o[key2] !== void 0);
    if (prop) {
      return prop[key2];
    }
    return void 0;
  }
};
NonStandardAuthorizationList = NonStandardAuthorizationList_1 = __decorate([
  AsnType({
    type: AsnTypeTypes.Sequence,
    itemType: NonStandardAuthorization
  })
], NonStandardAuthorizationList);
var NonStandardKeyDescription = class {
  attestationVersion = Version4.KM4;
  attestationSecurityLevel = SecurityLevel.software;
  keymasterVersion = 0;
  keymasterSecurityLevel = SecurityLevel.software;
  attestationChallenge = new OctetString2();
  uniqueId = new OctetString2();
  softwareEnforced = new NonStandardAuthorizationList();
  teeEnforced = new NonStandardAuthorizationList();
  get keyMintVersion() {
    return this.keymasterVersion;
  }
  set keyMintVersion(value) {
    this.keymasterVersion = value;
  }
  get keyMintSecurityLevel() {
    return this.keymasterSecurityLevel;
  }
  set keyMintSecurityLevel(value) {
    this.keymasterSecurityLevel = value;
  }
  get hardwareEnforced() {
    return this.teeEnforced;
  }
  set hardwareEnforced(value) {
    this.teeEnforced = value;
  }
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], NonStandardKeyDescription.prototype, "attestationVersion", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Enumerated })
], NonStandardKeyDescription.prototype, "attestationSecurityLevel", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], NonStandardKeyDescription.prototype, "keymasterVersion", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Enumerated })
], NonStandardKeyDescription.prototype, "keymasterSecurityLevel", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], NonStandardKeyDescription.prototype, "attestationChallenge", void 0);
__decorate([
  AsnProp({ type: OctetString2 })
], NonStandardKeyDescription.prototype, "uniqueId", void 0);
__decorate([
  AsnProp({ type: NonStandardAuthorizationList })
], NonStandardKeyDescription.prototype, "softwareEnforced", void 0);
__decorate([
  AsnProp({ type: NonStandardAuthorizationList })
], NonStandardKeyDescription.prototype, "teeEnforced", void 0);
var NonStandardKeyMintKeyDescription = class NonStandardKeyMintKeyDescription2 extends NonStandardKeyDescription {
  constructor(params = {}) {
    if ("keymasterVersion" in params && !("keyMintVersion" in params)) {
      params.keyMintVersion = params.keymasterVersion;
    }
    if ("keymasterSecurityLevel" in params && !("keyMintSecurityLevel" in params)) {
      params.keyMintSecurityLevel = params.keymasterSecurityLevel;
    }
    if ("teeEnforced" in params && !("hardwareEnforced" in params)) {
      params.hardwareEnforced = params.teeEnforced;
    }
    super(params);
  }
};
NonStandardKeyMintKeyDescription = __decorate([
  AsnType({ type: AsnTypeTypes.Sequence })
], NonStandardKeyMintKeyDescription);

// node_modules/@peculiar/asn1-android/build/es2015/attestation.js
var AttestationPackageInfo = class {
  packageName;
  version;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({ type: AsnPropTypes.OctetString })
], AttestationPackageInfo.prototype, "packageName", void 0);
__decorate([
  AsnProp({ type: AsnPropTypes.Integer })
], AttestationPackageInfo.prototype, "version", void 0);
var AttestationApplicationId = class {
  packageInfos;
  signatureDigests;
  constructor(params = {}) {
    Object.assign(this, params);
  }
};
__decorate([
  AsnProp({
    type: AttestationPackageInfo,
    repeated: "set"
  })
], AttestationApplicationId.prototype, "packageInfos", void 0);
__decorate([
  AsnProp({
    type: AsnPropTypes.OctetString,
    repeated: "set"
  })
], AttestationApplicationId.prototype, "signatureDigests", void 0);

// node_modules/@simplewebauthn/server/esm/registration/verifications/verifyAttestationAndroidKey.js
async function verifyAttestationAndroidKey(options) {
  const { authData, clientDataHash, attStmt, credentialPublicKey, aaguid, rootCertificates } = options;
  const x5c = attStmt.get("x5c");
  const sig = attStmt.get("sig");
  const alg = attStmt.get("alg");
  if (!x5c) {
    throw new Error("No attestation certificate provided in attestation statement (Android Key)");
  }
  if (!sig) {
    throw new Error("No attestation signature provided in attestation statement (Android Key)");
  }
  if (!alg) {
    throw new Error(`Attestation statement did not contain alg (Android Key)`);
  }
  if (!isCOSEAlg(alg)) {
    throw new Error(`Attestation statement contained invalid alg ${alg} (Android Key)`);
  }
  const parsedCert = AsnParser.parse(x5c[0], Certificate);
  const parsedCertPubKey = new Uint8Array(parsedCert.tbsCertificate.subjectPublicKeyInfo.subjectPublicKey);
  const credPubKeyPKCS = convertCOSEtoPKCS(credentialPublicKey);
  if (!isoUint8Array_exports.areEqual(credPubKeyPKCS, parsedCertPubKey)) {
    throw new Error("Credential public key does not equal leaf cert public key (Android Key)");
  }
  const extKeyStore = parsedCert.tbsCertificate.extensions?.find((ext) => ext.extnID === id_ce_keyDescription);
  if (!extKeyStore) {
    throw new Error("Certificate did not contain extKeyStore (Android Key)");
  }
  const parsedExtKeyStore = AsnParser.parse(extKeyStore.extnValue, KeyDescription);
  const { attestationChallenge, teeEnforced, softwareEnforced } = parsedExtKeyStore;
  if (!isoUint8Array_exports.areEqual(new Uint8Array(attestationChallenge.buffer), clientDataHash)) {
    throw new Error("Attestation challenge was not equal to client data hash (Android Key)");
  }
  if (teeEnforced.allApplications !== void 0) {
    throw new Error('teeEnforced contained "allApplications [600]" tag (Android Key)');
  }
  if (softwareEnforced.allApplications !== void 0) {
    throw new Error('teeEnforced contained "allApplications [600]" tag (Android Key)');
  }
  const statement = await MetadataService.getStatement(aaguid);
  if (statement) {
    try {
      await verifyAttestationWithMetadata({
        statement,
        credentialPublicKey,
        x5c,
        attestationStatementAlg: alg
      });
    } catch (err) {
      const _err = err;
      throw new Error(`${_err.message} (Android Key)`, { cause: _err });
    }
  } else {
    const x5cNoRootPEM = x5c.slice(0, -1).map(convertCertBufferToPEM);
    const x5cRootPEM = x5c.slice(-1).map(convertCertBufferToPEM);
    try {
      await validateCertificatePath(x5cNoRootPEM, x5cRootPEM);
    } catch (err) {
      const _err = err;
      throw new Error(`${_err.message} (Android Key)`, { cause: _err });
    }
    if (rootCertificates.length > 0 && rootCertificates.indexOf(x5cRootPEM[0]) < 0) {
      throw new Error("x5c root certificate was not a known root certificate (Android Key)");
    }
  }
  const signatureBase = isoUint8Array_exports.concat([authData, clientDataHash]);
  return verifySignature({
    signature: sig,
    data: signatureBase,
    x509Certificate: x5c[0],
    hashAlgorithm: alg
  });
}

// node_modules/@simplewebauthn/server/esm/registration/verifications/verifyAttestationApple.js
async function verifyAttestationApple(options) {
  const { attStmt, authData, clientDataHash, credentialPublicKey, rootCertificates } = options;
  const x5c = attStmt.get("x5c");
  if (!x5c) {
    throw new Error("No attestation certificate provided in attestation statement (Apple)");
  }
  try {
    await validateCertificatePath(x5c.map(convertCertBufferToPEM), rootCertificates);
  } catch (err) {
    const _err = err;
    throw new Error(`${_err.message} (Apple)`);
  }
  const parsedCredCert = AsnParser.parse(x5c[0], Certificate);
  const { extensions, subjectPublicKeyInfo } = parsedCredCert.tbsCertificate;
  if (!extensions) {
    throw new Error("credCert missing extensions (Apple)");
  }
  const extCertNonce = extensions.find((ext) => ext.extnID === "1.2.840.113635.100.8.2");
  if (!extCertNonce) {
    throw new Error('credCert missing "1.2.840.113635.100.8.2" extension (Apple)');
  }
  const nonceToHash = isoUint8Array_exports.concat([authData, clientDataHash]);
  const nonce = await toHash(nonceToHash);
  const extNonce = new Uint8Array(extCertNonce.extnValue.buffer).slice(6);
  if (!isoUint8Array_exports.areEqual(nonce, extNonce)) {
    throw new Error(`credCert nonce was not expected value (Apple)`);
  }
  const credPubKeyPKCS = convertCOSEtoPKCS(credentialPublicKey);
  const credCertSubjectPublicKey = new Uint8Array(subjectPublicKeyInfo.subjectPublicKey);
  if (!isoUint8Array_exports.areEqual(credPubKeyPKCS, credCertSubjectPublicKey)) {
    throw new Error("Credential public key does not equal credCert public key (Apple)");
  }
  return true;
}

// node_modules/@simplewebauthn/server/esm/registration/verifyRegistrationResponse.js
async function verifyRegistrationResponse(options) {
  const { response: response2, expectedChallenge, expectedOrigin, expectedRPID, expectedType, requireUserPresence = true, requireUserVerification = true, supportedAlgorithmIDs = getDefaultSupportedAlgorithmIDs(), attestationSafetyNetEnforceCTSCheck = true } = options;
  const { id, rawId, type: credentialType, response: attestationResponse } = response2;
  if (!id) {
    throw new Error("Missing credential ID");
  }
  if (id !== rawId) {
    throw new Error("Credential ID was not base64url-encoded");
  }
  if (credentialType !== "public-key") {
    throw new Error(`Unexpected credential type ${credentialType}, expected "public-key"`);
  }
  const clientDataJSON = decodeClientDataJSON(attestationResponse.clientDataJSON);
  const { type, origin, challenge, tokenBinding } = clientDataJSON;
  if (Array.isArray(expectedType)) {
    if (!expectedType.includes(type)) {
      const joinedExpectedType = expectedType.join(", ");
      throw new Error(`Unexpected registration response type "${type}", expected one of: ${joinedExpectedType}`);
    }
  } else if (expectedType) {
    if (type !== expectedType) {
      throw new Error(`Unexpected registration response type "${type}", expected "${expectedType}"`);
    }
  } else if (type !== "webauthn.create") {
    throw new Error(`Unexpected registration response type: ${type}`);
  }
  if (typeof expectedChallenge === "function") {
    if (!await expectedChallenge(challenge)) {
      throw new Error(`Custom challenge verifier returned false for registration response challenge "${challenge}"`);
    }
  } else if (challenge !== expectedChallenge) {
    throw new Error(`Unexpected registration response challenge "${challenge}", expected "${expectedChallenge}"`);
  }
  if (Array.isArray(expectedOrigin)) {
    if (!expectedOrigin.includes(origin)) {
      throw new Error(`Unexpected registration response origin "${origin}", expected one of: ${expectedOrigin.join(", ")}`);
    }
  } else {
    if (origin !== expectedOrigin) {
      throw new Error(`Unexpected registration response origin "${origin}", expected "${expectedOrigin}"`);
    }
  }
  if (tokenBinding) {
    if (typeof tokenBinding !== "object") {
      throw new Error(`Unexpected value for TokenBinding "${tokenBinding}"`);
    }
    if (["present", "supported", "not-supported"].indexOf(tokenBinding.status) < 0) {
      throw new Error(`Unexpected tokenBinding.status value of "${tokenBinding.status}"`);
    }
  }
  const attestationObject = isoBase64URL_exports.toBuffer(attestationResponse.attestationObject);
  const decodedAttestationObject = decodeAttestationObject(attestationObject);
  const fmt = decodedAttestationObject.get("fmt");
  const authData = decodedAttestationObject.get("authData");
  const attStmt = decodedAttestationObject.get("attStmt");
  const parsedAuthData = parseAuthenticatorData(authData);
  const { aaguid, rpIdHash, flags, credentialID, counter, credentialPublicKey, extensionsData } = parsedAuthData;
  let matchedRPID;
  if (expectedRPID) {
    let expectedRPIDs = [];
    if (typeof expectedRPID === "string") {
      expectedRPIDs = [expectedRPID];
    } else {
      expectedRPIDs = expectedRPID;
    }
    matchedRPID = await matchExpectedRPID(rpIdHash, expectedRPIDs);
  }
  if (requireUserPresence && !flags.up) {
    throw new Error("User presence was required, but user was not present");
  }
  if (requireUserVerification && !flags.uv) {
    throw new Error("User verification was required, but user could not be verified");
  }
  if (!credentialID) {
    throw new Error("No credential ID was provided by authenticator");
  }
  if (!credentialPublicKey) {
    throw new Error("No public key was provided by authenticator");
  }
  if (!aaguid) {
    throw new Error("No AAGUID was present during registration");
  }
  const decodedPublicKey = decodeCredentialPublicKey(credentialPublicKey);
  const pubKeyAlg = decodedPublicKey.get(COSEKEYS.alg);
  if (typeof pubKeyAlg !== "number") {
    throw new Error("Credential public key was missing numeric alg");
  }
  if (!supportedAlgorithmIDs.includes(pubKeyAlg)) {
    const supported = supportedAlgorithmIDs.join(", ");
    throw new Error(`Unexpected public key alg "${pubKeyAlg}", expected one of "${supported}"`);
  }
  if (isPQCCOSEAlg(pubKeyAlg) && !SettingsService.runtimeSupportsPQC()) {
    throw new PQCNotSupportedError(pubKeyAlg);
  }
  const clientDataHash = await toHash(isoBase64URL_exports.toBuffer(attestationResponse.clientDataJSON));
  const rootCertificates = SettingsService.getRootCertificates({ identifier: fmt });
  const verifierOpts = {
    aaguid,
    attStmt,
    authData,
    clientDataHash,
    credentialID,
    credentialPublicKey,
    rootCertificates,
    rpIdHash,
    attestationSafetyNetEnforceCTSCheck
  };
  let verified = false;
  if (fmt === "fido-u2f") {
    verified = await verifyAttestationFIDOU2F(verifierOpts);
  } else if (fmt === "packed") {
    verified = await verifyAttestationPacked(verifierOpts);
  } else if (fmt === "android-safetynet") {
    verified = await verifyAttestationAndroidSafetyNet(verifierOpts);
  } else if (fmt === "android-key") {
    verified = await verifyAttestationAndroidKey(verifierOpts);
  } else if (fmt === "tpm") {
    verified = await verifyAttestationTPM(verifierOpts);
  } else if (fmt === "apple") {
    verified = await verifyAttestationApple(verifierOpts);
  } else if (fmt === "none") {
    if (attStmt.size > 0) {
      throw new Error("None attestation had unexpected attestation statement");
    }
    verified = true;
  } else {
    throw new Error(`Unsupported Attestation Format: ${fmt}`);
  }
  if (!verified) {
    return { verified: false };
  }
  const { credentialDeviceType, credentialBackedUp } = parseBackupFlags(flags);
  return {
    verified: true,
    registrationInfo: {
      fmt,
      aaguid: convertAAGUIDToString(aaguid),
      credentialType,
      credential: {
        id: isoBase64URL_exports.fromBuffer(credentialID),
        publicKey: credentialPublicKey,
        counter,
        transports: response2.response.transports
      },
      attestationObject,
      userVerified: flags.uv,
      credentialDeviceType,
      credentialBackedUp,
      origin: clientDataJSON.origin,
      rpID: matchedRPID,
      authenticatorExtensionResults: extensionsData
    }
  };
}

// node_modules/@simplewebauthn/server/esm/authentication/generateAuthenticationOptions.js
async function generateAuthenticationOptions(options) {
  const { allowCredentials, challenge = await generateChallenge(), timeout = 6e4, userVerification = "preferred", extensions, rpID } = options;
  let _challenge = challenge;
  if (typeof _challenge === "string") {
    _challenge = isoUint8Array_exports.fromUTF8String(_challenge);
  }
  return {
    rpId: rpID,
    challenge: isoBase64URL_exports.fromBuffer(_challenge),
    allowCredentials: allowCredentials?.map((cred) => {
      if (!isoBase64URL_exports.isBase64URL(cred.id)) {
        throw new Error(`allowCredential id "${cred.id}" is not a valid base64url string`);
      }
      return {
        ...cred,
        id: isoBase64URL_exports.trimPadding(cred.id),
        type: "public-key"
      };
    }),
    timeout,
    userVerification,
    extensions
  };
}

// node_modules/@simplewebauthn/server/esm/authentication/verifyAuthenticationResponse.js
async function verifyAuthenticationResponse(options) {
  const { response: response2, expectedChallenge, expectedOrigin, expectedRPID, expectedType, expectedTopOrigin, credential, requireUserVerification = true, advancedFIDOConfig } = options;
  const { id, rawId, type: credentialType, response: assertionResponse } = response2;
  if (!id) {
    throw new Error("Missing credential ID");
  }
  if (id !== rawId) {
    throw new Error("Credential ID was not base64url-encoded");
  }
  if (credentialType !== "public-key") {
    throw new Error(`Unexpected credential type ${credentialType}, expected "public-key"`);
  }
  if (!response2) {
    throw new Error("Credential missing response");
  }
  if (typeof assertionResponse?.clientDataJSON !== "string") {
    throw new Error("Credential response clientDataJSON was not a string");
  }
  const clientDataJSON = decodeClientDataJSON(assertionResponse.clientDataJSON);
  const { type, origin, challenge, tokenBinding, crossOrigin, topOrigin } = clientDataJSON;
  if (Array.isArray(expectedType)) {
    if (!expectedType.includes(type)) {
      const joinedExpectedType = expectedType.join(", ");
      throw new Error(`Unexpected authentication response type "${type}", expected one of: ${joinedExpectedType}`);
    }
  } else if (expectedType) {
    if (type !== expectedType) {
      throw new Error(`Unexpected authentication response type "${type}", expected "${expectedType}"`);
    }
  } else if (type !== "webauthn.get") {
    throw new Error(`Unexpected authentication response type: ${type}`);
  }
  if (typeof expectedChallenge === "function") {
    if (!await expectedChallenge(challenge)) {
      throw new Error(`Custom challenge verifier returned false for registration response challenge "${challenge}"`);
    }
  } else if (challenge !== expectedChallenge) {
    throw new Error(`Unexpected authentication response challenge "${challenge}", expected "${expectedChallenge}"`);
  }
  if (crossOrigin) {
    if (topOrigin) {
      if (!expectedTopOrigin) {
        throw new Error(`Detected cross-origin authentication response from top origin of "${topOrigin}", but a value for \`expectedTopOrigin\` was not specified when calling \`verifyAuthenticationResponse()\``);
      }
      if (Array.isArray(expectedTopOrigin)) {
        if (!expectedTopOrigin.includes(topOrigin)) {
          const joinedExpectedTopOrigin = expectedTopOrigin.join(", ");
          throw new Error(`Unexpected cross-origin authentication response top origin of "${topOrigin}", expected one of: ${joinedExpectedTopOrigin}`);
        }
      } else {
        if (topOrigin !== expectedTopOrigin) {
          throw new Error(`Unexpected cross-origin authentication response top origin of "${topOrigin}", expected: ${expectedTopOrigin}`);
        }
      }
    }
  } else {
    if (topOrigin) {
      throw new Error(`Unexpected top origin of "${topOrigin}" within a non-cross-origin authentication response. This error should be reported to the browser vendor as a WebAuthn specification violation with a link to https://w3c.github.io/webauthn/#dom-collectedclientdata-toporigin`);
    }
  }
  if (Array.isArray(expectedOrigin)) {
    if (!expectedOrigin.includes(origin)) {
      const joinedExpectedOrigin = expectedOrigin.join(", ");
      throw new Error(`Unexpected authentication response origin "${origin}", expected one of: ${joinedExpectedOrigin}`);
    }
  } else {
    if (origin !== expectedOrigin) {
      throw new Error(`Unexpected authentication response origin "${origin}", expected "${expectedOrigin}"`);
    }
  }
  if (!isoBase64URL_exports.isBase64URL(assertionResponse.authenticatorData)) {
    throw new Error("Credential response authenticatorData was not a base64url string");
  }
  if (!isoBase64URL_exports.isBase64URL(assertionResponse.signature)) {
    throw new Error("Credential response signature was not a base64url string");
  }
  if (assertionResponse.userHandle && typeof assertionResponse.userHandle !== "string") {
    throw new Error("Credential response userHandle was not a string");
  }
  if (tokenBinding) {
    if (typeof tokenBinding !== "object") {
      throw new Error("ClientDataJSON tokenBinding was not an object");
    }
    if (["present", "supported", "notSupported"].indexOf(tokenBinding.status) < 0) {
      throw new Error(`Unexpected tokenBinding status ${tokenBinding.status}`);
    }
  }
  const authDataBuffer = isoBase64URL_exports.toBuffer(assertionResponse.authenticatorData);
  const parsedAuthData = parseAuthenticatorData(authDataBuffer);
  const { rpIdHash, flags, counter, extensionsData } = parsedAuthData;
  let expectedRPIDs = [];
  if (typeof expectedRPID === "string") {
    expectedRPIDs = [expectedRPID];
  } else {
    expectedRPIDs = expectedRPID;
  }
  const matchedRPID = await matchExpectedRPID(rpIdHash, expectedRPIDs);
  if (advancedFIDOConfig !== void 0) {
    const { userVerification: fidoUserVerification } = advancedFIDOConfig;
    if (fidoUserVerification === "required") {
      if (!flags.uv) {
        throw new Error("User verification required, but user could not be verified");
      }
    } else if (fidoUserVerification === "preferred" || fidoUserVerification === "discouraged") {
    }
  } else {
    if (!flags.up) {
      throw new Error("User not present during authentication");
    }
    if (requireUserVerification && !flags.uv) {
      throw new Error("User verification required, but user could not be verified");
    }
  }
  const clientDataHash = await toHash(isoBase64URL_exports.toBuffer(assertionResponse.clientDataJSON));
  const signatureBase = isoUint8Array_exports.concat([authDataBuffer, clientDataHash]);
  const signature = isoBase64URL_exports.toBuffer(assertionResponse.signature);
  if ((counter > 0 || credential.counter > 0) && counter <= credential.counter) {
    throw new Error(`Response counter value ${counter} was lower than expected ${credential.counter}`);
  }
  const decodedPublicKey = decodeCredentialPublicKey(credential.publicKey);
  const pubKeyAlg = decodedPublicKey.get(COSEKEYS.alg);
  if (typeof pubKeyAlg !== "number") {
    throw new Error("Credential public key was missing numeric alg");
  }
  if (isPQCCOSEAlg(pubKeyAlg) && !SettingsService.runtimeSupportsPQC()) {
    throw new PQCNotSupportedError(pubKeyAlg);
  }
  const { credentialDeviceType, credentialBackedUp } = parseBackupFlags(flags);
  const toReturn = {
    verified: await verifySignature({
      signature,
      data: signatureBase,
      credentialPublicKey: credential.publicKey
    }),
    authenticationInfo: {
      newCounter: counter,
      credentialID: credential.id,
      userVerified: flags.uv,
      credentialDeviceType,
      credentialBackedUp,
      authenticatorExtensionResults: extensionsData,
      origin: clientDataJSON.origin,
      rpID: matchedRPID
    }
  };
  return toReturn;
}

// lib/passkeys.ts
init_chat_db();
init_app_errors();
init_access();
var CHALLENGE_COOKIE = "__Host-project_room_challenge";
var CHALLENGE_AGE = 5 * 60 * 1e3;
function config() {
  const rpID = env13.WEBAUTHN_RP_ID || process.env.WEBAUTHN_RP_ID || "", origin = env13.WEBAUTHN_ORIGIN || process.env.WEBAUTHN_ORIGIN || "";
  let url;
  try {
    url = new URL(origin);
  } catch {
    fail(503, "Passkey sign-in is not configured yet.");
  }
  if (!rpID || url.hostname !== rpID || url.origin !== origin || url.protocol !== "https:") fail(503, "Passkey sign-in is not configured yet.");
  return { rpID, origin };
}
function transports(value) {
  try {
    return JSON.parse(value);
  } catch {
    return [];
  }
}
async function createChallenge(challenge, purpose, person) {
  const existing = await cookieValue(companyId() === "main" ? CHALLENGE_COOKIE : CHALLENGE_COOKIE + "_" + companyId()), browser = /^[A-Za-z0-9_-]{43}$/.test(existing) ? existing : newToken(), now = Date.now(), id = crypto.randomUUID();
  await db().batch([
    db().prepare("DELETE FROM passkey_challenges WHERE expires_at <= ?").bind(now),
    db().prepare("INSERT INTO passkey_challenges (id,challenge,purpose,browser_hash,user_id,session_hash,auth_version,expires_at) VALUES (?,?,?,?,?,?,?,?)").bind(id, challenge, purpose, await tokenHash(browser), person?.id || null, person?.session_hash || null, person?.auth_version ?? null, now + CHALLENGE_AGE)
  ]);
  return { challengeId: id, cookie: (companyId() === "main" ? CHALLENGE_COOKIE : CHALLENGE_COOKIE + "_" + companyId()) + "=" + browser + "; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=300" };
}
async function consumeChallenge(id, purpose, person) {
  const browser = await cookieValue(companyId() === "main" ? CHALLENGE_COOKIE : CHALLENGE_COOKIE + "_" + companyId());
  if (typeof id !== "string" || id.length > 80 || !/^[A-Za-z0-9_-]{43}$/.test(browser)) fail(400, "This passkey request expired. Try again.");
  const challenge = await db().prepare("DELETE FROM passkey_challenges WHERE id = ? AND browser_hash = ? AND purpose = ? AND expires_at > ? RETURNING *").bind(id, await tokenHash(browser), purpose, Date.now()).first();
  if (!challenge) fail(400, "This passkey request was used or expired. Try again.");
  if (person && (challenge.user_id !== person.id || challenge.session_hash !== person.session_hash || challenge.auth_version !== person.auth_version)) fail(401, "Your account changed. Start the passkey request again.");
  return challenge;
}
async function registrationOptions() {
  const person = await currentSession(true);
  if (person.auth_level === "passkey" && person.verified_at < Date.now() - RECENT_AGE) fail(428, "Confirm your passkey before adding another.");
  const { rpID } = config();
  const keys = await db().prepare("SELECT id,transports FROM passkeys WHERE user_id = ?").bind(person.id).all();
  if (keys.results.length >= 8) fail(400, "You can keep up to eight passkeys. Remove an unused one first.");
  await db().prepare("UPDATE people SET webauthn_user_id = ? WHERE id = ? AND webauthn_user_id IS NULL AND active = 1 AND auth_version = ?").bind(newToken(), person.id, person.auth_version).run();
  const account = await db().prepare("SELECT webauthn_user_id FROM people WHERE id = ? AND active = 1 AND auth_version = ?").bind(person.id, person.auth_version).first();
  if (!account?.webauthn_user_id) fail(401, "Your account changed. Start again.");
  const options = await generateRegistrationOptions({ rpName: "Teamstead Crew", rpID, userID: fromBase64url(account.webauthn_user_id), userName: person.name, userDisplayName: person.name, attestationType: "none", supportedAlgorithmIDs: [-7, -257], authenticatorSelection: { residentKey: "required", userVerification: "required" }, excludeCredentials: keys.results.map((k) => ({ id: k.id, transports: transports(k.transports) })) });
  return { options, ...await createChallenge(options.challenge, "register", person) };
}
async function registrationVerify(data) {
  const person = await currentSession(true);
  if (person.auth_level === "passkey" && person.verified_at < Date.now() - RECENT_AGE) fail(428, "Confirm your existing passkey before adding another.");
  const challenge = await consumeChallenge(data.challengeId, "register", person), { rpID, origin } = config();
  let result;
  try {
    result = await verifyRegistrationResponse({ response: data.response, expectedChallenge: challenge.challenge, expectedOrigin: origin, expectedRPID: rpID, requireUserPresence: true, requireUserVerification: true, supportedAlgorithmIDs: [-7, -257] });
  } catch {
    fail(400, "The passkey could not be verified. Please try again.");
  }
  if (!result.verified || !result.registrationInfo) fail(400, "The passkey could not be verified. Please try again.");
  const info = result.registrationInfo, key2 = info.credential, now = Date.now(), setup = person.auth_level === "setup";
  const label = typeof data.name === "string" ? data.name.trim().slice(0, 60) : "";
  const account = await db().prepare("SELECT webauthn_user_id FROM people WHERE id = ?").bind(person.id).first();
  if (!account?.webauthn_user_id) fail(401, "Start passkey setup again.");
  const session = newToken(), sessionHash = await tokenHash(session), sessionId = crypto.randomUUID();
  const results = await db().batch([
    db().prepare("INSERT INTO passkeys (id,user_id,public_key,webauthn_user_id,counter,transports,device_type,backed_up,name,created_at,last_challenge_id) SELECT ?,p.id,?,?,?,?,?,?,?,?,? FROM people p JOIN sessions s ON s.user_id = p.id WHERE p.id = ? AND p.active = 1 AND p.auth_version = ? AND s.session_hash = ? AND s.auth_version = p.auth_version AND s.expires_at > ? AND (SELECT COUNT(*) FROM passkeys WHERE user_id = p.id) < 8 AND ((s.auth_level = ? AND s.verified_at >= ?) OR (s.auth_level = ? AND EXISTS (SELECT 1 FROM access_tokens t WHERE t.token_hash = s.setup_token_hash AND t.user_id = p.id AND t.used_at = 0 AND t.expires_at > ? AND (p.passkey_enrolled = 0 OR t.purpose = ?))))").bind(key2.id, toBase64url(key2.publicKey), account.webauthn_user_id, key2.counter, JSON.stringify(key2.transports || []), info.credentialDeviceType, info.credentialBackedUp ? 1 : 0, label || deviceLabel((await headers()).get("user-agent") || ""), now, challenge.id, person.id, person.auth_version, person.session_hash, now, "passkey", now - RECENT_AGE, "setup", now, "recovery"),
    db().prepare("UPDATE access_tokens SET used_at = ? WHERE user_id = ? AND EXISTS (SELECT 1 FROM passkeys WHERE id = ? AND last_challenge_id = ?)").bind(now, person.id, key2.id, challenge.id),
    db().prepare("UPDATE people SET passkey_enrolled = 1, joined_at = CASE WHEN joined_at = 0 THEN ? ELSE joined_at END, auth_version = auth_version + ? WHERE id = ? AND EXISTS (SELECT 1 FROM passkeys WHERE id = ? AND last_challenge_id = ?)").bind(now, setup ? 1 : 0, person.id, key2.id, challenge.id),
    ...setup ? [
      db().prepare("DELETE FROM sessions WHERE user_id = ? AND EXISTS (SELECT 1 FROM passkeys WHERE id = ? AND last_challenge_id = ?)").bind(person.id, key2.id, challenge.id),
      db().prepare("DELETE FROM passkey_challenges WHERE user_id = ? AND EXISTS (SELECT 1 FROM passkeys WHERE id = ? AND last_challenge_id = ?)").bind(person.id, key2.id, challenge.id),
      db().prepare("INSERT INTO sessions (session_hash,user_id,auth_version,expires_at,id,auth_level,created_at,verified_at,last_seen_at,device_label) SELECT ?,p.id,p.auth_version,?,?,?,?,?,?,? FROM people p WHERE p.id = ? AND p.active = 1 AND EXISTS (SELECT 1 FROM passkeys WHERE id = ? AND last_challenge_id = ?)").bind(sessionHash, now + SESSION_AGE * 1e3, sessionId, "passkey", now, now, now, deviceLabel((await headers()).get("user-agent") || ""), person.id, key2.id, challenge.id)
    ] : [],
    db().prepare("INSERT INTO security_events (id,actor_id,target_id,action,at) SELECT ?,?,?,?,? WHERE EXISTS (SELECT 1 FROM passkeys WHERE id = ? AND last_challenge_id = ?)").bind(crypto.randomUUID(), person.id, person.id, setup ? "passkey_setup_completed" : "passkey_added", now, key2.id, challenge.id)
  ]);
  if (!results[0].meta.changes) fail(401, "Your setup or account changed. Sign in with your passkey, or ask for a new setup link.");
  return { ok: true, userId: person.id, ...setup ? { cookie: sessionCookie(session) } : {} };
}
async function authenticationOptions(reauth = false) {
  const person = reauth ? await currentSession() : void 0, { rpID } = config();
  const keys = person ? await db().prepare("SELECT id,transports FROM passkeys WHERE user_id = ?").bind(person.id).all() : null;
  if (person && !keys?.results.length) fail(401, "No passkey is available. Ask your workspace owner for account recovery.");
  const options = await generateAuthenticationOptions({ rpID, userVerification: "required", allowCredentials: keys?.results.map((k) => ({ id: k.id, transports: transports(k.transports) })) || [] });
  return { options, ...await createChallenge(options.challenge, reauth ? "reauth" : "login", person) };
}
async function authenticationVerify(data, reauth = false) {
  const person = reauth ? await currentSession() : void 0, challenge = await consumeChallenge(data.challengeId, reauth ? "reauth" : "login", person), { rpID, origin } = config();
  const response2 = data.response;
  if (!response2 || typeof response2.id !== "string" || response2.id.length > 2048) fail(400, "The passkey response is incomplete.");
  const stored = await db().prepare("SELECT k.*,p.auth_version,p.active FROM passkeys k JOIN people p ON p.id = k.user_id WHERE k.id = ? AND p.active = 1").bind(response2.id).first();
  if (!stored || person && stored.user_id !== person.id) fail(401, "This passkey does not belong to the account being opened.");
  if (!reauth && !response2.response?.userHandle || response2.response?.userHandle && response2.response.userHandle !== stored.webauthn_user_id) fail(401, "This passkey does not match the account.");
  let result;
  try {
    result = await verifyAuthenticationResponse({ response: response2, expectedChallenge: challenge.challenge, expectedOrigin: origin, expectedRPID: rpID, requireUserVerification: true, credential: { id: stored.id, publicKey: fromBase64url(stored.public_key), counter: stored.counter, transports: transports(stored.transports) } });
  } catch {
    fail(400, "The passkey could not be verified. Please try again.");
  }
  if (!result.verified) fail(400, "The passkey could not be verified.");
  const now = Date.now(), session = newToken(), hash = await tokenHash(session), id = crypto.randomUUID(), info = result.authenticationInfo;
  const results = await db().batch([
    db().prepare("UPDATE passkeys SET counter = ?,last_used_at = ?,backed_up = ?,last_challenge_id = ? WHERE id = ? AND counter = ? AND EXISTS (SELECT 1 FROM people WHERE id = passkeys.user_id AND active = 1 AND auth_version = ?)" + (reauth ? " AND EXISTS (SELECT 1 FROM sessions WHERE session_hash = ? AND user_id = passkeys.user_id AND auth_level = ? AND expires_at > ? AND auth_version = ?)" : "")).bind(info.newCounter, now, info.credentialBackedUp ? 1 : 0, challenge.id, stored.id, stored.counter, stored.auth_version, ...reauth ? [person.session_hash, "passkey", now, person.auth_version] : []),
    reauth ? db().prepare("UPDATE sessions SET verified_at = ?,last_seen_at = ? WHERE session_hash = ? AND EXISTS (SELECT 1 FROM passkeys WHERE id = ? AND last_challenge_id = ?)").bind(now, now, person.session_hash, stored.id, challenge.id) : db().prepare("INSERT INTO sessions (session_hash,user_id,auth_version,expires_at,id,auth_level,created_at,verified_at,last_seen_at,device_label) SELECT ?,p.id,p.auth_version,?,?,?,?,?,?,? FROM people p WHERE p.id = ? AND p.active = 1 AND EXISTS (SELECT 1 FROM passkeys WHERE id = ? AND last_challenge_id = ?)").bind(hash, now + SESSION_AGE * 1e3, id, "passkey", now, now, now, deviceLabel((await headers()).get("user-agent") || ""), stored.user_id, stored.id, challenge.id),
    db().prepare("INSERT INTO security_events (id,actor_id,target_id,action,at) SELECT ?,?,?,?,? WHERE EXISTS (SELECT 1 FROM passkeys WHERE id = ? AND last_challenge_id = ?)").bind(crypto.randomUUID(), stored.user_id, stored.user_id, reauth ? "passkey_confirmed" : "signed_in", now, stored.id, challenge.id),
    db().prepare("DELETE FROM sessions WHERE expires_at <= ?").bind(now)
  ]);
  if (!results[0].meta.changes || !results[1].meta.changes) fail(401, "Your account changed during sign-in. Try again.");
  return { ok: true, userId: stored.user_id, ...!reauth ? { cookie: sessionCookie(session) } : {} };
}

// app/api/passkeys/route.ts
var dynamic2 = "force-dynamic";
var windows = /* @__PURE__ */ new Map();
function rateLimit(request2) {
  const ip = request2.headers.get("cf-connecting-ip") || "local", now = Date.now(), prior = windows.get(ip);
  if (prior && now - prior.at < 6e4) {
    if (++prior.count > 120) fail(429, "Too many sign-in attempts. Wait a minute and try again.");
  } else {
    if (windows.size > 2e3) windows.clear();
    windows.set(ip, { at: now, count: 1 });
  }
}
async function POST8(request2) {
  try {
    checkOrigin(request2);
    rateLimit(request2);
    if (!request2.headers.get("content-type")?.startsWith("application/json")) fail(415, "Use a supported passkey format.");
    const raw = await request2.text();
    if (raw.length > 24e3) fail(413, "This passkey request is too large.");
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      fail(400, "Please try again.");
    }
    if (!data || typeof data !== "object" || Array.isArray(data)) fail(400, "Please try again.");
    let result;
    if (data.action === "register_options") result = await registrationOptions();
    else if (data.action === "register_verify") result = await registrationVerify(data);
    else if (data.action === "auth_options") result = await authenticationOptions(data.purpose === "reauth");
    else if (data.action === "auth_verify") result = await authenticationVerify(data, data.purpose === "reauth");
    else fail(400, "Unknown passkey request.");
    const { cookie, ...body } = result, res = response(body);
    if (cookie) res.headers.set("Set-Cookie", cookie);
    return res;
  } catch (e) {
    return handleError(e);
  }
}

// app/api/chat/route.ts
var route_exports9 = {};
__export(route_exports9, {
  GET: () => GET6,
  POST: () => POST9,
  dynamic: () => dynamic3
});

// lib/member-removal.ts
init_company_sql();
init_chat_db();
init_company_context();
init_security_events();
async function removeCompanyPerson(me, data) {
  const database = db(), id = required(data.userId), self2 = id === me.id;
  if (!["owner", "admin"].includes(me.role)) fail(403, "Only an owner or admin can remove people.");
  const target = await database.prepare("SELECT role FROM people WHERE id=? AND active=1").bind(id).first();
  if (!target) fail(404, "This person is no longer in the company.");
  let successor = null;
  if (target.role === "owner") {
    successor = self2 ? required(data.successorId) : me.id;
    const eligible = await database.prepare("SELECT id FROM people WHERE id=? AND id<>? AND role='admin' AND active=1 AND passkey_enrolled=1 AND joined_at>0").bind(successor, id).first();
    if (!eligible) fail(400, "Choose an active admin who has finished signing in to become owner.");
  } else if (self2) fail(400, "Ask another admin to remove your account.");
  if (me.role === "admin" && target.role === "admin") fail(403, "Only the owner can remove another admin.");
  const combined = await rawDb().prepare("SELECT user_id FROM company_member_links WHERE company=? AND user_id=?").bind(companyId(), id).first();
  if (combined && me.role !== "owner") fail(403, "Ask the owner to remove this person\u2019s connected Maintenance Hub access.");
  if (combined) await revokeCombinedMember(id);
  const guard2 = successor ? { sql: "EXISTS (SELECT 1 FROM people target JOIN workspace w ON w.owner_id=target.id JOIN people successor ON successor.id=? WHERE target.id=? AND target.active=1 AND target.role='owner' AND w.id='main' AND successor.id<>target.id AND successor.active=1 AND successor.role='admin' AND successor.passkey_enrolled=1 AND successor.joined_at>0)", values: [successor, id] } : { sql: "EXISTS (SELECT 1 FROM people target WHERE target.id=? AND target.active=1 AND target.role=?)", values: [id, target.role] };
  const gate = securityGate(me, self2 ? "owner_left_company" : "member_removal_requested", id, guard2);
  const changes2 = await database.batch([
    gate.statement,
    ...successor ? [rawDb().prepare("UPDATE company_registry SET owner_id=? WHERE id=? AND owner_id=? AND " + companySql(gate.condition, companyId())).bind(successor, companyId(), id), database.prepare("UPDATE workspace SET owner_id=? WHERE id='main' AND " + gate.condition).bind(successor), database.prepare("UPDATE people SET role='owner' WHERE id=? AND " + gate.condition).bind(successor)] : [],
    ...["room_members", "maintenance_links", "sessions", "access_tokens", "passkeys", "passkey_challenges"].map((table) => database.prepare("DELETE FROM " + table + " WHERE user_id=? AND " + gate.condition).bind(id)),
    database.prepare("UPDATE people SET active=0,role='member',auth_version=auth_version+1 WHERE id=? AND " + gate.condition).bind(id)
  ]);
  if (!changes2[0].meta.changes) fail(409, "Access changed. Refresh People and confirm your passkey before trying again.");
  return { ok: true, leftCompany: self2, newOwnerId: successor };
}

// app/api/chat/route.ts
init_company_context();
init_r2_storage();
init_chat_db();
import { env as env14 } from "cloudflare:workers";
init_access();
init_security_events();

// lib/ai-privacy.ts
function sanitizeForAi(input) {
  let redactions = 0;
  const privateParameter = /[?#&](?:access|hub|invite|invitation|recovery|setup|token|access_token|refresh_token|api_key|apikey|secret|password|code)[ \t]*=/i;
  let text = input.replace(/\S+/g, (word) => {
    let decoded = word;
    for (let i = 0; i < 4; i++) {
      const next = decoded.replace(/(?:%[0-9a-f]{2})+/gi, (chunk) => {
        try {
          return decodeURIComponent(chunk);
        } catch {
          return chunk.replace(/%([0-9a-f]{2})/gi, (_m, hex2) => String.fromCharCode(parseInt(hex2, 16)));
        }
      });
      if (next === decoded) break;
      decoded = next;
    }
    if (privateParameter.test(decoded) || /https?:\/\/[^/@\s]+:[^/@\s]+@/i.test(decoded)) {
      redactions++;
      return "[private access link removed]";
    }
    return word;
  });
  text = text.replace(/\bBearer[ \t]+[A-Za-z0-9._~+/=-]{8,}/gi, () => {
    redactions++;
    return "Bearer [credential removed]";
  });
  text = text.replace(/(["']?)\b((?:[A-Z][A-Z0-9_]*_)?(?:api[ _-]?key|password|secret|(?:access|refresh)[ _-]?token))\1[ \t]*[:=][ \t]*(?:"[^"\n]+"|'[^'\n]+'|[^\s<>]+)/gi, (_all, quote, label) => {
    redactions++;
    return quote + label + quote + ": " + (quote ? '"[credential removed]"' : "[credential removed]");
  });
  text = text.replace(/\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{16,}\b/g, () => {
    redactions++;
    return "[API credential removed]";
  });
  return { text, redactions };
}

// app/api/chat/route.ts
init_chat_notifications();
init_maintenance_bots();
var dynamic3 = "force-dynamic";
async function GET6(request2) {
  try {
    const me = await member(), database = db(), url = new URL(request2.url), action = url.searchParams.get("action") || "state";
    if (action === "notification_settings") return response(await notificationStatus(me.id));
    if (action === "state") {
      const [workspace, members, rooms, memberships, invitations] = await Promise.all([
        database.prepare("SELECT id,name,owner_id,ai_enabled,(logo_data IS NOT NULL AND logo_data <> '') AS has_logo FROM workspace WHERE id = ?").bind("main").first(),
        database.prepare("SELECT id,name,role,active,joined_at" + (me.role === "owner" ? ",email" : "") + " FROM people WHERE active = 1 ORDER BY joined_at,id").all(),
        database.prepare("SELECT r.*, (SELECT COUNT(*) FROM messages m WHERE m.room_id = r.id AND m.created_at > rm.read_at AND m.user_id <> ? AND m.deleted = 0) AS unread,(SELECT MAX(created_at) FROM messages m WHERE m.room_id = r.id) AS last_at FROM rooms r JOIN room_members rm ON rm.room_id = r.id WHERE rm.user_id = ? ORDER BY r.created_at,r.name").bind(me.id, me.id).all(),
        database.prepare("SELECT other.room_id,other.user_id FROM room_members other JOIN room_members mine ON mine.room_id = other.room_id WHERE mine.user_id = ?").bind(me.id).all(),
        me.role === "owner" ? database.prepare("SELECT email,name,room_ids FROM invitations ORDER BY created_at").all() : Promise.resolve({ results: [] })
      ]);
      const prefs = await database.prepare("SELECT * FROM conversation_preferences WHERE user_id=?").bind(me.id).all();
      const profiles = await database.prepare("SELECT user_id,job_title,updated_at,(photo IS NOT NULL OR r2_key IS NOT NULL) AS has_photo FROM crew_profiles").all();
      const statuses = await database.prepare("SELECT s.user_id,s.status,s.expires_at FROM employee_status s JOIN people p ON p.id=s.user_id WHERE p.active=1 AND s.auth_version=p.auth_version AND s.expires_at>?").bind(Date.now()).all();
      const withStatus = (person) => {
        const s = statuses.results.find((s2) => s2.user_id === person.id);
        const p = profiles.results.find((p2) => p2.user_id === person.id);
        return { ...person, job_title: p?.job_title || "", photo_url: p?.has_photo ? companyPath("/api/photos/avatar-" + person.id + "?v=" + p.updated_at) : "", status: s?.status || null, status_expires_at: s?.expires_at || 0 };
      };
      const registry = /^c_/.test(companyId()) ? await rawDb().prepare("SELECT hub_ready FROM company_registry WHERE id=?").bind(companyId()).first() : null;
      const products = await companyProducts();
      return response({ products, companyReady: registry ? products.hub ? !!registry.hub_ready : (await rawDb().prepare("SELECT status FROM company_registry WHERE id=?").bind(companyId()).first())?.status === "active" : true, me: withStatus(me), workspace, members: members.results.map(withStatus), rooms: rooms.results.map((r) => ({ ...r, ...prefs.results.find((p) => p.room_id === r.id) || {}, memberIds: memberships.results.filter((x) => x.room_id === r.id).map((x) => x.user_id) })), invitations: invitations.results });
    }
    if (action === "ai_permission") {
      const w = await database.prepare("SELECT ai_enabled FROM workspace WHERE id = ?").bind("main").first();
      return response({ enabled: !!w?.ai_enabled });
    }
    if (action === "ai_context") {
      const enabled = await database.prepare("SELECT ai_enabled FROM workspace WHERE id = ?").bind("main").first();
      if (!enabled?.ai_enabled) fail(403, "AI shortcuts are disabled for this workspace.");
      const msg = await messageAccess(required(url.searchParams.get("id")), me.id);
      if (msg.deleted) fail(404, "That message has been removed.");
      return response(sanitizeForAi(msg.body));
    }
    if (action === "messages") {
      const roomId = required(url.searchParams.get("roomId"));
      await roomAccess(roomId, me.id);
      const parentId = url.searchParams.get("parentId"), before = url.searchParams.get("before");
      let parent = null;
      if (parentId) {
        const p = await messageAccess(parentId, me.id);
        if (p.room_id !== roomId || p.parent_id) fail(404, "Thread unavailable.");
        parent = await database.prepare(messageSelect + "WHERE m.id = ?").bind(parentId).first();
      }
      const params = [roomId];
      let where = "WHERE m.room_id = ? AND m.parent_id " + (parentId ? "= ?" : "IS NULL");
      if (parentId) params.push(parentId);
      if (before) {
        const split = before.indexOf(":");
        const at = Number(before.slice(0, split));
        const id = before.slice(split + 1);
        if (split < 1 || !Number.isFinite(at) || !id) fail(400, "Invalid message page.");
        where += " AND (m.created_at < ? OR (m.created_at = ? AND m.id < ?))";
        params.push(at, at, id);
      }
      const list = await database.prepare(messageSelect + where + " ORDER BY m.created_at DESC,m.id DESC LIMIT 81").bind(...params).all();
      const hasMore = list.results.length > 80, rows = list.results.slice(0, 80).reverse();
      const messages = await enrich(rows, me.id);
      return response({ messages, parent: parent ? (await enrich([parent], me.id))[0] : null, hasMore, serverTime: Date.now() });
    }
    if (action === "search" || action === "files" || action === "pins" || action === "saved") {
      const roomId = url.searchParams.get("roomId");
      const q = str(url.searchParams.get("q") || "", 200);
      if (action === "search" && q.length < 2) return response({ messages: [] });
      const params = [me.id];
      let where = "JOIN room_members rm ON rm.room_id = m.room_id WHERE rm.user_id = ? AND m.deleted = 0";
      if (roomId) {
        await roomAccess(roomId, me.id);
        where += " AND m.room_id = ?";
        params.push(roomId);
      }
      if (action === "search") {
        where += " AND instr(lower(m.body),lower(?)) > 0";
        params.push(q);
      }
      if (action === "files") where += " AND EXISTS (SELECT 1 FROM attachments a WHERE a.message_id = m.id)";
      if (action === "pins") where += " AND m.pinned = 1";
      if (action === "saved") {
        where += " AND EXISTS (SELECT 1 FROM saved_messages sm WHERE sm.message_id=m.id AND sm.user_id=?)";
        params.push(me.id);
      }
      const rows = await database.prepare(messageSelect + where + " ORDER BY m.created_at DESC,m.id DESC LIMIT 100").bind(...params).all();
      return response({ messages: await enrich(rows.results, me.id) });
    }
    fail(400, "Unknown request.");
  } catch (e) {
    return handleError(e);
  }
}
async function POST9(request2) {
  try {
    checkOrigin(request2);
    const me = await member(), database = db();
    if (request2.headers.get("content-type")?.startsWith("multipart/form-data")) {
      if (new URL(request2.url).searchParams.get("action") === "profile_photo") {
        const data2 = await request2.formData(), file = data2.get("photo");
        if (!file || typeof file === "string" || file.size > 512 * 1024) fail(413, "Choose a profile photo of 512 KB or smaller.");
        const bytes = new Uint8Array(await file.arrayBuffer());
        if (bytes[0] !== 255 || bytes[1] !== 216 || bytes[2] !== 255) fail(415, "Choose a JPG profile photo.");
        if (env14.CHAT_PHOTOS) {
          const now = Date.now(), key2 = "profiles/" + encodeURIComponent(me.id) + "/" + crypto.randomUUID() + ".jpg";
          await r2Put("chat", key2, bytes, "image/jpeg");
          await database.prepare("INSERT INTO crew_profiles(user_id,r2_key,photo_mime,updated_at) VALUES(?,?,'image/jpeg',?) ON CONFLICT(user_id) DO UPDATE SET r2_key=excluded.r2_key,photo_mime=excluded.photo_mime,updated_at=excluded.updated_at").bind(me.id, key2, now).run();
          return response({ ok: true });
        }
        await database.prepare("INSERT INTO crew_profiles (user_id,photo,photo_mime,updated_at) VALUES (?,?,'image/jpeg',?) ON CONFLICT(user_id) DO UPDATE SET photo=excluded.photo,photo_mime=excluded.photo_mime,updated_at=excluded.updated_at").bind(me.id, bytes, Date.now()).run();
        return response({ ok: true });
      }
      return await sendMessage(request2, me);
    }
    if (!request2.headers.get("content-type")?.startsWith("application/json")) fail(415, "Use a supported message format.");
    const raw = await request2.text();
    if (raw.length > 32e3) fail(413, "This change is too large.");
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      fail(400, "Please try that again.");
    }
    if (!data || typeof data !== "object" || Array.isArray(data)) fail(400, "Please try that again.");
    const action = required(data.action);
    if (action === "set_status") {
      const statusActor = await currentSession();
      if (statusActor.id !== me.id) fail(401, "Sign in again.");
      const status = required(data.status, 20), hours = Number(data.hours);
      if (!["available", "working", "away", "driving", "clear"].includes(status) || ![1, 4, 8].includes(hours)) fail(400, "Choose a status and duration.");
      if (status === "clear") await database.prepare("DELETE FROM employee_status WHERE user_id=?").bind(me.id).run();
      else await database.prepare("INSERT INTO employee_status (user_id,status,expires_at,auth_version) SELECT ?,?,?,? WHERE EXISTS(SELECT 1 FROM people WHERE id=? AND active=1 AND auth_version=?) ON CONFLICT(user_id) DO UPDATE SET status=excluded.status,expires_at=excluded.expires_at,auth_version=excluded.auth_version").bind(me.id, status, Date.now() + hours * 36e5, statusActor.auth_version, me.id, statusActor.auth_version).run();
      return response({ ok: true });
    }
    if (action === "notification_settings") return response(await updateNotifications(await requireRecent(), data));
    if (action === "notification_subscribe") return response(await subscribe(await requireRecent(), data.subscription, true));
    if (action === "notification_unsubscribe") return response(await unsubscribe(await requireRecent(), data.id));
    if (action === "read") {
      const roomId = required(data.roomId);
      await roomAccess(roomId, me.id);
      const through = Number(data.through);
      if (!Number.isFinite(through) || through < 0) fail(400, "Invalid read time.");
      await database.prepare("UPDATE room_members SET read_at = MAX(read_at,?) WHERE room_id = ? AND user_id = ?").bind(Math.min(through, Date.now()), roomId, me.id).run();
      return response({ ok: true });
    }
    if (action === "conversation_preferences") {
      const roomId = required(data.roomId);
      await roomAccess(roomId, me.id);
      if (typeof data.favorite !== "boolean" || !["all", "mentions", "muted"].includes(String(data.notification))) fail(400, "Choose valid conversation settings.");
      const section = str(data.section || "", 40);
      await database.prepare("INSERT INTO conversation_preferences (user_id,room_id,favorite,section,notification) VALUES (?,?,?,?,?) ON CONFLICT(user_id,room_id) DO UPDATE SET favorite=excluded.favorite,section=excluded.section,notification=excluded.notification").bind(me.id, roomId, data.favorite ? 1 : 0, section, data.notification).run();
      return response({ ok: true });
    }
    if (action === "save_message") {
      const id = required(data.id), msg = await messageAccess(id, me.id);
      if (msg.deleted) fail(404, "This message was removed.");
      if (data.saved === false) await database.prepare("DELETE FROM saved_messages WHERE user_id=? AND message_id=?").bind(me.id, id).run();
      else await database.prepare("INSERT OR IGNORE INTO saved_messages (user_id,message_id,saved_at) VALUES (?,?,?)").bind(me.id, id, Date.now()).run();
      return response({ ok: true });
    }
    if (action === "profile_details") {
      const jobTitle = str(data.jobTitle || "", 60);
      await database.prepare("INSERT INTO crew_profiles (user_id,job_title) VALUES (?,?) ON CONFLICT(user_id) DO UPDATE SET job_title=excluded.job_title").bind(me.id, jobTitle).run();
      return response({ ok: true });
    }
    if (action === "profile") {
      const name = required(data.name, 60);
      await database.prepare("UPDATE people SET name = ? WHERE id = ?").bind(name, me.id).run();
      return response({ ok: true });
    }
    if (action === "rename_workspace") {
      if (me.role !== "owner") fail(403, "Only the workspace owner can change its name.");
      const name = required(data.name, 60);
      await database.prepare("UPDATE workspace SET name = ? WHERE id = ?").bind(name, "main").run();
      return response({ ok: true });
    }
    if (action === "create_channel") {
      if (!["owner", "admin"].includes(me.role)) fail(403, "Only an owner or manager can create channels.");
      const name = required(data.name, 45).toLowerCase().replace(/\s+/g, "-");
      if (!/^[a-z0-9][a-z0-9_-]*$/.test(name)) fail(400, "Use letters, numbers, hyphens, or underscores for the channel name.");
      const description = str(data.description || "", 250), visibility = data.visibility === "shared" ? "shared" : "private", id = crypto.randomUUID(), verified = await requireRecent(), gate = securityGate(verified, "channel_created", me.id);
      const selected = await selectedPeople(data.memberIds, me.id);
      const result = await database.batch([
        gate.statement,
        database.prepare("INSERT INTO rooms (id,name,description,kind,visibility,created_by,created_at) SELECT ?,?,?, ?,?,?,? WHERE " + gate.condition).bind(id, name, description, "channel", visibility, me.id, Date.now()),
        ...visibility === "shared" ? [database.prepare("INSERT INTO room_members (room_id,user_id,read_at) SELECT ?,id,0 FROM people WHERE active = 1 AND " + gate.condition).bind(id)] : selected.map((userId) => database.prepare("INSERT INTO room_members (room_id,user_id,read_at) SELECT ?,?,0 WHERE " + gate.condition).bind(id, userId))
      ]);
      if (!result[0].meta.changes) fail(401, "Your session changed. Sign in again.");
      return response({ id }, 201);
    }
    if (action === "update_channel") {
      const roomId = required(data.roomId), room = await roomAccess(roomId, me.id);
      if (room.kind !== "channel" || !["owner", "admin"].includes(me.role)) fail(403, "Only an owner or manager can edit channels.");
      const name = required(data.name, 45).toLowerCase().replace(/\s+/g, "-");
      if (!/^[a-z0-9][a-z0-9_-]*$/.test(name)) fail(400, "Use letters, numbers, hyphens, or underscores for the channel name.");
      const description = str(data.description || "", 250), visibility = data.visibility === "shared" ? "shared" : "private", selected = await selectedPeople(data.memberIds, me.id);
      const verified = await requireRecent(), gate = securityGate(verified, "channel_permissions_changed", me.id);
      const result = await database.batch([
        gate.statement,
        database.prepare("UPDATE rooms SET name = ?,description = ?,visibility = ? WHERE id = ? AND " + gate.condition).bind(name, description, visibility, roomId),
        database.prepare("DELETE FROM room_members WHERE room_id = ? AND user_id NOT IN (" + (visibility === "shared" ? "SELECT id FROM people WHERE active = 1" : selected.map(() => "?").join(",")) + ") AND " + gate.condition).bind(roomId, ...visibility === "shared" ? [] : selected),
        ...visibility === "shared" ? [database.prepare("INSERT OR IGNORE INTO room_members (room_id,user_id,read_at) SELECT ?,id,0 FROM people WHERE active = 1 AND " + gate.condition).bind(roomId)] : selected.map((id) => database.prepare("INSERT OR IGNORE INTO room_members (room_id,user_id,read_at) SELECT ?,?,0 WHERE " + gate.condition).bind(roomId, id))
      ]);
      if (!result[0].meta.changes) fail(401, "Your session changed. Sign in again.");
      return response({ ok: true });
    }
    if (action === "dm") {
      const other = required(data.userId);
      if (other === me.id) fail(400, "Choose another person.");
      if (!await database.prepare("SELECT id FROM people WHERE id = ? AND active = 1").bind(other).first()) fail(404, "This person has not joined the workspace.");
      const pair = [me.id, other].sort(), key2 = JSON.stringify(pair), hash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(key2)), id = "dm-" + Array.from(new Uint8Array(hash), (b) => b.toString(16).padStart(2, "0")).join("");
      await database.batch([
        database.prepare("INSERT OR IGNORE INTO rooms (id,name,description,kind,visibility,dm_key,created_by,created_at) VALUES (?, ?,?, ?,?,?,?,?)").bind(id, "Direct message", "Private to the two members in the app. Workspace operators can access stored data.", "dm", "private", key2, me.id, Date.now()),
        ...pair.map((userId) => database.prepare("INSERT OR IGNORE INTO room_members (room_id,user_id,read_at) VALUES (?,?,0)").bind(id, userId))
      ]);
      return response({ id });
    }
    if (["edit", "delete", "pin", "react"].includes(action)) {
      const id = required(data.id), msg = await messageAccess(id, me.id);
      if (action === "edit" || action === "delete") {
        if (msg.user_id !== me.id) fail(403, "You can only change your own messages.");
        if (action === "delete") return response(await deleteMessage(id, me));
        if (msg.deleted) fail(400, "This message was removed.");
        const body = str(data.body);
        if (!body && !await database.prepare("SELECT id FROM attachments WHERE message_id = ?").bind(id).first()) fail(400, "A message needs text or a photo.");
        await database.prepare("UPDATE messages SET body = ?,edited_at = ? WHERE id = ?").bind(body, Date.now(), id).run();
        return response({ ok: true });
      }
      if (msg.deleted) fail(400, "This message was removed.");
      if (action === "pin") {
        await database.prepare("UPDATE messages SET pinned = ? WHERE id = ?").bind(data.pinned ? 1 : 0, id).run();
        return response({ ok: true });
      }
      const emoji = required(data.emoji, 12);
      if (!["\u{1F44D}", "\u2764\uFE0F", "\u2705", "\u{1F389}", "\u{1F440}"].includes(emoji)) fail(400, "Choose an available reaction.");
      if (data.active === false) await database.prepare("DELETE FROM reactions WHERE message_id = ? AND user_id = ? AND emoji = ?").bind(id, me.id, emoji).run();
      else await database.prepare("INSERT OR IGNORE INTO reactions (message_id,user_id,emoji) VALUES (?,?,?)").bind(id, me.id, emoji).run();
      return response({ ok: true });
    }
    if (action === "remove_member") {
      return response(await removeCompanyPerson(await requireRecent(), data));
    }
    fail(400, "Unknown change.");
  } catch (e) {
    return handleError(e);
  }
}
async function selectedPeople(value, me) {
  const ids = Array.isArray(value) ? value.filter((v) => typeof v === "string").slice(0, 80) : [];
  const result = Array.from(/* @__PURE__ */ new Set([me, ...ids]));
  for (const id of result) if (!await db().prepare("SELECT id FROM people WHERE id = ? AND active = 1").bind(id).first()) fail(400, "Choose people who have joined the workspace.");
  return result;
}

// app/api/maintenance/route.ts
var route_exports10 = {};
__export(route_exports10, {
  GET: () => GET7,
  POST: () => POST10,
  dynamic: () => dynamic4
});
init_maintenance_links();
init_access();
var dynamic4 = "force-dynamic";
async function GET7() {
  try {
    const me = await member();
    return response(await connectionStatus(me.id));
  } catch (e) {
    return handleError(e);
  }
}
async function POST10(request2) {
  try {
    checkOrigin(request2);
    const me = await requireRecent();
    if (!request2.headers.get("content-type")?.startsWith("application/json")) fail(415, "Use a supported connection format.");
    const raw = await request2.text();
    if (raw.length > 8192) fail(413, "That link is too long.");
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      fail(400, "Please try connecting again.");
    }
    if (!data || typeof data !== "object") fail(400, "Please try connecting again.");
    if (data.action === "connect") return response(await saveConnection(me.id, data.link, me));
    if (data.action === "disconnect") {
      await disconnect(me.id, me);
      return response({ connected: false });
    }
    fail(400, "Unknown connection change.");
  } catch (e) {
    return handleError(e);
  }
}

// app/api/work-orders/route.ts
var route_exports11 = {};
__export(route_exports11, {
  GET: () => GET8,
  POST: () => POST11
});
init_chat_db();

// lib/work-order-match.ts
function assetWords(text) {
  const stop = new Set("the a an and or on in at is it its to of for with this that has have was are out not tried still but issue problem please".split(" "));
  const words = [...new Set((text.toLowerCase().match(/[\p{L}\p{N}]+/gu) || []).filter((w) => w.length >= 2 && !stop.has(w)))];
  return { queries: words.slice(0, 16), complete: words.length <= 16 };
}
function matchAssets(text, assets) {
  const normalize5 = (s) => " " + (s.toLowerCase().match(/[\p{L}\p{N}]+/gu) || []).join(" ") + " ";
  const body = normalize5(text);
  return [...new Map(assets.filter((a) => a.name.trim().length >= 2 && body.includes(normalize5(a.name))).map((a) => [a.id, a])).values()];
}
async function sourceOperationId(scope, label) {
  const bytes = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(scope + ":" + label))).slice(0, 16);
  bytes[6] = bytes[6] & 15 | 64;
  bytes[8] = bytes[8] & 63 | 128;
  const hex2 = [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex2.slice(0, 8) + "-" + hex2.slice(8, 12) + "-" + hex2.slice(12, 16) + "-" + hex2.slice(16, 20) + "-" + hex2.slice(20);
}

// app/api/work-orders/route.ts
init_access();
init_maintenance_links();
init_company_context();
var uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
async function context(roomId, userId) {
  const room = await roomAccess(roomId, userId);
  if (room.kind !== "channel" || room.name.trim().toLowerCase() !== "maintenance") fail(400, "Open the maintenance channel to submit a work order.");
  const link = await connectionUrl(userId);
  if (!link) fail(400, "Connect your personal Maintenance Hub link in Security & privacy first.");
  const token = new URLSearchParams(new URL(link).hash.slice(1)).get("hub");
  if (!token) fail(400, "Reconnect your personal Maintenance Hub link.");
  return { token, base: "https://fhqmnlpgqslllzrovxbp.supabase.co/functions/v1/" + (companyId() === "main" ? "" : "company-hub/"), signal: void 0 };
}
async function hub(ctx, path, init) {
  let res;
  try {
    res = await fetch(ctx.base + path, { ...init, headers: { ...Object.fromEntries(new Headers(init.headers)), Authorization: "Bearer " + ctx.token }, redirect: "manual", signal: ctx.signal || AbortSignal.timeout(45e3) });
  } catch {
    fail(503, "The Hub did not confirm the save. Keep this form open and retry the same request.");
  }
  if (!res.ok) {
    if (res.status === 401 || res.status === 403) fail(403, "Your personal Hub access does not allow this request. Check your Hub connection.");
    if (res.status === 400 || res.status === 413 || res.status === 415) fail(400, "The Hub rejected the details or photo. Check them in your Maintenance Hub before starting another request.");
    if (res.status === 409) fail(409, "Check your Hub for the existing work order before starting another request.");
    fail(503, "The Hub did not confirm the save. Keep this form open and retry the same request.");
  }
  return res;
}
async function workflow(ctx, action, data) {
  return (await hub(ctx, "hub-workflow/" + action, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) })).json();
}
async function GET8(request2) {
  try {
    const me = await member(), url = new URL(request2.url), ctx = await context(required(url.searchParams.get("roomId"), 100), me.id);
    if (url.searchParams.has("messageId")) {
      ctx.signal = AbortSignal.timeout(2e4);
      const msg = await messageAccess(required(url.searchParams.get("messageId"), 80), me.id);
      if (msg.deleted || msg.room_id !== url.searchParams.get("roomId") || msg.user_id !== me.id || msg.parent_id) fail(404, "Open your maintenance issue message.");
      const terms = assetWords(msg.body);
      let complete = terms.complete;
      const found = [];
      for (let i = 0; i < terms.queries.length; i += 4) {
        const pages = await Promise.all(terms.queries.slice(i, i + 4).map((query2) => workflow(ctx, "assets", { query: query2 })));
        for (const page of pages) {
          if (!Array.isArray(page)) fail(503, "Asset lookup is unavailable. Try again.");
          if (page.length >= 20) complete = false;
          found.push(...page.filter((a) => typeof a.id === "string" && uuid.test(a.id) && typeof a.name === "string").map((a) => ({ id: a.id, name: a.name, number: typeof a.number === "string" ? a.number : "" })));
        }
      }
      const row = await db().prepare(messageSelect + "WHERE m.id=?").bind(msg.id).first();
      if (!row) fail(404, "That message is unavailable.");
      return response({ matches: matchAssets(msg.body, found), complete, message: (await enrich([row], me.id))[0] });
    }
    const query = (url.searchParams.get("query") || "").trim().slice(0, 100);
    const data = await workflow(ctx, "assets", { query });
    if (!Array.isArray(data)) fail(503, "Asset lookup is unavailable. Try again.");
    return response({ assets: data.filter((a) => typeof a.id === "string" && uuid.test(a.id) && typeof a.name === "string").map((a) => ({ id: a.id, name: a.name, number: typeof a.number === "string" ? a.number : "" })) });
  } catch (e) {
    return handleError(e);
  }
}
async function POST11(request2) {
  try {
    checkOrigin(request2);
    const me = await requireRecent();
    if (!request2.headers.get("content-type")?.startsWith("multipart/form-data")) fail(415, "Use the work-order form.");
    const form = await request2.formData(), roomId = required(form.get("roomId"), 100), ctx = await context(roomId, me.id);
    let id = required(form.get("id"), 36), photoId = required(form.get("photoId"), 36), publishId = required(form.get("publishId"), 36);
    const sourceId = form.get("sourceMessageId");
    if (sourceId) {
      const source = await messageAccess(required(sourceId, 80), me.id);
      if (source.deleted || source.room_id !== roomId) fail(404, "That issue message is unavailable.");
      const scope = companyId() + ":" + me.id + ":" + source.id;
      [id, photoId, publishId] = await Promise.all(["request", "photo", "publish"].map((label) => sourceOperationId(scope, label)));
    }
    const asset = required(form.get("asset"), 36), description = required(form.get("description"), 4e3), safety = form.get("safety");
    if (![id, photoId, publishId, asset].every((v) => uuid.test(v)) || (/* @__PURE__ */ new Set([id, photoId, publishId])).size !== 3 || description.length < 10 || !["true", "false"].includes(String(safety))) fail(400, "Choose an asset and describe the issue in at least 10 characters.");
    const photo = form.get("photo");
    if (!(photo instanceof File) || photo.type !== "image/jpeg" || !photo.size || photo.size > 512 * 1024) fail(400, "Attach a prepared JPG photo of 512 KB or smaller.");
    const bytes = new Uint8Array(await photo.arrayBuffer());
    if (bytes.length < 12 || bytes[0] !== 255 || bytes[1] !== 216 || bytes[2] !== 255) fail(400, "Choose a valid photo.");
    const created = await workflow(ctx, "create", { operation_id: id, id, kind: "requested", asset_id: asset, description, is_safety_critical: safety === "true", is_test: false });
    if (created?.id !== id) fail(503, "The Hub did not confirm your work-order draft. Retry the same form.");
    const stored = await (await hub(ctx, "hub-photo/list", { method: "POST", headers: { "x-work-request-id": id } })).json();
    if (!stored?.photos?.some((p) => p.id === photoId)) await hub(ctx, "hub-photo/upload", { method: "POST", headers: { "Content-Type": "image/jpeg", "x-work-request-id": id, "x-photo-id": photoId }, body: bytes });
    const published = await workflow(ctx, "publish", { operation_id: publishId, id });
    if (published?.id !== id) fail(503, "The Hub did not confirm submission. Retry the same form.");
    return response({ id, number: created.number ?? null, status: published.status || "submitted" }, 201);
  } catch (e) {
    return handleError(e);
  }
}

// app/api/security/route.ts
var route_exports12 = {};
__export(route_exports12, {
  GET: () => GET9,
  POST: () => POST12,
  dynamic: () => dynamic5
});
init_chat_db();
init_access();
init_security_events();
init_maintenance_links();
init_photo_storage();
var dynamic5 = "force-dynamic";
async function GET9() {
  try {
    const me = await currentSession(), now = Date.now();
    const [keys, sessions, events, maintenance, workspace, photosPending] = await Promise.all([
      db().prepare("SELECT id,name,device_type,backed_up,created_at,last_used_at FROM passkeys WHERE user_id = ? ORDER BY created_at").bind(me.id).all(),
      db().prepare("SELECT id,device_label,created_at,last_seen_at,expires_at FROM sessions WHERE user_id = ? AND auth_level = ? AND auth_version = ? AND expires_at > ? ORDER BY created_at DESC").bind(me.id, "passkey", me.auth_version, now).all(),
      db().prepare("SELECT e.id,e.action,e.at,actor.name AS actor,target.name AS target FROM security_events e LEFT JOIN people actor ON actor.id = e.actor_id LEFT JOIN people target ON target.id = e.target_id" + (me.role === "owner" ? "" : " WHERE e.actor_id = ? OR e.target_id = ?") + " ORDER BY e.at DESC LIMIT 50").bind(...me.role === "owner" ? [] : [me.id, me.id]).all(),
      connectionStatus(me.id),
      db().prepare("SELECT ai_enabled FROM workspace WHERE id = ?").bind("main").first(),
      pendingDeletionCount(me)
    ]);
    return response({ keys: keys.results, sessions: sessions.results.map((s) => ({ ...s, current: s.id === me.session_id })), events: events.results, maintenance, aiEnabled: !!workspace?.ai_enabled, photosPending, photoStorage: await photoStorageUsage() });
  } catch (e) {
    return handleError(e);
  }
}
async function POST12(request2) {
  try {
    checkOrigin(request2);
    const me = await requireRecent();
    if (!request2.headers.get("content-type")?.startsWith("application/json")) fail(415, "Use a supported settings format.");
    const raw = await request2.text();
    if (raw.length > 8e3) fail(413, "This change is too large.");
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      fail(400, "Please try again.");
    }
    if (!data || typeof data !== "object" || Array.isArray(data)) fail(400, "Please try again.");
    const action = required(data.action);
    if (action === "retry_deletions") return response({ ok: true, photosPending: await retryFileDeletions(me) });
    if (action === "rename_key") {
      const id = required(data.id, 2048), name = required(data.name, 60), gate = securityGate(me, "passkey_rename_requested", me.id);
      const r = await db().batch([gate.statement, db().prepare("UPDATE passkeys SET name = ? WHERE id = ? AND user_id = ? AND " + gate.condition).bind(name, id, me.id)]);
      if (!r[0].meta.changes) fail(401, "Your session changed. Sign in again.");
      if (!r[1].meta.changes) fail(404, "This passkey was not found.");
      return response({ ok: true });
    }
    if (action === "remove_key") {
      const id = required(data.id, 2048), gate = securityGate(me, "passkey_removal_requested", me.id);
      const r = await db().batch([gate.statement, db().prepare("DELETE FROM passkeys WHERE id = ? AND user_id = ? AND (SELECT COUNT(*) FROM passkeys WHERE user_id = ?) > 1 AND " + gate.condition).bind(id, me.id, me.id)]);
      if (!r[0].meta.changes) fail(401, "Your session changed. Sign in again.");
      if (!r[1].meta.changes) fail(400, "Keep at least one passkey. Add a backup before removing your last one.");
      return response({ ok: true });
    }
    if (action === "revoke_session" || action === "revoke_other_sessions") {
      const id = action === "revoke_session" ? required(data.id) : null;
      if (id === me.session_id) fail(400, "Use Sign out to close this session.");
      const gate = securityGate(me, "other_sessions_revocation_requested", me.id);
      const r = await db().batch([gate.statement, db().prepare("DELETE FROM sessions WHERE user_id = ? AND session_hash <> ?" + (id ? " AND id = ?" : "") + " AND " + gate.condition).bind(me.id, me.session_hash, ...id ? [id] : []), db().prepare("DELETE FROM passkey_challenges WHERE user_id = ? AND session_hash <> ? AND " + gate.condition).bind(me.id, me.session_hash)]);
      if (!r[0].meta.changes) fail(401, "Your session changed. Sign in again.");
      return response({ ok: true });
    }
    if (action === "ai_permission") {
      if (me.role !== "owner") fail(403, "Only the workspace owner can change app permissions.");
      if (typeof data.enabled !== "boolean") fail(400, "Choose whether AI shortcuts are enabled.");
      const gate = securityGate(me, data.enabled ? "ai_shortcuts_enabled" : "ai_shortcuts_disabled");
      const r = await db().batch([gate.statement, db().prepare("UPDATE workspace SET ai_enabled = ? WHERE id = ? AND " + gate.condition).bind(data.enabled ? 1 : 0, "main")]);
      if (!r[0].meta.changes) fail(401, "Your session changed. Sign in again.");
      return response({ ok: true });
    }
    fail(400, "Unknown security change.");
  } catch (e) {
    return handleError(e);
  }
}

// app/api/branding/route.ts
var route_exports13 = {};
__export(route_exports13, {
  GET: () => GET10,
  POST: () => POST13,
  dynamic: () => dynamic6
});
init_chat_db();
init_access();
init_company_context();
var dynamic6 = "force-dynamic";
var MAX_LOGO_BYTES = 512 * 1024;
var LOGO_TYPES = /* @__PURE__ */ new Set(["image/jpeg", "image/png", "image/webp"]);
function decodeLogo(value) {
  if (typeof value !== "string" || value.length > 75e4) fail(413, "Choose a company logo smaller than 512 KB.");
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(value);
  if (!match || !LOGO_TYPES.has(match[1])) fail(415, "Choose a JPG, PNG, or WebP company logo.");
  let binary2 = "";
  try {
    binary2 = atob(match[2]);
  } catch {
    fail(415, "This company logo could not be read. Choose another image.");
  }
  if (!binary2.length || binary2.length > MAX_LOGO_BYTES) fail(413, "Choose a company logo smaller than 512 KB.");
  const bytes = Uint8Array.from(binary2, (c) => c.charCodeAt(0));
  const jpeg = bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
  const png = bytes.length >= 8 && [137, 80, 78, 71, 13, 10, 26, 10].every((n, i) => bytes[i] === n);
  const webp = bytes.length >= 12 && String.fromCharCode(...bytes.slice(0, 4)) === "RIFF" && String.fromCharCode(...bytes.slice(8, 12)) === "WEBP";
  if (match[1] === "image/jpeg" && !jpeg || match[1] === "image/png" && !png || match[1] === "image/webp" && !webp) fail(415, "This company logo does not match its image type. Choose another image.");
  return { data: value, mime: match[1], bytes };
}
async function GET10(request2) {
  try {
    const me = await currentPerson();
    const workspace = await db().prepare("SELECT name,owner_id,logo_data FROM workspace WHERE id='main'").first();
    if (!workspace) fail(404, "Company branding is unavailable.");
    if (new URL(request2.url).searchParams.get("image") === "1") {
      if (!workspace.logo_data) fail(404, "This company has not added a logo.");
      const logo = decodeLogo(workspace.logo_data);
      return new Response(logo.bytes, { headers: { "Content-Type": logo.mime, "Content-Length": String(logo.bytes.length), "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
    }
    return response({ companyName: workspace.name, viewerName: me.name, hasLogo: !!workspace.logo_data, logoUrl: workspace.logo_data ? companyPath("/api/branding?image=1") : null });
  } catch (error) {
    return handleError(error);
  }
}
async function POST13(request2) {
  try {
    checkOrigin(request2);
    if (!request2.headers.get("content-type")?.startsWith("application/json")) fail(415, "Use a supported company-logo format.");
    const me = await requireRecent();
    const workspace = await db().prepare("SELECT owner_id FROM workspace WHERE id='main'").first();
    if (me.role !== "owner" || workspace?.owner_id !== me.id) fail(403, "Only the company owner can change its logo.");
    const data = await request2.json();
    if (data.action === "remove") {
      await db().prepare("UPDATE workspace SET logo_data=NULL WHERE id='main' AND owner_id=?").bind(me.id).run();
      return response({ ok: true, hasLogo: false });
    }
    if (data.action !== "set") fail(400, "Choose a company-logo action.");
    const logo = decodeLogo(data.logoData);
    await db().prepare("UPDATE workspace SET logo_data=? WHERE id='main' AND owner_id=?").bind(logo.data, me.id).run();
    return response({ ok: true, hasLogo: true, logoUrl: companyPath("/api/branding?image=1") });
  } catch (error) {
    return handleError(error);
  }
}

// app/api/photos/[id]/route.ts
init_r2_storage();
init_chat_db();
import { env as env15 } from "cloudflare:workers";
async function GET11(request2, { params }) {
  try {
    const me = await member(), { id } = await params;
    if (id.startsWith("avatar-")) {
      const profile = await db().prepare("SELECT cp.photo,cp.photo_mime,cp.r2_key FROM crew_profiles cp JOIN people p ON p.id=cp.user_id WHERE cp.user_id=? AND p.active=1 AND (cp.photo IS NOT NULL OR cp.r2_key IS NOT NULL)").bind(id.slice(7)).first();
      if (!profile) fail(404, "Profile photo unavailable.");
      if (profile.r2_key) {
        if (!env15.CHAT_PHOTOS) fail(503, "Profile photo temporarily unavailable.");
        const object2 = await r2Get("chat", profile.r2_key);
        if (!object2) fail(503, "Profile photo temporarily unavailable.");
        return new Response(object2.body, { headers: { "Content-Type": "image/jpeg", "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
      }
      return new Response(new Uint8Array(profile.photo), { headers: { "Content-Type": "image/jpeg", "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
    }
    const file = await db().prepare("SELECT a.object_key,a.mime,a.name FROM attachments a JOIN messages m ON m.id = a.message_id JOIN room_members rm ON rm.room_id = m.room_id WHERE a.id = ? AND rm.user_id = ? AND m.deleted = 0").bind(id, me.id).first();
    if (!file) fail(404, "Photo not available.");
    const object = await bucket().get(file.object_key);
    if (!object) fail(404, "Photo not found.");
    return new Response(object.body, { headers: { "Content-Type": file.mime, "Content-Length": String(object.size), "Content-Disposition": file.mime === "application/pdf" && new URL(request2.url).searchParams.get("download") === "1" ? "attachment; filename*=UTF-8''" + encodeURIComponent(file.name.replace(/[\r\n]/g, "")) : "inline", "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff", "Content-Security-Policy": "default-src 'none'; sandbox" } });
  } catch (e) {
    return handleError(e);
  }
}

// app/maintenance/open/route.ts
var route_exports14 = {};
__export(route_exports14, {
  GET: () => GET12,
  dynamic: () => dynamic7
});
init_company_context();
init_company_context();
init_maintenance_links();
var dynamic7 = "force-dynamic";
async function GET12(request2) {
  try {
    const me = await member(), params = new URL(request2.url).searchParams, expected = params.get("viewer");
    if (expected && expected !== me.id) fail(401, "Your account changed on this device. Open Maintenance again.");
    const url = await connectionUrl(me.id);
    let destination = url || companyPath("/?section=maintenance");
    if (url) {
      const hub2 = new URL(url), fragment = new URLSearchParams(hub2.hash.slice(1)), products = await companyProducts();
      if (params.get("form") === "problem") hub2.pathname = "/request";
      hub2.searchParams.set("teamsteadPlan", products.plan);
      if (products.chat) {
        fragment.set("entry", "project-room");
        fragment.set("chatCompany", companyId());
      } else {
        fragment.delete("entry");
        fragment.delete("chatCompany");
      }
      hub2.hash = fragment.toString();
      destination = hub2.toString();
    }
    return new Response(null, { status: 303, headers: { Location: destination, "Cache-Control": "private, no-store", "Referrer-Policy": "no-referrer", "X-Content-Type-Options": "nosniff" } });
  } catch (e) {
    if (e instanceof ChatError && e.status === 401) return new Response(null, { status: 303, headers: { Location: companyPath("/?section=maintenance"), "Cache-Control": "no-store" } });
    return handleError(e);
  }
}

// app/api/bots/route.ts
var route_exports15 = {};
__export(route_exports15, {
  GET: () => GET13,
  POST: () => POST14
});
init_company_context();
init_chat_db();
import { env as env16 } from "cloudflare:workers";
init_access();
init_maintenance_bots();
async function GET13() {
  try {
    const me = await member();
    return response(await botStatus(me.id));
  } catch (e) {
    return handleError(e);
  }
}
async function POST14(request2) {
  try {
    if (new URL(request2.url).searchParams.get("action") === "tick") {
      const expected = env16.BOT_RUNNER_TOKEN_HASH || "", token = request2.headers.get("authorization")?.replace(/^Bearer /, "") || "";
      if (!/^[A-Za-z0-9_-]{43}$/.test(token) || !/^[a-f0-9]{64}$/.test(expected)) fail(401, "Unavailable.");
      const actual = await tokenHash(token);
      let diff = 0;
      for (let i = 0; i < 64; i++) diff |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
      if (diff) fail(401, "Unavailable.");
      const result = await runBots();
      if (companyId() === "main") {
        const companies = await rawDb().prepare("SELECT id FROM company_registry WHERE id<>'main' AND status='active' AND hub_ready=1").all();
        await Promise.allSettled(companies.results.map(async (co) => {
          const url = new URL("https://teamstead-crew.pages.dev/api/bots?action=tick");
          url.searchParams.set("company", co.id);
          const r = await fetch(url, { method: "POST", headers: { Authorization: "Bearer " + token }, signal: AbortSignal.timeout(2e4) });
          if (!r.ok) throw Error("Company notification check could not finish");
        }));
      }
      return response(result);
    }
    checkOrigin(request2);
    const me = await member();
    if (!request2.headers.get("content-type")?.startsWith("application/json")) fail(415, "Use Teamstead Crew to update your bots.");
    const raw = await request2.text();
    if (raw.length > 8192) fail(413, "Request too large.");
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      fail(400, "Please try again.");
    }
    if (data?.action === "enable") {
      if (data.enabled !== true && data.enabled !== false) fail(400, "Choose on or off.");
      if (data.enabled && data.consent !== true) fail(400, "Confirm that your personal Hub can be read by your Maintenance bots.");
      return response(await enableBot(await requireRecent(), data.enabled));
    }
    if (data?.action === "subscribe") return response(await subscribe(await requireRecent(), data.subscription));
    if (data?.action === "unsubscribe") return response(await unsubscribe(await requireRecent(), data.id));
    if (data?.action === "my_jobs" || data?.action === "check") return response(await checkJobs(me.id, data.action === "my_jobs"));
    if (data?.action === "test_push") {
      await requireRecent();
      await sendPush(me.id, true);
      return response({ ok: true });
    }
    fail(400, "Unknown bot action.");
  } catch (e) {
    return handleError(e);
  }
}

// app/api/crew-call/route.ts
var route_exports16 = {};
__export(route_exports16, {
  GET: () => GET14,
  POST: () => POST15
});
init_chat_db();
init_company_context();
init_access();
var LEASE = 45e3;
var MAX_DURATION = 2 * 60 * 60 * 1e3;
async function context2(roomId, testLimit = 0) {
  const me = await currentSession(), room = await roomAccess(roomId, me.id);
  if (room.kind === "bot") fail(400, "Open a person or team conversation for Crew Call.");
  return { me, co: companyId() + ([10, 40].includes(testLimit) ? `:crew-call-test-${testLimit}` : ""), limit: [10, 40].includes(testLimit) ? testLimit : 14, roomId, database: rawDb() };
}
async function visiblePeers(co, roomId, now) {
  const [peers, members] = await Promise.all([
    rawDb().prepare("SELECT * FROM crew_call_peers WHERE company_id=? AND room_id=? AND seen_at>? AND joined_at>?").bind(co, roomId, now - LEASE, now - MAX_DURATION).all(),
    db().prepare("SELECT p.id,p.name,p.auth_version FROM people p JOIN room_members rm ON rm.user_id=p.id WHERE rm.room_id=? AND p.active=1").bind(roomId).all()
  ]);
  return peers.results.flatMap((p) => {
    const m = members.results.find((m2) => m2.id === p.user_id && m2.auth_version === p.auth_version);
    return m ? [{ peerId: p.peer_id, userId: m.id, name: m.name }] : [];
  });
}
async function GET14(request2) {
  try {
    const u = new URL(request2.url), roomId = required(u.searchParams.get("roomId")), ctx = await context2(roomId, Number(u.searchParams.get("test"))), now = Date.now();
    const peers = await visiblePeers(ctx.co, roomId, now), peerId = u.searchParams.get("peerId");
    if (!peerId) return response({ peers });
    if (!peers.some((p) => p.peerId === peerId && p.userId === ctx.me.id)) fail(409, "Your call ended. Join again to reconnect.");
    const since = Number(u.searchParams.get("since") || 0);
    if (!Number.isSafeInteger(since) || since < 0) fail(400, "Invalid call cursor.");
    const signals = await ctx.database.prepare("SELECT id,sender,payload FROM crew_call_signals WHERE company_id=? AND room_id=? AND target=? AND id>? AND created_at>? ORDER BY id LIMIT 100").bind(ctx.co, roomId, peerId, since, now - 12e4).all();
    return response({ peers, signals: signals.results.map((s) => ({ ...s, payload: JSON.parse(s.payload) })) });
  } catch (e) {
    return handleError(e);
  }
}
async function POST15(request2) {
  try {
    checkOrigin(request2);
    const text = await request2.text();
    if (text.length > 65e3) fail(413, "Call update too large.");
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      fail(400, "Invalid call update.");
    }
    if (!data || Array.isArray(data)) fail(400, "Invalid call update.");
    const roomId = required(data.roomId), peerId = required(data.peerId), action = required(data.action), ctx = await context2(roomId, Number(data.test)), { database, co, me, limit } = ctx, now = Date.now();
    if (!/^[a-f0-9-]{36}$/.test(peerId)) fail(400, "Invalid call identifier.");
    if (action === "join") {
      await database.batch([
        database.prepare("DELETE FROM crew_call_peers WHERE company_id=? AND room_id=? AND (seen_at<=? OR joined_at<=?)").bind(co, roomId, now - LEASE, now - MAX_DURATION),
        database.prepare("DELETE FROM crew_call_signals WHERE created_at<?").bind(now - 12e4),
        database.prepare("INSERT INTO crew_call_peers(company_id,room_id,user_id,peer_id,auth_version,joined_at,seen_at) SELECT ?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM crew_call_peers WHERE company_id=? AND room_id=?)<? ON CONFLICT(company_id,room_id,user_id) DO UPDATE SET seen_at=excluded.seen_at WHERE crew_call_peers.peer_id=excluded.peer_id AND crew_call_peers.auth_version=excluded.auth_version").bind(co, roomId, me.id, peerId, me.auth_version, now, now, co, roomId, limit)
      ]);
      const own2 = await database.prepare("SELECT peer_id FROM crew_call_peers WHERE company_id=? AND room_id=? AND user_id=?").bind(co, roomId, me.id).first();
      if (own2?.peer_id !== peerId) fail(409, `This call is full (${limit} people), or you already joined on another device.`);
      return response({ peers: await visiblePeers(co, roomId, now) });
    }
    if (action === "leave") {
      await database.batch([database.prepare("DELETE FROM crew_call_peers WHERE company_id=? AND room_id=? AND user_id=? AND peer_id=?").bind(co, roomId, me.id, peerId), database.prepare("DELETE FROM crew_call_signals WHERE company_id=? AND room_id=? AND (target=? OR sender=?)").bind(co, roomId, peerId, peerId)]);
      return response({ ok: true });
    }
    const own = await database.prepare("SELECT * FROM crew_call_peers WHERE company_id=? AND room_id=? AND user_id=? AND peer_id=? AND auth_version=? AND seen_at>? AND joined_at>?").bind(co, roomId, me.id, peerId, me.auth_version, now - LEASE, now - MAX_DURATION).first();
    if (!own) fail(409, "Your call ended. Join again to reconnect.");
    if (action === "heartbeat") {
      await database.prepare("UPDATE crew_call_peers SET seen_at=? WHERE company_id=? AND room_id=? AND user_id=? AND peer_id=?").bind(now, co, roomId, me.id, peerId).run();
      return response({ ok: true });
    }
    if (action !== "signal") fail(400, "Unknown call action.");
    const target = required(data.target), peers = await visiblePeers(co, roomId, now);
    if (target === peerId || !peers.some((p) => p.peerId === target)) fail(404, "That person left the call.");
    const payload = data.payload;
    if (!payload || typeof payload !== "object" || !["offer", "answer", "ice"].includes(String(payload.type))) fail(400, "Invalid call signal.");
    if (payload.type === "offer" || payload.type === "answer") {
      if (typeof payload.sdp !== "string" || !payload.sdp || payload.sdp.length > 55e3) fail(400, "Invalid call description.");
    }
    if (payload.type === "ice") {
      const c = payload.candidate;
      if (!c || typeof c !== "object" || typeof c.candidate !== "string" || c.candidate.length > 4e3) fail(400, "Invalid connection update.");
    }
    const encoded = JSON.stringify(payload);
    if (encoded.length > 6e4) fail(413, "Call signal too large.");
    const count = await database.prepare("SELECT COUNT(*) AS n FROM crew_call_signals WHERE company_id=? AND sender=? AND created_at>?").bind(co, peerId, now - 6e4).first();
    if ((count?.n || 0) >= (limit > 4 ? (limit - 1) * 80 : 240)) fail(429, "Too many call updates. Leave and try again shortly.");
    await database.prepare("INSERT INTO crew_call_signals(company_id,room_id,sender,target,payload,created_at) VALUES(?,?,?,?,?,?)").bind(co, roomId, peerId, target, encoded, now).run();
    return response({ ok: true });
  } catch (e) {
    return handleError(e);
  }
}

// lib/parts-finder.js
init_access();
import { env as env17 } from "cloudflare:workers";
var priceCache = /* @__PURE__ */ new Map();
var storeCache = /* @__PURE__ */ new Map();
var stockCache = /* @__PURE__ */ new Map();
var CACHE_TTL_MS = 15 * 60 * 1e3;
var MAX_CACHE_ENTRIES = 40;
var securityHeaders = {
  "content-security-policy": "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'",
  "referrer-policy": "strict-origin-when-cross-origin",
  "x-content-type-options": "nosniff",
  "x-frame-options": "SAMEORIGIN",
  "permissions-policy": "camera=(), microphone=(), geolocation=(self)"
};
function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...securityHeaders,
      ...extraHeaders
    }
  });
}
function safeUrl(value) {
  try {
    const url = new URL(String(value || ""), "https://www.google.com");
    return ["http:", "https:"].includes(url.protocol) ? url.href : "";
  } catch {
    return "";
  }
}
function parseDeliveryCost(delivery) {
  const text = String(delivery || "");
  if (/free/i.test(text)) return 0;
  const match = text.match(/\$\s*([0-9]+(?:\.[0-9]{1,2})?)/);
  return match ? Number(match[1]) : 0;
}
function normalizePriceResult(item, index) {
  const price = Number(item?.extracted_price);
  if (!Number.isFinite(price) || price < 0) return null;
  const delivery = String(item?.delivery || item?.shipping || "Shipping not shown").slice(0, 120);
  return {
    id: String(item?.product_id || item?.position || index),
    productId: String(item?.product_id || "").slice(0, 80),
    pageToken: String(item?.immersive_product_page_token || "").slice(0, 5e3),
    title: String(item?.title || "Part listing").slice(0, 180),
    seller: String(item?.source || item?.seller || "Online seller").slice(0, 80),
    price,
    priceText: String(item?.price || "").slice(0, 40),
    delivery,
    shipping: parseDeliveryCost(delivery),
    link: safeUrl(item?.product_link || item?.link),
    rating: Number.isFinite(Number(item?.rating)) ? Number(item.rating) : null,
    reviews: Number.isFinite(Number(item?.reviews)) ? Number(item.reviews) : null
  };
}
async function searchPrices(request2, env18) {
  if (request2.method !== "GET") return json({ error: "Method not allowed" }, 405, { allow: "GET" });
  if (!env18.SERPAPI_API_KEY) return json({ error: "Live pricing is not configured yet." }, 503);
  const requestUrl = new URL(request2.url);
  const query = String(requestUrl.searchParams.get("q") || "").replace(/[\u0000-\u001f\u007f]/g, " ").trim();
  const location = String(requestUrl.searchParams.get("location") || "").trim();
  if (query.length < 2 || query.length > 120) return json({ error: "Enter a part name or number between 2 and 120 characters." }, 400);
  if (location && !/^\d{5}$/.test(location)) return json({ error: "Use a five-digit ZIP code." }, 400);
  const cacheKey = `${query.toLowerCase()}|${location}`;
  const cached = priceCache.get(cacheKey);
  if (cached && Date.now() - cached.savedAt < CACHE_TTL_MS) {
    return json({ ...cached.payload, cached: true });
  }
  const providerUrl = new URL("https://serpapi.com/search.json");
  providerUrl.searchParams.set("engine", "google_shopping");
  providerUrl.searchParams.set("q", query);
  providerUrl.searchParams.set("gl", "us");
  providerUrl.searchParams.set("hl", "en");
  if (location) providerUrl.searchParams.set("location", location);
  providerUrl.searchParams.set("api_key", env18.SERPAPI_API_KEY);
  let providerResponse;
  try {
    providerResponse = await fetch(providerUrl, { headers: { accept: "application/json" } });
  } catch {
    return json({ error: "The pricing service could not be reached. Try again in a moment." }, 502);
  }
  let providerData;
  try {
    providerData = await providerResponse.json();
  } catch {
    return json({ error: "The pricing service returned an unreadable response." }, 502);
  }
  if (!providerResponse.ok || providerData?.error) {
    const message = String(providerData?.error || "");
    const quota = /limit|quota|searches|credits/i.test(message);
    return json({ error: quota ? "The free monthly price-search allowance has been used. Try the Google Shopping link below." : "Live prices are temporarily unavailable. Try again shortly." }, quota ? 429 : 502);
  }
  const sourceItems = Array.isArray(providerData?.shopping_results) ? providerData.shopping_results : Array.isArray(providerData?.inline_shopping_results) ? providerData.inline_shopping_results : [];
  const prices2 = sourceItems.map(normalizePriceResult).filter(Boolean).slice(0, 10);
  const payload = { query, prices: prices2, searchedAt: (/* @__PURE__ */ new Date()).toISOString() };
  priceCache.set(cacheKey, { savedAt: Date.now(), payload });
  if (priceCache.size > MAX_CACHE_ENTRIES) priceCache.delete(priceCache.keys().next().value);
  return json(payload);
}
function getMapsLink(item) {
  const url = new URL("https://www.google.com/maps/search/");
  url.searchParams.set("api", "1");
  url.searchParams.set("query", [item?.title, item?.address].filter(Boolean).join(" ") || "parts store");
  if (item?.place_id) url.searchParams.set("query_place_id", String(item.place_id));
  return url.href;
}
function normalizeStoreResult(item, index) {
  const title = String(item?.title || "").trim().slice(0, 120);
  if (!title) return null;
  return {
    id: String(item?.place_id || item?.data_id || item?.position || index),
    title,
    type: String(item?.type || "Parts store").slice(0, 80),
    address: String(item?.address || "Address not shown").slice(0, 180),
    phone: String(item?.phone || "").slice(0, 40),
    rating: Number.isFinite(Number(item?.rating)) ? Number(item.rating) : null,
    reviews: Number.isFinite(Number(item?.reviews)) ? Number(item.reviews) : null,
    openState: String(item?.open_state || "Hours not shown").slice(0, 100),
    directions: getMapsLink(item)
  };
}
async function searchStores(request2, env18) {
  if (request2.method !== "GET") return json({ error: "Method not allowed" }, 405, { allow: "GET" });
  if (!env18.SERPAPI_API_KEY) return json({ error: "Nearby-store search is not configured yet." }, 503);
  const requestUrl = new URL(request2.url);
  const zip = String(requestUrl.searchParams.get("zip") || "").trim();
  const latitudeParam = requestUrl.searchParams.get("lat");
  const longitudeParam = requestUrl.searchParams.get("lon");
  const latitude = Number(latitudeParam);
  const longitude = Number(longitudeParam);
  const hasCoordinates = latitudeParam !== null && longitudeParam !== null && Number.isFinite(latitude) && Number.isFinite(longitude);
  if (zip && !/^\d{5}$/.test(zip)) return json({ error: "Use a five-digit ZIP code." }, 400);
  if (hasCoordinates && (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180)) return json({ error: "The location coordinates are invalid." }, 400);
  if (!zip && !hasCoordinates) return json({ error: "Use your current location or enter a ZIP code first." }, 400);
  const areaKey = zip || `${latitude.toFixed(3)},${longitude.toFixed(3)}`;
  const cached = storeCache.get(areaKey);
  if (cached && Date.now() - cached.savedAt < CACHE_TTL_MS) return json({ ...cached.payload, cached: true });
  const providerUrl = new URL("https://serpapi.com/search.json");
  providerUrl.searchParams.set("engine", "google_maps");
  providerUrl.searchParams.set("type", "search");
  providerUrl.searchParams.set("q", zip ? `auto parts stores near ${zip}` : "auto parts stores near me");
  providerUrl.searchParams.set("hl", "en");
  providerUrl.searchParams.set("gl", "us");
  if (hasCoordinates) {
    providerUrl.searchParams.set("ll", `@${latitude.toFixed(6)},${longitude.toFixed(6)},14z`);
    providerUrl.searchParams.set("nearby", "true");
  }
  providerUrl.searchParams.set("api_key", env18.SERPAPI_API_KEY);
  let providerResponse;
  try {
    providerResponse = await fetch(providerUrl, { headers: { accept: "application/json" } });
  } catch {
    return json({ error: "The nearby-store service could not be reached. Try again in a moment." }, 502);
  }
  let providerData;
  try {
    providerData = await providerResponse.json();
  } catch {
    return json({ error: "The nearby-store service returned an unreadable response." }, 502);
  }
  if (!providerResponse.ok || providerData?.error) {
    const message = String(providerData?.error || "");
    const quota = /limit|quota|searches|credits/i.test(message);
    return json({ error: quota ? "The free monthly search allowance has been used. Open Maps instead." : "Nearby stores are temporarily unavailable. Try again shortly." }, quota ? 429 : 502);
  }
  const sourceItems = Array.isArray(providerData?.local_results) ? providerData.local_results : [];
  const stores2 = sourceItems.map(normalizeStoreResult).filter(Boolean).slice(0, 8);
  const payload = { stores: stores2, areaLabel: zip ? `ZIP ${zip}` : "your current location", searchedAt: (/* @__PURE__ */ new Date()).toISOString() };
  storeCache.set(areaKey, { savedAt: Date.now(), payload });
  if (storeCache.size > MAX_CACHE_ENTRIES) storeCache.delete(storeCache.keys().next().value);
  return json(payload);
}
function normalizeStockOffer(item, index) {
  const details = Array.isArray(item?.details_and_offers) ? item.details_and_offers.map((value) => String(value || "").trim().slice(0, 160)).filter(Boolean).slice(0, 6) : [];
  const reportedStatus = details.find((value) => /\b(in stock|out of stock|available|unavailable|pickup)\b/i.test(value));
  const price = Number(item?.extracted_price);
  return {
    id: String(item?.position || index),
    seller: String(item?.name || "Online seller").slice(0, 100),
    title: String(item?.title || "Product offer").slice(0, 180),
    price: Number.isFinite(price) && price >= 0 ? price : null,
    priceText: String(item?.price || "").slice(0, 40),
    status: String(reportedStatus || "Stock not reported").slice(0, 160),
    details,
    link: safeUrl(item?.link)
  };
}
async function searchStock(request2, env18) {
  if (request2.method !== "GET") return json({ error: "Method not allowed" }, 405, { allow: "GET" });
  if (!env18.SERPAPI_API_KEY) return json({ error: "Online-stock checks are not configured yet." }, 503);
  const requestUrl = new URL(request2.url);
  const productId = String(requestUrl.searchParams.get("product_id") || "").trim();
  const pageToken = String(requestUrl.searchParams.get("page_token") || "").trim();
  if (productId && !/^\d{5,80}$/.test(productId)) return json({ error: "This listing does not have a usable product number." }, 400);
  if (pageToken && (pageToken.length < 16 || pageToken.length > 5e3 || /[\u0000-\u001f\u007f]/.test(pageToken))) return json({ error: "This listing does not have a usable stock token." }, 400);
  if (!productId && !pageToken) return json({ error: "Stock information is not available for this listing." }, 400);
  const cacheKey = pageToken || productId;
  const cached = stockCache.get(cacheKey);
  if (cached && Date.now() - cached.savedAt < CACHE_TTL_MS) return json({ ...cached.payload, cached: true });
  const providerUrl = new URL("https://serpapi.com/search.json");
  providerUrl.searchParams.set("engine", "google_product");
  providerUrl.searchParams.set("gl", "us");
  providerUrl.searchParams.set("hl", "en");
  if (pageToken) providerUrl.searchParams.set("page_token", pageToken);
  else {
    providerUrl.searchParams.set("product_id", productId);
    providerUrl.searchParams.set("offer_view", "true");
  }
  providerUrl.searchParams.set("api_key", env18.SERPAPI_API_KEY);
  let providerResponse;
  try {
    providerResponse = await fetch(providerUrl, { headers: { accept: "application/json" } });
  } catch {
    return json({ error: "The online-stock service could not be reached. Try again in a moment." }, 502);
  }
  let providerData;
  try {
    providerData = await providerResponse.json();
  } catch {
    return json({ error: "The online-stock service returned an unreadable response." }, 502);
  }
  if (!providerResponse.ok || providerData?.error) {
    const message = String(providerData?.error || "");
    const quota = /limit|quota|searches|credits/i.test(message);
    return json({ error: quota ? "The free monthly search allowance has been used. Open the listing to check stock." : "Online stock is temporarily unavailable. Open the listing or try again shortly." }, quota ? 429 : 502);
  }
  const sourceOffers = Array.isArray(providerData?.product_results?.stores) ? providerData.product_results.stores : [];
  const offers = sourceOffers.map(normalizeStockOffer).slice(0, 8);
  const availableCount = offers.filter((offer) => /\bin stock\b|\bavailable\b|\bpickup\b/i.test(offer.status) && !/\bout of stock\b|\bunavailable\b/i.test(offer.status)).length;
  const payload = {
    title: String(providerData?.product_results?.title || "Product").slice(0, 180),
    summary: availableCount ? `${availableCount} seller${availableCount === 1 ? "" : "s"} report availability` : "Online stock was not confirmed",
    offers,
    checkedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  stockCache.set(cacheKey, { savedAt: Date.now(), payload });
  if (stockCache.size > MAX_CACHE_ENTRIES) stockCache.delete(stockCache.keys().next().value);
  return json(payload);
}
async function authenticated(handler, request2) {
  await currentPerson();
  return handler(request2, env17);
}
function prices(request2) {
  return authenticated(searchPrices, request2);
}
function stores(request2) {
  return authenticated(searchStores, request2);
}
function stock(request2) {
  return authenticated(searchStock, request2);
}

// lib/hub-r2-bridge.ts
init_r2_storage();
init_app_errors();
var encoder = new TextEncoder();
async function hubR2Bridge(request2) {
  const headers2 = { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" };
  const error = (status) => new Response(null, { status, headers: headers2 });
  try {
    if (!["GET", "PUT"].includes(request2.method) || new URL(request2.url).search) return error(400);
    const key2 = request2.headers.get("x-object-key") || "", timestamp = request2.headers.get("x-signed-at") || "", signature = request2.headers.get("x-signature") || "";
    const manual = /^manuals\/rides\/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.pdf$/.test(key2);
    if (!manual && !/^(work-orders\/[0-9a-f-]{36}\/(problem|completion)|parts\/[0-9a-f-]{36})\/[0-9a-f-]{36}\.jpg$/.test(key2) || !/^\d{13}$/.test(timestamp) || Math.abs(Date.now() - Number(timestamp)) > 6e4 || !/^[A-Za-z0-9_-]{86}$/.test(signature)) return error(401);
    const limit = manual ? 20971520 : 5242880, contentType = manual ? "application/pdf" : "image/jpeg";
    if (Number(request2.headers.get("content-length") || 0) > limit) return error(413);
    const chunks = [];
    let length = 0;
    if (request2.body) {
      const reader = request2.body.getReader();
      try {
        for (; ; ) {
          const { done, value } = await reader.read();
          if (done) break;
          length += value.length;
          if (length > limit) {
            await reader.cancel();
            return error(413);
          }
          chunks.push(value);
        }
      } finally {
        reader.releaseLock();
      }
    }
    const bytes = new Uint8Array(length);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.length;
    }
    if (request2.method === "GET" && length) return error(400);
    const signed = encoder.encode(["pms-hub-r2-v1", request2.method, key2, timestamp, await digest(bytes)].join("\n"));
    const publicKey = await crypto.subtle.importKey("jwk", BRIDGE_PUBLIC_KEY, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
    const sig = Uint8Array.from(atob(signature.replace(/-/g, "+").replace(/_/g, "/") + "=="), (x) => x.charCodeAt(0));
    if (!await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, publicKey, sig, signed)) return error(401);
    if (request2.method === "GET") {
      const object = await r2Get("maintenance", key2);
      return object ? new Response(object.body, { headers: { ...headers2, "Content-Type": contentType } }) : error(404);
    }
    if (!length || request2.headers.get("content-type") !== contentType) return error(415);
    if (manual && new TextDecoder().decode(bytes.subarray(0, 5)) !== "%PDF-") return error(415);
    await r2Put("maintenance", key2, bytes, contentType);
    return error(201);
  } catch (e) {
    return error(e instanceof ChatError ? e.status : 503);
  }
}

// worker/index.ts
init_request_context();

// lib/company-install-manifest.ts
function companyInstallManifest(request2) {
  if (!["GET", "HEAD"].includes(request2.method)) return new Response("Method not allowed", { status: 405 });
  const co = new URL(request2.url).searchParams.get("company") || "main";
  if (!/^(main|demo|pilot|c_[a-f0-9]{16})$/.test(co)) return new Response("Company not found", { status: 404 });
  const start = co === "main" ? "/" : "/?company=" + co;
  const manifest = { id: start, name: "Teamstead Crew", short_name: "Teamstead Crew", description: "Your private team conversations and maintenance workspace.", start_url: start, scope: "/", display: "standalone", background_color: "#f7f9f5", theme_color: "#154e48", icons: [{ src: "/app-icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any maskable" }] };
  return new Response(request2.method === "HEAD" ? null : JSON.stringify(manifest), { headers: { "Content-Type": "application/manifest+json", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
}

// worker/index.ts
var routes = {
  "/api/checkout": route_exports,
  "/api/hub-billing-access": { POST: hubBillingAttestation },
  "/api/stripe-webhook": route_exports2,
  "/api/roster": route_exports4,
  "/api/signup": route_exports5,
  "/api/platform": route_exports6,
  "/api/workspaces": route_exports3,
  "/api/workspace-attestation": { POST: workspaceAttestation },
  "/api/access": route_exports7,
  "/api/passkeys": route_exports8,
  "/api/chat": route_exports9,
  "/api/maintenance": route_exports10,
  "/api/work-orders": route_exports11,
  "/api/security": route_exports12,
  "/api/branding": route_exports13,
  "/api/bots": route_exports15,
  "/api/crew-call": route_exports16,
  "/api/parts-prices": { GET: prices },
  "/api/parts-stores": { GET: stores },
  "/api/parts-stock": { GET: stock },
  "/maintenance/open": route_exports14
};
var MAX_REQUEST_BYTES = 2 * 1024 * 1024;
function jsonError(message, status, extra = {}) {
  return Response.json({ error: message }, { status, headers: { "Cache-Control": "private, no-store", ...extra } });
}
async function boundedRequest(request2) {
  if (!request2.body) return request2;
  if (Number(request2.headers.get("content-length") || 0) > MAX_REQUEST_BYTES) {
    return jsonError("This upload is too large. Choose up to three photos or PDFs through the app.", 413);
  }
  const reader = request2.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > MAX_REQUEST_BYTES) {
        await reader.cancel();
        return jsonError("This upload is too large for the free pilot.", 413);
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return new Request(request2, { body: bytes });
}
function protect(response2) {
  const result = new Response(response2.body, response2);
  result.headers.set("Cache-Control", "private, no-store");
  result.headers.set("X-Content-Type-Options", "nosniff");
  result.headers.set("Referrer-Policy", "no-referrer");
  result.headers.set("X-Frame-Options", "DENY");
  result.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  return result;
}
function protectParts(response2) {
  const result = protect(response2);
  result.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=(self)");
  return result;
}
var index_default = {
  async fetch(request2, env18) {
    if (!await teamsteadBoundary(request2, env18.DB)) return protect(jsonError("Teamstead is not ready. Please use your current company link.", 503));
    const path = new URL(request2.url).pathname;
    if (path === "/manifest.webmanifest") return companyInstallManifest(request2);
    if (path === "/api/hub-photo-storage") return protect(await hubR2Bridge(request2));
    const route = routes[path];
    const photo = /^\/api\/photos\/([^/]+)$/.exec(path);
    const partsAsset = path === "/parts" || path.startsWith("/parts/");
    if (!route && !photo && !partsAsset) {
      if (path === "/api" || path.startsWith("/api/") || path.startsWith("/maintenance/open/")) {
        return protect(jsonError("This action is not available.", 404));
      }
      return env18.ASSETS.fetch(request2);
    }
    const method = request2.method;
    if (partsAsset && !["GET", "HEAD"].includes(method)) return protect(jsonError("Method not allowed.", 405, { Allow: "GET, HEAD" }));
    if (photo && method !== "GET") return protect(jsonError("Method not allowed.", 405, { Allow: "GET" }));
    const handler = route?.[method];
    if (!partsAsset && !photo && !handler) return protect(jsonError("Method not allowed.", 405, { Allow: Object.keys(route).filter((key2) => key2 === "GET" || key2 === "POST").join(", ") }));
    try {
      const bounded = method === "POST" ? await boundedRequest(request2) : request2;
      if (bounded instanceof Response) return protect(bounded);
      return await withRequest(bounded, async () => {
        const co = companyId();
        if (co !== "main") {
          const registry = await env18.DB.prepare("SELECT status FROM company_registry WHERE id=?").bind(co).first();
          if (["suspended", "archived", "deleting"].includes(registry?.status || "")) return protect(jsonError("This company\u2019s access is paused. Contact its owner.", 403));
          if (/^c_/.test(co) && (!registry || registry.status === "building")) return protect(jsonError("Company setup is not ready.", 404));
        }
        const products = await companyProducts();
        const action = method === "POST" ? await bounded.clone().json().then((d) => d.action).catch(() => null) : new URL(bounded.url).searchParams.get("action") || "state";
        if (!products.hub && ["/api/maintenance", "/api/work-orders", "/maintenance/open", "/api/bots", "/api/roster"].includes(path)) return protect(jsonError("Maintenance Hub is not included in your plan.", 403));
        if (!products.hub && path === "/api/access" && method === "POST") {
          const data = await bounded.clone().json().catch(() => ({}));
          if (data.maintenanceLink) return protect(jsonError("Maintenance Hub is not included in your plan.", 403));
        }
        if (!products.parts && (partsAsset || path.startsWith("/api/parts-"))) return protect(jsonError("Parts Finder is not included in your plan.", 403));
        if (["/api/crew-call", "/api/chat", "/api/maintenance", "/api/work-orders", "/maintenance/open", "/api/bots", "/api/roster", "/api/parts-prices", "/api/parts-stores", "/api/parts-stock"].includes(path) || photo || partsAsset) {
          const billing = await companyBillingAccess(co);
          if (!billing.allowed && path === "/api/chat" && method === "GET" && action === "state") {
            const me = await currentPerson(), workspace = await db().prepare("SELECT id,name,owner_id,ai_enabled FROM workspace WHERE id=?").bind("main").first(), registry = await rawDb().prepare("SELECT hub_ready,status FROM company_registry WHERE id=?").bind(co).first();
            return protect(Response.json({ billingRequired: true, products, companyReady: products.hub ? !!registry?.hub_ready : registry?.status === "active", me, workspace, members: [], rooms: [], invitations: [] }));
          }
          if (!billing.allowed) return protect(jsonError("Your company subscription needs attention. The owner can open Billing to restore access.", 402));
        }
        const directoryActions = ["update_status", "update_profile", "remove_member"];
        if (!products.chat && (path === "/api/chat" && !(method === "GET" && action === "state") && !directoryActions.includes(action) || path === "/api/bots" || path === "/api/work-orders" || path === "/api/crew-call" || photo && !photo[1].startsWith("avatar-"))) return protect(jsonError("Chat is not included in your plan.", 403));
        if (partsAsset) {
          await currentPerson();
          const assetUrl = new URL(bounded.url);
          if (assetUrl.pathname === "/parts") assetUrl.pathname = "/parts/";
          const response3 = await env18.ASSETS.fetch(new Request(assetUrl, bounded));
          return protectParts(response3);
        }
        const response2 = photo ? await GET11(bounded, { params: Promise.resolve({ id: decodeURIComponent(photo[1]) }) }) : await handler(bounded);
        return protect(response2);
      });
    } catch (error) {
      if (partsAsset && error instanceof ChatError && error.status === 401) {
        const signIn = new URL("/", request2.url);
        const company = new URL(request2.url).searchParams.get("company");
        if (company && company !== "main") signIn.searchParams.set("company", company);
        return protect(Response.redirect(signIn.toString(), 303));
      }
      if (error instanceof ChatError) return protect(jsonError(error.message, error.status));
      return protect(jsonError("PMS Crew could not complete this request. Please try again.", 500));
    }
  }
};
export {
  index_default as default
};
/*! Bundled license information:

pvtsutils/build/index.js:
  (*!
   * MIT License
   * 
   * Copyright (c) 2017-2024 Peculiar Ventures, LLC
   * 
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   * 
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * 
   *)

reflect-metadata/Reflect.js:
  (*! *****************************************************************************
  Copyright (C) Microsoft. All rights reserved.
  Licensed under the Apache License, Version 2.0 (the "License"); you may not use
  this file except in compliance with the License. You may obtain a copy of the
  License at http://www.apache.org/licenses/LICENSE-2.0
  
  THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
  WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
  MERCHANTABLITY OR NON-INFRINGEMENT.
  
  See the Apache Version 2.0 License for specific language governing permissions
  and limitations under the License.
  ***************************************************************************** *)

tslib/tslib.js:
  (*! *****************************************************************************
  Copyright (c) Microsoft Corporation.
  
  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.
  
  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** *)

pvutils/build/utils.es.js:
  (*!
   Copyright (c) Peculiar Ventures, LLC
  *)

asn1js/build/index.es.js:
  (*!
   * Copyright (c) 2014, GMO GlobalSign
   * Copyright (c) 2015-2022, Peculiar Ventures
   * All rights reserved.
   * 
   * Author 2014-2019, Yury Strozhevsky
   * 
   * Redistribution and use in source and binary forms, with or without modification,
   * are permitted provided that the following conditions are met:
   * 
   * * Redistributions of source code must retain the above copyright notice, this
   *   list of conditions and the following disclaimer.
   * 
   * * Redistributions in binary form must reproduce the above copyright notice, this
   *   list of conditions and the following disclaimer in the documentation and/or
   *   other materials provided with the distribution.
   * 
   * * Neither the name of the copyright holder nor the names of its
   *   contributors may be used to endorse or promote products derived from
   *   this software without specific prior written permission.
   * 
   * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
   * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
   * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
   * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
   * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
   * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
   * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
   * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
   * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
   * 
   *)

@peculiar/x509/build/x509.es.js:
  (*!
   * MIT License
   * 
   * Copyright (c) Peculiar Ventures. All rights reserved.
   * 
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   * 
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * 
   *)
*/
